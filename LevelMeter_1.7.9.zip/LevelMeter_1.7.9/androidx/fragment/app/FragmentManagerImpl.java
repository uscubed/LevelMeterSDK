package androidx.fragment.app;

import android.animation.Animator;
import android.animation.AnimatorInflater;
import android.animation.AnimatorListenerAdapter;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.os.Looper;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.view.animation.ScaleAnimation;
import android.view.animation.Transformation;
import androidx.activity.OnBackPressedCallback;
import androidx.activity.OnBackPressedDispatcher;
import androidx.activity.OnBackPressedDispatcherOwner;
import androidx.collection.ArraySet;
import androidx.core.util.DebugUtils;
import androidx.core.util.LogWriter;
import androidx.core.view.OneShotPreDrawListener;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.ViewModelStore;
import androidx.lifecycle.ViewModelStoreOwner;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

final class FragmentManagerImpl extends FragmentManager implements LayoutInflater.Factory2 {
  static final int ANIM_DUR = 220;
  
  public static final int ANIM_STYLE_CLOSE_ENTER = 3;
  
  public static final int ANIM_STYLE_CLOSE_EXIT = 4;
  
  public static final int ANIM_STYLE_FADE_ENTER = 5;
  
  public static final int ANIM_STYLE_FADE_EXIT = 6;
  
  public static final int ANIM_STYLE_OPEN_ENTER = 1;
  
  public static final int ANIM_STYLE_OPEN_EXIT = 2;
  
  static boolean DEBUG = false;
  
  static final Interpolator DECELERATE_CUBIC;
  
  static final Interpolator DECELERATE_QUINT = (Interpolator)new DecelerateInterpolator(2.5F);
  
  static final String TAG = "FragmentManager";
  
  static final String TARGET_REQUEST_CODE_STATE_TAG = "android:target_req_state";
  
  static final String TARGET_STATE_TAG = "android:target_state";
  
  static final String USER_VISIBLE_HINT_TAG = "android:user_visible_hint";
  
  static final String VIEW_STATE_TAG = "android:view_state";
  
  final HashMap<String, Fragment> mActive = new HashMap<String, Fragment>();
  
  final ArrayList<Fragment> mAdded = new ArrayList<Fragment>();
  
  ArrayList<Integer> mAvailBackStackIndices;
  
  ArrayList<BackStackRecord> mBackStack;
  
  ArrayList<FragmentManager.OnBackStackChangedListener> mBackStackChangeListeners;
  
  ArrayList<BackStackRecord> mBackStackIndices;
  
  FragmentContainer mContainer;
  
  ArrayList<Fragment> mCreatedMenus;
  
  int mCurState = 0;
  
  boolean mDestroyed;
  
  Runnable mExecCommit = new Runnable() {
      final FragmentManagerImpl this$0;
      
      public void run() {
        FragmentManagerImpl.this.execPendingActions();
      }
    };
  
  boolean mExecutingActions;
  
  boolean mHavePendingDeferredStart;
  
  FragmentHostCallback mHost;
  
  private final CopyOnWriteArrayList<FragmentLifecycleCallbacksHolder> mLifecycleCallbacks = new CopyOnWriteArrayList<FragmentLifecycleCallbacksHolder>();
  
  boolean mNeedMenuInvalidate;
  
  int mNextFragmentIndex = 0;
  
  private FragmentManagerViewModel mNonConfig;
  
  private final OnBackPressedCallback mOnBackPressedCallback = new OnBackPressedCallback(false) {
      final FragmentManagerImpl this$0;
      
      public void handleOnBackPressed() {
        FragmentManagerImpl.this.handleOnBackPressed();
      }
    };
  
  private OnBackPressedDispatcher mOnBackPressedDispatcher;
  
  Fragment mParent;
  
  ArrayList<OpGenerator> mPendingActions;
  
  ArrayList<StartEnterTransitionListener> mPostponedTransactions;
  
  Fragment mPrimaryNav;
  
  SparseArray<Parcelable> mStateArray = null;
  
  Bundle mStateBundle = null;
  
  boolean mStateSaved;
  
  boolean mStopped;
  
  ArrayList<Fragment> mTmpAddedFragments;
  
  ArrayList<Boolean> mTmpIsPop;
  
  ArrayList<BackStackRecord> mTmpRecords;
  
  static {
    DECELERATE_CUBIC = (Interpolator)new DecelerateInterpolator(1.5F);
  }
  
  private void addAddedFragments(ArraySet<Fragment> paramArraySet) {
    int i = this.mCurState;
    if (i < 1)
      return; 
    int j = Math.min(i, 3);
    int k = this.mAdded.size();
    for (i = 0; i < k; i++) {
      Fragment fragment = this.mAdded.get(i);
      if (fragment.mState < j) {
        moveToState(fragment, j, fragment.getNextAnim(), fragment.getNextTransition(), false);
        if (fragment.mView != null && !fragment.mHidden && fragment.mIsNewlyAdded)
          paramArraySet.add(fragment); 
      } 
    } 
  }
  
  private void animateRemoveFragment(final Fragment fragment, AnimationOrAnimator paramAnimationOrAnimator, int paramInt) {
    EndViewTransitionAnimation endViewTransitionAnimation;
    final View viewToAnimate = fragment.mView;
    final ViewGroup container = fragment.mContainer;
    viewGroup.startViewTransition(view);
    fragment.setStateAfterAnimating(paramInt);
    if (paramAnimationOrAnimator.animation != null) {
      endViewTransitionAnimation = new EndViewTransitionAnimation(paramAnimationOrAnimator.animation, viewGroup, view);
      fragment.setAnimatingAway(fragment.mView);
      endViewTransitionAnimation.setAnimationListener(new Animation.AnimationListener() {
            final FragmentManagerImpl this$0;
            
            final ViewGroup val$container;
            
            final Fragment val$fragment;
            
            public void onAnimationEnd(Animation param1Animation) {
              container.post(new Runnable() {
                    final FragmentManagerImpl.null this$1;
                    
                    public void run() {
                      if (fragment.getAnimatingAway() != null) {
                        fragment.setAnimatingAway(null);
                        FragmentManagerImpl.this.moveToState(fragment, fragment.getStateAfterAnimating(), 0, 0, false);
                      } 
                    }
                  });
            }
            
            public void onAnimationRepeat(Animation param1Animation) {}
            
            public void onAnimationStart(Animation param1Animation) {}
          });
      fragment.mView.startAnimation((Animation)endViewTransitionAnimation);
    } else {
      Animator animator = ((AnimationOrAnimator)endViewTransitionAnimation).animator;
      fragment.setAnimator(((AnimationOrAnimator)endViewTransitionAnimation).animator);
      animator.addListener((Animator.AnimatorListener)new AnimatorListenerAdapter() {
            final FragmentManagerImpl this$0;
            
            final ViewGroup val$container;
            
            final Fragment val$fragment;
            
            final View val$viewToAnimate;
            
            public void onAnimationEnd(Animator param1Animator) {
              container.endViewTransition(viewToAnimate);
              param1Animator = fragment.getAnimator();
              fragment.setAnimator(null);
              if (param1Animator != null && container.indexOfChild(viewToAnimate) < 0) {
                FragmentManagerImpl fragmentManagerImpl = FragmentManagerImpl.this;
                Fragment fragment = fragment;
                fragmentManagerImpl.moveToState(fragment, fragment.getStateAfterAnimating(), 0, 0, false);
              } 
            }
          });
      animator.setTarget(fragment.mView);
      animator.start();
    } 
  }
  
  private void burpActive() {
    this.mActive.values().removeAll(Collections.singleton(null));
  }
  
  private void checkStateLoss() {
    if (!isStateSaved())
      return; 
    throw new IllegalStateException("Can not perform this action after onSaveInstanceState");
  }
  
  private void cleanupExec() {
    this.mExecutingActions = false;
    this.mTmpIsPop.clear();
    this.mTmpRecords.clear();
  }
  
  private void dispatchParentPrimaryNavigationFragmentChanged(Fragment paramFragment) {
    if (paramFragment != null && this.mActive.get(paramFragment.mWho) == paramFragment)
      paramFragment.performPrimaryNavigationFragmentChanged(); 
  }
  
  private void dispatchStateChange(int paramInt) {
    try {
      this.mExecutingActions = true;
      moveToState(paramInt, false);
      this.mExecutingActions = false;
      return;
    } finally {
      this.mExecutingActions = false;
    } 
  }
  
  private void endAnimatingAwayFragments() {
    for (Fragment fragment : this.mActive.values()) {
      if (fragment != null) {
        if (fragment.getAnimatingAway() != null) {
          int i = fragment.getStateAfterAnimating();
          View view = fragment.getAnimatingAway();
          Animation animation = view.getAnimation();
          if (animation != null) {
            animation.cancel();
            view.clearAnimation();
          } 
          fragment.setAnimatingAway(null);
          moveToState(fragment, i, 0, 0, false);
          continue;
        } 
        if (fragment.getAnimator() != null)
          fragment.getAnimator().end(); 
      } 
    } 
  }
  
  private void ensureExecReady(boolean paramBoolean) {
    if (!this.mExecutingActions) {
      if (this.mHost != null) {
        if (Looper.myLooper() == this.mHost.getHandler().getLooper()) {
          if (!paramBoolean)
            checkStateLoss(); 
          if (this.mTmpRecords == null) {
            this.mTmpRecords = new ArrayList<BackStackRecord>();
            this.mTmpIsPop = new ArrayList<Boolean>();
          } 
          this.mExecutingActions = true;
          try {
            executePostponedTransaction((ArrayList<BackStackRecord>)null, (ArrayList<Boolean>)null);
            return;
          } finally {
            this.mExecutingActions = false;
          } 
        } 
        throw new IllegalStateException("Must be called from main thread of fragment host");
      } 
      throw new IllegalStateException("Fragment host has been destroyed");
    } 
    throw new IllegalStateException("FragmentManager is already executing transactions");
  }
  
  private static void executeOps(ArrayList<BackStackRecord> paramArrayList, ArrayList<Boolean> paramArrayList1, int paramInt1, int paramInt2) {
    while (paramInt1 < paramInt2) {
      BackStackRecord backStackRecord = paramArrayList.get(paramInt1);
      boolean bool = ((Boolean)paramArrayList1.get(paramInt1)).booleanValue();
      boolean bool1 = true;
      if (bool) {
        backStackRecord.bumpBackStackNesting(-1);
        if (paramInt1 != paramInt2 - 1)
          bool1 = false; 
        backStackRecord.executePopOps(bool1);
      } else {
        backStackRecord.bumpBackStackNesting(1);
        backStackRecord.executeOps();
      } 
      paramInt1++;
    } 
  }
  
  private void executeOpsTogether(ArrayList<BackStackRecord> paramArrayList, ArrayList<Boolean> paramArrayList1, int paramInt1, int paramInt2) {
    int k;
    int i = paramInt1;
    boolean bool = ((BackStackRecord)paramArrayList.get(i)).mReorderingAllowed;
    ArrayList<Fragment> arrayList = this.mTmpAddedFragments;
    if (arrayList == null) {
      this.mTmpAddedFragments = new ArrayList<Fragment>();
    } else {
      arrayList.clear();
    } 
    this.mTmpAddedFragments.addAll(this.mAdded);
    Fragment fragment = getPrimaryNavigationFragment();
    boolean bool1 = false;
    int j;
    for (j = i; j < paramInt2; j++) {
      BackStackRecord backStackRecord = paramArrayList.get(j);
      if (!((Boolean)paramArrayList1.get(j)).booleanValue()) {
        fragment = backStackRecord.expandOps(this.mTmpAddedFragments, fragment);
      } else {
        fragment = backStackRecord.trackAddedFragmentsInPop(this.mTmpAddedFragments, fragment);
      } 
      if (bool1 || backStackRecord.mAddToBackStack) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
    } 
    this.mTmpAddedFragments.clear();
    if (!bool)
      FragmentTransition.startTransitions(this, paramArrayList, paramArrayList1, paramInt1, paramInt2, false); 
    executeOps(paramArrayList, paramArrayList1, paramInt1, paramInt2);
    if (bool) {
      ArraySet<Fragment> arraySet = new ArraySet();
      addAddedFragments(arraySet);
      k = postponePostponableTransactions(paramArrayList, paramArrayList1, paramInt1, paramInt2, arraySet);
      makeRemovedFragmentsInvisible(arraySet);
    } else {
      k = paramInt2;
    } 
    j = i;
    if (k != i) {
      j = i;
      if (bool) {
        FragmentTransition.startTransitions(this, paramArrayList, paramArrayList1, paramInt1, k, true);
        moveToState(this.mCurState, true);
        j = i;
      } 
    } 
    while (j < paramInt2) {
      BackStackRecord backStackRecord = paramArrayList.get(j);
      if (((Boolean)paramArrayList1.get(j)).booleanValue() && backStackRecord.mIndex >= 0) {
        freeBackStackIndex(backStackRecord.mIndex);
        backStackRecord.mIndex = -1;
      } 
      backStackRecord.runOnCommitRunnables();
      j++;
    } 
    if (bool1)
      reportBackStackChanged(); 
  }
  
  private void executePostponedTransaction(ArrayList<BackStackRecord> paramArrayList, ArrayList<Boolean> paramArrayList1) {
    // Byte code:
    //   0: aload_0
    //   1: getfield mPostponedTransactions : Ljava/util/ArrayList;
    //   4: astore_3
    //   5: aload_3
    //   6: ifnonnull -> 15
    //   9: iconst_0
    //   10: istore #4
    //   12: goto -> 21
    //   15: aload_3
    //   16: invokevirtual size : ()I
    //   19: istore #4
    //   21: iconst_0
    //   22: istore #5
    //   24: iload #4
    //   26: istore #6
    //   28: iload #5
    //   30: istore #4
    //   32: iload #4
    //   34: iload #6
    //   36: if_icmpge -> 240
    //   39: aload_0
    //   40: getfield mPostponedTransactions : Ljava/util/ArrayList;
    //   43: iload #4
    //   45: invokevirtual get : (I)Ljava/lang/Object;
    //   48: checkcast androidx/fragment/app/FragmentManagerImpl$StartEnterTransitionListener
    //   51: astore_3
    //   52: aload_1
    //   53: ifnull -> 109
    //   56: aload_3
    //   57: getfield mIsBack : Z
    //   60: ifne -> 109
    //   63: aload_1
    //   64: aload_3
    //   65: getfield mRecord : Landroidx/fragment/app/BackStackRecord;
    //   68: invokevirtual indexOf : (Ljava/lang/Object;)I
    //   71: istore #5
    //   73: iload #5
    //   75: iconst_m1
    //   76: if_icmpeq -> 109
    //   79: aload_2
    //   80: iload #5
    //   82: invokevirtual get : (I)Ljava/lang/Object;
    //   85: checkcast java/lang/Boolean
    //   88: invokevirtual booleanValue : ()Z
    //   91: ifeq -> 109
    //   94: aload_3
    //   95: invokevirtual cancelTransaction : ()V
    //   98: iload #4
    //   100: istore #7
    //   102: iload #6
    //   104: istore #5
    //   106: goto -> 227
    //   109: aload_3
    //   110: invokevirtual isReady : ()Z
    //   113: ifne -> 152
    //   116: iload #4
    //   118: istore #7
    //   120: iload #6
    //   122: istore #5
    //   124: aload_1
    //   125: ifnull -> 227
    //   128: iload #4
    //   130: istore #7
    //   132: iload #6
    //   134: istore #5
    //   136: aload_3
    //   137: getfield mRecord : Landroidx/fragment/app/BackStackRecord;
    //   140: aload_1
    //   141: iconst_0
    //   142: aload_1
    //   143: invokevirtual size : ()I
    //   146: invokevirtual interactsWith : (Ljava/util/ArrayList;II)Z
    //   149: ifeq -> 227
    //   152: aload_0
    //   153: getfield mPostponedTransactions : Ljava/util/ArrayList;
    //   156: iload #4
    //   158: invokevirtual remove : (I)Ljava/lang/Object;
    //   161: pop
    //   162: iload #4
    //   164: iconst_1
    //   165: isub
    //   166: istore #7
    //   168: iload #6
    //   170: iconst_1
    //   171: isub
    //   172: istore #5
    //   174: aload_1
    //   175: ifnull -> 223
    //   178: aload_3
    //   179: getfield mIsBack : Z
    //   182: ifne -> 223
    //   185: aload_1
    //   186: aload_3
    //   187: getfield mRecord : Landroidx/fragment/app/BackStackRecord;
    //   190: invokevirtual indexOf : (Ljava/lang/Object;)I
    //   193: istore #4
    //   195: iload #4
    //   197: iconst_m1
    //   198: if_icmpeq -> 223
    //   201: aload_2
    //   202: iload #4
    //   204: invokevirtual get : (I)Ljava/lang/Object;
    //   207: checkcast java/lang/Boolean
    //   210: invokevirtual booleanValue : ()Z
    //   213: ifeq -> 223
    //   216: aload_3
    //   217: invokevirtual cancelTransaction : ()V
    //   220: goto -> 227
    //   223: aload_3
    //   224: invokevirtual completeTransaction : ()V
    //   227: iload #7
    //   229: iconst_1
    //   230: iadd
    //   231: istore #4
    //   233: iload #5
    //   235: istore #6
    //   237: goto -> 32
    //   240: return
  }
  
  private Fragment findFragmentUnder(Fragment paramFragment) {
    ViewGroup viewGroup = paramFragment.mContainer;
    View view = paramFragment.mView;
    if (viewGroup != null && view != null)
      for (int i = this.mAdded.indexOf(paramFragment) - 1; i >= 0; i--) {
        paramFragment = this.mAdded.get(i);
        if (paramFragment.mContainer == viewGroup && paramFragment.mView != null)
          return paramFragment; 
      }  
    return null;
  }
  
  private void forcePostponedTransactions() {
    if (this.mPostponedTransactions != null)
      while (!this.mPostponedTransactions.isEmpty())
        ((StartEnterTransitionListener)this.mPostponedTransactions.remove(0)).completeTransaction();  
  }
  
  private boolean generateOpsForPendingActions(ArrayList<BackStackRecord> paramArrayList, ArrayList<Boolean> paramArrayList1) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mPendingActions : Ljava/util/ArrayList;
    //   6: astore_3
    //   7: iconst_0
    //   8: istore #4
    //   10: aload_3
    //   11: ifnull -> 102
    //   14: aload_0
    //   15: getfield mPendingActions : Ljava/util/ArrayList;
    //   18: invokevirtual size : ()I
    //   21: ifne -> 27
    //   24: goto -> 102
    //   27: aload_0
    //   28: getfield mPendingActions : Ljava/util/ArrayList;
    //   31: invokevirtual size : ()I
    //   34: istore #5
    //   36: iconst_0
    //   37: istore #6
    //   39: iload #4
    //   41: iload #5
    //   43: if_icmpge -> 76
    //   46: iload #6
    //   48: aload_0
    //   49: getfield mPendingActions : Ljava/util/ArrayList;
    //   52: iload #4
    //   54: invokevirtual get : (I)Ljava/lang/Object;
    //   57: checkcast androidx/fragment/app/FragmentManagerImpl$OpGenerator
    //   60: aload_1
    //   61: aload_2
    //   62: invokeinterface generateOps : (Ljava/util/ArrayList;Ljava/util/ArrayList;)Z
    //   67: ior
    //   68: istore #6
    //   70: iinc #4, 1
    //   73: goto -> 39
    //   76: aload_0
    //   77: getfield mPendingActions : Ljava/util/ArrayList;
    //   80: invokevirtual clear : ()V
    //   83: aload_0
    //   84: getfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   87: invokevirtual getHandler : ()Landroid/os/Handler;
    //   90: aload_0
    //   91: getfield mExecCommit : Ljava/lang/Runnable;
    //   94: invokevirtual removeCallbacks : (Ljava/lang/Runnable;)V
    //   97: aload_0
    //   98: monitorexit
    //   99: iload #6
    //   101: ireturn
    //   102: aload_0
    //   103: monitorexit
    //   104: iconst_0
    //   105: ireturn
    //   106: astore_1
    //   107: aload_0
    //   108: monitorexit
    //   109: aload_1
    //   110: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	106	finally
    //   14	24	106	finally
    //   27	36	106	finally
    //   46	70	106	finally
    //   76	99	106	finally
    //   102	104	106	finally
    //   107	109	106	finally
  }
  
  private boolean isMenuAvailable(Fragment paramFragment) {
    boolean bool;
    if ((paramFragment.mHasMenu && paramFragment.mMenuVisible) || paramFragment.mChildFragmentManager.checkForMenus()) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  static AnimationOrAnimator makeFadeAnimation(float paramFloat1, float paramFloat2) {
    AlphaAnimation alphaAnimation = new AlphaAnimation(paramFloat1, paramFloat2);
    alphaAnimation.setInterpolator(DECELERATE_CUBIC);
    alphaAnimation.setDuration(220L);
    return new AnimationOrAnimator((Animation)alphaAnimation);
  }
  
  static AnimationOrAnimator makeOpenCloseAnimation(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    AnimationSet animationSet = new AnimationSet(false);
    ScaleAnimation scaleAnimation = new ScaleAnimation(paramFloat1, paramFloat2, paramFloat1, paramFloat2, 1, 0.5F, 1, 0.5F);
    scaleAnimation.setInterpolator(DECELERATE_QUINT);
    scaleAnimation.setDuration(220L);
    animationSet.addAnimation((Animation)scaleAnimation);
    AlphaAnimation alphaAnimation = new AlphaAnimation(paramFloat3, paramFloat4);
    alphaAnimation.setInterpolator(DECELERATE_CUBIC);
    alphaAnimation.setDuration(220L);
    animationSet.addAnimation((Animation)alphaAnimation);
    return new AnimationOrAnimator((Animation)animationSet);
  }
  
  private void makeRemovedFragmentsInvisible(ArraySet<Fragment> paramArraySet) {
    int i = paramArraySet.size();
    for (byte b = 0; b < i; b++) {
      Fragment fragment = (Fragment)paramArraySet.valueAt(b);
      if (!fragment.mAdded) {
        View view = fragment.requireView();
        fragment.mPostponedAlpha = view.getAlpha();
        view.setAlpha(0.0F);
      } 
    } 
  }
  
  private boolean popBackStackImmediate(String paramString, int paramInt1, int paramInt2) {
    execPendingActions();
    ensureExecReady(true);
    Fragment fragment = this.mPrimaryNav;
    if (fragment != null && paramInt1 < 0 && paramString == null && fragment.getChildFragmentManager().popBackStackImmediate())
      return true; 
    boolean bool = popBackStackState(this.mTmpRecords, this.mTmpIsPop, paramString, paramInt1, paramInt2);
    if (bool) {
      this.mExecutingActions = true;
      try {
        removeRedundantOperationsAndExecute(this.mTmpRecords, this.mTmpIsPop);
      } finally {
        cleanupExec();
      } 
    } 
    updateOnBackPressedCallbackEnabled();
    doPendingDeferredStart();
    burpActive();
    return bool;
  }
  
  private int postponePostponableTransactions(ArrayList<BackStackRecord> paramArrayList, ArrayList<Boolean> paramArrayList1, int paramInt1, int paramInt2, ArraySet<Fragment> paramArraySet) {
    int i = paramInt2 - 1;
    int j;
    for (j = paramInt2; i >= paramInt1; j = k) {
      boolean bool1;
      BackStackRecord backStackRecord = paramArrayList.get(i);
      boolean bool = ((Boolean)paramArrayList1.get(i)).booleanValue();
      if (backStackRecord.isPostponed() && !backStackRecord.interactsWith(paramArrayList, i + 1, paramInt2)) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      int k = j;
      if (bool1) {
        if (this.mPostponedTransactions == null)
          this.mPostponedTransactions = new ArrayList<StartEnterTransitionListener>(); 
        StartEnterTransitionListener startEnterTransitionListener = new StartEnterTransitionListener(backStackRecord, bool);
        this.mPostponedTransactions.add(startEnterTransitionListener);
        backStackRecord.setOnStartPostponedListener(startEnterTransitionListener);
        if (bool) {
          backStackRecord.executeOps();
        } else {
          backStackRecord.executePopOps(false);
        } 
        k = j - 1;
        if (i != k) {
          paramArrayList.remove(i);
          paramArrayList.add(k, backStackRecord);
        } 
        addAddedFragments(paramArraySet);
      } 
      i--;
    } 
    return j;
  }
  
  private void removeRedundantOperationsAndExecute(ArrayList<BackStackRecord> paramArrayList, ArrayList<Boolean> paramArrayList1) {
    if (paramArrayList == null || paramArrayList.isEmpty())
      return; 
    if (paramArrayList1 != null && paramArrayList.size() == paramArrayList1.size()) {
      executePostponedTransaction(paramArrayList, paramArrayList1);
      int i = paramArrayList.size();
      int j = 0;
      int k;
      for (k = 0; j < i; k = n) {
        int m = j;
        int n = k;
        if (!((BackStackRecord)paramArrayList.get(j)).mReorderingAllowed) {
          if (k != j)
            executeOpsTogether(paramArrayList, paramArrayList1, k, j); 
          k = j + 1;
          n = k;
          if (((Boolean)paramArrayList1.get(j)).booleanValue())
            while (true) {
              n = k;
              if (k < i) {
                n = k;
                if (((Boolean)paramArrayList1.get(k)).booleanValue()) {
                  n = k;
                  if (!((BackStackRecord)paramArrayList.get(k)).mReorderingAllowed) {
                    k++;
                    continue;
                  } 
                } 
              } 
              break;
            }  
          executeOpsTogether(paramArrayList, paramArrayList1, j, n);
          m = n - 1;
        } 
        j = m + 1;
      } 
      if (k != i)
        executeOpsTogether(paramArrayList, paramArrayList1, k, i); 
      return;
    } 
    throw new IllegalStateException("Internal error with the back stack records");
  }
  
  public static int reverseTransit(int paramInt) {
    char c = ' ';
    if (paramInt != 4097)
      if (paramInt != 4099) {
        if (paramInt != 8194) {
          c = Character.MIN_VALUE;
        } else {
          c = 'ခ';
        } 
      } else {
        c = 'ဃ';
      }  
    return c;
  }
  
  private void throwException(RuntimeException paramRuntimeException) {
    Log.e("FragmentManager", paramRuntimeException.getMessage());
    Log.e("FragmentManager", "Activity state:");
    PrintWriter printWriter = new PrintWriter((Writer)new LogWriter("FragmentManager"));
    FragmentHostCallback fragmentHostCallback = this.mHost;
    if (fragmentHostCallback != null) {
      try {
        fragmentHostCallback.onDump("  ", (FileDescriptor)null, printWriter, new String[0]);
      } catch (Exception exception) {
        Log.e("FragmentManager", "Failed dumping state", exception);
      } 
    } else {
      try {
        dump("  ", (FileDescriptor)null, (PrintWriter)exception, new String[0]);
      } catch (Exception exception1) {
        Log.e("FragmentManager", "Failed dumping state", exception1);
      } 
    } 
    throw paramRuntimeException;
  }
  
  public static int transitToStyleIndex(int paramInt, boolean paramBoolean) {
    if (paramInt != 4097) {
      if (paramInt != 4099) {
        if (paramInt != 8194) {
          paramInt = -1;
        } else if (paramBoolean) {
          paramInt = 3;
        } else {
          paramInt = 4;
        } 
      } else if (paramBoolean) {
        paramInt = 5;
      } else {
        paramInt = 6;
      } 
    } else if (paramBoolean) {
      paramInt = 1;
    } else {
      paramInt = 2;
    } 
    return paramInt;
  }
  
  private void updateOnBackPressedCallbackEnabled() {
    ArrayList<OpGenerator> arrayList = this.mPendingActions;
    boolean bool = true;
    if (arrayList != null && !arrayList.isEmpty()) {
      this.mOnBackPressedCallback.setEnabled(true);
      return;
    } 
    OnBackPressedCallback onBackPressedCallback = this.mOnBackPressedCallback;
    if (getBackStackEntryCount() <= 0 || !isPrimaryNavigation(this.mParent))
      bool = false; 
    onBackPressedCallback.setEnabled(bool);
  }
  
  void addBackStackState(BackStackRecord paramBackStackRecord) {
    if (this.mBackStack == null)
      this.mBackStack = new ArrayList<BackStackRecord>(); 
    this.mBackStack.add(paramBackStackRecord);
  }
  
  public void addFragment(Fragment paramFragment, boolean paramBoolean) {
    if (DEBUG) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("add: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    makeActive(paramFragment);
    if (!paramFragment.mDetached)
      if (!this.mAdded.contains(paramFragment)) {
        synchronized (this.mAdded) {
          this.mAdded.add(paramFragment);
          paramFragment.mAdded = true;
          paramFragment.mRemoving = false;
          if (paramFragment.mView == null)
            paramFragment.mHiddenChanged = false; 
          if (isMenuAvailable(paramFragment))
            this.mNeedMenuInvalidate = true; 
          if (paramBoolean)
            moveToState(paramFragment); 
        } 
      } else {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Fragment already added: ");
        stringBuilder.append(paramFragment);
        throw new IllegalStateException(stringBuilder.toString());
      }  
  }
  
  public void addOnBackStackChangedListener(FragmentManager.OnBackStackChangedListener paramOnBackStackChangedListener) {
    if (this.mBackStackChangeListeners == null)
      this.mBackStackChangeListeners = new ArrayList<FragmentManager.OnBackStackChangedListener>(); 
    this.mBackStackChangeListeners.add(paramOnBackStackChangedListener);
  }
  
  void addRetainedFragment(Fragment paramFragment) {
    if (isStateSaved()) {
      if (DEBUG)
        Log.v("FragmentManager", "Ignoring addRetainedFragment as the state is already saved"); 
      return;
    } 
    if (this.mNonConfig.addRetainedFragment(paramFragment) && DEBUG) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Updating retained Fragments: Added ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
  }
  
  public int allocBackStackIndex(BackStackRecord paramBackStackRecord) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   6: ifnull -> 111
    //   9: aload_0
    //   10: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   13: invokevirtual size : ()I
    //   16: ifgt -> 22
    //   19: goto -> 111
    //   22: aload_0
    //   23: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   26: aload_0
    //   27: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   30: invokevirtual size : ()I
    //   33: iconst_1
    //   34: isub
    //   35: invokevirtual remove : (I)Ljava/lang/Object;
    //   38: checkcast java/lang/Integer
    //   41: invokevirtual intValue : ()I
    //   44: istore_2
    //   45: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   48: ifeq -> 97
    //   51: new java/lang/StringBuilder
    //   54: astore_3
    //   55: aload_3
    //   56: invokespecial <init> : ()V
    //   59: aload_3
    //   60: ldc_w 'Adding back stack index '
    //   63: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   66: pop
    //   67: aload_3
    //   68: iload_2
    //   69: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   72: pop
    //   73: aload_3
    //   74: ldc_w ' with '
    //   77: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   80: pop
    //   81: aload_3
    //   82: aload_1
    //   83: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   86: pop
    //   87: ldc 'FragmentManager'
    //   89: aload_3
    //   90: invokevirtual toString : ()Ljava/lang/String;
    //   93: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   96: pop
    //   97: aload_0
    //   98: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   101: iload_2
    //   102: aload_1
    //   103: invokevirtual set : (ILjava/lang/Object;)Ljava/lang/Object;
    //   106: pop
    //   107: aload_0
    //   108: monitorexit
    //   109: iload_2
    //   110: ireturn
    //   111: aload_0
    //   112: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   115: ifnonnull -> 131
    //   118: new java/util/ArrayList
    //   121: astore_3
    //   122: aload_3
    //   123: invokespecial <init> : ()V
    //   126: aload_0
    //   127: aload_3
    //   128: putfield mBackStackIndices : Ljava/util/ArrayList;
    //   131: aload_0
    //   132: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   135: invokevirtual size : ()I
    //   138: istore_2
    //   139: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   142: ifeq -> 191
    //   145: new java/lang/StringBuilder
    //   148: astore_3
    //   149: aload_3
    //   150: invokespecial <init> : ()V
    //   153: aload_3
    //   154: ldc_w 'Setting back stack index '
    //   157: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   160: pop
    //   161: aload_3
    //   162: iload_2
    //   163: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   166: pop
    //   167: aload_3
    //   168: ldc_w ' to '
    //   171: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   174: pop
    //   175: aload_3
    //   176: aload_1
    //   177: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   180: pop
    //   181: ldc 'FragmentManager'
    //   183: aload_3
    //   184: invokevirtual toString : ()Ljava/lang/String;
    //   187: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   190: pop
    //   191: aload_0
    //   192: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   195: aload_1
    //   196: invokevirtual add : (Ljava/lang/Object;)Z
    //   199: pop
    //   200: aload_0
    //   201: monitorexit
    //   202: iload_2
    //   203: ireturn
    //   204: astore_1
    //   205: aload_0
    //   206: monitorexit
    //   207: aload_1
    //   208: athrow
    // Exception table:
    //   from	to	target	type
    //   2	19	204	finally
    //   22	97	204	finally
    //   97	109	204	finally
    //   111	131	204	finally
    //   131	191	204	finally
    //   191	202	204	finally
    //   205	207	204	finally
  }
  
  public void attachController(FragmentHostCallback paramFragmentHostCallback, FragmentContainer paramFragmentContainer, Fragment paramFragment) {
    if (this.mHost == null) {
      this.mHost = paramFragmentHostCallback;
      this.mContainer = paramFragmentContainer;
      this.mParent = paramFragment;
      if (this.mParent != null)
        updateOnBackPressedCallbackEnabled(); 
      if (paramFragmentHostCallback instanceof OnBackPressedDispatcherOwner) {
        Fragment fragment;
        OnBackPressedDispatcherOwner onBackPressedDispatcherOwner = (OnBackPressedDispatcherOwner)paramFragmentHostCallback;
        this.mOnBackPressedDispatcher = onBackPressedDispatcherOwner.getOnBackPressedDispatcher();
        if (paramFragment != null)
          fragment = paramFragment; 
        this.mOnBackPressedDispatcher.addCallback(fragment, this.mOnBackPressedCallback);
      } 
      if (paramFragment != null) {
        this.mNonConfig = paramFragment.mFragmentManager.getChildNonConfig(paramFragment);
      } else if (paramFragmentHostCallback instanceof ViewModelStoreOwner) {
        this.mNonConfig = FragmentManagerViewModel.getInstance(((ViewModelStoreOwner)paramFragmentHostCallback).getViewModelStore());
      } else {
        this.mNonConfig = new FragmentManagerViewModel(false);
      } 
      return;
    } 
    throw new IllegalStateException("Already attached");
  }
  
  public void attachFragment(Fragment paramFragment) {
    if (DEBUG) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("attach: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (paramFragment.mDetached) {
      paramFragment.mDetached = false;
      if (!paramFragment.mAdded)
        if (!this.mAdded.contains(paramFragment)) {
          if (DEBUG) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("add from attach: ");
            stringBuilder.append(paramFragment);
            Log.v("FragmentManager", stringBuilder.toString());
          } 
          synchronized (this.mAdded) {
            this.mAdded.add(paramFragment);
            paramFragment.mAdded = true;
            if (isMenuAvailable(paramFragment))
              this.mNeedMenuInvalidate = true; 
          } 
        } else {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Fragment already added: ");
          stringBuilder.append(paramFragment);
          throw new IllegalStateException(stringBuilder.toString());
        }  
    } 
  }
  
  public FragmentTransaction beginTransaction() {
    return new BackStackRecord(this);
  }
  
  boolean checkForMenus() {
    Iterator<Fragment> iterator = this.mActive.values().iterator();
    boolean bool = false;
    while (iterator.hasNext()) {
      Fragment fragment = iterator.next();
      boolean bool1 = bool;
      if (fragment != null)
        bool1 = isMenuAvailable(fragment); 
      bool = bool1;
      if (bool1)
        return true; 
    } 
    return false;
  }
  
  void completeExecute(BackStackRecord paramBackStackRecord, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) {
    if (paramBoolean1) {
      paramBackStackRecord.executePopOps(paramBoolean3);
    } else {
      paramBackStackRecord.executeOps();
    } 
    ArrayList<BackStackRecord> arrayList = new ArrayList(1);
    ArrayList<Boolean> arrayList1 = new ArrayList(1);
    arrayList.add(paramBackStackRecord);
    arrayList1.add(Boolean.valueOf(paramBoolean1));
    if (paramBoolean2)
      FragmentTransition.startTransitions(this, arrayList, arrayList1, 0, 1, true); 
    if (paramBoolean3)
      moveToState(this.mCurState, true); 
    for (Fragment fragment : this.mActive.values()) {
      if (fragment != null && fragment.mView != null && fragment.mIsNewlyAdded && paramBackStackRecord.interactsWith(fragment.mContainerId)) {
        if (fragment.mPostponedAlpha > 0.0F)
          fragment.mView.setAlpha(fragment.mPostponedAlpha); 
        if (paramBoolean3) {
          fragment.mPostponedAlpha = 0.0F;
          continue;
        } 
        fragment.mPostponedAlpha = -1.0F;
        fragment.mIsNewlyAdded = false;
      } 
    } 
  }
  
  void completeShowHideFragment(final Fragment fragment) {
    if (fragment.mView != null) {
      AnimationOrAnimator animationOrAnimator = loadAnimation(fragment, fragment.getNextTransition(), fragment.mHidden ^ true, fragment.getNextTransitionStyle());
      if (animationOrAnimator != null && animationOrAnimator.animator != null) {
        animationOrAnimator.animator.setTarget(fragment.mView);
        if (fragment.mHidden) {
          if (fragment.isHideReplaced()) {
            fragment.setHideReplaced(false);
          } else {
            final ViewGroup container = fragment.mContainer;
            final View animatingView = fragment.mView;
            viewGroup.startViewTransition(view);
            animationOrAnimator.animator.addListener((Animator.AnimatorListener)new AnimatorListenerAdapter() {
                  final FragmentManagerImpl this$0;
                  
                  final View val$animatingView;
                  
                  final ViewGroup val$container;
                  
                  final Fragment val$fragment;
                  
                  public void onAnimationEnd(Animator param1Animator) {
                    container.endViewTransition(animatingView);
                    param1Animator.removeListener((Animator.AnimatorListener)this);
                    if (fragment.mView != null && fragment.mHidden)
                      fragment.mView.setVisibility(8); 
                  }
                });
          } 
        } else {
          fragment.mView.setVisibility(0);
        } 
        animationOrAnimator.animator.start();
      } else {
        boolean bool;
        if (animationOrAnimator != null) {
          fragment.mView.startAnimation(animationOrAnimator.animation);
          animationOrAnimator.animation.start();
        } 
        if (fragment.mHidden && !fragment.isHideReplaced()) {
          bool = true;
        } else {
          bool = false;
        } 
        fragment.mView.setVisibility(bool);
        if (fragment.isHideReplaced())
          fragment.setHideReplaced(false); 
      } 
    } 
    if (fragment.mAdded && isMenuAvailable(fragment))
      this.mNeedMenuInvalidate = true; 
    fragment.mHiddenChanged = false;
    fragment.onHiddenChanged(fragment.mHidden);
  }
  
  public void detachFragment(Fragment paramFragment) {
    if (DEBUG) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("detach: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (!paramFragment.mDetached) {
      paramFragment.mDetached = true;
      if (paramFragment.mAdded) {
        if (DEBUG) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("remove from detach: ");
          stringBuilder.append(paramFragment);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        synchronized (this.mAdded) {
          this.mAdded.remove(paramFragment);
          if (isMenuAvailable(paramFragment))
            this.mNeedMenuInvalidate = true; 
          paramFragment.mAdded = false;
        } 
      } 
    } 
  }
  
  public void dispatchActivityCreated() {
    this.mStateSaved = false;
    this.mStopped = false;
    dispatchStateChange(2);
  }
  
  public void dispatchConfigurationChanged(Configuration paramConfiguration) {
    for (byte b = 0; b < this.mAdded.size(); b++) {
      Fragment fragment = this.mAdded.get(b);
      if (fragment != null)
        fragment.performConfigurationChanged(paramConfiguration); 
    } 
  }
  
  public boolean dispatchContextItemSelected(MenuItem paramMenuItem) {
    if (this.mCurState < 1)
      return false; 
    for (byte b = 0; b < this.mAdded.size(); b++) {
      Fragment fragment = this.mAdded.get(b);
      if (fragment != null && fragment.performContextItemSelected(paramMenuItem))
        return true; 
    } 
    return false;
  }
  
  public void dispatchCreate() {
    this.mStateSaved = false;
    this.mStopped = false;
    dispatchStateChange(1);
  }
  
  public boolean dispatchCreateOptionsMenu(Menu paramMenu, MenuInflater paramMenuInflater) {
    int i = this.mCurState;
    boolean bool1 = false;
    if (i < 1)
      return false; 
    ArrayList<Fragment> arrayList = null;
    i = 0;
    boolean bool2;
    for (bool2 = false; i < this.mAdded.size(); bool2 = bool) {
      Fragment fragment = this.mAdded.get(i);
      ArrayList<Fragment> arrayList1 = arrayList;
      boolean bool = bool2;
      if (fragment != null) {
        arrayList1 = arrayList;
        bool = bool2;
        if (fragment.performCreateOptionsMenu(paramMenu, paramMenuInflater)) {
          arrayList1 = arrayList;
          if (arrayList == null)
            arrayList1 = new ArrayList(); 
          arrayList1.add(fragment);
          bool = true;
        } 
      } 
      i++;
      arrayList = arrayList1;
    } 
    if (this.mCreatedMenus != null)
      for (i = bool1; i < this.mCreatedMenus.size(); i++) {
        Fragment fragment = this.mCreatedMenus.get(i);
        if (arrayList == null || !arrayList.contains(fragment))
          fragment.onDestroyOptionsMenu(); 
      }  
    this.mCreatedMenus = arrayList;
    return bool2;
  }
  
  public void dispatchDestroy() {
    this.mDestroyed = true;
    execPendingActions();
    dispatchStateChange(0);
    this.mHost = null;
    this.mContainer = null;
    this.mParent = null;
    if (this.mOnBackPressedDispatcher != null) {
      this.mOnBackPressedCallback.remove();
      this.mOnBackPressedDispatcher = null;
    } 
  }
  
  public void dispatchDestroyView() {
    dispatchStateChange(1);
  }
  
  public void dispatchLowMemory() {
    for (byte b = 0; b < this.mAdded.size(); b++) {
      Fragment fragment = this.mAdded.get(b);
      if (fragment != null)
        fragment.performLowMemory(); 
    } 
  }
  
  public void dispatchMultiWindowModeChanged(boolean paramBoolean) {
    for (int i = this.mAdded.size() - 1; i >= 0; i--) {
      Fragment fragment = this.mAdded.get(i);
      if (fragment != null)
        fragment.performMultiWindowModeChanged(paramBoolean); 
    } 
  }
  
  void dispatchOnFragmentActivityCreated(Fragment paramFragment, Bundle paramBundle, boolean paramBoolean) {
    Fragment fragment = this.mParent;
    if (fragment != null) {
      FragmentManager fragmentManager = fragment.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentActivityCreated(paramFragment, paramBundle, true); 
    } 
    for (FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder : this.mLifecycleCallbacks) {
      if (!paramBoolean || fragmentLifecycleCallbacksHolder.mRecursive)
        fragmentLifecycleCallbacksHolder.mCallback.onFragmentActivityCreated(this, paramFragment, paramBundle); 
    } 
  }
  
  void dispatchOnFragmentAttached(Fragment paramFragment, Context paramContext, boolean paramBoolean) {
    Fragment fragment = this.mParent;
    if (fragment != null) {
      FragmentManager fragmentManager = fragment.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentAttached(paramFragment, paramContext, true); 
    } 
    for (FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder : this.mLifecycleCallbacks) {
      if (!paramBoolean || fragmentLifecycleCallbacksHolder.mRecursive)
        fragmentLifecycleCallbacksHolder.mCallback.onFragmentAttached(this, paramFragment, paramContext); 
    } 
  }
  
  void dispatchOnFragmentCreated(Fragment paramFragment, Bundle paramBundle, boolean paramBoolean) {
    Fragment fragment = this.mParent;
    if (fragment != null) {
      FragmentManager fragmentManager = fragment.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentCreated(paramFragment, paramBundle, true); 
    } 
    for (FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder : this.mLifecycleCallbacks) {
      if (!paramBoolean || fragmentLifecycleCallbacksHolder.mRecursive)
        fragmentLifecycleCallbacksHolder.mCallback.onFragmentCreated(this, paramFragment, paramBundle); 
    } 
  }
  
  void dispatchOnFragmentDestroyed(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.mParent;
    if (fragment != null) {
      FragmentManager fragmentManager = fragment.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentDestroyed(paramFragment, true); 
    } 
    for (FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder : this.mLifecycleCallbacks) {
      if (!paramBoolean || fragmentLifecycleCallbacksHolder.mRecursive)
        fragmentLifecycleCallbacksHolder.mCallback.onFragmentDestroyed(this, paramFragment); 
    } 
  }
  
  void dispatchOnFragmentDetached(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.mParent;
    if (fragment != null) {
      FragmentManager fragmentManager = fragment.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentDetached(paramFragment, true); 
    } 
    for (FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder : this.mLifecycleCallbacks) {
      if (!paramBoolean || fragmentLifecycleCallbacksHolder.mRecursive)
        fragmentLifecycleCallbacksHolder.mCallback.onFragmentDetached(this, paramFragment); 
    } 
  }
  
  void dispatchOnFragmentPaused(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.mParent;
    if (fragment != null) {
      FragmentManager fragmentManager = fragment.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentPaused(paramFragment, true); 
    } 
    for (FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder : this.mLifecycleCallbacks) {
      if (!paramBoolean || fragmentLifecycleCallbacksHolder.mRecursive)
        fragmentLifecycleCallbacksHolder.mCallback.onFragmentPaused(this, paramFragment); 
    } 
  }
  
  void dispatchOnFragmentPreAttached(Fragment paramFragment, Context paramContext, boolean paramBoolean) {
    Fragment fragment = this.mParent;
    if (fragment != null) {
      FragmentManager fragmentManager = fragment.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentPreAttached(paramFragment, paramContext, true); 
    } 
    for (FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder : this.mLifecycleCallbacks) {
      if (!paramBoolean || fragmentLifecycleCallbacksHolder.mRecursive)
        fragmentLifecycleCallbacksHolder.mCallback.onFragmentPreAttached(this, paramFragment, paramContext); 
    } 
  }
  
  void dispatchOnFragmentPreCreated(Fragment paramFragment, Bundle paramBundle, boolean paramBoolean) {
    Fragment fragment = this.mParent;
    if (fragment != null) {
      FragmentManager fragmentManager = fragment.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentPreCreated(paramFragment, paramBundle, true); 
    } 
    for (FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder : this.mLifecycleCallbacks) {
      if (!paramBoolean || fragmentLifecycleCallbacksHolder.mRecursive)
        fragmentLifecycleCallbacksHolder.mCallback.onFragmentPreCreated(this, paramFragment, paramBundle); 
    } 
  }
  
  void dispatchOnFragmentResumed(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.mParent;
    if (fragment != null) {
      FragmentManager fragmentManager = fragment.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentResumed(paramFragment, true); 
    } 
    for (FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder : this.mLifecycleCallbacks) {
      if (!paramBoolean || fragmentLifecycleCallbacksHolder.mRecursive)
        fragmentLifecycleCallbacksHolder.mCallback.onFragmentResumed(this, paramFragment); 
    } 
  }
  
  void dispatchOnFragmentSaveInstanceState(Fragment paramFragment, Bundle paramBundle, boolean paramBoolean) {
    Fragment fragment = this.mParent;
    if (fragment != null) {
      FragmentManager fragmentManager = fragment.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentSaveInstanceState(paramFragment, paramBundle, true); 
    } 
    for (FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder : this.mLifecycleCallbacks) {
      if (!paramBoolean || fragmentLifecycleCallbacksHolder.mRecursive)
        fragmentLifecycleCallbacksHolder.mCallback.onFragmentSaveInstanceState(this, paramFragment, paramBundle); 
    } 
  }
  
  void dispatchOnFragmentStarted(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.mParent;
    if (fragment != null) {
      FragmentManager fragmentManager = fragment.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentStarted(paramFragment, true); 
    } 
    for (FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder : this.mLifecycleCallbacks) {
      if (!paramBoolean || fragmentLifecycleCallbacksHolder.mRecursive)
        fragmentLifecycleCallbacksHolder.mCallback.onFragmentStarted(this, paramFragment); 
    } 
  }
  
  void dispatchOnFragmentStopped(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.mParent;
    if (fragment != null) {
      FragmentManager fragmentManager = fragment.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentStopped(paramFragment, true); 
    } 
    for (FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder : this.mLifecycleCallbacks) {
      if (!paramBoolean || fragmentLifecycleCallbacksHolder.mRecursive)
        fragmentLifecycleCallbacksHolder.mCallback.onFragmentStopped(this, paramFragment); 
    } 
  }
  
  void dispatchOnFragmentViewCreated(Fragment paramFragment, View paramView, Bundle paramBundle, boolean paramBoolean) {
    Fragment fragment = this.mParent;
    if (fragment != null) {
      FragmentManager fragmentManager = fragment.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentViewCreated(paramFragment, paramView, paramBundle, true); 
    } 
    for (FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder : this.mLifecycleCallbacks) {
      if (!paramBoolean || fragmentLifecycleCallbacksHolder.mRecursive)
        fragmentLifecycleCallbacksHolder.mCallback.onFragmentViewCreated(this, paramFragment, paramView, paramBundle); 
    } 
  }
  
  void dispatchOnFragmentViewDestroyed(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.mParent;
    if (fragment != null) {
      FragmentManager fragmentManager = fragment.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentViewDestroyed(paramFragment, true); 
    } 
    for (FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder : this.mLifecycleCallbacks) {
      if (!paramBoolean || fragmentLifecycleCallbacksHolder.mRecursive)
        fragmentLifecycleCallbacksHolder.mCallback.onFragmentViewDestroyed(this, paramFragment); 
    } 
  }
  
  public boolean dispatchOptionsItemSelected(MenuItem paramMenuItem) {
    if (this.mCurState < 1)
      return false; 
    for (byte b = 0; b < this.mAdded.size(); b++) {
      Fragment fragment = this.mAdded.get(b);
      if (fragment != null && fragment.performOptionsItemSelected(paramMenuItem))
        return true; 
    } 
    return false;
  }
  
  public void dispatchOptionsMenuClosed(Menu paramMenu) {
    if (this.mCurState < 1)
      return; 
    for (byte b = 0; b < this.mAdded.size(); b++) {
      Fragment fragment = this.mAdded.get(b);
      if (fragment != null)
        fragment.performOptionsMenuClosed(paramMenu); 
    } 
  }
  
  public void dispatchPause() {
    dispatchStateChange(3);
  }
  
  public void dispatchPictureInPictureModeChanged(boolean paramBoolean) {
    for (int i = this.mAdded.size() - 1; i >= 0; i--) {
      Fragment fragment = this.mAdded.get(i);
      if (fragment != null)
        fragment.performPictureInPictureModeChanged(paramBoolean); 
    } 
  }
  
  public boolean dispatchPrepareOptionsMenu(Menu paramMenu) {
    int i = this.mCurState;
    byte b = 0;
    if (i < 1)
      return false; 
    boolean bool;
    for (bool = false; b < this.mAdded.size(); bool = bool1) {
      Fragment fragment = this.mAdded.get(b);
      boolean bool1 = bool;
      if (fragment != null) {
        bool1 = bool;
        if (fragment.performPrepareOptionsMenu(paramMenu))
          bool1 = true; 
      } 
      b++;
    } 
    return bool;
  }
  
  void dispatchPrimaryNavigationFragmentChanged() {
    updateOnBackPressedCallbackEnabled();
    dispatchParentPrimaryNavigationFragmentChanged(this.mPrimaryNav);
  }
  
  public void dispatchResume() {
    this.mStateSaved = false;
    this.mStopped = false;
    dispatchStateChange(4);
  }
  
  public void dispatchStart() {
    this.mStateSaved = false;
    this.mStopped = false;
    dispatchStateChange(3);
  }
  
  public void dispatchStop() {
    this.mStopped = true;
    dispatchStateChange(2);
  }
  
  void doPendingDeferredStart() {
    if (this.mHavePendingDeferredStart) {
      this.mHavePendingDeferredStart = false;
      startPendingDeferredFragments();
    } 
  }
  
  public void dump(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString) {
    // Byte code:
    //   0: new java/lang/StringBuilder
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore #5
    //   9: aload #5
    //   11: aload_1
    //   12: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   15: pop
    //   16: aload #5
    //   18: ldc_w '    '
    //   21: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   24: pop
    //   25: aload #5
    //   27: invokevirtual toString : ()Ljava/lang/String;
    //   30: astore #5
    //   32: aload_0
    //   33: getfield mActive : Ljava/util/HashMap;
    //   36: invokevirtual isEmpty : ()Z
    //   39: ifne -> 138
    //   42: aload_3
    //   43: aload_1
    //   44: invokevirtual print : (Ljava/lang/String;)V
    //   47: aload_3
    //   48: ldc_w 'Active Fragments in '
    //   51: invokevirtual print : (Ljava/lang/String;)V
    //   54: aload_3
    //   55: aload_0
    //   56: invokestatic identityHashCode : (Ljava/lang/Object;)I
    //   59: invokestatic toHexString : (I)Ljava/lang/String;
    //   62: invokevirtual print : (Ljava/lang/String;)V
    //   65: aload_3
    //   66: ldc_w ':'
    //   69: invokevirtual println : (Ljava/lang/String;)V
    //   72: aload_0
    //   73: getfield mActive : Ljava/util/HashMap;
    //   76: invokevirtual values : ()Ljava/util/Collection;
    //   79: invokeinterface iterator : ()Ljava/util/Iterator;
    //   84: astore #6
    //   86: aload #6
    //   88: invokeinterface hasNext : ()Z
    //   93: ifeq -> 138
    //   96: aload #6
    //   98: invokeinterface next : ()Ljava/lang/Object;
    //   103: checkcast androidx/fragment/app/Fragment
    //   106: astore #7
    //   108: aload_3
    //   109: aload_1
    //   110: invokevirtual print : (Ljava/lang/String;)V
    //   113: aload_3
    //   114: aload #7
    //   116: invokevirtual println : (Ljava/lang/Object;)V
    //   119: aload #7
    //   121: ifnull -> 86
    //   124: aload #7
    //   126: aload #5
    //   128: aload_2
    //   129: aload_3
    //   130: aload #4
    //   132: invokevirtual dump : (Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V
    //   135: goto -> 86
    //   138: aload_0
    //   139: getfield mAdded : Ljava/util/ArrayList;
    //   142: invokevirtual size : ()I
    //   145: istore #8
    //   147: iconst_0
    //   148: istore #9
    //   150: iload #8
    //   152: ifle -> 229
    //   155: aload_3
    //   156: aload_1
    //   157: invokevirtual print : (Ljava/lang/String;)V
    //   160: aload_3
    //   161: ldc_w 'Added Fragments:'
    //   164: invokevirtual println : (Ljava/lang/String;)V
    //   167: iconst_0
    //   168: istore #10
    //   170: iload #10
    //   172: iload #8
    //   174: if_icmpge -> 229
    //   177: aload_0
    //   178: getfield mAdded : Ljava/util/ArrayList;
    //   181: iload #10
    //   183: invokevirtual get : (I)Ljava/lang/Object;
    //   186: checkcast androidx/fragment/app/Fragment
    //   189: astore_2
    //   190: aload_3
    //   191: aload_1
    //   192: invokevirtual print : (Ljava/lang/String;)V
    //   195: aload_3
    //   196: ldc_w '  #'
    //   199: invokevirtual print : (Ljava/lang/String;)V
    //   202: aload_3
    //   203: iload #10
    //   205: invokevirtual print : (I)V
    //   208: aload_3
    //   209: ldc_w ': '
    //   212: invokevirtual print : (Ljava/lang/String;)V
    //   215: aload_3
    //   216: aload_2
    //   217: invokevirtual toString : ()Ljava/lang/String;
    //   220: invokevirtual println : (Ljava/lang/String;)V
    //   223: iinc #10, 1
    //   226: goto -> 170
    //   229: aload_0
    //   230: getfield mCreatedMenus : Ljava/util/ArrayList;
    //   233: astore_2
    //   234: aload_2
    //   235: ifnull -> 323
    //   238: aload_2
    //   239: invokevirtual size : ()I
    //   242: istore #8
    //   244: iload #8
    //   246: ifle -> 323
    //   249: aload_3
    //   250: aload_1
    //   251: invokevirtual print : (Ljava/lang/String;)V
    //   254: aload_3
    //   255: ldc_w 'Fragments Created Menus:'
    //   258: invokevirtual println : (Ljava/lang/String;)V
    //   261: iconst_0
    //   262: istore #10
    //   264: iload #10
    //   266: iload #8
    //   268: if_icmpge -> 323
    //   271: aload_0
    //   272: getfield mCreatedMenus : Ljava/util/ArrayList;
    //   275: iload #10
    //   277: invokevirtual get : (I)Ljava/lang/Object;
    //   280: checkcast androidx/fragment/app/Fragment
    //   283: astore_2
    //   284: aload_3
    //   285: aload_1
    //   286: invokevirtual print : (Ljava/lang/String;)V
    //   289: aload_3
    //   290: ldc_w '  #'
    //   293: invokevirtual print : (Ljava/lang/String;)V
    //   296: aload_3
    //   297: iload #10
    //   299: invokevirtual print : (I)V
    //   302: aload_3
    //   303: ldc_w ': '
    //   306: invokevirtual print : (Ljava/lang/String;)V
    //   309: aload_3
    //   310: aload_2
    //   311: invokevirtual toString : ()Ljava/lang/String;
    //   314: invokevirtual println : (Ljava/lang/String;)V
    //   317: iinc #10, 1
    //   320: goto -> 264
    //   323: aload_0
    //   324: getfield mBackStack : Ljava/util/ArrayList;
    //   327: astore_2
    //   328: aload_2
    //   329: ifnull -> 424
    //   332: aload_2
    //   333: invokevirtual size : ()I
    //   336: istore #8
    //   338: iload #8
    //   340: ifle -> 424
    //   343: aload_3
    //   344: aload_1
    //   345: invokevirtual print : (Ljava/lang/String;)V
    //   348: aload_3
    //   349: ldc_w 'Back Stack:'
    //   352: invokevirtual println : (Ljava/lang/String;)V
    //   355: iconst_0
    //   356: istore #10
    //   358: iload #10
    //   360: iload #8
    //   362: if_icmpge -> 424
    //   365: aload_0
    //   366: getfield mBackStack : Ljava/util/ArrayList;
    //   369: iload #10
    //   371: invokevirtual get : (I)Ljava/lang/Object;
    //   374: checkcast androidx/fragment/app/BackStackRecord
    //   377: astore_2
    //   378: aload_3
    //   379: aload_1
    //   380: invokevirtual print : (Ljava/lang/String;)V
    //   383: aload_3
    //   384: ldc_w '  #'
    //   387: invokevirtual print : (Ljava/lang/String;)V
    //   390: aload_3
    //   391: iload #10
    //   393: invokevirtual print : (I)V
    //   396: aload_3
    //   397: ldc_w ': '
    //   400: invokevirtual print : (Ljava/lang/String;)V
    //   403: aload_3
    //   404: aload_2
    //   405: invokevirtual toString : ()Ljava/lang/String;
    //   408: invokevirtual println : (Ljava/lang/String;)V
    //   411: aload_2
    //   412: aload #5
    //   414: aload_3
    //   415: invokevirtual dump : (Ljava/lang/String;Ljava/io/PrintWriter;)V
    //   418: iinc #10, 1
    //   421: goto -> 358
    //   424: aload_0
    //   425: monitorenter
    //   426: aload_0
    //   427: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   430: ifnull -> 518
    //   433: aload_0
    //   434: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   437: invokevirtual size : ()I
    //   440: istore #8
    //   442: iload #8
    //   444: ifle -> 518
    //   447: aload_3
    //   448: aload_1
    //   449: invokevirtual print : (Ljava/lang/String;)V
    //   452: aload_3
    //   453: ldc_w 'Back Stack Indices:'
    //   456: invokevirtual println : (Ljava/lang/String;)V
    //   459: iconst_0
    //   460: istore #10
    //   462: iload #10
    //   464: iload #8
    //   466: if_icmpge -> 518
    //   469: aload_0
    //   470: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   473: iload #10
    //   475: invokevirtual get : (I)Ljava/lang/Object;
    //   478: checkcast androidx/fragment/app/BackStackRecord
    //   481: astore_2
    //   482: aload_3
    //   483: aload_1
    //   484: invokevirtual print : (Ljava/lang/String;)V
    //   487: aload_3
    //   488: ldc_w '  #'
    //   491: invokevirtual print : (Ljava/lang/String;)V
    //   494: aload_3
    //   495: iload #10
    //   497: invokevirtual print : (I)V
    //   500: aload_3
    //   501: ldc_w ': '
    //   504: invokevirtual print : (Ljava/lang/String;)V
    //   507: aload_3
    //   508: aload_2
    //   509: invokevirtual println : (Ljava/lang/Object;)V
    //   512: iinc #10, 1
    //   515: goto -> 462
    //   518: aload_0
    //   519: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   522: ifnull -> 561
    //   525: aload_0
    //   526: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   529: invokevirtual size : ()I
    //   532: ifle -> 561
    //   535: aload_3
    //   536: aload_1
    //   537: invokevirtual print : (Ljava/lang/String;)V
    //   540: aload_3
    //   541: ldc_w 'mAvailBackStackIndices: '
    //   544: invokevirtual print : (Ljava/lang/String;)V
    //   547: aload_3
    //   548: aload_0
    //   549: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   552: invokevirtual toArray : ()[Ljava/lang/Object;
    //   555: invokestatic toString : ([Ljava/lang/Object;)Ljava/lang/String;
    //   558: invokevirtual println : (Ljava/lang/String;)V
    //   561: aload_0
    //   562: monitorexit
    //   563: aload_0
    //   564: getfield mPendingActions : Ljava/util/ArrayList;
    //   567: astore_2
    //   568: aload_2
    //   569: ifnull -> 655
    //   572: aload_2
    //   573: invokevirtual size : ()I
    //   576: istore #8
    //   578: iload #8
    //   580: ifle -> 655
    //   583: aload_3
    //   584: aload_1
    //   585: invokevirtual print : (Ljava/lang/String;)V
    //   588: aload_3
    //   589: ldc_w 'Pending Actions:'
    //   592: invokevirtual println : (Ljava/lang/String;)V
    //   595: iload #9
    //   597: istore #10
    //   599: iload #10
    //   601: iload #8
    //   603: if_icmpge -> 655
    //   606: aload_0
    //   607: getfield mPendingActions : Ljava/util/ArrayList;
    //   610: iload #10
    //   612: invokevirtual get : (I)Ljava/lang/Object;
    //   615: checkcast androidx/fragment/app/FragmentManagerImpl$OpGenerator
    //   618: astore_2
    //   619: aload_3
    //   620: aload_1
    //   621: invokevirtual print : (Ljava/lang/String;)V
    //   624: aload_3
    //   625: ldc_w '  #'
    //   628: invokevirtual print : (Ljava/lang/String;)V
    //   631: aload_3
    //   632: iload #10
    //   634: invokevirtual print : (I)V
    //   637: aload_3
    //   638: ldc_w ': '
    //   641: invokevirtual print : (Ljava/lang/String;)V
    //   644: aload_3
    //   645: aload_2
    //   646: invokevirtual println : (Ljava/lang/Object;)V
    //   649: iinc #10, 1
    //   652: goto -> 599
    //   655: aload_3
    //   656: aload_1
    //   657: invokevirtual print : (Ljava/lang/String;)V
    //   660: aload_3
    //   661: ldc_w 'FragmentManager misc state:'
    //   664: invokevirtual println : (Ljava/lang/String;)V
    //   667: aload_3
    //   668: aload_1
    //   669: invokevirtual print : (Ljava/lang/String;)V
    //   672: aload_3
    //   673: ldc_w '  mHost='
    //   676: invokevirtual print : (Ljava/lang/String;)V
    //   679: aload_3
    //   680: aload_0
    //   681: getfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   684: invokevirtual println : (Ljava/lang/Object;)V
    //   687: aload_3
    //   688: aload_1
    //   689: invokevirtual print : (Ljava/lang/String;)V
    //   692: aload_3
    //   693: ldc_w '  mContainer='
    //   696: invokevirtual print : (Ljava/lang/String;)V
    //   699: aload_3
    //   700: aload_0
    //   701: getfield mContainer : Landroidx/fragment/app/FragmentContainer;
    //   704: invokevirtual println : (Ljava/lang/Object;)V
    //   707: aload_0
    //   708: getfield mParent : Landroidx/fragment/app/Fragment;
    //   711: ifnull -> 734
    //   714: aload_3
    //   715: aload_1
    //   716: invokevirtual print : (Ljava/lang/String;)V
    //   719: aload_3
    //   720: ldc_w '  mParent='
    //   723: invokevirtual print : (Ljava/lang/String;)V
    //   726: aload_3
    //   727: aload_0
    //   728: getfield mParent : Landroidx/fragment/app/Fragment;
    //   731: invokevirtual println : (Ljava/lang/Object;)V
    //   734: aload_3
    //   735: aload_1
    //   736: invokevirtual print : (Ljava/lang/String;)V
    //   739: aload_3
    //   740: ldc_w '  mCurState='
    //   743: invokevirtual print : (Ljava/lang/String;)V
    //   746: aload_3
    //   747: aload_0
    //   748: getfield mCurState : I
    //   751: invokevirtual print : (I)V
    //   754: aload_3
    //   755: ldc_w ' mStateSaved='
    //   758: invokevirtual print : (Ljava/lang/String;)V
    //   761: aload_3
    //   762: aload_0
    //   763: getfield mStateSaved : Z
    //   766: invokevirtual print : (Z)V
    //   769: aload_3
    //   770: ldc_w ' mStopped='
    //   773: invokevirtual print : (Ljava/lang/String;)V
    //   776: aload_3
    //   777: aload_0
    //   778: getfield mStopped : Z
    //   781: invokevirtual print : (Z)V
    //   784: aload_3
    //   785: ldc_w ' mDestroyed='
    //   788: invokevirtual print : (Ljava/lang/String;)V
    //   791: aload_3
    //   792: aload_0
    //   793: getfield mDestroyed : Z
    //   796: invokevirtual println : (Z)V
    //   799: aload_0
    //   800: getfield mNeedMenuInvalidate : Z
    //   803: ifeq -> 826
    //   806: aload_3
    //   807: aload_1
    //   808: invokevirtual print : (Ljava/lang/String;)V
    //   811: aload_3
    //   812: ldc_w '  mNeedMenuInvalidate='
    //   815: invokevirtual print : (Ljava/lang/String;)V
    //   818: aload_3
    //   819: aload_0
    //   820: getfield mNeedMenuInvalidate : Z
    //   823: invokevirtual println : (Z)V
    //   826: return
    //   827: astore_1
    //   828: aload_0
    //   829: monitorexit
    //   830: aload_1
    //   831: athrow
    // Exception table:
    //   from	to	target	type
    //   426	442	827	finally
    //   447	459	827	finally
    //   469	512	827	finally
    //   518	561	827	finally
    //   561	563	827	finally
    //   828	830	827	finally
  }
  
  public void enqueueAction(OpGenerator paramOpGenerator, boolean paramBoolean) {
    // Byte code:
    //   0: iload_2
    //   1: ifne -> 8
    //   4: aload_0
    //   5: invokespecial checkStateLoss : ()V
    //   8: aload_0
    //   9: monitorenter
    //   10: aload_0
    //   11: getfield mDestroyed : Z
    //   14: ifne -> 63
    //   17: aload_0
    //   18: getfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   21: ifnonnull -> 27
    //   24: goto -> 63
    //   27: aload_0
    //   28: getfield mPendingActions : Ljava/util/ArrayList;
    //   31: ifnonnull -> 47
    //   34: new java/util/ArrayList
    //   37: astore_3
    //   38: aload_3
    //   39: invokespecial <init> : ()V
    //   42: aload_0
    //   43: aload_3
    //   44: putfield mPendingActions : Ljava/util/ArrayList;
    //   47: aload_0
    //   48: getfield mPendingActions : Ljava/util/ArrayList;
    //   51: aload_1
    //   52: invokevirtual add : (Ljava/lang/Object;)Z
    //   55: pop
    //   56: aload_0
    //   57: invokevirtual scheduleCommit : ()V
    //   60: aload_0
    //   61: monitorexit
    //   62: return
    //   63: iload_2
    //   64: ifeq -> 70
    //   67: aload_0
    //   68: monitorexit
    //   69: return
    //   70: new java/lang/IllegalStateException
    //   73: astore_1
    //   74: aload_1
    //   75: ldc_w 'Activity has been destroyed'
    //   78: invokespecial <init> : (Ljava/lang/String;)V
    //   81: aload_1
    //   82: athrow
    //   83: astore_1
    //   84: aload_0
    //   85: monitorexit
    //   86: aload_1
    //   87: athrow
    // Exception table:
    //   from	to	target	type
    //   10	24	83	finally
    //   27	47	83	finally
    //   47	62	83	finally
    //   67	69	83	finally
    //   70	83	83	finally
    //   84	86	83	finally
  }
  
  void ensureInflatedFragmentView(Fragment paramFragment) {
    if (paramFragment.mFromLayout && !paramFragment.mPerformedCreateView) {
      paramFragment.performCreateView(paramFragment.performGetLayoutInflater(paramFragment.mSavedFragmentState), null, paramFragment.mSavedFragmentState);
      if (paramFragment.mView != null) {
        paramFragment.mInnerView = paramFragment.mView;
        paramFragment.mView.setSaveFromParentEnabled(false);
        if (paramFragment.mHidden)
          paramFragment.mView.setVisibility(8); 
        paramFragment.onViewCreated(paramFragment.mView, paramFragment.mSavedFragmentState);
        dispatchOnFragmentViewCreated(paramFragment, paramFragment.mView, paramFragment.mSavedFragmentState, false);
      } else {
        paramFragment.mInnerView = null;
      } 
    } 
  }
  
  public boolean execPendingActions() {
    ensureExecReady(true);
    boolean bool = false;
    while (generateOpsForPendingActions(this.mTmpRecords, this.mTmpIsPop)) {
      this.mExecutingActions = true;
      try {
        removeRedundantOperationsAndExecute(this.mTmpRecords, this.mTmpIsPop);
        cleanupExec();
      } finally {
        cleanupExec();
      } 
    } 
    updateOnBackPressedCallbackEnabled();
    doPendingDeferredStart();
    burpActive();
    return bool;
  }
  
  public void execSingleAction(OpGenerator paramOpGenerator, boolean paramBoolean) {
    if (paramBoolean && (this.mHost == null || this.mDestroyed))
      return; 
    ensureExecReady(paramBoolean);
    if (paramOpGenerator.generateOps(this.mTmpRecords, this.mTmpIsPop)) {
      this.mExecutingActions = true;
      try {
        removeRedundantOperationsAndExecute(this.mTmpRecords, this.mTmpIsPop);
      } finally {
        cleanupExec();
      } 
    } 
    updateOnBackPressedCallbackEnabled();
    doPendingDeferredStart();
    burpActive();
  }
  
  public boolean executePendingTransactions() {
    boolean bool = execPendingActions();
    forcePostponedTransactions();
    return bool;
  }
  
  public Fragment findFragmentById(int paramInt) {
    for (int i = this.mAdded.size() - 1; i >= 0; i--) {
      Fragment fragment = this.mAdded.get(i);
      if (fragment != null && fragment.mFragmentId == paramInt)
        return fragment; 
    } 
    for (Fragment fragment : this.mActive.values()) {
      if (fragment != null && fragment.mFragmentId == paramInt)
        return fragment; 
    } 
    return null;
  }
  
  public Fragment findFragmentByTag(String paramString) {
    if (paramString != null)
      for (int i = this.mAdded.size() - 1; i >= 0; i--) {
        Fragment fragment = this.mAdded.get(i);
        if (fragment != null && paramString.equals(fragment.mTag))
          return fragment; 
      }  
    if (paramString != null)
      for (Fragment fragment : this.mActive.values()) {
        if (fragment != null && paramString.equals(fragment.mTag))
          return fragment; 
      }  
    return null;
  }
  
  public Fragment findFragmentByWho(String paramString) {
    for (Fragment fragment : this.mActive.values()) {
      if (fragment != null) {
        fragment = fragment.findFragmentByWho(paramString);
        if (fragment != null)
          return fragment; 
      } 
    } 
    return null;
  }
  
  public void freeBackStackIndex(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   6: iload_1
    //   7: aconst_null
    //   8: invokevirtual set : (ILjava/lang/Object;)Ljava/lang/Object;
    //   11: pop
    //   12: aload_0
    //   13: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   16: ifnonnull -> 32
    //   19: new java/util/ArrayList
    //   22: astore_2
    //   23: aload_2
    //   24: invokespecial <init> : ()V
    //   27: aload_0
    //   28: aload_2
    //   29: putfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   32: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   35: ifeq -> 70
    //   38: new java/lang/StringBuilder
    //   41: astore_2
    //   42: aload_2
    //   43: invokespecial <init> : ()V
    //   46: aload_2
    //   47: ldc_w 'Freeing back stack index '
    //   50: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   53: pop
    //   54: aload_2
    //   55: iload_1
    //   56: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   59: pop
    //   60: ldc 'FragmentManager'
    //   62: aload_2
    //   63: invokevirtual toString : ()Ljava/lang/String;
    //   66: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   69: pop
    //   70: aload_0
    //   71: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   74: iload_1
    //   75: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   78: invokevirtual add : (Ljava/lang/Object;)Z
    //   81: pop
    //   82: aload_0
    //   83: monitorexit
    //   84: return
    //   85: astore_2
    //   86: aload_0
    //   87: monitorexit
    //   88: aload_2
    //   89: athrow
    // Exception table:
    //   from	to	target	type
    //   2	32	85	finally
    //   32	70	85	finally
    //   70	84	85	finally
    //   86	88	85	finally
  }
  
  int getActiveFragmentCount() {
    return this.mActive.size();
  }
  
  List<Fragment> getActiveFragments() {
    return new ArrayList<Fragment>(this.mActive.values());
  }
  
  public FragmentManager.BackStackEntry getBackStackEntryAt(int paramInt) {
    return this.mBackStack.get(paramInt);
  }
  
  public int getBackStackEntryCount() {
    boolean bool;
    ArrayList<BackStackRecord> arrayList = this.mBackStack;
    if (arrayList != null) {
      bool = arrayList.size();
    } else {
      bool = false;
    } 
    return bool;
  }
  
  FragmentManagerViewModel getChildNonConfig(Fragment paramFragment) {
    return this.mNonConfig.getChildNonConfig(paramFragment);
  }
  
  public Fragment getFragment(Bundle paramBundle, String paramString) {
    String str = paramBundle.getString(paramString);
    if (str == null)
      return null; 
    Fragment fragment = this.mActive.get(str);
    if (fragment == null) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Fragment no longer exists for key ");
      stringBuilder.append(paramString);
      stringBuilder.append(": unique id ");
      stringBuilder.append(str);
      throwException(new IllegalStateException(stringBuilder.toString()));
    } 
    return fragment;
  }
  
  public FragmentFactory getFragmentFactory() {
    if (super.getFragmentFactory() == DEFAULT_FACTORY) {
      Fragment fragment = this.mParent;
      if (fragment != null)
        return fragment.mFragmentManager.getFragmentFactory(); 
      setFragmentFactory(new FragmentFactory() {
            final FragmentManagerImpl this$0;
            
            public Fragment instantiate(ClassLoader param1ClassLoader, String param1String) {
              return FragmentManagerImpl.this.mHost.instantiate(FragmentManagerImpl.this.mHost.getContext(), param1String, null);
            }
          });
    } 
    return super.getFragmentFactory();
  }
  
  public List<Fragment> getFragments() {
    if (this.mAdded.isEmpty())
      return Collections.emptyList(); 
    synchronized (this.mAdded) {
      return (List)this.mAdded.clone();
    } 
  }
  
  LayoutInflater.Factory2 getLayoutInflaterFactory() {
    return this;
  }
  
  public Fragment getPrimaryNavigationFragment() {
    return this.mPrimaryNav;
  }
  
  ViewModelStore getViewModelStore(Fragment paramFragment) {
    return this.mNonConfig.getViewModelStore(paramFragment);
  }
  
  void handleOnBackPressed() {
    execPendingActions();
    if (this.mOnBackPressedCallback.isEnabled()) {
      popBackStackImmediate();
    } else {
      this.mOnBackPressedDispatcher.onBackPressed();
    } 
  }
  
  public void hideFragment(Fragment paramFragment) {
    if (DEBUG) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("hide: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (!paramFragment.mHidden) {
      paramFragment.mHidden = true;
      paramFragment.mHiddenChanged = true ^ paramFragment.mHiddenChanged;
    } 
  }
  
  public boolean isDestroyed() {
    return this.mDestroyed;
  }
  
  boolean isPrimaryNavigation(Fragment paramFragment) {
    boolean bool = true;
    if (paramFragment == null)
      return true; 
    FragmentManagerImpl fragmentManagerImpl = paramFragment.mFragmentManager;
    if (paramFragment != fragmentManagerImpl.getPrimaryNavigationFragment() || !isPrimaryNavigation(fragmentManagerImpl.mParent))
      bool = false; 
    return bool;
  }
  
  boolean isStateAtLeast(int paramInt) {
    boolean bool;
    if (this.mCurState >= paramInt) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public boolean isStateSaved() {
    return (this.mStateSaved || this.mStopped);
  }
  
  AnimationOrAnimator loadAnimation(Fragment paramFragment, int paramInt1, boolean paramBoolean, int paramInt2) {
    int i = paramFragment.getNextAnim();
    boolean bool = false;
    paramFragment.setNextAnim(0);
    if (paramFragment.mContainer != null && paramFragment.mContainer.getLayoutTransition() != null)
      return null; 
    Animation animation = paramFragment.onCreateAnimation(paramInt1, paramBoolean, i);
    if (animation != null)
      return new AnimationOrAnimator(animation); 
    Animator animator = paramFragment.onCreateAnimator(paramInt1, paramBoolean, i);
    if (animator != null)
      return new AnimationOrAnimator(animator); 
    if (i != 0) {
      boolean bool1 = "anim".equals(this.mHost.getContext().getResources().getResourceTypeName(i));
      boolean bool2 = bool;
      if (bool1)
        try {
          Animation animation1 = AnimationUtils.loadAnimation(this.mHost.getContext(), i);
          if (animation1 != null)
            return new AnimationOrAnimator(animation1); 
          bool2 = true;
        } catch (android.content.res.Resources.NotFoundException notFoundException) {
          throw notFoundException;
        } catch (RuntimeException runtimeException) {
          bool2 = bool;
        }  
      if (!bool2)
        try {
          animator = AnimatorInflater.loadAnimator(this.mHost.getContext(), i);
          if (animator != null)
            return new AnimationOrAnimator(animator); 
        } catch (RuntimeException runtimeException) {
          Animation animation1;
          if (!bool1) {
            animation1 = AnimationUtils.loadAnimation(this.mHost.getContext(), i);
            if (animation1 != null)
              return new AnimationOrAnimator(animation1); 
          } else {
            throw animation1;
          } 
        }  
    } 
    if (paramInt1 == 0)
      return null; 
    paramInt1 = transitToStyleIndex(paramInt1, paramBoolean);
    if (paramInt1 < 0)
      return null; 
    switch (paramInt1) {
      default:
        paramInt1 = paramInt2;
        if (paramInt2 == 0) {
          paramInt1 = paramInt2;
          if (this.mHost.onHasWindowAnimations())
            paramInt1 = this.mHost.onGetWindowAnimations(); 
        } 
        break;
      case 6:
        return makeFadeAnimation(1.0F, 0.0F);
      case 5:
        return makeFadeAnimation(0.0F, 1.0F);
      case 4:
        return makeOpenCloseAnimation(1.0F, 1.075F, 1.0F, 0.0F);
      case 3:
        return makeOpenCloseAnimation(0.975F, 1.0F, 0.0F, 1.0F);
      case 2:
        return makeOpenCloseAnimation(1.0F, 0.975F, 1.0F, 0.0F);
      case 1:
        return makeOpenCloseAnimation(1.125F, 1.0F, 0.0F, 1.0F);
    } 
    if (paramInt1 == 0);
    return null;
  }
  
  void makeActive(Fragment paramFragment) {
    if (this.mActive.get(paramFragment.mWho) != null)
      return; 
    this.mActive.put(paramFragment.mWho, paramFragment);
    if (paramFragment.mRetainInstanceChangedWhileDetached) {
      if (paramFragment.mRetainInstance) {
        addRetainedFragment(paramFragment);
      } else {
        removeRetainedFragment(paramFragment);
      } 
      paramFragment.mRetainInstanceChangedWhileDetached = false;
    } 
    if (DEBUG) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Added fragment to active set ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
  }
  
  void makeInactive(Fragment paramFragment) {
    if (this.mActive.get(paramFragment.mWho) == null)
      return; 
    if (DEBUG) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Removed fragment from active set ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    for (Fragment fragment : this.mActive.values()) {
      if (fragment != null && paramFragment.mWho.equals(fragment.mTargetWho)) {
        fragment.mTarget = paramFragment;
        fragment.mTargetWho = null;
      } 
    } 
    this.mActive.put(paramFragment.mWho, null);
    removeRetainedFragment(paramFragment);
    if (paramFragment.mTargetWho != null)
      paramFragment.mTarget = this.mActive.get(paramFragment.mTargetWho); 
    paramFragment.initState();
  }
  
  void moveFragmentToExpectedState(Fragment paramFragment) {
    if (paramFragment == null)
      return; 
    if (!this.mActive.containsKey(paramFragment.mWho)) {
      if (DEBUG) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Ignoring moving ");
        stringBuilder.append(paramFragment);
        stringBuilder.append(" to state ");
        stringBuilder.append(this.mCurState);
        stringBuilder.append("since it is not added to ");
        stringBuilder.append(this);
        Log.v("FragmentManager", stringBuilder.toString());
      } 
      return;
    } 
    int i = this.mCurState;
    int j = i;
    if (paramFragment.mRemoving)
      if (paramFragment.isInBackStack()) {
        j = Math.min(i, 1);
      } else {
        j = Math.min(i, 0);
      }  
    moveToState(paramFragment, j, paramFragment.getNextTransition(), paramFragment.getNextTransitionStyle(), false);
    if (paramFragment.mView != null) {
      Fragment fragment = findFragmentUnder(paramFragment);
      if (fragment != null) {
        View view = fragment.mView;
        ViewGroup viewGroup = paramFragment.mContainer;
        j = viewGroup.indexOfChild(view);
        i = viewGroup.indexOfChild(paramFragment.mView);
        if (i < j) {
          viewGroup.removeViewAt(i);
          viewGroup.addView(paramFragment.mView, j);
        } 
      } 
      if (paramFragment.mIsNewlyAdded && paramFragment.mContainer != null) {
        if (paramFragment.mPostponedAlpha > 0.0F)
          paramFragment.mView.setAlpha(paramFragment.mPostponedAlpha); 
        paramFragment.mPostponedAlpha = 0.0F;
        paramFragment.mIsNewlyAdded = false;
        AnimationOrAnimator animationOrAnimator = loadAnimation(paramFragment, paramFragment.getNextTransition(), true, paramFragment.getNextTransitionStyle());
        if (animationOrAnimator != null)
          if (animationOrAnimator.animation != null) {
            paramFragment.mView.startAnimation(animationOrAnimator.animation);
          } else {
            animationOrAnimator.animator.setTarget(paramFragment.mView);
            animationOrAnimator.animator.start();
          }  
      } 
    } 
    if (paramFragment.mHiddenChanged)
      completeShowHideFragment(paramFragment); 
  }
  
  void moveToState(int paramInt, boolean paramBoolean) {
    if (this.mHost != null || paramInt == 0) {
      if (!paramBoolean && paramInt == this.mCurState)
        return; 
      this.mCurState = paramInt;
      int i = this.mAdded.size();
      for (paramInt = 0; paramInt < i; paramInt++)
        moveFragmentToExpectedState(this.mAdded.get(paramInt)); 
      for (Fragment fragment : this.mActive.values()) {
        if (fragment != null && (fragment.mRemoving || fragment.mDetached) && !fragment.mIsNewlyAdded)
          moveFragmentToExpectedState(fragment); 
      } 
      startPendingDeferredFragments();
      if (this.mNeedMenuInvalidate) {
        FragmentHostCallback fragmentHostCallback = this.mHost;
        if (fragmentHostCallback != null && this.mCurState == 4) {
          fragmentHostCallback.onSupportInvalidateOptionsMenu();
          this.mNeedMenuInvalidate = false;
        } 
      } 
      return;
    } 
    throw new IllegalStateException("No activity");
  }
  
  void moveToState(Fragment paramFragment) {
    moveToState(paramFragment, this.mCurState, 0, 0, false);
  }
  
  void moveToState(Fragment paramFragment, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean) {
    // Byte code:
    //   0: aload_1
    //   1: getfield mAdded : Z
    //   4: istore #6
    //   6: iconst_1
    //   7: istore #7
    //   9: iconst_1
    //   10: istore #8
    //   12: iconst_1
    //   13: istore #9
    //   15: iload #6
    //   17: ifeq -> 33
    //   20: aload_1
    //   21: getfield mDetached : Z
    //   24: ifeq -> 30
    //   27: goto -> 33
    //   30: goto -> 47
    //   33: iload_2
    //   34: istore #10
    //   36: iload #10
    //   38: istore_2
    //   39: iload #10
    //   41: iconst_1
    //   42: if_icmple -> 47
    //   45: iconst_1
    //   46: istore_2
    //   47: iload_2
    //   48: istore #10
    //   50: aload_1
    //   51: getfield mRemoving : Z
    //   54: ifeq -> 94
    //   57: iload_2
    //   58: istore #10
    //   60: iload_2
    //   61: aload_1
    //   62: getfield mState : I
    //   65: if_icmple -> 94
    //   68: aload_1
    //   69: getfield mState : I
    //   72: ifne -> 88
    //   75: aload_1
    //   76: invokevirtual isInBackStack : ()Z
    //   79: ifeq -> 88
    //   82: iconst_1
    //   83: istore #10
    //   85: goto -> 94
    //   88: aload_1
    //   89: getfield mState : I
    //   92: istore #10
    //   94: iload #10
    //   96: istore_2
    //   97: aload_1
    //   98: getfield mDeferStart : Z
    //   101: ifeq -> 126
    //   104: iload #10
    //   106: istore_2
    //   107: aload_1
    //   108: getfield mState : I
    //   111: iconst_3
    //   112: if_icmpge -> 126
    //   115: iload #10
    //   117: istore_2
    //   118: iload #10
    //   120: iconst_2
    //   121: if_icmple -> 126
    //   124: iconst_2
    //   125: istore_2
    //   126: aload_1
    //   127: getfield mMaxState : Landroidx/lifecycle/Lifecycle$State;
    //   130: getstatic androidx/lifecycle/Lifecycle$State.CREATED : Landroidx/lifecycle/Lifecycle$State;
    //   133: if_acmpne -> 145
    //   136: iload_2
    //   137: iconst_1
    //   138: invokestatic min : (II)I
    //   141: istore_2
    //   142: goto -> 157
    //   145: iload_2
    //   146: aload_1
    //   147: getfield mMaxState : Landroidx/lifecycle/Lifecycle$State;
    //   150: invokevirtual ordinal : ()I
    //   153: invokestatic min : (II)I
    //   156: istore_2
    //   157: aload_1
    //   158: getfield mState : I
    //   161: iload_2
    //   162: if_icmpgt -> 1474
    //   165: aload_1
    //   166: getfield mFromLayout : Z
    //   169: ifeq -> 180
    //   172: aload_1
    //   173: getfield mInLayout : Z
    //   176: ifne -> 180
    //   179: return
    //   180: aload_1
    //   181: invokevirtual getAnimatingAway : ()Landroid/view/View;
    //   184: ifnonnull -> 194
    //   187: aload_1
    //   188: invokevirtual getAnimator : ()Landroid/animation/Animator;
    //   191: ifnull -> 216
    //   194: aload_1
    //   195: aconst_null
    //   196: invokevirtual setAnimatingAway : (Landroid/view/View;)V
    //   199: aload_1
    //   200: aconst_null
    //   201: invokevirtual setAnimator : (Landroid/animation/Animator;)V
    //   204: aload_0
    //   205: aload_1
    //   206: aload_1
    //   207: invokevirtual getStateAfterAnimating : ()I
    //   210: iconst_0
    //   211: iconst_0
    //   212: iconst_1
    //   213: invokevirtual moveToState : (Landroidx/fragment/app/Fragment;IIIZ)V
    //   216: aload_1
    //   217: getfield mState : I
    //   220: istore #4
    //   222: iload #4
    //   224: ifeq -> 259
    //   227: iload_2
    //   228: istore_3
    //   229: iload #4
    //   231: iconst_1
    //   232: if_icmpeq -> 880
    //   235: iload #4
    //   237: iconst_2
    //   238: if_icmpeq -> 256
    //   241: iload #4
    //   243: iconst_3
    //   244: if_icmpeq -> 253
    //   247: iload_2
    //   248: istore #10
    //   250: goto -> 2275
    //   253: goto -> 1398
    //   256: goto -> 1341
    //   259: iload_2
    //   260: istore_3
    //   261: iload_2
    //   262: ifle -> 880
    //   265: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   268: ifeq -> 307
    //   271: new java/lang/StringBuilder
    //   274: dup
    //   275: invokespecial <init> : ()V
    //   278: astore #11
    //   280: aload #11
    //   282: ldc_w 'moveto CREATED: '
    //   285: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   288: pop
    //   289: aload #11
    //   291: aload_1
    //   292: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   295: pop
    //   296: ldc 'FragmentManager'
    //   298: aload #11
    //   300: invokevirtual toString : ()Ljava/lang/String;
    //   303: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   306: pop
    //   307: iload_2
    //   308: istore_3
    //   309: aload_1
    //   310: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   313: ifnull -> 466
    //   316: aload_1
    //   317: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   320: aload_0
    //   321: getfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   324: invokevirtual getContext : ()Landroid/content/Context;
    //   327: invokevirtual getClassLoader : ()Ljava/lang/ClassLoader;
    //   330: invokevirtual setClassLoader : (Ljava/lang/ClassLoader;)V
    //   333: aload_1
    //   334: aload_1
    //   335: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   338: ldc 'android:view_state'
    //   340: invokevirtual getSparseParcelableArray : (Ljava/lang/String;)Landroid/util/SparseArray;
    //   343: putfield mSavedViewState : Landroid/util/SparseArray;
    //   346: aload_0
    //   347: aload_1
    //   348: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   351: ldc 'android:target_state'
    //   353: invokevirtual getFragment : (Landroid/os/Bundle;Ljava/lang/String;)Landroidx/fragment/app/Fragment;
    //   356: astore #11
    //   358: aload #11
    //   360: ifnull -> 373
    //   363: aload #11
    //   365: getfield mWho : Ljava/lang/String;
    //   368: astore #11
    //   370: goto -> 376
    //   373: aconst_null
    //   374: astore #11
    //   376: aload_1
    //   377: aload #11
    //   379: putfield mTargetWho : Ljava/lang/String;
    //   382: aload_1
    //   383: getfield mTargetWho : Ljava/lang/String;
    //   386: ifnull -> 403
    //   389: aload_1
    //   390: aload_1
    //   391: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   394: ldc 'android:target_req_state'
    //   396: iconst_0
    //   397: invokevirtual getInt : (Ljava/lang/String;I)I
    //   400: putfield mTargetRequestCode : I
    //   403: aload_1
    //   404: getfield mSavedUserVisibleHint : Ljava/lang/Boolean;
    //   407: ifnull -> 429
    //   410: aload_1
    //   411: aload_1
    //   412: getfield mSavedUserVisibleHint : Ljava/lang/Boolean;
    //   415: invokevirtual booleanValue : ()Z
    //   418: putfield mUserVisibleHint : Z
    //   421: aload_1
    //   422: aconst_null
    //   423: putfield mSavedUserVisibleHint : Ljava/lang/Boolean;
    //   426: goto -> 443
    //   429: aload_1
    //   430: aload_1
    //   431: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   434: ldc 'android:user_visible_hint'
    //   436: iconst_1
    //   437: invokevirtual getBoolean : (Ljava/lang/String;Z)Z
    //   440: putfield mUserVisibleHint : Z
    //   443: iload_2
    //   444: istore_3
    //   445: aload_1
    //   446: getfield mUserVisibleHint : Z
    //   449: ifne -> 466
    //   452: aload_1
    //   453: iconst_1
    //   454: putfield mDeferStart : Z
    //   457: iload_2
    //   458: istore_3
    //   459: iload_2
    //   460: iconst_2
    //   461: if_icmple -> 466
    //   464: iconst_2
    //   465: istore_3
    //   466: aload_0
    //   467: getfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   470: astore #11
    //   472: aload_1
    //   473: aload #11
    //   475: putfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   478: aload_0
    //   479: getfield mParent : Landroidx/fragment/app/Fragment;
    //   482: astore #12
    //   484: aload_1
    //   485: aload #12
    //   487: putfield mParentFragment : Landroidx/fragment/app/Fragment;
    //   490: aload #12
    //   492: ifnull -> 505
    //   495: aload #12
    //   497: getfield mChildFragmentManager : Landroidx/fragment/app/FragmentManagerImpl;
    //   500: astore #11
    //   502: goto -> 512
    //   505: aload #11
    //   507: getfield mFragmentManager : Landroidx/fragment/app/FragmentManagerImpl;
    //   510: astore #11
    //   512: aload_1
    //   513: aload #11
    //   515: putfield mFragmentManager : Landroidx/fragment/app/FragmentManagerImpl;
    //   518: aload_1
    //   519: getfield mTarget : Landroidx/fragment/app/Fragment;
    //   522: ifnull -> 657
    //   525: aload_0
    //   526: getfield mActive : Ljava/util/HashMap;
    //   529: aload_1
    //   530: getfield mTarget : Landroidx/fragment/app/Fragment;
    //   533: getfield mWho : Ljava/lang/String;
    //   536: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   539: aload_1
    //   540: getfield mTarget : Landroidx/fragment/app/Fragment;
    //   543: if_acmpne -> 591
    //   546: aload_1
    //   547: getfield mTarget : Landroidx/fragment/app/Fragment;
    //   550: getfield mState : I
    //   553: iconst_1
    //   554: if_icmpge -> 572
    //   557: aload_0
    //   558: aload_1
    //   559: getfield mTarget : Landroidx/fragment/app/Fragment;
    //   562: iconst_1
    //   563: iconst_0
    //   564: iconst_0
    //   565: iconst_1
    //   566: invokevirtual moveToState : (Landroidx/fragment/app/Fragment;IIIZ)V
    //   569: goto -> 572
    //   572: aload_1
    //   573: aload_1
    //   574: getfield mTarget : Landroidx/fragment/app/Fragment;
    //   577: getfield mWho : Ljava/lang/String;
    //   580: putfield mTargetWho : Ljava/lang/String;
    //   583: aload_1
    //   584: aconst_null
    //   585: putfield mTarget : Landroidx/fragment/app/Fragment;
    //   588: goto -> 657
    //   591: new java/lang/StringBuilder
    //   594: dup
    //   595: invokespecial <init> : ()V
    //   598: astore #11
    //   600: aload #11
    //   602: ldc_w 'Fragment '
    //   605: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   608: pop
    //   609: aload #11
    //   611: aload_1
    //   612: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   615: pop
    //   616: aload #11
    //   618: ldc_w ' declared target fragment '
    //   621: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   624: pop
    //   625: aload #11
    //   627: aload_1
    //   628: getfield mTarget : Landroidx/fragment/app/Fragment;
    //   631: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   634: pop
    //   635: aload #11
    //   637: ldc_w ' that does not belong to this FragmentManager!'
    //   640: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   643: pop
    //   644: new java/lang/IllegalStateException
    //   647: dup
    //   648: aload #11
    //   650: invokevirtual toString : ()Ljava/lang/String;
    //   653: invokespecial <init> : (Ljava/lang/String;)V
    //   656: athrow
    //   657: aload_1
    //   658: getfield mTargetWho : Ljava/lang/String;
    //   661: ifnull -> 773
    //   664: aload_0
    //   665: getfield mActive : Ljava/util/HashMap;
    //   668: aload_1
    //   669: getfield mTargetWho : Ljava/lang/String;
    //   672: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   675: checkcast androidx/fragment/app/Fragment
    //   678: astore #11
    //   680: aload #11
    //   682: ifnull -> 707
    //   685: aload #11
    //   687: getfield mState : I
    //   690: iconst_1
    //   691: if_icmpge -> 773
    //   694: aload_0
    //   695: aload #11
    //   697: iconst_1
    //   698: iconst_0
    //   699: iconst_0
    //   700: iconst_1
    //   701: invokevirtual moveToState : (Landroidx/fragment/app/Fragment;IIIZ)V
    //   704: goto -> 773
    //   707: new java/lang/StringBuilder
    //   710: dup
    //   711: invokespecial <init> : ()V
    //   714: astore #11
    //   716: aload #11
    //   718: ldc_w 'Fragment '
    //   721: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   724: pop
    //   725: aload #11
    //   727: aload_1
    //   728: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   731: pop
    //   732: aload #11
    //   734: ldc_w ' declared target fragment '
    //   737: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   740: pop
    //   741: aload #11
    //   743: aload_1
    //   744: getfield mTargetWho : Ljava/lang/String;
    //   747: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   750: pop
    //   751: aload #11
    //   753: ldc_w ' that does not belong to this FragmentManager!'
    //   756: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   759: pop
    //   760: new java/lang/IllegalStateException
    //   763: dup
    //   764: aload #11
    //   766: invokevirtual toString : ()Ljava/lang/String;
    //   769: invokespecial <init> : (Ljava/lang/String;)V
    //   772: athrow
    //   773: aload_0
    //   774: aload_1
    //   775: aload_0
    //   776: getfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   779: invokevirtual getContext : ()Landroid/content/Context;
    //   782: iconst_0
    //   783: invokevirtual dispatchOnFragmentPreAttached : (Landroidx/fragment/app/Fragment;Landroid/content/Context;Z)V
    //   786: aload_1
    //   787: invokevirtual performAttach : ()V
    //   790: aload_1
    //   791: getfield mParentFragment : Landroidx/fragment/app/Fragment;
    //   794: ifnonnull -> 808
    //   797: aload_0
    //   798: getfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   801: aload_1
    //   802: invokevirtual onAttachFragment : (Landroidx/fragment/app/Fragment;)V
    //   805: goto -> 816
    //   808: aload_1
    //   809: getfield mParentFragment : Landroidx/fragment/app/Fragment;
    //   812: aload_1
    //   813: invokevirtual onAttachFragment : (Landroidx/fragment/app/Fragment;)V
    //   816: aload_0
    //   817: aload_1
    //   818: aload_0
    //   819: getfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   822: invokevirtual getContext : ()Landroid/content/Context;
    //   825: iconst_0
    //   826: invokevirtual dispatchOnFragmentAttached : (Landroidx/fragment/app/Fragment;Landroid/content/Context;Z)V
    //   829: aload_1
    //   830: getfield mIsCreated : Z
    //   833: ifne -> 867
    //   836: aload_0
    //   837: aload_1
    //   838: aload_1
    //   839: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   842: iconst_0
    //   843: invokevirtual dispatchOnFragmentPreCreated : (Landroidx/fragment/app/Fragment;Landroid/os/Bundle;Z)V
    //   846: aload_1
    //   847: aload_1
    //   848: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   851: invokevirtual performCreate : (Landroid/os/Bundle;)V
    //   854: aload_0
    //   855: aload_1
    //   856: aload_1
    //   857: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   860: iconst_0
    //   861: invokevirtual dispatchOnFragmentCreated : (Landroidx/fragment/app/Fragment;Landroid/os/Bundle;Z)V
    //   864: goto -> 880
    //   867: aload_1
    //   868: aload_1
    //   869: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   872: invokevirtual restoreChildFragmentState : (Landroid/os/Bundle;)V
    //   875: aload_1
    //   876: iconst_1
    //   877: putfield mState : I
    //   880: iload_3
    //   881: ifle -> 889
    //   884: aload_0
    //   885: aload_1
    //   886: invokevirtual ensureInflatedFragmentView : (Landroidx/fragment/app/Fragment;)V
    //   889: iload_3
    //   890: iconst_1
    //   891: if_icmple -> 1339
    //   894: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   897: ifeq -> 936
    //   900: new java/lang/StringBuilder
    //   903: dup
    //   904: invokespecial <init> : ()V
    //   907: astore #11
    //   909: aload #11
    //   911: ldc_w 'moveto ACTIVITY_CREATED: '
    //   914: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   917: pop
    //   918: aload #11
    //   920: aload_1
    //   921: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   924: pop
    //   925: ldc 'FragmentManager'
    //   927: aload #11
    //   929: invokevirtual toString : ()Ljava/lang/String;
    //   932: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   935: pop
    //   936: aload_1
    //   937: getfield mFromLayout : Z
    //   940: ifne -> 1301
    //   943: aload_1
    //   944: getfield mContainerId : I
    //   947: ifeq -> 1154
    //   950: aload_1
    //   951: getfield mContainerId : I
    //   954: iconst_m1
    //   955: if_icmpne -> 1008
    //   958: new java/lang/StringBuilder
    //   961: dup
    //   962: invokespecial <init> : ()V
    //   965: astore #11
    //   967: aload #11
    //   969: ldc_w 'Cannot create fragment '
    //   972: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   975: pop
    //   976: aload #11
    //   978: aload_1
    //   979: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   982: pop
    //   983: aload #11
    //   985: ldc_w ' for a container view with no id'
    //   988: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   991: pop
    //   992: aload_0
    //   993: new java/lang/IllegalArgumentException
    //   996: dup
    //   997: aload #11
    //   999: invokevirtual toString : ()Ljava/lang/String;
    //   1002: invokespecial <init> : (Ljava/lang/String;)V
    //   1005: invokespecial throwException : (Ljava/lang/RuntimeException;)V
    //   1008: aload_0
    //   1009: getfield mContainer : Landroidx/fragment/app/FragmentContainer;
    //   1012: aload_1
    //   1013: getfield mContainerId : I
    //   1016: invokevirtual onFindViewById : (I)Landroid/view/View;
    //   1019: checkcast android/view/ViewGroup
    //   1022: astore #12
    //   1024: aload #12
    //   1026: astore #11
    //   1028: aload #12
    //   1030: ifnonnull -> 1157
    //   1033: aload #12
    //   1035: astore #11
    //   1037: aload_1
    //   1038: getfield mRestored : Z
    //   1041: ifne -> 1157
    //   1044: aload_1
    //   1045: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   1048: aload_1
    //   1049: getfield mContainerId : I
    //   1052: invokevirtual getResourceName : (I)Ljava/lang/String;
    //   1055: astore #11
    //   1057: goto -> 1067
    //   1060: astore #11
    //   1062: ldc_w 'unknown'
    //   1065: astore #11
    //   1067: new java/lang/StringBuilder
    //   1070: dup
    //   1071: invokespecial <init> : ()V
    //   1074: astore #13
    //   1076: aload #13
    //   1078: ldc_w 'No view found for id 0x'
    //   1081: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1084: pop
    //   1085: aload #13
    //   1087: aload_1
    //   1088: getfield mContainerId : I
    //   1091: invokestatic toHexString : (I)Ljava/lang/String;
    //   1094: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1097: pop
    //   1098: aload #13
    //   1100: ldc_w ' ('
    //   1103: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1106: pop
    //   1107: aload #13
    //   1109: aload #11
    //   1111: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1114: pop
    //   1115: aload #13
    //   1117: ldc_w ') for fragment '
    //   1120: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1123: pop
    //   1124: aload #13
    //   1126: aload_1
    //   1127: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1130: pop
    //   1131: aload_0
    //   1132: new java/lang/IllegalArgumentException
    //   1135: dup
    //   1136: aload #13
    //   1138: invokevirtual toString : ()Ljava/lang/String;
    //   1141: invokespecial <init> : (Ljava/lang/String;)V
    //   1144: invokespecial throwException : (Ljava/lang/RuntimeException;)V
    //   1147: aload #12
    //   1149: astore #11
    //   1151: goto -> 1157
    //   1154: aconst_null
    //   1155: astore #11
    //   1157: aload_1
    //   1158: aload #11
    //   1160: putfield mContainer : Landroid/view/ViewGroup;
    //   1163: aload_1
    //   1164: aload_1
    //   1165: aload_1
    //   1166: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   1169: invokevirtual performGetLayoutInflater : (Landroid/os/Bundle;)Landroid/view/LayoutInflater;
    //   1172: aload #11
    //   1174: aload_1
    //   1175: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   1178: invokevirtual performCreateView : (Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)V
    //   1181: aload_1
    //   1182: getfield mView : Landroid/view/View;
    //   1185: ifnull -> 1296
    //   1188: aload_1
    //   1189: aload_1
    //   1190: getfield mView : Landroid/view/View;
    //   1193: putfield mInnerView : Landroid/view/View;
    //   1196: aload_1
    //   1197: getfield mView : Landroid/view/View;
    //   1200: iconst_0
    //   1201: invokevirtual setSaveFromParentEnabled : (Z)V
    //   1204: aload #11
    //   1206: ifnull -> 1218
    //   1209: aload #11
    //   1211: aload_1
    //   1212: getfield mView : Landroid/view/View;
    //   1215: invokevirtual addView : (Landroid/view/View;)V
    //   1218: aload_1
    //   1219: getfield mHidden : Z
    //   1222: ifeq -> 1234
    //   1225: aload_1
    //   1226: getfield mView : Landroid/view/View;
    //   1229: bipush #8
    //   1231: invokevirtual setVisibility : (I)V
    //   1234: aload_1
    //   1235: aload_1
    //   1236: getfield mView : Landroid/view/View;
    //   1239: aload_1
    //   1240: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   1243: invokevirtual onViewCreated : (Landroid/view/View;Landroid/os/Bundle;)V
    //   1246: aload_0
    //   1247: aload_1
    //   1248: aload_1
    //   1249: getfield mView : Landroid/view/View;
    //   1252: aload_1
    //   1253: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   1256: iconst_0
    //   1257: invokevirtual dispatchOnFragmentViewCreated : (Landroidx/fragment/app/Fragment;Landroid/view/View;Landroid/os/Bundle;Z)V
    //   1260: aload_1
    //   1261: getfield mView : Landroid/view/View;
    //   1264: invokevirtual getVisibility : ()I
    //   1267: ifne -> 1284
    //   1270: aload_1
    //   1271: getfield mContainer : Landroid/view/ViewGroup;
    //   1274: ifnull -> 1284
    //   1277: iload #9
    //   1279: istore #5
    //   1281: goto -> 1287
    //   1284: iconst_0
    //   1285: istore #5
    //   1287: aload_1
    //   1288: iload #5
    //   1290: putfield mIsNewlyAdded : Z
    //   1293: goto -> 1301
    //   1296: aload_1
    //   1297: aconst_null
    //   1298: putfield mInnerView : Landroid/view/View;
    //   1301: aload_1
    //   1302: aload_1
    //   1303: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   1306: invokevirtual performActivityCreated : (Landroid/os/Bundle;)V
    //   1309: aload_0
    //   1310: aload_1
    //   1311: aload_1
    //   1312: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   1315: iconst_0
    //   1316: invokevirtual dispatchOnFragmentActivityCreated : (Landroidx/fragment/app/Fragment;Landroid/os/Bundle;Z)V
    //   1319: aload_1
    //   1320: getfield mView : Landroid/view/View;
    //   1323: ifnull -> 1334
    //   1326: aload_1
    //   1327: aload_1
    //   1328: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   1331: invokevirtual restoreViewState : (Landroid/os/Bundle;)V
    //   1334: aload_1
    //   1335: aconst_null
    //   1336: putfield mSavedFragmentState : Landroid/os/Bundle;
    //   1339: iload_3
    //   1340: istore_2
    //   1341: iload_2
    //   1342: iconst_2
    //   1343: if_icmple -> 1398
    //   1346: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   1349: ifeq -> 1388
    //   1352: new java/lang/StringBuilder
    //   1355: dup
    //   1356: invokespecial <init> : ()V
    //   1359: astore #11
    //   1361: aload #11
    //   1363: ldc_w 'moveto STARTED: '
    //   1366: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1369: pop
    //   1370: aload #11
    //   1372: aload_1
    //   1373: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1376: pop
    //   1377: ldc 'FragmentManager'
    //   1379: aload #11
    //   1381: invokevirtual toString : ()Ljava/lang/String;
    //   1384: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1387: pop
    //   1388: aload_1
    //   1389: invokevirtual performStart : ()V
    //   1392: aload_0
    //   1393: aload_1
    //   1394: iconst_0
    //   1395: invokevirtual dispatchOnFragmentStarted : (Landroidx/fragment/app/Fragment;Z)V
    //   1398: iload_2
    //   1399: istore #10
    //   1401: iload_2
    //   1402: iconst_3
    //   1403: if_icmple -> 2275
    //   1406: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   1409: ifeq -> 1448
    //   1412: new java/lang/StringBuilder
    //   1415: dup
    //   1416: invokespecial <init> : ()V
    //   1419: astore #11
    //   1421: aload #11
    //   1423: ldc_w 'moveto RESUMED: '
    //   1426: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1429: pop
    //   1430: aload #11
    //   1432: aload_1
    //   1433: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1436: pop
    //   1437: ldc 'FragmentManager'
    //   1439: aload #11
    //   1441: invokevirtual toString : ()Ljava/lang/String;
    //   1444: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1447: pop
    //   1448: aload_1
    //   1449: invokevirtual performResume : ()V
    //   1452: aload_0
    //   1453: aload_1
    //   1454: iconst_0
    //   1455: invokevirtual dispatchOnFragmentResumed : (Landroidx/fragment/app/Fragment;Z)V
    //   1458: aload_1
    //   1459: aconst_null
    //   1460: putfield mSavedFragmentState : Landroid/os/Bundle;
    //   1463: aload_1
    //   1464: aconst_null
    //   1465: putfield mSavedViewState : Landroid/util/SparseArray;
    //   1468: iload_2
    //   1469: istore #10
    //   1471: goto -> 2275
    //   1474: iload_2
    //   1475: istore #10
    //   1477: aload_1
    //   1478: getfield mState : I
    //   1481: iload_2
    //   1482: if_icmple -> 2275
    //   1485: aload_1
    //   1486: getfield mState : I
    //   1489: istore #10
    //   1491: iload #10
    //   1493: iconst_1
    //   1494: if_icmpeq -> 1889
    //   1497: iload #10
    //   1499: iconst_2
    //   1500: if_icmpeq -> 1641
    //   1503: iload #10
    //   1505: iconst_3
    //   1506: if_icmpeq -> 1581
    //   1509: iload #10
    //   1511: iconst_4
    //   1512: if_icmpeq -> 1521
    //   1515: iload_2
    //   1516: istore #10
    //   1518: goto -> 2275
    //   1521: iload_2
    //   1522: iconst_4
    //   1523: if_icmpge -> 1578
    //   1526: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   1529: ifeq -> 1568
    //   1532: new java/lang/StringBuilder
    //   1535: dup
    //   1536: invokespecial <init> : ()V
    //   1539: astore #11
    //   1541: aload #11
    //   1543: ldc_w 'movefrom RESUMED: '
    //   1546: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1549: pop
    //   1550: aload #11
    //   1552: aload_1
    //   1553: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1556: pop
    //   1557: ldc 'FragmentManager'
    //   1559: aload #11
    //   1561: invokevirtual toString : ()Ljava/lang/String;
    //   1564: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1567: pop
    //   1568: aload_1
    //   1569: invokevirtual performPause : ()V
    //   1572: aload_0
    //   1573: aload_1
    //   1574: iconst_0
    //   1575: invokevirtual dispatchOnFragmentPaused : (Landroidx/fragment/app/Fragment;Z)V
    //   1578: goto -> 1581
    //   1581: iload_2
    //   1582: iconst_3
    //   1583: if_icmpge -> 1638
    //   1586: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   1589: ifeq -> 1628
    //   1592: new java/lang/StringBuilder
    //   1595: dup
    //   1596: invokespecial <init> : ()V
    //   1599: astore #11
    //   1601: aload #11
    //   1603: ldc_w 'movefrom STARTED: '
    //   1606: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1609: pop
    //   1610: aload #11
    //   1612: aload_1
    //   1613: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1616: pop
    //   1617: ldc 'FragmentManager'
    //   1619: aload #11
    //   1621: invokevirtual toString : ()Ljava/lang/String;
    //   1624: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1627: pop
    //   1628: aload_1
    //   1629: invokevirtual performStop : ()V
    //   1632: aload_0
    //   1633: aload_1
    //   1634: iconst_0
    //   1635: invokevirtual dispatchOnFragmentStopped : (Landroidx/fragment/app/Fragment;Z)V
    //   1638: goto -> 1641
    //   1641: iload_2
    //   1642: iconst_2
    //   1643: if_icmpge -> 1889
    //   1646: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   1649: ifeq -> 1688
    //   1652: new java/lang/StringBuilder
    //   1655: dup
    //   1656: invokespecial <init> : ()V
    //   1659: astore #11
    //   1661: aload #11
    //   1663: ldc_w 'movefrom ACTIVITY_CREATED: '
    //   1666: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1669: pop
    //   1670: aload #11
    //   1672: aload_1
    //   1673: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1676: pop
    //   1677: ldc 'FragmentManager'
    //   1679: aload #11
    //   1681: invokevirtual toString : ()Ljava/lang/String;
    //   1684: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1687: pop
    //   1688: aload_1
    //   1689: getfield mView : Landroid/view/View;
    //   1692: ifnull -> 1718
    //   1695: aload_0
    //   1696: getfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   1699: aload_1
    //   1700: invokevirtual onShouldSaveFragmentState : (Landroidx/fragment/app/Fragment;)Z
    //   1703: ifeq -> 1718
    //   1706: aload_1
    //   1707: getfield mSavedViewState : Landroid/util/SparseArray;
    //   1710: ifnonnull -> 1718
    //   1713: aload_0
    //   1714: aload_1
    //   1715: invokevirtual saveFragmentViewState : (Landroidx/fragment/app/Fragment;)V
    //   1718: aload_1
    //   1719: invokevirtual performDestroyView : ()V
    //   1722: aload_0
    //   1723: aload_1
    //   1724: iconst_0
    //   1725: invokevirtual dispatchOnFragmentViewDestroyed : (Landroidx/fragment/app/Fragment;Z)V
    //   1728: aload_1
    //   1729: getfield mView : Landroid/view/View;
    //   1732: ifnull -> 1856
    //   1735: aload_1
    //   1736: getfield mContainer : Landroid/view/ViewGroup;
    //   1739: ifnull -> 1856
    //   1742: aload_1
    //   1743: getfield mContainer : Landroid/view/ViewGroup;
    //   1746: aload_1
    //   1747: getfield mView : Landroid/view/View;
    //   1750: invokevirtual endViewTransition : (Landroid/view/View;)V
    //   1753: aload_1
    //   1754: getfield mView : Landroid/view/View;
    //   1757: invokevirtual clearAnimation : ()V
    //   1760: aload_1
    //   1761: invokevirtual getParentFragment : ()Landroidx/fragment/app/Fragment;
    //   1764: ifnull -> 1777
    //   1767: aload_1
    //   1768: invokevirtual getParentFragment : ()Landroidx/fragment/app/Fragment;
    //   1771: getfield mRemoving : Z
    //   1774: ifne -> 1856
    //   1777: aload_0
    //   1778: getfield mCurState : I
    //   1781: ifle -> 1824
    //   1784: aload_0
    //   1785: getfield mDestroyed : Z
    //   1788: ifne -> 1824
    //   1791: aload_1
    //   1792: getfield mView : Landroid/view/View;
    //   1795: invokevirtual getVisibility : ()I
    //   1798: ifne -> 1824
    //   1801: aload_1
    //   1802: getfield mPostponedAlpha : F
    //   1805: fconst_0
    //   1806: fcmpl
    //   1807: iflt -> 1824
    //   1810: aload_0
    //   1811: aload_1
    //   1812: iload_3
    //   1813: iconst_0
    //   1814: iload #4
    //   1816: invokevirtual loadAnimation : (Landroidx/fragment/app/Fragment;IZI)Landroidx/fragment/app/FragmentManagerImpl$AnimationOrAnimator;
    //   1819: astore #11
    //   1821: goto -> 1827
    //   1824: aconst_null
    //   1825: astore #11
    //   1827: aload_1
    //   1828: fconst_0
    //   1829: putfield mPostponedAlpha : F
    //   1832: aload #11
    //   1834: ifnull -> 1845
    //   1837: aload_0
    //   1838: aload_1
    //   1839: aload #11
    //   1841: iload_2
    //   1842: invokespecial animateRemoveFragment : (Landroidx/fragment/app/Fragment;Landroidx/fragment/app/FragmentManagerImpl$AnimationOrAnimator;I)V
    //   1845: aload_1
    //   1846: getfield mContainer : Landroid/view/ViewGroup;
    //   1849: aload_1
    //   1850: getfield mView : Landroid/view/View;
    //   1853: invokevirtual removeView : (Landroid/view/View;)V
    //   1856: aload_1
    //   1857: aconst_null
    //   1858: putfield mContainer : Landroid/view/ViewGroup;
    //   1861: aload_1
    //   1862: aconst_null
    //   1863: putfield mView : Landroid/view/View;
    //   1866: aload_1
    //   1867: aconst_null
    //   1868: putfield mViewLifecycleOwner : Landroidx/fragment/app/FragmentViewLifecycleOwner;
    //   1871: aload_1
    //   1872: getfield mViewLifecycleOwnerLiveData : Landroidx/lifecycle/MutableLiveData;
    //   1875: aconst_null
    //   1876: invokevirtual setValue : (Ljava/lang/Object;)V
    //   1879: aload_1
    //   1880: aconst_null
    //   1881: putfield mInnerView : Landroid/view/View;
    //   1884: aload_1
    //   1885: iconst_0
    //   1886: putfield mInLayout : Z
    //   1889: iload_2
    //   1890: istore #10
    //   1892: iload_2
    //   1893: iconst_1
    //   1894: if_icmpge -> 2275
    //   1897: aload_0
    //   1898: getfield mDestroyed : Z
    //   1901: ifeq -> 1953
    //   1904: aload_1
    //   1905: invokevirtual getAnimatingAway : ()Landroid/view/View;
    //   1908: ifnull -> 1930
    //   1911: aload_1
    //   1912: invokevirtual getAnimatingAway : ()Landroid/view/View;
    //   1915: astore #11
    //   1917: aload_1
    //   1918: aconst_null
    //   1919: invokevirtual setAnimatingAway : (Landroid/view/View;)V
    //   1922: aload #11
    //   1924: invokevirtual clearAnimation : ()V
    //   1927: goto -> 1953
    //   1930: aload_1
    //   1931: invokevirtual getAnimator : ()Landroid/animation/Animator;
    //   1934: ifnull -> 1953
    //   1937: aload_1
    //   1938: invokevirtual getAnimator : ()Landroid/animation/Animator;
    //   1941: astore #11
    //   1943: aload_1
    //   1944: aconst_null
    //   1945: invokevirtual setAnimator : (Landroid/animation/Animator;)V
    //   1948: aload #11
    //   1950: invokevirtual cancel : ()V
    //   1953: aload_1
    //   1954: invokevirtual getAnimatingAway : ()Landroid/view/View;
    //   1957: ifnonnull -> 2263
    //   1960: aload_1
    //   1961: invokevirtual getAnimator : ()Landroid/animation/Animator;
    //   1964: ifnull -> 1970
    //   1967: goto -> 2263
    //   1970: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   1973: ifeq -> 2012
    //   1976: new java/lang/StringBuilder
    //   1979: dup
    //   1980: invokespecial <init> : ()V
    //   1983: astore #11
    //   1985: aload #11
    //   1987: ldc_w 'movefrom CREATED: '
    //   1990: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1993: pop
    //   1994: aload #11
    //   1996: aload_1
    //   1997: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   2000: pop
    //   2001: ldc 'FragmentManager'
    //   2003: aload #11
    //   2005: invokevirtual toString : ()Ljava/lang/String;
    //   2008: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   2011: pop
    //   2012: aload_1
    //   2013: getfield mRemoving : Z
    //   2016: ifeq -> 2031
    //   2019: aload_1
    //   2020: invokevirtual isInBackStack : ()Z
    //   2023: ifne -> 2031
    //   2026: iconst_1
    //   2027: istore_3
    //   2028: goto -> 2033
    //   2031: iconst_0
    //   2032: istore_3
    //   2033: iload_3
    //   2034: ifne -> 2059
    //   2037: aload_0
    //   2038: getfield mNonConfig : Landroidx/fragment/app/FragmentManagerViewModel;
    //   2041: aload_1
    //   2042: invokevirtual shouldDestroy : (Landroidx/fragment/app/Fragment;)Z
    //   2045: ifeq -> 2051
    //   2048: goto -> 2059
    //   2051: aload_1
    //   2052: iconst_0
    //   2053: putfield mState : I
    //   2056: goto -> 2144
    //   2059: aload_0
    //   2060: getfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   2063: astore #11
    //   2065: aload #11
    //   2067: instanceof androidx/lifecycle/ViewModelStoreOwner
    //   2070: ifeq -> 2085
    //   2073: aload_0
    //   2074: getfield mNonConfig : Landroidx/fragment/app/FragmentManagerViewModel;
    //   2077: invokevirtual isCleared : ()Z
    //   2080: istore #9
    //   2082: goto -> 2117
    //   2085: iload #7
    //   2087: istore #9
    //   2089: aload #11
    //   2091: invokevirtual getContext : ()Landroid/content/Context;
    //   2094: instanceof android/app/Activity
    //   2097: ifeq -> 2117
    //   2100: iconst_1
    //   2101: aload_0
    //   2102: getfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   2105: invokevirtual getContext : ()Landroid/content/Context;
    //   2108: checkcast android/app/Activity
    //   2111: invokevirtual isChangingConfigurations : ()Z
    //   2114: ixor
    //   2115: istore #9
    //   2117: iload_3
    //   2118: ifne -> 2126
    //   2121: iload #9
    //   2123: ifeq -> 2134
    //   2126: aload_0
    //   2127: getfield mNonConfig : Landroidx/fragment/app/FragmentManagerViewModel;
    //   2130: aload_1
    //   2131: invokevirtual clearNonConfigState : (Landroidx/fragment/app/Fragment;)V
    //   2134: aload_1
    //   2135: invokevirtual performDestroy : ()V
    //   2138: aload_0
    //   2139: aload_1
    //   2140: iconst_0
    //   2141: invokevirtual dispatchOnFragmentDestroyed : (Landroidx/fragment/app/Fragment;Z)V
    //   2144: aload_1
    //   2145: invokevirtual performDetach : ()V
    //   2148: aload_0
    //   2149: aload_1
    //   2150: iconst_0
    //   2151: invokevirtual dispatchOnFragmentDetached : (Landroidx/fragment/app/Fragment;Z)V
    //   2154: iload_2
    //   2155: istore #10
    //   2157: iload #5
    //   2159: ifne -> 2275
    //   2162: iload_3
    //   2163: ifne -> 2252
    //   2166: aload_0
    //   2167: getfield mNonConfig : Landroidx/fragment/app/FragmentManagerViewModel;
    //   2170: aload_1
    //   2171: invokevirtual shouldDestroy : (Landroidx/fragment/app/Fragment;)Z
    //   2174: ifeq -> 2180
    //   2177: goto -> 2252
    //   2180: aload_1
    //   2181: aconst_null
    //   2182: putfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   2185: aload_1
    //   2186: aconst_null
    //   2187: putfield mParentFragment : Landroidx/fragment/app/Fragment;
    //   2190: aload_1
    //   2191: aconst_null
    //   2192: putfield mFragmentManager : Landroidx/fragment/app/FragmentManagerImpl;
    //   2195: iload_2
    //   2196: istore #10
    //   2198: aload_1
    //   2199: getfield mTargetWho : Ljava/lang/String;
    //   2202: ifnull -> 2275
    //   2205: aload_0
    //   2206: getfield mActive : Ljava/util/HashMap;
    //   2209: aload_1
    //   2210: getfield mTargetWho : Ljava/lang/String;
    //   2213: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   2216: checkcast androidx/fragment/app/Fragment
    //   2219: astore #11
    //   2221: iload_2
    //   2222: istore #10
    //   2224: aload #11
    //   2226: ifnull -> 2275
    //   2229: iload_2
    //   2230: istore #10
    //   2232: aload #11
    //   2234: invokevirtual getRetainInstance : ()Z
    //   2237: ifeq -> 2275
    //   2240: aload_1
    //   2241: aload #11
    //   2243: putfield mTarget : Landroidx/fragment/app/Fragment;
    //   2246: iload_2
    //   2247: istore #10
    //   2249: goto -> 2275
    //   2252: aload_0
    //   2253: aload_1
    //   2254: invokevirtual makeInactive : (Landroidx/fragment/app/Fragment;)V
    //   2257: iload_2
    //   2258: istore #10
    //   2260: goto -> 2275
    //   2263: aload_1
    //   2264: iload_2
    //   2265: invokevirtual setStateAfterAnimating : (I)V
    //   2268: iload #8
    //   2270: istore #10
    //   2272: goto -> 2275
    //   2275: aload_1
    //   2276: getfield mState : I
    //   2279: iload #10
    //   2281: if_icmpeq -> 2362
    //   2284: new java/lang/StringBuilder
    //   2287: dup
    //   2288: invokespecial <init> : ()V
    //   2291: astore #11
    //   2293: aload #11
    //   2295: ldc_w 'moveToState: Fragment state for '
    //   2298: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2301: pop
    //   2302: aload #11
    //   2304: aload_1
    //   2305: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   2308: pop
    //   2309: aload #11
    //   2311: ldc_w ' not updated inline; expected state '
    //   2314: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2317: pop
    //   2318: aload #11
    //   2320: iload #10
    //   2322: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   2325: pop
    //   2326: aload #11
    //   2328: ldc_w ' found '
    //   2331: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2334: pop
    //   2335: aload #11
    //   2337: aload_1
    //   2338: getfield mState : I
    //   2341: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   2344: pop
    //   2345: ldc 'FragmentManager'
    //   2347: aload #11
    //   2349: invokevirtual toString : ()Ljava/lang/String;
    //   2352: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   2355: pop
    //   2356: aload_1
    //   2357: iload #10
    //   2359: putfield mState : I
    //   2362: return
    // Exception table:
    //   from	to	target	type
    //   1044	1057	1060	android/content/res/Resources$NotFoundException
  }
  
  public void noteStateNotSaved() {
    byte b = 0;
    this.mStateSaved = false;
    this.mStopped = false;
    int i = this.mAdded.size();
    while (b < i) {
      Fragment fragment = this.mAdded.get(b);
      if (fragment != null)
        fragment.noteStateNotSaved(); 
      b++;
    } 
  }
  
  public View onCreateView(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    boolean bool = "fragment".equals(paramString);
    paramString = null;
    if (!bool)
      return null; 
    String str1 = paramAttributeSet.getAttributeValue(null, "class");
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, FragmentTag.Fragment);
    int i = 0;
    String str2 = str1;
    if (str1 == null)
      str2 = typedArray.getString(0); 
    int j = typedArray.getResourceId(1, -1);
    str1 = typedArray.getString(2);
    typedArray.recycle();
    if (str2 == null || !FragmentFactory.isFragmentClass(paramContext.getClassLoader(), str2))
      return null; 
    if (paramView != null)
      i = paramView.getId(); 
    if (i != -1 || j != -1 || str1 != null) {
      String str = paramString;
      if (j != -1)
        fragment1 = findFragmentById(j); 
      Fragment fragment2 = fragment1;
      if (fragment1 == null) {
        fragment2 = fragment1;
        if (str1 != null)
          fragment2 = findFragmentByTag(str1); 
      } 
      Fragment fragment1 = fragment2;
      if (fragment2 == null) {
        fragment1 = fragment2;
        if (i != -1)
          fragment1 = findFragmentById(i); 
      } 
      if (DEBUG) {
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("onCreateView: id=0x");
        stringBuilder2.append(Integer.toHexString(j));
        stringBuilder2.append(" fname=");
        stringBuilder2.append(str2);
        stringBuilder2.append(" existing=");
        stringBuilder2.append(fragment1);
        Log.v("FragmentManager", stringBuilder2.toString());
      } 
      if (fragment1 == null) {
        int k;
        fragment1 = getFragmentFactory().instantiate(paramContext.getClassLoader(), str2);
        fragment1.mFromLayout = true;
        if (j != 0) {
          k = j;
        } else {
          k = i;
        } 
        fragment1.mFragmentId = k;
        fragment1.mContainerId = i;
        fragment1.mTag = str1;
        fragment1.mInLayout = true;
        fragment1.mFragmentManager = this;
        FragmentHostCallback fragmentHostCallback = this.mHost;
        fragment1.mHost = fragmentHostCallback;
        fragment1.onInflate(fragmentHostCallback.getContext(), paramAttributeSet, fragment1.mSavedFragmentState);
        addFragment(fragment1, true);
      } else if (!fragment1.mInLayout) {
        fragment1.mInLayout = true;
        FragmentHostCallback fragmentHostCallback = this.mHost;
        fragment1.mHost = fragmentHostCallback;
        fragment1.onInflate(fragmentHostCallback.getContext(), paramAttributeSet, fragment1.mSavedFragmentState);
      } else {
        stringBuilder1 = new StringBuilder();
        stringBuilder1.append(paramAttributeSet.getPositionDescription());
        stringBuilder1.append(": Duplicate id 0x");
        stringBuilder1.append(Integer.toHexString(j));
        stringBuilder1.append(", tag ");
        stringBuilder1.append(str1);
        stringBuilder1.append(", or parent id 0x");
        stringBuilder1.append(Integer.toHexString(i));
        stringBuilder1.append(" with another fragment for ");
        stringBuilder1.append(str2);
        throw new IllegalArgumentException(stringBuilder1.toString());
      } 
      if (this.mCurState < 1 && ((Fragment)stringBuilder1).mFromLayout) {
        moveToState((Fragment)stringBuilder1, 1, 0, 0, false);
      } else {
        moveToState((Fragment)stringBuilder1);
      } 
      if (((Fragment)stringBuilder1).mView != null) {
        if (j != 0)
          ((Fragment)stringBuilder1).mView.setId(j); 
        if (((Fragment)stringBuilder1).mView.getTag() == null)
          ((Fragment)stringBuilder1).mView.setTag(str1); 
        return ((Fragment)stringBuilder1).mView;
      } 
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("Fragment ");
      stringBuilder1.append(str2);
      stringBuilder1.append(" did not create a view.");
      throw new IllegalStateException(stringBuilder1.toString());
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramAttributeSet.getPositionDescription());
    stringBuilder.append(": Must specify unique android:id, android:tag, or have a parent with an id for ");
    stringBuilder.append(str2);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public View onCreateView(String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    return onCreateView((View)null, paramString, paramContext, paramAttributeSet);
  }
  
  public void performPendingDeferredStart(Fragment paramFragment) {
    if (paramFragment.mDeferStart) {
      if (this.mExecutingActions) {
        this.mHavePendingDeferredStart = true;
        return;
      } 
      paramFragment.mDeferStart = false;
      moveToState(paramFragment, this.mCurState, 0, 0, false);
    } 
  }
  
  public void popBackStack() {
    enqueueAction(new PopBackStackState(null, -1, 0), false);
  }
  
  public void popBackStack(int paramInt1, int paramInt2) {
    if (paramInt1 >= 0) {
      enqueueAction(new PopBackStackState(null, paramInt1, paramInt2), false);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Bad id: ");
    stringBuilder.append(paramInt1);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void popBackStack(String paramString, int paramInt) {
    enqueueAction(new PopBackStackState(paramString, -1, paramInt), false);
  }
  
  public boolean popBackStackImmediate() {
    checkStateLoss();
    return popBackStackImmediate((String)null, -1, 0);
  }
  
  public boolean popBackStackImmediate(int paramInt1, int paramInt2) {
    checkStateLoss();
    execPendingActions();
    if (paramInt1 >= 0)
      return popBackStackImmediate((String)null, paramInt1, paramInt2); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Bad id: ");
    stringBuilder.append(paramInt1);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public boolean popBackStackImmediate(String paramString, int paramInt) {
    checkStateLoss();
    return popBackStackImmediate(paramString, -1, paramInt);
  }
  
  boolean popBackStackState(ArrayList<BackStackRecord> paramArrayList, ArrayList<Boolean> paramArrayList1, String paramString, int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: getfield mBackStack : Ljava/util/ArrayList;
    //   4: astore #6
    //   6: aload #6
    //   8: ifnonnull -> 13
    //   11: iconst_0
    //   12: ireturn
    //   13: aload_3
    //   14: ifnonnull -> 71
    //   17: iload #4
    //   19: ifge -> 71
    //   22: iload #5
    //   24: iconst_1
    //   25: iand
    //   26: ifne -> 71
    //   29: aload #6
    //   31: invokevirtual size : ()I
    //   34: iconst_1
    //   35: isub
    //   36: istore #4
    //   38: iload #4
    //   40: ifge -> 45
    //   43: iconst_0
    //   44: ireturn
    //   45: aload_1
    //   46: aload_0
    //   47: getfield mBackStack : Ljava/util/ArrayList;
    //   50: iload #4
    //   52: invokevirtual remove : (I)Ljava/lang/Object;
    //   55: invokevirtual add : (Ljava/lang/Object;)Z
    //   58: pop
    //   59: aload_2
    //   60: iconst_1
    //   61: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   64: invokevirtual add : (Ljava/lang/Object;)Z
    //   67: pop
    //   68: goto -> 322
    //   71: aload_3
    //   72: ifnonnull -> 89
    //   75: iload #4
    //   77: iflt -> 83
    //   80: goto -> 89
    //   83: iconst_m1
    //   84: istore #7
    //   86: goto -> 259
    //   89: aload_0
    //   90: getfield mBackStack : Ljava/util/ArrayList;
    //   93: invokevirtual size : ()I
    //   96: iconst_1
    //   97: isub
    //   98: istore #8
    //   100: iload #8
    //   102: iflt -> 162
    //   105: aload_0
    //   106: getfield mBackStack : Ljava/util/ArrayList;
    //   109: iload #8
    //   111: invokevirtual get : (I)Ljava/lang/Object;
    //   114: checkcast androidx/fragment/app/BackStackRecord
    //   117: astore #6
    //   119: aload_3
    //   120: ifnull -> 138
    //   123: aload_3
    //   124: aload #6
    //   126: invokevirtual getName : ()Ljava/lang/String;
    //   129: invokevirtual equals : (Ljava/lang/Object;)Z
    //   132: ifeq -> 138
    //   135: goto -> 162
    //   138: iload #4
    //   140: iflt -> 156
    //   143: iload #4
    //   145: aload #6
    //   147: getfield mIndex : I
    //   150: if_icmpne -> 156
    //   153: goto -> 162
    //   156: iinc #8, -1
    //   159: goto -> 100
    //   162: iload #8
    //   164: ifge -> 169
    //   167: iconst_0
    //   168: ireturn
    //   169: iload #8
    //   171: istore #7
    //   173: iload #5
    //   175: iconst_1
    //   176: iand
    //   177: ifeq -> 259
    //   180: iload #8
    //   182: iconst_1
    //   183: isub
    //   184: istore #5
    //   186: iload #5
    //   188: istore #7
    //   190: iload #5
    //   192: iflt -> 259
    //   195: aload_0
    //   196: getfield mBackStack : Ljava/util/ArrayList;
    //   199: iload #5
    //   201: invokevirtual get : (I)Ljava/lang/Object;
    //   204: checkcast androidx/fragment/app/BackStackRecord
    //   207: astore #6
    //   209: aload_3
    //   210: ifnull -> 229
    //   213: iload #5
    //   215: istore #8
    //   217: aload_3
    //   218: aload #6
    //   220: invokevirtual getName : ()Ljava/lang/String;
    //   223: invokevirtual equals : (Ljava/lang/Object;)Z
    //   226: ifne -> 180
    //   229: iload #5
    //   231: istore #7
    //   233: iload #4
    //   235: iflt -> 259
    //   238: iload #5
    //   240: istore #7
    //   242: iload #4
    //   244: aload #6
    //   246: getfield mIndex : I
    //   249: if_icmpne -> 259
    //   252: iload #5
    //   254: istore #8
    //   256: goto -> 180
    //   259: iload #7
    //   261: aload_0
    //   262: getfield mBackStack : Ljava/util/ArrayList;
    //   265: invokevirtual size : ()I
    //   268: iconst_1
    //   269: isub
    //   270: if_icmpne -> 275
    //   273: iconst_0
    //   274: ireturn
    //   275: aload_0
    //   276: getfield mBackStack : Ljava/util/ArrayList;
    //   279: invokevirtual size : ()I
    //   282: iconst_1
    //   283: isub
    //   284: istore #4
    //   286: iload #4
    //   288: iload #7
    //   290: if_icmple -> 322
    //   293: aload_1
    //   294: aload_0
    //   295: getfield mBackStack : Ljava/util/ArrayList;
    //   298: iload #4
    //   300: invokevirtual remove : (I)Ljava/lang/Object;
    //   303: invokevirtual add : (Ljava/lang/Object;)Z
    //   306: pop
    //   307: aload_2
    //   308: iconst_1
    //   309: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   312: invokevirtual add : (Ljava/lang/Object;)Z
    //   315: pop
    //   316: iinc #4, -1
    //   319: goto -> 286
    //   322: iconst_1
    //   323: ireturn
  }
  
  public void putFragment(Bundle paramBundle, String paramString, Fragment paramFragment) {
    if (paramFragment.mFragmentManager != this) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Fragment ");
      stringBuilder.append(paramFragment);
      stringBuilder.append(" is not currently in the FragmentManager");
      throwException(new IllegalStateException(stringBuilder.toString()));
    } 
    paramBundle.putString(paramString, paramFragment.mWho);
  }
  
  public void registerFragmentLifecycleCallbacks(FragmentManager.FragmentLifecycleCallbacks paramFragmentLifecycleCallbacks, boolean paramBoolean) {
    this.mLifecycleCallbacks.add(new FragmentLifecycleCallbacksHolder(paramFragmentLifecycleCallbacks, paramBoolean));
  }
  
  public void removeFragment(Fragment paramFragment) {
    if (DEBUG) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("remove: ");
      stringBuilder.append(paramFragment);
      stringBuilder.append(" nesting=");
      stringBuilder.append(paramFragment.mBackStackNesting);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    boolean bool = paramFragment.isInBackStack();
    if (!paramFragment.mDetached || (bool ^ true) != 0)
      synchronized (this.mAdded) {
        this.mAdded.remove(paramFragment);
        if (isMenuAvailable(paramFragment))
          this.mNeedMenuInvalidate = true; 
        paramFragment.mAdded = false;
        paramFragment.mRemoving = true;
        return;
      }  
  }
  
  public void removeOnBackStackChangedListener(FragmentManager.OnBackStackChangedListener paramOnBackStackChangedListener) {
    ArrayList<FragmentManager.OnBackStackChangedListener> arrayList = this.mBackStackChangeListeners;
    if (arrayList != null)
      arrayList.remove(paramOnBackStackChangedListener); 
  }
  
  void removeRetainedFragment(Fragment paramFragment) {
    if (isStateSaved()) {
      if (DEBUG)
        Log.v("FragmentManager", "Ignoring removeRetainedFragment as the state is already saved"); 
      return;
    } 
    if (this.mNonConfig.removeRetainedFragment(paramFragment) && DEBUG) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Updating retained Fragments: Removed ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
  }
  
  void reportBackStackChanged() {
    if (this.mBackStackChangeListeners != null)
      for (byte b = 0; b < this.mBackStackChangeListeners.size(); b++)
        ((FragmentManager.OnBackStackChangedListener)this.mBackStackChangeListeners.get(b)).onBackStackChanged();  
  }
  
  void restoreAllState(Parcelable paramParcelable, FragmentManagerNonConfig paramFragmentManagerNonConfig) {
    if (this.mHost instanceof ViewModelStoreOwner)
      throwException(new IllegalStateException("You must use restoreSaveState when your FragmentHostCallback implements ViewModelStoreOwner")); 
    this.mNonConfig.restoreFromSnapshot(paramFragmentManagerNonConfig);
    restoreSaveState(paramParcelable);
  }
  
  void restoreSaveState(Parcelable paramParcelable) {
    // Byte code:
    //   0: aload_1
    //   1: ifnonnull -> 5
    //   4: return
    //   5: aload_1
    //   6: checkcast androidx/fragment/app/FragmentManagerState
    //   9: astore_2
    //   10: aload_2
    //   11: getfield mActive : Ljava/util/ArrayList;
    //   14: ifnonnull -> 18
    //   17: return
    //   18: aload_0
    //   19: getfield mNonConfig : Landroidx/fragment/app/FragmentManagerViewModel;
    //   22: invokevirtual getRetainedFragments : ()Ljava/util/Collection;
    //   25: invokeinterface iterator : ()Ljava/util/Iterator;
    //   30: astore_3
    //   31: aload_3
    //   32: invokeinterface hasNext : ()Z
    //   37: ifeq -> 346
    //   40: aload_3
    //   41: invokeinterface next : ()Ljava/lang/Object;
    //   46: checkcast androidx/fragment/app/Fragment
    //   49: astore #4
    //   51: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   54: ifeq -> 90
    //   57: new java/lang/StringBuilder
    //   60: dup
    //   61: invokespecial <init> : ()V
    //   64: astore_1
    //   65: aload_1
    //   66: ldc_w 'restoreSaveState: re-attaching retained '
    //   69: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   72: pop
    //   73: aload_1
    //   74: aload #4
    //   76: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   79: pop
    //   80: ldc 'FragmentManager'
    //   82: aload_1
    //   83: invokevirtual toString : ()Ljava/lang/String;
    //   86: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   89: pop
    //   90: aload_2
    //   91: getfield mActive : Ljava/util/ArrayList;
    //   94: invokevirtual iterator : ()Ljava/util/Iterator;
    //   97: astore #5
    //   99: aload #5
    //   101: invokeinterface hasNext : ()Z
    //   106: ifeq -> 138
    //   109: aload #5
    //   111: invokeinterface next : ()Ljava/lang/Object;
    //   116: checkcast androidx/fragment/app/FragmentState
    //   119: astore_1
    //   120: aload_1
    //   121: getfield mWho : Ljava/lang/String;
    //   124: aload #4
    //   126: getfield mWho : Ljava/lang/String;
    //   129: invokevirtual equals : (Ljava/lang/Object;)Z
    //   132: ifeq -> 99
    //   135: goto -> 140
    //   138: aconst_null
    //   139: astore_1
    //   140: aload_1
    //   141: ifnonnull -> 229
    //   144: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   147: ifeq -> 200
    //   150: new java/lang/StringBuilder
    //   153: dup
    //   154: invokespecial <init> : ()V
    //   157: astore_1
    //   158: aload_1
    //   159: ldc_w 'Discarding retained Fragment '
    //   162: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   165: pop
    //   166: aload_1
    //   167: aload #4
    //   169: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   172: pop
    //   173: aload_1
    //   174: ldc_w ' that was not found in the set of active Fragments '
    //   177: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   180: pop
    //   181: aload_1
    //   182: aload_2
    //   183: getfield mActive : Ljava/util/ArrayList;
    //   186: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   189: pop
    //   190: ldc 'FragmentManager'
    //   192: aload_1
    //   193: invokevirtual toString : ()Ljava/lang/String;
    //   196: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   199: pop
    //   200: aload_0
    //   201: aload #4
    //   203: iconst_1
    //   204: iconst_0
    //   205: iconst_0
    //   206: iconst_0
    //   207: invokevirtual moveToState : (Landroidx/fragment/app/Fragment;IIIZ)V
    //   210: aload #4
    //   212: iconst_1
    //   213: putfield mRemoving : Z
    //   216: aload_0
    //   217: aload #4
    //   219: iconst_0
    //   220: iconst_0
    //   221: iconst_0
    //   222: iconst_0
    //   223: invokevirtual moveToState : (Landroidx/fragment/app/Fragment;IIIZ)V
    //   226: goto -> 31
    //   229: aload_1
    //   230: aload #4
    //   232: putfield mInstance : Landroidx/fragment/app/Fragment;
    //   235: aload #4
    //   237: aconst_null
    //   238: putfield mSavedViewState : Landroid/util/SparseArray;
    //   241: aload #4
    //   243: iconst_0
    //   244: putfield mBackStackNesting : I
    //   247: aload #4
    //   249: iconst_0
    //   250: putfield mInLayout : Z
    //   253: aload #4
    //   255: iconst_0
    //   256: putfield mAdded : Z
    //   259: aload #4
    //   261: getfield mTarget : Landroidx/fragment/app/Fragment;
    //   264: ifnull -> 280
    //   267: aload #4
    //   269: getfield mTarget : Landroidx/fragment/app/Fragment;
    //   272: getfield mWho : Ljava/lang/String;
    //   275: astore #5
    //   277: goto -> 283
    //   280: aconst_null
    //   281: astore #5
    //   283: aload #4
    //   285: aload #5
    //   287: putfield mTargetWho : Ljava/lang/String;
    //   290: aload #4
    //   292: aconst_null
    //   293: putfield mTarget : Landroidx/fragment/app/Fragment;
    //   296: aload_1
    //   297: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   300: ifnull -> 31
    //   303: aload_1
    //   304: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   307: aload_0
    //   308: getfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   311: invokevirtual getContext : ()Landroid/content/Context;
    //   314: invokevirtual getClassLoader : ()Ljava/lang/ClassLoader;
    //   317: invokevirtual setClassLoader : (Ljava/lang/ClassLoader;)V
    //   320: aload #4
    //   322: aload_1
    //   323: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   326: ldc 'android:view_state'
    //   328: invokevirtual getSparseParcelableArray : (Ljava/lang/String;)Landroid/util/SparseArray;
    //   331: putfield mSavedViewState : Landroid/util/SparseArray;
    //   334: aload #4
    //   336: aload_1
    //   337: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   340: putfield mSavedFragmentState : Landroid/os/Bundle;
    //   343: goto -> 31
    //   346: aload_0
    //   347: getfield mActive : Ljava/util/HashMap;
    //   350: invokevirtual clear : ()V
    //   353: aload_2
    //   354: getfield mActive : Ljava/util/ArrayList;
    //   357: invokevirtual iterator : ()Ljava/util/Iterator;
    //   360: astore_1
    //   361: aload_1
    //   362: invokeinterface hasNext : ()Z
    //   367: ifeq -> 496
    //   370: aload_1
    //   371: invokeinterface next : ()Ljava/lang/Object;
    //   376: checkcast androidx/fragment/app/FragmentState
    //   379: astore_3
    //   380: aload_3
    //   381: ifnull -> 361
    //   384: aload_3
    //   385: aload_0
    //   386: getfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   389: invokevirtual getContext : ()Landroid/content/Context;
    //   392: invokevirtual getClassLoader : ()Ljava/lang/ClassLoader;
    //   395: aload_0
    //   396: invokevirtual getFragmentFactory : ()Landroidx/fragment/app/FragmentFactory;
    //   399: invokevirtual instantiate : (Ljava/lang/ClassLoader;Landroidx/fragment/app/FragmentFactory;)Landroidx/fragment/app/Fragment;
    //   402: astore #4
    //   404: aload #4
    //   406: aload_0
    //   407: putfield mFragmentManager : Landroidx/fragment/app/FragmentManagerImpl;
    //   410: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   413: ifeq -> 473
    //   416: new java/lang/StringBuilder
    //   419: dup
    //   420: invokespecial <init> : ()V
    //   423: astore #5
    //   425: aload #5
    //   427: ldc_w 'restoreSaveState: active ('
    //   430: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   433: pop
    //   434: aload #5
    //   436: aload #4
    //   438: getfield mWho : Ljava/lang/String;
    //   441: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   444: pop
    //   445: aload #5
    //   447: ldc_w '): '
    //   450: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   453: pop
    //   454: aload #5
    //   456: aload #4
    //   458: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   461: pop
    //   462: ldc 'FragmentManager'
    //   464: aload #5
    //   466: invokevirtual toString : ()Ljava/lang/String;
    //   469: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   472: pop
    //   473: aload_0
    //   474: getfield mActive : Ljava/util/HashMap;
    //   477: aload #4
    //   479: getfield mWho : Ljava/lang/String;
    //   482: aload #4
    //   484: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   487: pop
    //   488: aload_3
    //   489: aconst_null
    //   490: putfield mInstance : Landroidx/fragment/app/Fragment;
    //   493: goto -> 361
    //   496: aload_0
    //   497: getfield mAdded : Ljava/util/ArrayList;
    //   500: invokevirtual clear : ()V
    //   503: aload_2
    //   504: getfield mAdded : Ljava/util/ArrayList;
    //   507: ifnull -> 744
    //   510: aload_2
    //   511: getfield mAdded : Ljava/util/ArrayList;
    //   514: invokevirtual iterator : ()Ljava/util/Iterator;
    //   517: astore #5
    //   519: aload #5
    //   521: invokeinterface hasNext : ()Z
    //   526: ifeq -> 744
    //   529: aload #5
    //   531: invokeinterface next : ()Ljava/lang/Object;
    //   536: checkcast java/lang/String
    //   539: astore_3
    //   540: aload_0
    //   541: getfield mActive : Ljava/util/HashMap;
    //   544: aload_3
    //   545: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   548: checkcast androidx/fragment/app/Fragment
    //   551: astore_1
    //   552: aload_1
    //   553: ifnonnull -> 606
    //   556: new java/lang/StringBuilder
    //   559: dup
    //   560: invokespecial <init> : ()V
    //   563: astore #4
    //   565: aload #4
    //   567: ldc_w 'No instantiated fragment for ('
    //   570: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   573: pop
    //   574: aload #4
    //   576: aload_3
    //   577: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   580: pop
    //   581: aload #4
    //   583: ldc_w ')'
    //   586: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   589: pop
    //   590: aload_0
    //   591: new java/lang/IllegalStateException
    //   594: dup
    //   595: aload #4
    //   597: invokevirtual toString : ()Ljava/lang/String;
    //   600: invokespecial <init> : (Ljava/lang/String;)V
    //   603: invokespecial throwException : (Ljava/lang/RuntimeException;)V
    //   606: aload_1
    //   607: iconst_1
    //   608: putfield mAdded : Z
    //   611: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   614: ifeq -> 669
    //   617: new java/lang/StringBuilder
    //   620: dup
    //   621: invokespecial <init> : ()V
    //   624: astore #4
    //   626: aload #4
    //   628: ldc_w 'restoreSaveState: added ('
    //   631: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   634: pop
    //   635: aload #4
    //   637: aload_3
    //   638: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   641: pop
    //   642: aload #4
    //   644: ldc_w '): '
    //   647: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   650: pop
    //   651: aload #4
    //   653: aload_1
    //   654: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   657: pop
    //   658: ldc 'FragmentManager'
    //   660: aload #4
    //   662: invokevirtual toString : ()Ljava/lang/String;
    //   665: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   668: pop
    //   669: aload_0
    //   670: getfield mAdded : Ljava/util/ArrayList;
    //   673: aload_1
    //   674: invokevirtual contains : (Ljava/lang/Object;)Z
    //   677: ifne -> 706
    //   680: aload_0
    //   681: getfield mAdded : Ljava/util/ArrayList;
    //   684: astore_3
    //   685: aload_3
    //   686: monitorenter
    //   687: aload_0
    //   688: getfield mAdded : Ljava/util/ArrayList;
    //   691: aload_1
    //   692: invokevirtual add : (Ljava/lang/Object;)Z
    //   695: pop
    //   696: aload_3
    //   697: monitorexit
    //   698: goto -> 519
    //   701: astore_1
    //   702: aload_3
    //   703: monitorexit
    //   704: aload_1
    //   705: athrow
    //   706: new java/lang/StringBuilder
    //   709: dup
    //   710: invokespecial <init> : ()V
    //   713: astore #5
    //   715: aload #5
    //   717: ldc_w 'Already added '
    //   720: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   723: pop
    //   724: aload #5
    //   726: aload_1
    //   727: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   730: pop
    //   731: new java/lang/IllegalStateException
    //   734: dup
    //   735: aload #5
    //   737: invokevirtual toString : ()Ljava/lang/String;
    //   740: invokespecial <init> : (Ljava/lang/String;)V
    //   743: athrow
    //   744: aload_2
    //   745: getfield mBackStack : [Landroidx/fragment/app/BackStackState;
    //   748: ifnull -> 934
    //   751: aload_0
    //   752: new java/util/ArrayList
    //   755: dup
    //   756: aload_2
    //   757: getfield mBackStack : [Landroidx/fragment/app/BackStackState;
    //   760: arraylength
    //   761: invokespecial <init> : (I)V
    //   764: putfield mBackStack : Ljava/util/ArrayList;
    //   767: iconst_0
    //   768: istore #6
    //   770: iload #6
    //   772: aload_2
    //   773: getfield mBackStack : [Landroidx/fragment/app/BackStackState;
    //   776: arraylength
    //   777: if_icmpge -> 939
    //   780: aload_2
    //   781: getfield mBackStack : [Landroidx/fragment/app/BackStackState;
    //   784: iload #6
    //   786: aaload
    //   787: aload_0
    //   788: invokevirtual instantiate : (Landroidx/fragment/app/FragmentManagerImpl;)Landroidx/fragment/app/BackStackRecord;
    //   791: astore_1
    //   792: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   795: ifeq -> 903
    //   798: new java/lang/StringBuilder
    //   801: dup
    //   802: invokespecial <init> : ()V
    //   805: astore #5
    //   807: aload #5
    //   809: ldc_w 'restoreAllState: back stack #'
    //   812: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   815: pop
    //   816: aload #5
    //   818: iload #6
    //   820: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   823: pop
    //   824: aload #5
    //   826: ldc_w ' (index '
    //   829: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   832: pop
    //   833: aload #5
    //   835: aload_1
    //   836: getfield mIndex : I
    //   839: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   842: pop
    //   843: aload #5
    //   845: ldc_w '): '
    //   848: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   851: pop
    //   852: aload #5
    //   854: aload_1
    //   855: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   858: pop
    //   859: ldc 'FragmentManager'
    //   861: aload #5
    //   863: invokevirtual toString : ()Ljava/lang/String;
    //   866: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   869: pop
    //   870: new java/io/PrintWriter
    //   873: dup
    //   874: new androidx/core/util/LogWriter
    //   877: dup
    //   878: ldc 'FragmentManager'
    //   880: invokespecial <init> : (Ljava/lang/String;)V
    //   883: invokespecial <init> : (Ljava/io/Writer;)V
    //   886: astore #5
    //   888: aload_1
    //   889: ldc_w '  '
    //   892: aload #5
    //   894: iconst_0
    //   895: invokevirtual dump : (Ljava/lang/String;Ljava/io/PrintWriter;Z)V
    //   898: aload #5
    //   900: invokevirtual close : ()V
    //   903: aload_0
    //   904: getfield mBackStack : Ljava/util/ArrayList;
    //   907: aload_1
    //   908: invokevirtual add : (Ljava/lang/Object;)Z
    //   911: pop
    //   912: aload_1
    //   913: getfield mIndex : I
    //   916: iflt -> 928
    //   919: aload_0
    //   920: aload_1
    //   921: getfield mIndex : I
    //   924: aload_1
    //   925: invokevirtual setBackStackIndex : (ILandroidx/fragment/app/BackStackRecord;)V
    //   928: iinc #6, 1
    //   931: goto -> 770
    //   934: aload_0
    //   935: aconst_null
    //   936: putfield mBackStack : Ljava/util/ArrayList;
    //   939: aload_2
    //   940: getfield mPrimaryNavActiveWho : Ljava/lang/String;
    //   943: ifnull -> 972
    //   946: aload_0
    //   947: aload_0
    //   948: getfield mActive : Ljava/util/HashMap;
    //   951: aload_2
    //   952: getfield mPrimaryNavActiveWho : Ljava/lang/String;
    //   955: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   958: checkcast androidx/fragment/app/Fragment
    //   961: putfield mPrimaryNav : Landroidx/fragment/app/Fragment;
    //   964: aload_0
    //   965: aload_0
    //   966: getfield mPrimaryNav : Landroidx/fragment/app/Fragment;
    //   969: invokespecial dispatchParentPrimaryNavigationFragmentChanged : (Landroidx/fragment/app/Fragment;)V
    //   972: aload_0
    //   973: aload_2
    //   974: getfield mNextFragmentIndex : I
    //   977: putfield mNextFragmentIndex : I
    //   980: return
    // Exception table:
    //   from	to	target	type
    //   687	698	701	finally
    //   702	704	701	finally
  }
  
  @Deprecated
  FragmentManagerNonConfig retainNonConfig() {
    if (this.mHost instanceof ViewModelStoreOwner)
      throwException(new IllegalStateException("You cannot use retainNonConfig when your FragmentHostCallback implements ViewModelStoreOwner.")); 
    return this.mNonConfig.getSnapshot();
  }
  
  Parcelable saveAllState() {
    StringBuilder stringBuilder;
    ArrayList arrayList1;
    forcePostponedTransactions();
    endAnimatingAwayFragments();
    execPendingActions();
    this.mStateSaved = true;
    boolean bool = this.mActive.isEmpty();
    Iterator<Fragment> iterator1 = null;
    if (bool)
      return null; 
    ArrayList<FragmentState> arrayList = new ArrayList(this.mActive.size());
    Iterator<Fragment> iterator2 = this.mActive.values().iterator();
    boolean bool1 = false;
    int i = 0;
    while (iterator2.hasNext()) {
      arrayList1 = (ArrayList)iterator2.next();
      if (arrayList1 != null) {
        if (((Fragment)arrayList1).mFragmentManager != this) {
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append("Failure saving state: active ");
          stringBuilder1.append(arrayList1);
          stringBuilder1.append(" was removed from the FragmentManager");
          throwException(new IllegalStateException(stringBuilder1.toString()));
        } 
        FragmentState fragmentState = new FragmentState((Fragment)arrayList1);
        arrayList.add(fragmentState);
        if (((Fragment)arrayList1).mState > 0 && fragmentState.mSavedFragmentState == null) {
          fragmentState.mSavedFragmentState = saveFragmentBasicState((Fragment)arrayList1);
          if (((Fragment)arrayList1).mTargetWho != null) {
            Fragment fragment1 = this.mActive.get(((Fragment)arrayList1).mTargetWho);
            if (fragment1 == null) {
              StringBuilder stringBuilder1 = new StringBuilder();
              stringBuilder1.append("Failure saving state: ");
              stringBuilder1.append(arrayList1);
              stringBuilder1.append(" has target not in fragment manager: ");
              stringBuilder1.append(((Fragment)arrayList1).mTargetWho);
              throwException(new IllegalStateException(stringBuilder1.toString()));
            } 
            if (fragmentState.mSavedFragmentState == null)
              fragmentState.mSavedFragmentState = new Bundle(); 
            putFragment(fragmentState.mSavedFragmentState, "android:target_state", fragment1);
            if (((Fragment)arrayList1).mTargetRequestCode != 0)
              fragmentState.mSavedFragmentState.putInt("android:target_req_state", ((Fragment)arrayList1).mTargetRequestCode); 
          } 
        } else {
          fragmentState.mSavedFragmentState = ((Fragment)arrayList1).mSavedFragmentState;
        } 
        if (DEBUG) {
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append("Saved state of ");
          stringBuilder1.append(arrayList1);
          stringBuilder1.append(": ");
          stringBuilder1.append(fragmentState.mSavedFragmentState);
          Log.v("FragmentManager", stringBuilder1.toString());
        } 
        i = 1;
      } 
    } 
    if (!i) {
      if (DEBUG)
        Log.v("FragmentManager", "saveAllState: no fragments!"); 
      return null;
    } 
    i = this.mAdded.size();
    if (i > 0) {
      ArrayList<String> arrayList3 = new ArrayList(i);
      Iterator<Fragment> iterator = this.mAdded.iterator();
      while (true) {
        arrayList1 = arrayList3;
        if (iterator.hasNext()) {
          Fragment fragment1 = iterator.next();
          arrayList3.add(fragment1.mWho);
          if (fragment1.mFragmentManager != this) {
            StringBuilder stringBuilder1 = new StringBuilder();
            stringBuilder1.append("Failure saving state: active ");
            stringBuilder1.append(fragment1);
            stringBuilder1.append(" was removed from the FragmentManager");
            throwException(new IllegalStateException(stringBuilder1.toString()));
          } 
          if (DEBUG) {
            StringBuilder stringBuilder1 = new StringBuilder();
            stringBuilder1.append("saveAllState: adding fragment (");
            stringBuilder1.append(fragment1.mWho);
            stringBuilder1.append("): ");
            stringBuilder1.append(fragment1);
            Log.v("FragmentManager", stringBuilder1.toString());
          } 
          continue;
        } 
        break;
      } 
    } else {
      arrayList1 = null;
    } 
    ArrayList<BackStackRecord> arrayList2 = this.mBackStack;
    iterator2 = iterator1;
    if (arrayList2 != null) {
      int j = arrayList2.size();
      iterator2 = iterator1;
      if (j > 0) {
        BackStackState[] arrayOfBackStackState = new BackStackState[j];
        i = bool1;
        while (true) {
          BackStackState[] arrayOfBackStackState1 = arrayOfBackStackState;
          if (i < j) {
            arrayOfBackStackState[i] = new BackStackState(this.mBackStack.get(i));
            if (DEBUG) {
              stringBuilder = new StringBuilder();
              stringBuilder.append("saveAllState: adding back stack #");
              stringBuilder.append(i);
              stringBuilder.append(": ");
              stringBuilder.append(this.mBackStack.get(i));
              Log.v("FragmentManager", stringBuilder.toString());
            } 
            i++;
            continue;
          } 
          break;
        } 
      } 
    } 
    FragmentManagerState fragmentManagerState = new FragmentManagerState();
    fragmentManagerState.mActive = arrayList;
    fragmentManagerState.mAdded = arrayList1;
    fragmentManagerState.mBackStack = (BackStackState[])stringBuilder;
    Fragment fragment = this.mPrimaryNav;
    if (fragment != null)
      fragmentManagerState.mPrimaryNavActiveWho = fragment.mWho; 
    fragmentManagerState.mNextFragmentIndex = this.mNextFragmentIndex;
    return fragmentManagerState;
  }
  
  Bundle saveFragmentBasicState(Fragment paramFragment) {
    if (this.mStateBundle == null)
      this.mStateBundle = new Bundle(); 
    paramFragment.performSaveInstanceState(this.mStateBundle);
    dispatchOnFragmentSaveInstanceState(paramFragment, this.mStateBundle, false);
    if (!this.mStateBundle.isEmpty()) {
      bundle1 = this.mStateBundle;
      this.mStateBundle = null;
    } else {
      bundle1 = null;
    } 
    if (paramFragment.mView != null)
      saveFragmentViewState(paramFragment); 
    Bundle bundle2 = bundle1;
    if (paramFragment.mSavedViewState != null) {
      bundle2 = bundle1;
      if (bundle1 == null)
        bundle2 = new Bundle(); 
      bundle2.putSparseParcelableArray("android:view_state", paramFragment.mSavedViewState);
    } 
    Bundle bundle1 = bundle2;
    if (!paramFragment.mUserVisibleHint) {
      bundle1 = bundle2;
      if (bundle2 == null)
        bundle1 = new Bundle(); 
      bundle1.putBoolean("android:user_visible_hint", paramFragment.mUserVisibleHint);
    } 
    return bundle1;
  }
  
  public Fragment.SavedState saveFragmentInstanceState(Fragment paramFragment) {
    if (paramFragment.mFragmentManager != this) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Fragment ");
      stringBuilder.append(paramFragment);
      stringBuilder.append(" is not currently in the FragmentManager");
      throwException(new IllegalStateException(stringBuilder.toString()));
    } 
    int i = paramFragment.mState;
    Fragment.SavedState savedState2 = null;
    Fragment.SavedState savedState1 = savedState2;
    if (i > 0) {
      Bundle bundle = saveFragmentBasicState(paramFragment);
      savedState1 = savedState2;
      if (bundle != null)
        savedState1 = new Fragment.SavedState(bundle); 
    } 
    return savedState1;
  }
  
  void saveFragmentViewState(Fragment paramFragment) {
    if (paramFragment.mInnerView == null)
      return; 
    SparseArray<Parcelable> sparseArray = this.mStateArray;
    if (sparseArray == null) {
      this.mStateArray = new SparseArray();
    } else {
      sparseArray.clear();
    } 
    paramFragment.mInnerView.saveHierarchyState(this.mStateArray);
    if (this.mStateArray.size() > 0) {
      paramFragment.mSavedViewState = this.mStateArray;
      this.mStateArray = null;
    } 
  }
  
  void scheduleCommit() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mPostponedTransactions : Ljava/util/ArrayList;
    //   6: astore_1
    //   7: iconst_0
    //   8: istore_2
    //   9: aload_1
    //   10: ifnull -> 28
    //   13: aload_0
    //   14: getfield mPostponedTransactions : Ljava/util/ArrayList;
    //   17: invokevirtual isEmpty : ()Z
    //   20: ifne -> 28
    //   23: iconst_1
    //   24: istore_3
    //   25: goto -> 30
    //   28: iconst_0
    //   29: istore_3
    //   30: iload_2
    //   31: istore #4
    //   33: aload_0
    //   34: getfield mPendingActions : Ljava/util/ArrayList;
    //   37: ifnull -> 57
    //   40: iload_2
    //   41: istore #4
    //   43: aload_0
    //   44: getfield mPendingActions : Ljava/util/ArrayList;
    //   47: invokevirtual size : ()I
    //   50: iconst_1
    //   51: if_icmpne -> 57
    //   54: iconst_1
    //   55: istore #4
    //   57: iload_3
    //   58: ifne -> 66
    //   61: iload #4
    //   63: ifeq -> 99
    //   66: aload_0
    //   67: getfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   70: invokevirtual getHandler : ()Landroid/os/Handler;
    //   73: aload_0
    //   74: getfield mExecCommit : Ljava/lang/Runnable;
    //   77: invokevirtual removeCallbacks : (Ljava/lang/Runnable;)V
    //   80: aload_0
    //   81: getfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   84: invokevirtual getHandler : ()Landroid/os/Handler;
    //   87: aload_0
    //   88: getfield mExecCommit : Ljava/lang/Runnable;
    //   91: invokevirtual post : (Ljava/lang/Runnable;)Z
    //   94: pop
    //   95: aload_0
    //   96: invokespecial updateOnBackPressedCallbackEnabled : ()V
    //   99: aload_0
    //   100: monitorexit
    //   101: return
    //   102: astore_1
    //   103: aload_0
    //   104: monitorexit
    //   105: aload_1
    //   106: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	102	finally
    //   13	23	102	finally
    //   33	40	102	finally
    //   43	54	102	finally
    //   66	99	102	finally
    //   99	101	102	finally
    //   103	105	102	finally
  }
  
  public void setBackStackIndex(int paramInt, BackStackRecord paramBackStackRecord) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   6: ifnonnull -> 22
    //   9: new java/util/ArrayList
    //   12: astore_3
    //   13: aload_3
    //   14: invokespecial <init> : ()V
    //   17: aload_0
    //   18: aload_3
    //   19: putfield mBackStackIndices : Ljava/util/ArrayList;
    //   22: aload_0
    //   23: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   26: invokevirtual size : ()I
    //   29: istore #4
    //   31: iload #4
    //   33: istore #5
    //   35: iload_1
    //   36: iload #4
    //   38: if_icmpge -> 106
    //   41: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   44: ifeq -> 93
    //   47: new java/lang/StringBuilder
    //   50: astore_3
    //   51: aload_3
    //   52: invokespecial <init> : ()V
    //   55: aload_3
    //   56: ldc_w 'Setting back stack index '
    //   59: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   62: pop
    //   63: aload_3
    //   64: iload_1
    //   65: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   68: pop
    //   69: aload_3
    //   70: ldc_w ' to '
    //   73: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   76: pop
    //   77: aload_3
    //   78: aload_2
    //   79: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   82: pop
    //   83: ldc 'FragmentManager'
    //   85: aload_3
    //   86: invokevirtual toString : ()Ljava/lang/String;
    //   89: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   92: pop
    //   93: aload_0
    //   94: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   97: iload_1
    //   98: aload_2
    //   99: invokevirtual set : (ILjava/lang/Object;)Ljava/lang/Object;
    //   102: pop
    //   103: goto -> 260
    //   106: iload #5
    //   108: iload_1
    //   109: if_icmpge -> 199
    //   112: aload_0
    //   113: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   116: aconst_null
    //   117: invokevirtual add : (Ljava/lang/Object;)Z
    //   120: pop
    //   121: aload_0
    //   122: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   125: ifnonnull -> 141
    //   128: new java/util/ArrayList
    //   131: astore_3
    //   132: aload_3
    //   133: invokespecial <init> : ()V
    //   136: aload_0
    //   137: aload_3
    //   138: putfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   141: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   144: ifeq -> 180
    //   147: new java/lang/StringBuilder
    //   150: astore_3
    //   151: aload_3
    //   152: invokespecial <init> : ()V
    //   155: aload_3
    //   156: ldc_w 'Adding available back stack index '
    //   159: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   162: pop
    //   163: aload_3
    //   164: iload #5
    //   166: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   169: pop
    //   170: ldc 'FragmentManager'
    //   172: aload_3
    //   173: invokevirtual toString : ()Ljava/lang/String;
    //   176: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   179: pop
    //   180: aload_0
    //   181: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   184: iload #5
    //   186: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   189: invokevirtual add : (Ljava/lang/Object;)Z
    //   192: pop
    //   193: iinc #5, 1
    //   196: goto -> 106
    //   199: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   202: ifeq -> 251
    //   205: new java/lang/StringBuilder
    //   208: astore_3
    //   209: aload_3
    //   210: invokespecial <init> : ()V
    //   213: aload_3
    //   214: ldc_w 'Adding back stack index '
    //   217: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   220: pop
    //   221: aload_3
    //   222: iload_1
    //   223: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   226: pop
    //   227: aload_3
    //   228: ldc_w ' with '
    //   231: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   234: pop
    //   235: aload_3
    //   236: aload_2
    //   237: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   240: pop
    //   241: ldc 'FragmentManager'
    //   243: aload_3
    //   244: invokevirtual toString : ()Ljava/lang/String;
    //   247: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   250: pop
    //   251: aload_0
    //   252: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   255: aload_2
    //   256: invokevirtual add : (Ljava/lang/Object;)Z
    //   259: pop
    //   260: aload_0
    //   261: monitorexit
    //   262: return
    //   263: astore_2
    //   264: aload_0
    //   265: monitorexit
    //   266: aload_2
    //   267: athrow
    // Exception table:
    //   from	to	target	type
    //   2	22	263	finally
    //   22	31	263	finally
    //   41	93	263	finally
    //   93	103	263	finally
    //   112	141	263	finally
    //   141	180	263	finally
    //   180	193	263	finally
    //   199	251	263	finally
    //   251	260	263	finally
    //   260	262	263	finally
    //   264	266	263	finally
  }
  
  public void setMaxLifecycle(Fragment paramFragment, Lifecycle.State paramState) {
    if (this.mActive.get(paramFragment.mWho) == paramFragment && (paramFragment.mHost == null || paramFragment.getFragmentManager() == this)) {
      paramFragment.mMaxState = paramState;
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(paramFragment);
    stringBuilder.append(" is not an active fragment of FragmentManager ");
    stringBuilder.append(this);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void setPrimaryNavigationFragment(Fragment paramFragment) {
    if (paramFragment == null || (this.mActive.get(paramFragment.mWho) == paramFragment && (paramFragment.mHost == null || paramFragment.getFragmentManager() == this))) {
      Fragment fragment = this.mPrimaryNav;
      this.mPrimaryNav = paramFragment;
      dispatchParentPrimaryNavigationFragmentChanged(fragment);
      dispatchParentPrimaryNavigationFragmentChanged(this.mPrimaryNav);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(paramFragment);
    stringBuilder.append(" is not an active fragment of FragmentManager ");
    stringBuilder.append(this);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void showFragment(Fragment paramFragment) {
    if (DEBUG) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("show: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (paramFragment.mHidden) {
      paramFragment.mHidden = false;
      paramFragment.mHiddenChanged ^= 0x1;
    } 
  }
  
  void startPendingDeferredFragments() {
    for (Fragment fragment : this.mActive.values()) {
      if (fragment != null)
        performPendingDeferredStart(fragment); 
    } 
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder(128);
    stringBuilder.append("FragmentManager{");
    stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
    stringBuilder.append(" in ");
    Fragment fragment = this.mParent;
    if (fragment != null) {
      DebugUtils.buildShortClassTag(fragment, stringBuilder);
    } else {
      DebugUtils.buildShortClassTag(this.mHost, stringBuilder);
    } 
    stringBuilder.append("}}");
    return stringBuilder.toString();
  }
  
  public void unregisterFragmentLifecycleCallbacks(FragmentManager.FragmentLifecycleCallbacks paramFragmentLifecycleCallbacks) {
    // Byte code:
    //   0: aload_0
    //   1: getfield mLifecycleCallbacks : Ljava/util/concurrent/CopyOnWriteArrayList;
    //   4: astore_2
    //   5: aload_2
    //   6: monitorenter
    //   7: iconst_0
    //   8: istore_3
    //   9: aload_0
    //   10: getfield mLifecycleCallbacks : Ljava/util/concurrent/CopyOnWriteArrayList;
    //   13: invokevirtual size : ()I
    //   16: istore #4
    //   18: iload_3
    //   19: iload #4
    //   21: if_icmpge -> 60
    //   24: aload_0
    //   25: getfield mLifecycleCallbacks : Ljava/util/concurrent/CopyOnWriteArrayList;
    //   28: iload_3
    //   29: invokevirtual get : (I)Ljava/lang/Object;
    //   32: checkcast androidx/fragment/app/FragmentManagerImpl$FragmentLifecycleCallbacksHolder
    //   35: getfield mCallback : Landroidx/fragment/app/FragmentManager$FragmentLifecycleCallbacks;
    //   38: aload_1
    //   39: if_acmpne -> 54
    //   42: aload_0
    //   43: getfield mLifecycleCallbacks : Ljava/util/concurrent/CopyOnWriteArrayList;
    //   46: iload_3
    //   47: invokevirtual remove : (I)Ljava/lang/Object;
    //   50: pop
    //   51: goto -> 60
    //   54: iinc #3, 1
    //   57: goto -> 18
    //   60: aload_2
    //   61: monitorexit
    //   62: return
    //   63: astore_1
    //   64: aload_2
    //   65: monitorexit
    //   66: aload_1
    //   67: athrow
    // Exception table:
    //   from	to	target	type
    //   9	18	63	finally
    //   24	51	63	finally
    //   60	62	63	finally
    //   64	66	63	finally
  }
  
  private static class AnimationOrAnimator {
    public final Animation animation = null;
    
    public final Animator animator;
    
    AnimationOrAnimator(Animator param1Animator) {
      this.animator = param1Animator;
      if (param1Animator != null)
        return; 
      throw new IllegalStateException("Animator cannot be null");
    }
    
    AnimationOrAnimator(Animation param1Animation) {
      this.animator = null;
      if (param1Animation != null)
        return; 
      throw new IllegalStateException("Animation cannot be null");
    }
  }
  
  private static class EndViewTransitionAnimation extends AnimationSet implements Runnable {
    private boolean mAnimating = true;
    
    private final View mChild;
    
    private boolean mEnded;
    
    private final ViewGroup mParent;
    
    private boolean mTransitionEnded;
    
    EndViewTransitionAnimation(Animation param1Animation, ViewGroup param1ViewGroup, View param1View) {
      super(false);
      this.mParent = param1ViewGroup;
      this.mChild = param1View;
      addAnimation(param1Animation);
      this.mParent.post(this);
    }
    
    public boolean getTransformation(long param1Long, Transformation param1Transformation) {
      this.mAnimating = true;
      if (this.mEnded)
        return this.mTransitionEnded ^ true; 
      if (!super.getTransformation(param1Long, param1Transformation)) {
        this.mEnded = true;
        OneShotPreDrawListener.add((View)this.mParent, this);
      } 
      return true;
    }
    
    public boolean getTransformation(long param1Long, Transformation param1Transformation, float param1Float) {
      this.mAnimating = true;
      if (this.mEnded)
        return this.mTransitionEnded ^ true; 
      if (!super.getTransformation(param1Long, param1Transformation, param1Float)) {
        this.mEnded = true;
        OneShotPreDrawListener.add((View)this.mParent, this);
      } 
      return true;
    }
    
    public void run() {
      if (!this.mEnded && this.mAnimating) {
        this.mAnimating = false;
        this.mParent.post(this);
      } else {
        this.mParent.endViewTransition(this.mChild);
        this.mTransitionEnded = true;
      } 
    }
  }
  
  private static final class FragmentLifecycleCallbacksHolder {
    final FragmentManager.FragmentLifecycleCallbacks mCallback;
    
    final boolean mRecursive;
    
    FragmentLifecycleCallbacksHolder(FragmentManager.FragmentLifecycleCallbacks param1FragmentLifecycleCallbacks, boolean param1Boolean) {
      this.mCallback = param1FragmentLifecycleCallbacks;
      this.mRecursive = param1Boolean;
    }
  }
  
  static class FragmentTag {
    public static final int[] Fragment = new int[] { 16842755, 16842960, 16842961 };
    
    public static final int Fragment_id = 1;
    
    public static final int Fragment_name = 0;
    
    public static final int Fragment_tag = 2;
  }
  
  static interface OpGenerator {
    boolean generateOps(ArrayList<BackStackRecord> param1ArrayList, ArrayList<Boolean> param1ArrayList1);
  }
  
  private class PopBackStackState implements OpGenerator {
    final int mFlags;
    
    final int mId;
    
    final String mName;
    
    final FragmentManagerImpl this$0;
    
    PopBackStackState(String param1String, int param1Int1, int param1Int2) {
      this.mName = param1String;
      this.mId = param1Int1;
      this.mFlags = param1Int2;
    }
    
    public boolean generateOps(ArrayList<BackStackRecord> param1ArrayList, ArrayList<Boolean> param1ArrayList1) {
      return (FragmentManagerImpl.this.mPrimaryNav != null && this.mId < 0 && this.mName == null && FragmentManagerImpl.this.mPrimaryNav.getChildFragmentManager().popBackStackImmediate()) ? false : FragmentManagerImpl.this.popBackStackState(param1ArrayList, param1ArrayList1, this.mName, this.mId, this.mFlags);
    }
  }
  
  static class StartEnterTransitionListener implements Fragment.OnStartEnterTransitionListener {
    final boolean mIsBack;
    
    private int mNumPostponed;
    
    final BackStackRecord mRecord;
    
    StartEnterTransitionListener(BackStackRecord param1BackStackRecord, boolean param1Boolean) {
      this.mIsBack = param1Boolean;
      this.mRecord = param1BackStackRecord;
    }
    
    public void cancelTransaction() {
      this.mRecord.mManager.completeExecute(this.mRecord, this.mIsBack, false, false);
    }
    
    public void completeTransaction() {
      int i = this.mNumPostponed;
      byte b = 0;
      if (i > 0) {
        i = 1;
      } else {
        i = 0;
      } 
      FragmentManagerImpl fragmentManagerImpl = this.mRecord.mManager;
      int j = fragmentManagerImpl.mAdded.size();
      while (b < j) {
        Fragment fragment = fragmentManagerImpl.mAdded.get(b);
        fragment.setOnStartEnterTransitionListener(null);
        if (i != 0 && fragment.isPostponed())
          fragment.startPostponedEnterTransition(); 
        b++;
      } 
      this.mRecord.mManager.completeExecute(this.mRecord, this.mIsBack, i ^ 0x1, true);
    }
    
    public boolean isReady() {
      boolean bool;
      if (this.mNumPostponed == 0) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public void onStartEnterTransition() {
      this.mNumPostponed--;
      if (this.mNumPostponed != 0)
        return; 
      this.mRecord.mManager.scheduleCommit();
    }
    
    public void startListening() {
      this.mNumPostponed++;
    }
  }
}


/* Location:              /home/brandon/levelMeter_APK/dex2jar-2.x/dex-tools/build/distributions/dex-tools-2.2-SNAPSHOT/classes-dex2jar.jar!/androidx/fragment/app/FragmentManagerImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */