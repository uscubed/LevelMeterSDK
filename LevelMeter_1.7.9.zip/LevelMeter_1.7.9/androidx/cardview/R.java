package androidx.cardview;

public final class R {
  public static final class attr {
    public static final int cardBackgroundColor = 2130968686;
    
    public static final int cardCornerRadius = 2130968687;
    
    public static final int cardElevation = 2130968688;
    
    public static final int cardMaxElevation = 2130968690;
    
    public static final int cardPreventCornerOverlap = 2130968691;
    
    public static final int cardUseCompatPadding = 2130968692;
    
    public static final int cardViewStyle = 2130968693;
    
    public static final int contentPadding = 2130968768;
    
    public static final int contentPaddingBottom = 2130968769;
    
    public static final int contentPaddingLeft = 2130968770;
    
    public static final int contentPaddingRight = 2130968771;
    
    public static final int contentPaddingTop = 2130968772;
  }
  
  public static final class color {
    public static final int cardview_dark_background = 2131099689;
    
    public static final int cardview_light_background = 2131099690;
    
    public static final int cardview_shadow_end_color = 2131099691;
    
    public static final int cardview_shadow_start_color = 2131099692;
  }
  
  public static final class dimen {
    public static final int cardview_compat_inset_shadow = 2131165266;
    
    public static final int cardview_default_elevation = 2131165267;
    
    public static final int cardview_default_radius = 2131165268;
  }
  
  public static final class style {
    public static final int Base_CardView = 2131820562;
    
    public static final int CardView = 2131820766;
    
    public static final int CardView_Dark = 2131820767;
    
    public static final int CardView_Light = 2131820768;
  }
  
  public static final class styleable {
    public static final int[] CardView = new int[] { 
        16843071, 16843072, 2130968686, 2130968687, 2130968688, 2130968690, 2130968691, 2130968692, 2130968768, 2130968769, 
        2130968770, 2130968771, 2130968772 };
    
    public static final int CardView_android_minHeight = 1;
    
    public static final int CardView_android_minWidth = 0;
    
    public static final int CardView_cardBackgroundColor = 2;
    
    public static final int CardView_cardCornerRadius = 3;
    
    public static final int CardView_cardElevation = 4;
    
    public static final int CardView_cardMaxElevation = 5;
    
    public static final int CardView_cardPreventCornerOverlap = 6;
    
    public static final int CardView_cardUseCompatPadding = 7;
    
    public static final int CardView_contentPadding = 8;
    
    public static final int CardView_contentPaddingBottom = 9;
    
    public static final int CardView_contentPaddingLeft = 10;
    
    public static final int CardView_contentPaddingRight = 11;
    
    public static final int CardView_contentPaddingTop = 12;
  }
}


/* Location:              /home/brandon/levelMeter_APK/dex2jar-2.x/dex-tools/build/distributions/dex-tools-2.2-SNAPSHOT/classes-dex2jar.jar!/androidx/cardview/R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */