package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.SparseBooleanArray;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.R;
import androidx.appcompat.view.ActionBarPolicy;
import androidx.appcompat.view.menu.ActionMenuItemView;
import androidx.appcompat.view.menu.BaseMenuPresenter;
import androidx.appcompat.view.menu.MenuBuilder;
import androidx.appcompat.view.menu.MenuItemImpl;
import androidx.appcompat.view.menu.MenuPopupHelper;
import androidx.appcompat.view.menu.MenuPresenter;
import androidx.appcompat.view.menu.MenuView;
import androidx.appcompat.view.menu.ShowableListMenu;
import androidx.appcompat.view.menu.SubMenuBuilder;
import androidx.core.graphics.drawable.DrawableCompat;
import androidx.core.view.ActionProvider;
import java.util.ArrayList;

class ActionMenuPresenter extends BaseMenuPresenter implements ActionProvider.SubUiVisibilityListener {
  private static final String TAG = "ActionMenuPresenter";
  
  private final SparseBooleanArray mActionButtonGroups = new SparseBooleanArray();
  
  ActionButtonSubmenu mActionButtonPopup;
  
  private int mActionItemWidthLimit;
  
  private boolean mExpandedActionViewsExclusive;
  
  private int mMaxItems;
  
  private boolean mMaxItemsSet;
  
  private int mMinCellSize;
  
  int mOpenSubMenuId;
  
  OverflowMenuButton mOverflowButton;
  
  OverflowPopup mOverflowPopup;
  
  private Drawable mPendingOverflowIcon;
  
  private boolean mPendingOverflowIconSet;
  
  private ActionMenuPopupCallback mPopupCallback;
  
  final PopupPresenterCallback mPopupPresenterCallback = new PopupPresenterCallback();
  
  OpenOverflowRunnable mPostedOpenRunnable;
  
  private boolean mReserveOverflow;
  
  private boolean mReserveOverflowSet;
  
  private boolean mStrictWidthLimit;
  
  private int mWidthLimit;
  
  private boolean mWidthLimitSet;
  
  public ActionMenuPresenter(Context paramContext) {
    super(paramContext, R.layout.abc_action_menu_layout, R.layout.abc_action_menu_item_layout);
  }
  
  private View findViewForItem(MenuItem paramMenuItem) {
    ViewGroup viewGroup = (ViewGroup)this.mMenuView;
    if (viewGroup == null)
      return null; 
    int i = viewGroup.getChildCount();
    for (byte b = 0; b < i; b++) {
      View view = viewGroup.getChildAt(b);
      if (view instanceof MenuView.ItemView && ((MenuView.ItemView)view).getItemData() == paramMenuItem)
        return view; 
    } 
    return null;
  }
  
  public void bindItemView(MenuItemImpl paramMenuItemImpl, MenuView.ItemView paramItemView) {
    paramItemView.initialize(paramMenuItemImpl, 0);
    ActionMenuView actionMenuView = (ActionMenuView)this.mMenuView;
    ActionMenuItemView actionMenuItemView = (ActionMenuItemView)paramItemView;
    actionMenuItemView.setItemInvoker(actionMenuView);
    if (this.mPopupCallback == null)
      this.mPopupCallback = new ActionMenuPopupCallback(); 
    actionMenuItemView.setPopupCallback(this.mPopupCallback);
  }
  
  public boolean dismissPopupMenus() {
    return hideOverflowMenu() | hideSubMenus();
  }
  
  public boolean filterLeftoverView(ViewGroup paramViewGroup, int paramInt) {
    return (paramViewGroup.getChildAt(paramInt) == this.mOverflowButton) ? false : super.filterLeftoverView(paramViewGroup, paramInt);
  }
  
  public boolean flagActionItems() {
    // Byte code:
    //   0: aload_0
    //   1: getfield mMenu : Landroidx/appcompat/view/menu/MenuBuilder;
    //   4: astore_1
    //   5: iconst_0
    //   6: istore_2
    //   7: aload_1
    //   8: ifnull -> 27
    //   11: aload_0
    //   12: getfield mMenu : Landroidx/appcompat/view/menu/MenuBuilder;
    //   15: invokevirtual getVisibleItems : ()Ljava/util/ArrayList;
    //   18: astore_1
    //   19: aload_1
    //   20: invokevirtual size : ()I
    //   23: istore_3
    //   24: goto -> 31
    //   27: aconst_null
    //   28: astore_1
    //   29: iconst_0
    //   30: istore_3
    //   31: aload_0
    //   32: getfield mMaxItems : I
    //   35: istore #4
    //   37: aload_0
    //   38: getfield mActionItemWidthLimit : I
    //   41: istore #5
    //   43: iconst_0
    //   44: iconst_0
    //   45: invokestatic makeMeasureSpec : (II)I
    //   48: istore #6
    //   50: aload_0
    //   51: getfield mMenuView : Landroidx/appcompat/view/menu/MenuView;
    //   54: checkcast android/view/ViewGroup
    //   57: astore #7
    //   59: iconst_0
    //   60: istore #8
    //   62: iconst_0
    //   63: istore #9
    //   65: iload #9
    //   67: istore #10
    //   69: iload #10
    //   71: istore #11
    //   73: iload #11
    //   75: iload_3
    //   76: if_icmpge -> 157
    //   79: aload_1
    //   80: iload #11
    //   82: invokevirtual get : (I)Ljava/lang/Object;
    //   85: checkcast androidx/appcompat/view/menu/MenuItemImpl
    //   88: astore #12
    //   90: aload #12
    //   92: invokevirtual requiresActionButton : ()Z
    //   95: ifeq -> 104
    //   98: iinc #9, 1
    //   101: goto -> 121
    //   104: aload #12
    //   106: invokevirtual requestsActionButton : ()Z
    //   109: ifeq -> 118
    //   112: iinc #10, 1
    //   115: goto -> 121
    //   118: iconst_1
    //   119: istore #8
    //   121: iload #4
    //   123: istore #13
    //   125: aload_0
    //   126: getfield mExpandedActionViewsExclusive : Z
    //   129: ifeq -> 147
    //   132: iload #4
    //   134: istore #13
    //   136: aload #12
    //   138: invokevirtual isActionViewExpanded : ()Z
    //   141: ifeq -> 147
    //   144: iconst_0
    //   145: istore #13
    //   147: iinc #11, 1
    //   150: iload #13
    //   152: istore #4
    //   154: goto -> 73
    //   157: iload #4
    //   159: istore #11
    //   161: aload_0
    //   162: getfield mReserveOverflow : Z
    //   165: ifeq -> 193
    //   168: iload #8
    //   170: ifne -> 187
    //   173: iload #4
    //   175: istore #11
    //   177: iload #10
    //   179: iload #9
    //   181: iadd
    //   182: iload #4
    //   184: if_icmple -> 193
    //   187: iload #4
    //   189: iconst_1
    //   190: isub
    //   191: istore #11
    //   193: iload #11
    //   195: iload #9
    //   197: isub
    //   198: istore #9
    //   200: aload_0
    //   201: getfield mActionButtonGroups : Landroid/util/SparseBooleanArray;
    //   204: astore #12
    //   206: aload #12
    //   208: invokevirtual clear : ()V
    //   211: aload_0
    //   212: getfield mStrictWidthLimit : Z
    //   215: ifeq -> 247
    //   218: aload_0
    //   219: getfield mMinCellSize : I
    //   222: istore #4
    //   224: iload #5
    //   226: iload #4
    //   228: idiv
    //   229: istore #10
    //   231: iload #4
    //   233: iload #5
    //   235: iload #4
    //   237: irem
    //   238: iload #10
    //   240: idiv
    //   241: iadd
    //   242: istore #14
    //   244: goto -> 253
    //   247: iconst_0
    //   248: istore #14
    //   250: iconst_0
    //   251: istore #10
    //   253: iconst_0
    //   254: istore #4
    //   256: iload #5
    //   258: istore #11
    //   260: iconst_0
    //   261: istore #15
    //   263: iload_3
    //   264: istore #5
    //   266: iload_2
    //   267: istore_3
    //   268: iload #15
    //   270: iload #5
    //   272: if_icmpge -> 795
    //   275: aload_1
    //   276: iload #15
    //   278: invokevirtual get : (I)Ljava/lang/Object;
    //   281: checkcast androidx/appcompat/view/menu/MenuItemImpl
    //   284: astore #16
    //   286: aload #16
    //   288: invokevirtual requiresActionButton : ()Z
    //   291: ifeq -> 403
    //   294: aload_0
    //   295: aload #16
    //   297: aconst_null
    //   298: aload #7
    //   300: invokevirtual getItemView : (Landroidx/appcompat/view/menu/MenuItemImpl;Landroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    //   303: astore #17
    //   305: aload_0
    //   306: getfield mStrictWidthLimit : Z
    //   309: ifeq -> 332
    //   312: iload #10
    //   314: aload #17
    //   316: iload #14
    //   318: iload #10
    //   320: iload #6
    //   322: iload_3
    //   323: invokestatic measureChildForCells : (Landroid/view/View;IIII)I
    //   326: isub
    //   327: istore #10
    //   329: goto -> 341
    //   332: aload #17
    //   334: iload #6
    //   336: iload #6
    //   338: invokevirtual measure : (II)V
    //   341: aload #17
    //   343: invokevirtual getMeasuredWidth : ()I
    //   346: istore #8
    //   348: iload #11
    //   350: iload #8
    //   352: isub
    //   353: istore #11
    //   355: iload #4
    //   357: ifne -> 367
    //   360: iload #8
    //   362: istore #4
    //   364: goto -> 367
    //   367: aload #16
    //   369: invokevirtual getGroupId : ()I
    //   372: istore #8
    //   374: iload #8
    //   376: ifeq -> 387
    //   379: aload #12
    //   381: iload #8
    //   383: iconst_1
    //   384: invokevirtual put : (IZ)V
    //   387: aload #16
    //   389: iconst_1
    //   390: invokevirtual setIsActionButton : (Z)V
    //   393: iload #4
    //   395: istore #8
    //   397: iload_3
    //   398: istore #4
    //   400: goto -> 782
    //   403: aload #16
    //   405: invokevirtual requestsActionButton : ()Z
    //   408: ifeq -> 769
    //   411: aload #16
    //   413: invokevirtual getGroupId : ()I
    //   416: istore_2
    //   417: aload #12
    //   419: iload_2
    //   420: invokevirtual get : (I)Z
    //   423: istore #18
    //   425: iload #9
    //   427: ifgt -> 435
    //   430: iload #18
    //   432: ifeq -> 458
    //   435: iload #11
    //   437: ifle -> 458
    //   440: aload_0
    //   441: getfield mStrictWidthLimit : Z
    //   444: ifeq -> 452
    //   447: iload #10
    //   449: ifle -> 458
    //   452: iconst_1
    //   453: istore #19
    //   455: goto -> 461
    //   458: iconst_0
    //   459: istore #19
    //   461: iload #19
    //   463: istore #20
    //   465: iload #19
    //   467: istore #21
    //   469: iload #10
    //   471: istore #13
    //   473: iload #11
    //   475: istore #8
    //   477: iload #4
    //   479: istore_3
    //   480: iload #19
    //   482: ifeq -> 619
    //   485: aload_0
    //   486: aload #16
    //   488: aconst_null
    //   489: aload #7
    //   491: invokevirtual getItemView : (Landroidx/appcompat/view/menu/MenuItemImpl;Landroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    //   494: astore #17
    //   496: aload_0
    //   497: getfield mStrictWidthLimit : Z
    //   500: ifeq -> 543
    //   503: aload #17
    //   505: iload #14
    //   507: iload #10
    //   509: iload #6
    //   511: iconst_0
    //   512: invokestatic measureChildForCells : (Landroid/view/View;IIII)I
    //   515: istore_3
    //   516: iload #10
    //   518: iload_3
    //   519: isub
    //   520: istore #10
    //   522: iload_3
    //   523: ifne -> 532
    //   526: iconst_0
    //   527: istore #19
    //   529: goto -> 536
    //   532: iload #20
    //   534: istore #19
    //   536: iload #19
    //   538: istore #20
    //   540: goto -> 552
    //   543: aload #17
    //   545: iload #6
    //   547: iload #6
    //   549: invokevirtual measure : (II)V
    //   552: aload #17
    //   554: invokevirtual getMeasuredWidth : ()I
    //   557: istore #13
    //   559: iload #11
    //   561: iload #13
    //   563: isub
    //   564: istore #8
    //   566: iload #4
    //   568: istore_3
    //   569: iload #4
    //   571: ifne -> 577
    //   574: iload #13
    //   576: istore_3
    //   577: aload_0
    //   578: getfield mStrictWidthLimit : Z
    //   581: ifeq -> 592
    //   584: iload #8
    //   586: iflt -> 605
    //   589: goto -> 599
    //   592: iload #8
    //   594: iload_3
    //   595: iadd
    //   596: ifle -> 605
    //   599: iconst_1
    //   600: istore #4
    //   602: goto -> 608
    //   605: iconst_0
    //   606: istore #4
    //   608: iload #20
    //   610: iload #4
    //   612: iand
    //   613: istore #21
    //   615: iload #10
    //   617: istore #13
    //   619: iload #21
    //   621: ifeq -> 642
    //   624: iload_2
    //   625: ifeq -> 642
    //   628: aload #12
    //   630: iload_2
    //   631: iconst_1
    //   632: invokevirtual put : (IZ)V
    //   635: iload #9
    //   637: istore #4
    //   639: goto -> 730
    //   642: iload #9
    //   644: istore #4
    //   646: iload #18
    //   648: ifeq -> 730
    //   651: aload #12
    //   653: iload_2
    //   654: iconst_0
    //   655: invokevirtual put : (IZ)V
    //   658: iconst_0
    //   659: istore #10
    //   661: iload #9
    //   663: istore #4
    //   665: iload #10
    //   667: iload #15
    //   669: if_icmpge -> 730
    //   672: aload_1
    //   673: iload #10
    //   675: invokevirtual get : (I)Ljava/lang/Object;
    //   678: checkcast androidx/appcompat/view/menu/MenuItemImpl
    //   681: astore #17
    //   683: iload #9
    //   685: istore #4
    //   687: aload #17
    //   689: invokevirtual getGroupId : ()I
    //   692: iload_2
    //   693: if_icmpne -> 720
    //   696: iload #9
    //   698: istore #4
    //   700: aload #17
    //   702: invokevirtual isActionButton : ()Z
    //   705: ifeq -> 714
    //   708: iload #9
    //   710: iconst_1
    //   711: iadd
    //   712: istore #4
    //   714: aload #17
    //   716: iconst_0
    //   717: invokevirtual setIsActionButton : (Z)V
    //   720: iinc #10, 1
    //   723: iload #4
    //   725: istore #9
    //   727: goto -> 661
    //   730: iload #4
    //   732: istore #9
    //   734: iload #21
    //   736: ifeq -> 745
    //   739: iload #4
    //   741: iconst_1
    //   742: isub
    //   743: istore #9
    //   745: aload #16
    //   747: iload #21
    //   749: invokevirtual setIsActionButton : (Z)V
    //   752: iconst_0
    //   753: istore #4
    //   755: iload #13
    //   757: istore #10
    //   759: iload #8
    //   761: istore #11
    //   763: iload_3
    //   764: istore #8
    //   766: goto -> 782
    //   769: aload #16
    //   771: iload_3
    //   772: invokevirtual setIsActionButton : (Z)V
    //   775: iload #4
    //   777: istore #8
    //   779: iload_3
    //   780: istore #4
    //   782: iinc #15, 1
    //   785: iload #4
    //   787: istore_3
    //   788: iload #8
    //   790: istore #4
    //   792: goto -> 268
    //   795: iconst_1
    //   796: ireturn
  }
  
  public View getItemView(MenuItemImpl paramMenuItemImpl, View paramView, ViewGroup paramViewGroup) {
    boolean bool;
    View view = paramMenuItemImpl.getActionView();
    if (view == null || paramMenuItemImpl.hasCollapsibleActionView())
      view = super.getItemView(paramMenuItemImpl, paramView, paramViewGroup); 
    if (paramMenuItemImpl.isActionViewExpanded()) {
      bool = true;
    } else {
      bool = false;
    } 
    view.setVisibility(bool);
    ActionMenuView actionMenuView = (ActionMenuView)paramViewGroup;
    ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
    if (!actionMenuView.checkLayoutParams(layoutParams))
      view.setLayoutParams((ViewGroup.LayoutParams)actionMenuView.generateLayoutParams(layoutParams)); 
    return view;
  }
  
  public MenuView getMenuView(ViewGroup paramViewGroup) {
    MenuView menuView2 = this.mMenuView;
    MenuView menuView1 = super.getMenuView(paramViewGroup);
    if (menuView2 != menuView1)
      ((ActionMenuView)menuView1).setPresenter(this); 
    return menuView1;
  }
  
  public Drawable getOverflowIcon() {
    OverflowMenuButton overflowMenuButton = this.mOverflowButton;
    return (overflowMenuButton != null) ? overflowMenuButton.getDrawable() : (this.mPendingOverflowIconSet ? this.mPendingOverflowIcon : null);
  }
  
  public boolean hideOverflowMenu() {
    if (this.mPostedOpenRunnable != null && this.mMenuView != null) {
      ((View)this.mMenuView).removeCallbacks(this.mPostedOpenRunnable);
      this.mPostedOpenRunnable = null;
      return true;
    } 
    OverflowPopup overflowPopup = this.mOverflowPopup;
    if (overflowPopup != null) {
      overflowPopup.dismiss();
      return true;
    } 
    return false;
  }
  
  public boolean hideSubMenus() {
    ActionButtonSubmenu actionButtonSubmenu = this.mActionButtonPopup;
    if (actionButtonSubmenu != null) {
      actionButtonSubmenu.dismiss();
      return true;
    } 
    return false;
  }
  
  public void initForMenu(Context paramContext, MenuBuilder paramMenuBuilder) {
    super.initForMenu(paramContext, paramMenuBuilder);
    Resources resources = paramContext.getResources();
    ActionBarPolicy actionBarPolicy = ActionBarPolicy.get(paramContext);
    if (!this.mReserveOverflowSet)
      this.mReserveOverflow = actionBarPolicy.showsOverflowMenuButton(); 
    if (!this.mWidthLimitSet)
      this.mWidthLimit = actionBarPolicy.getEmbeddedMenuWidthLimit(); 
    if (!this.mMaxItemsSet)
      this.mMaxItems = actionBarPolicy.getMaxActionButtons(); 
    int i = this.mWidthLimit;
    if (this.mReserveOverflow) {
      if (this.mOverflowButton == null) {
        this.mOverflowButton = new OverflowMenuButton(this.mSystemContext);
        if (this.mPendingOverflowIconSet) {
          this.mOverflowButton.setImageDrawable(this.mPendingOverflowIcon);
          this.mPendingOverflowIcon = null;
          this.mPendingOverflowIconSet = false;
        } 
        int j = View.MeasureSpec.makeMeasureSpec(0, 0);
        this.mOverflowButton.measure(j, j);
      } 
      i -= this.mOverflowButton.getMeasuredWidth();
    } else {
      this.mOverflowButton = null;
    } 
    this.mActionItemWidthLimit = i;
    this.mMinCellSize = (int)((resources.getDisplayMetrics()).density * 56.0F);
  }
  
  public boolean isOverflowMenuShowPending() {
    return (this.mPostedOpenRunnable != null || isOverflowMenuShowing());
  }
  
  public boolean isOverflowMenuShowing() {
    boolean bool;
    OverflowPopup overflowPopup = this.mOverflowPopup;
    if (overflowPopup != null && overflowPopup.isShowing()) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public boolean isOverflowReserved() {
    return this.mReserveOverflow;
  }
  
  public void onCloseMenu(MenuBuilder paramMenuBuilder, boolean paramBoolean) {
    dismissPopupMenus();
    super.onCloseMenu(paramMenuBuilder, paramBoolean);
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    if (!this.mMaxItemsSet)
      this.mMaxItems = ActionBarPolicy.get(this.mContext).getMaxActionButtons(); 
    if (this.mMenu != null)
      this.mMenu.onItemsChanged(true); 
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof SavedState))
      return; 
    paramParcelable = paramParcelable;
    if (((SavedState)paramParcelable).openSubMenuId > 0) {
      MenuItem menuItem = this.mMenu.findItem(((SavedState)paramParcelable).openSubMenuId);
      if (menuItem != null)
        onSubMenuSelected((SubMenuBuilder)menuItem.getSubMenu()); 
    } 
  }
  
  public Parcelable onSaveInstanceState() {
    SavedState savedState = new SavedState();
    savedState.openSubMenuId = this.mOpenSubMenuId;
    return savedState;
  }
  
  public boolean onSubMenuSelected(SubMenuBuilder paramSubMenuBuilder) {
    boolean bool = paramSubMenuBuilder.hasVisibleItems();
    boolean bool1 = false;
    if (!bool)
      return false; 
    SubMenuBuilder subMenuBuilder;
    for (subMenuBuilder = paramSubMenuBuilder; subMenuBuilder.getParentMenu() != this.mMenu; subMenuBuilder = (SubMenuBuilder)subMenuBuilder.getParentMenu());
    View view = findViewForItem(subMenuBuilder.getItem());
    if (view == null)
      return false; 
    this.mOpenSubMenuId = paramSubMenuBuilder.getItem().getItemId();
    int i = paramSubMenuBuilder.size();
    byte b = 0;
    while (true) {
      bool = bool1;
      if (b < i) {
        MenuItem menuItem = paramSubMenuBuilder.getItem(b);
        if (menuItem.isVisible() && menuItem.getIcon() != null) {
          bool = true;
          break;
        } 
        b++;
        continue;
      } 
      break;
    } 
    this.mActionButtonPopup = new ActionButtonSubmenu(this.mContext, paramSubMenuBuilder, view);
    this.mActionButtonPopup.setForceShowIcon(bool);
    this.mActionButtonPopup.show();
    super.onSubMenuSelected(paramSubMenuBuilder);
    return true;
  }
  
  public void onSubUiVisibilityChanged(boolean paramBoolean) {
    if (paramBoolean) {
      super.onSubMenuSelected(null);
    } else if (this.mMenu != null) {
      this.mMenu.close(false);
    } 
  }
  
  public void setExpandedActionViewsExclusive(boolean paramBoolean) {
    this.mExpandedActionViewsExclusive = paramBoolean;
  }
  
  public void setItemLimit(int paramInt) {
    this.mMaxItems = paramInt;
    this.mMaxItemsSet = true;
  }
  
  public void setMenuView(ActionMenuView paramActionMenuView) {
    this.mMenuView = paramActionMenuView;
    paramActionMenuView.initialize(this.mMenu);
  }
  
  public void setOverflowIcon(Drawable paramDrawable) {
    OverflowMenuButton overflowMenuButton = this.mOverflowButton;
    if (overflowMenuButton != null) {
      overflowMenuButton.setImageDrawable(paramDrawable);
    } else {
      this.mPendingOverflowIconSet = true;
      this.mPendingOverflowIcon = paramDrawable;
    } 
  }
  
  public void setReserveOverflow(boolean paramBoolean) {
    this.mReserveOverflow = paramBoolean;
    this.mReserveOverflowSet = true;
  }
  
  public void setWidthLimit(int paramInt, boolean paramBoolean) {
    this.mWidthLimit = paramInt;
    this.mStrictWidthLimit = paramBoolean;
    this.mWidthLimitSet = true;
  }
  
  public boolean shouldIncludeItem(int paramInt, MenuItemImpl paramMenuItemImpl) {
    return paramMenuItemImpl.isActionButton();
  }
  
  public boolean showOverflowMenu() {
    if (this.mReserveOverflow && !isOverflowMenuShowing() && this.mMenu != null && this.mMenuView != null && this.mPostedOpenRunnable == null && !this.mMenu.getNonActionItems().isEmpty()) {
      this.mPostedOpenRunnable = new OpenOverflowRunnable(new OverflowPopup(this.mContext, this.mMenu, (View)this.mOverflowButton, true));
      ((View)this.mMenuView).post(this.mPostedOpenRunnable);
      super.onSubMenuSelected(null);
      return true;
    } 
    return false;
  }
  
  public void updateMenuView(boolean paramBoolean) {
    super.updateMenuView(paramBoolean);
    ((View)this.mMenuView).requestLayout();
    MenuBuilder<MenuItemImpl> menuBuilder = this.mMenu;
    byte b = 0;
    if (menuBuilder != null) {
      ArrayList<MenuItemImpl> arrayList = this.mMenu.getActionItems();
      int j = arrayList.size();
      for (byte b1 = 0; b1 < j; b1++) {
        ActionProvider actionProvider = ((MenuItemImpl)arrayList.get(b1)).getSupportActionProvider();
        if (actionProvider != null)
          actionProvider.setSubUiVisibilityListener(this); 
      } 
    } 
    if (this.mMenu != null) {
      ArrayList arrayList = this.mMenu.getNonActionItems();
    } else {
      menuBuilder = null;
    } 
    int i = b;
    if (this.mReserveOverflow) {
      i = b;
      if (menuBuilder != null) {
        int j = menuBuilder.size();
        if (j == 1) {
          i = ((MenuItemImpl)menuBuilder.get(0)).isActionViewExpanded() ^ true;
        } else {
          i = b;
          if (j > 0)
            i = 1; 
        } 
      } 
    } 
    if (i != 0) {
      if (this.mOverflowButton == null)
        this.mOverflowButton = new OverflowMenuButton(this.mSystemContext); 
      ViewGroup viewGroup = (ViewGroup)this.mOverflowButton.getParent();
      if (viewGroup != this.mMenuView) {
        if (viewGroup != null)
          viewGroup.removeView((View)this.mOverflowButton); 
        viewGroup = (ActionMenuView)this.mMenuView;
        viewGroup.addView((View)this.mOverflowButton, (ViewGroup.LayoutParams)viewGroup.generateOverflowButtonLayoutParams());
      } 
    } else {
      OverflowMenuButton overflowMenuButton = this.mOverflowButton;
      if (overflowMenuButton != null && overflowMenuButton.getParent() == this.mMenuView)
        ((ViewGroup)this.mMenuView).removeView((View)this.mOverflowButton); 
    } 
    ((ActionMenuView)this.mMenuView).setOverflowReserved(this.mReserveOverflow);
  }
  
  private class ActionButtonSubmenu extends MenuPopupHelper {
    final ActionMenuPresenter this$0;
    
    public ActionButtonSubmenu(Context param1Context, SubMenuBuilder param1SubMenuBuilder, View param1View) {
      super(param1Context, (MenuBuilder)param1SubMenuBuilder, param1View, false, R.attr.actionOverflowMenuStyle);
      if (!((MenuItemImpl)param1SubMenuBuilder.getItem()).isActionButton()) {
        ActionMenuPresenter.OverflowMenuButton overflowMenuButton;
        if (ActionMenuPresenter.this.mOverflowButton == null) {
          View view = (View)ActionMenuPresenter.this.mMenuView;
        } else {
          overflowMenuButton = ActionMenuPresenter.this.mOverflowButton;
        } 
        setAnchorView((View)overflowMenuButton);
      } 
      setPresenterCallback(ActionMenuPresenter.this.mPopupPresenterCallback);
    }
    
    protected void onDismiss() {
      ActionMenuPresenter actionMenuPresenter = ActionMenuPresenter.this;
      actionMenuPresenter.mActionButtonPopup = null;
      actionMenuPresenter.mOpenSubMenuId = 0;
      super.onDismiss();
    }
  }
  
  private class ActionMenuPopupCallback extends ActionMenuItemView.PopupCallback {
    final ActionMenuPresenter this$0;
    
    public ShowableListMenu getPopup() {
      ShowableListMenu showableListMenu;
      if (ActionMenuPresenter.this.mActionButtonPopup != null) {
        showableListMenu = (ShowableListMenu)ActionMenuPresenter.this.mActionButtonPopup.getPopup();
      } else {
        showableListMenu = null;
      } 
      return showableListMenu;
    }
  }
  
  private class OpenOverflowRunnable implements Runnable {
    private ActionMenuPresenter.OverflowPopup mPopup;
    
    final ActionMenuPresenter this$0;
    
    public OpenOverflowRunnable(ActionMenuPresenter.OverflowPopup param1OverflowPopup) {
      this.mPopup = param1OverflowPopup;
    }
    
    public void run() {
      if (ActionMenuPresenter.this.mMenu != null)
        ActionMenuPresenter.this.mMenu.changeMenuMode(); 
      View view = (View)ActionMenuPresenter.this.mMenuView;
      if (view != null && view.getWindowToken() != null && this.mPopup.tryShow())
        ActionMenuPresenter.this.mOverflowPopup = this.mPopup; 
      ActionMenuPresenter.this.mPostedOpenRunnable = null;
    }
  }
  
  private class OverflowMenuButton extends AppCompatImageView implements ActionMenuView.ActionMenuChildView {
    private final float[] mTempPts = new float[2];
    
    final ActionMenuPresenter this$0;
    
    public OverflowMenuButton(Context param1Context) {
      super(param1Context, (AttributeSet)null, R.attr.actionOverflowButtonStyle);
      setClickable(true);
      setFocusable(true);
      setVisibility(0);
      setEnabled(true);
      TooltipCompat.setTooltipText((View)this, getContentDescription());
      setOnTouchListener(new ForwardingListener((View)this) {
            final ActionMenuPresenter.OverflowMenuButton this$1;
            
            final ActionMenuPresenter val$this$0;
            
            public ShowableListMenu getPopup() {
              return (ShowableListMenu)((ActionMenuPresenter.this.mOverflowPopup == null) ? null : ActionMenuPresenter.this.mOverflowPopup.getPopup());
            }
            
            public boolean onForwardingStarted() {
              ActionMenuPresenter.this.showOverflowMenu();
              return true;
            }
            
            public boolean onForwardingStopped() {
              if (ActionMenuPresenter.this.mPostedOpenRunnable != null)
                return false; 
              ActionMenuPresenter.this.hideOverflowMenu();
              return true;
            }
          });
    }
    
    public boolean needsDividerAfter() {
      return false;
    }
    
    public boolean needsDividerBefore() {
      return false;
    }
    
    public boolean performClick() {
      if (super.performClick())
        return true; 
      playSoundEffect(0);
      ActionMenuPresenter.this.showOverflowMenu();
      return true;
    }
    
    protected boolean setFrame(int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      boolean bool = super.setFrame(param1Int1, param1Int2, param1Int3, param1Int4);
      Drawable drawable1 = getDrawable();
      Drawable drawable2 = getBackground();
      if (drawable1 != null && drawable2 != null) {
        int i = getWidth();
        param1Int3 = getHeight();
        param1Int1 = Math.max(i, param1Int3) / 2;
        int j = getPaddingLeft();
        int k = getPaddingRight();
        param1Int4 = getPaddingTop();
        param1Int2 = getPaddingBottom();
        j = (i + j - k) / 2;
        param1Int2 = (param1Int3 + param1Int4 - param1Int2) / 2;
        DrawableCompat.setHotspotBounds(drawable2, j - param1Int1, param1Int2 - param1Int1, j + param1Int1, param1Int2 + param1Int1);
      } 
      return bool;
    }
  }
  
  class null extends ForwardingListener {
    final ActionMenuPresenter.OverflowMenuButton this$1;
    
    final ActionMenuPresenter val$this$0;
    
    null(View param1View) {
      super(param1View);
    }
    
    public ShowableListMenu getPopup() {
      return (ShowableListMenu)((ActionMenuPresenter.this.mOverflowPopup == null) ? null : ActionMenuPresenter.this.mOverflowPopup.getPopup());
    }
    
    public boolean onForwardingStarted() {
      ActionMenuPresenter.this.showOverflowMenu();
      return true;
    }
    
    public boolean onForwardingStopped() {
      if (ActionMenuPresenter.this.mPostedOpenRunnable != null)
        return false; 
      ActionMenuPresenter.this.hideOverflowMenu();
      return true;
    }
  }
  
  private class OverflowPopup extends MenuPopupHelper {
    final ActionMenuPresenter this$0;
    
    public OverflowPopup(Context param1Context, MenuBuilder param1MenuBuilder, View param1View, boolean param1Boolean) {
      super(param1Context, param1MenuBuilder, param1View, param1Boolean, R.attr.actionOverflowMenuStyle);
      setGravity(8388613);
      setPresenterCallback(ActionMenuPresenter.this.mPopupPresenterCallback);
    }
    
    protected void onDismiss() {
      if (ActionMenuPresenter.this.mMenu != null)
        ActionMenuPresenter.this.mMenu.close(); 
      ActionMenuPresenter.this.mOverflowPopup = null;
      super.onDismiss();
    }
  }
  
  private class PopupPresenterCallback implements MenuPresenter.Callback {
    final ActionMenuPresenter this$0;
    
    public void onCloseMenu(MenuBuilder param1MenuBuilder, boolean param1Boolean) {
      if (param1MenuBuilder instanceof SubMenuBuilder)
        param1MenuBuilder.getRootMenu().close(false); 
      MenuPresenter.Callback callback = ActionMenuPresenter.this.getCallback();
      if (callback != null)
        callback.onCloseMenu(param1MenuBuilder, param1Boolean); 
    }
    
    public boolean onOpenSubMenu(MenuBuilder param1MenuBuilder) {
      boolean bool = false;
      if (param1MenuBuilder == null)
        return false; 
      ActionMenuPresenter.this.mOpenSubMenuId = ((SubMenuBuilder)param1MenuBuilder).getItem().getItemId();
      MenuPresenter.Callback callback = ActionMenuPresenter.this.getCallback();
      if (callback != null)
        bool = callback.onOpenSubMenu(param1MenuBuilder); 
      return bool;
    }
  }
  
  private static class SavedState implements Parcelable {
    public static final Parcelable.Creator<SavedState> CREATOR = new Parcelable.Creator<SavedState>() {
        public ActionMenuPresenter.SavedState createFromParcel(Parcel param2Parcel) {
          return new ActionMenuPresenter.SavedState(param2Parcel);
        }
        
        public ActionMenuPresenter.SavedState[] newArray(int param2Int) {
          return new ActionMenuPresenter.SavedState[param2Int];
        }
      };
    
    public int openSubMenuId;
    
    SavedState() {}
    
    SavedState(Parcel param1Parcel) {
      this.openSubMenuId = param1Parcel.readInt();
    }
    
    public int describeContents() {
      return 0;
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      param1Parcel.writeInt(this.openSubMenuId);
    }
  }
  
  static final class null implements Parcelable.Creator<SavedState> {
    public ActionMenuPresenter.SavedState createFromParcel(Parcel param1Parcel) {
      return new ActionMenuPresenter.SavedState(param1Parcel);
    }
    
    public ActionMenuPresenter.SavedState[] newArray(int param1Int) {
      return new ActionMenuPresenter.SavedState[param1Int];
    }
  }
}


/* Location:              /home/brandon/levelMeter_APK/dex2jar-2.x/dex-tools/build/distributions/dex-tools-2.2-SNAPSHOT/classes-dex2jar.jar!/androidx/appcompat/widget/ActionMenuPresenter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */