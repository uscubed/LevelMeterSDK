package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import androidx.appcompat.R;
import androidx.core.view.GravityCompat;
import androidx.core.view.ViewCompat;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

public class LinearLayoutCompat extends ViewGroup {
  private static final String ACCESSIBILITY_CLASS_NAME = "androidx.appcompat.widget.LinearLayoutCompat";
  
  public static final int HORIZONTAL = 0;
  
  private static final int INDEX_BOTTOM = 2;
  
  private static final int INDEX_CENTER_VERTICAL = 0;
  
  private static final int INDEX_FILL = 3;
  
  private static final int INDEX_TOP = 1;
  
  public static final int SHOW_DIVIDER_BEGINNING = 1;
  
  public static final int SHOW_DIVIDER_END = 4;
  
  public static final int SHOW_DIVIDER_MIDDLE = 2;
  
  public static final int SHOW_DIVIDER_NONE = 0;
  
  public static final int VERTICAL = 1;
  
  private static final int VERTICAL_GRAVITY_COUNT = 4;
  
  private boolean mBaselineAligned = true;
  
  private int mBaselineAlignedChildIndex = -1;
  
  private int mBaselineChildTop = 0;
  
  private Drawable mDivider;
  
  private int mDividerHeight;
  
  private int mDividerPadding;
  
  private int mDividerWidth;
  
  private int mGravity = 8388659;
  
  private int[] mMaxAscent;
  
  private int[] mMaxDescent;
  
  private int mOrientation;
  
  private int mShowDividers;
  
  private int mTotalLength;
  
  private boolean mUseLargestChild;
  
  private float mWeightSum;
  
  public LinearLayoutCompat(Context paramContext) {
    this(paramContext, (AttributeSet)null);
  }
  
  public LinearLayoutCompat(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0);
  }
  
  public LinearLayoutCompat(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    TintTypedArray tintTypedArray = TintTypedArray.obtainStyledAttributes(paramContext, paramAttributeSet, R.styleable.LinearLayoutCompat, paramInt, 0);
    paramInt = tintTypedArray.getInt(R.styleable.LinearLayoutCompat_android_orientation, -1);
    if (paramInt >= 0)
      setOrientation(paramInt); 
    paramInt = tintTypedArray.getInt(R.styleable.LinearLayoutCompat_android_gravity, -1);
    if (paramInt >= 0)
      setGravity(paramInt); 
    boolean bool = tintTypedArray.getBoolean(R.styleable.LinearLayoutCompat_android_baselineAligned, true);
    if (!bool)
      setBaselineAligned(bool); 
    this.mWeightSum = tintTypedArray.getFloat(R.styleable.LinearLayoutCompat_android_weightSum, -1.0F);
    this.mBaselineAlignedChildIndex = tintTypedArray.getInt(R.styleable.LinearLayoutCompat_android_baselineAlignedChildIndex, -1);
    this.mUseLargestChild = tintTypedArray.getBoolean(R.styleable.LinearLayoutCompat_measureWithLargestChild, false);
    setDividerDrawable(tintTypedArray.getDrawable(R.styleable.LinearLayoutCompat_divider));
    this.mShowDividers = tintTypedArray.getInt(R.styleable.LinearLayoutCompat_showDividers, 0);
    this.mDividerPadding = tintTypedArray.getDimensionPixelSize(R.styleable.LinearLayoutCompat_dividerPadding, 0);
    tintTypedArray.recycle();
  }
  
  private void forceUniformHeight(int paramInt1, int paramInt2) {
    int i = View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 1073741824);
    for (byte b = 0; b < paramInt1; b++) {
      View view = getVirtualChildAt(b);
      if (view.getVisibility() != 8) {
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        if (layoutParams.height == -1) {
          int j = layoutParams.width;
          layoutParams.width = view.getMeasuredWidth();
          measureChildWithMargins(view, paramInt2, 0, i, 0);
          layoutParams.width = j;
        } 
      } 
    } 
  }
  
  private void forceUniformWidth(int paramInt1, int paramInt2) {
    int i = View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824);
    for (byte b = 0; b < paramInt1; b++) {
      View view = getVirtualChildAt(b);
      if (view.getVisibility() != 8) {
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        if (layoutParams.width == -1) {
          int j = layoutParams.height;
          layoutParams.height = view.getMeasuredHeight();
          measureChildWithMargins(view, i, 0, paramInt2, 0);
          layoutParams.height = j;
        } 
      } 
    } 
  }
  
  private void setChildFrame(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    paramView.layout(paramInt1, paramInt2, paramInt3 + paramInt1, paramInt4 + paramInt2);
  }
  
  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return paramLayoutParams instanceof LayoutParams;
  }
  
  void drawDividersHorizontal(Canvas paramCanvas) {
    int i = getVirtualChildCount();
    boolean bool = ViewUtils.isLayoutRtl((View)this);
    int j;
    for (j = 0; j < i; j++) {
      View view = getVirtualChildAt(j);
      if (view != null && view.getVisibility() != 8 && hasDividerBeforeChildAt(j)) {
        int k;
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        if (bool) {
          k = view.getRight() + layoutParams.rightMargin;
        } else {
          k = view.getLeft() - layoutParams.leftMargin - this.mDividerWidth;
        } 
        drawVerticalDivider(paramCanvas, k);
      } 
    } 
    if (hasDividerBeforeChildAt(i)) {
      View view = getVirtualChildAt(i - 1);
      if (view == null) {
        if (bool) {
          j = getPaddingLeft();
        } else {
          int k = getWidth() - getPaddingRight();
          j = this.mDividerWidth;
          j = k - j;
        } 
      } else {
        int k;
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        if (bool) {
          k = view.getLeft() - layoutParams.leftMargin;
          j = this.mDividerWidth;
        } else {
          j = view.getRight() + layoutParams.rightMargin;
          drawVerticalDivider(paramCanvas, j);
        } 
        j = k - j;
      } 
    } else {
      return;
    } 
    drawVerticalDivider(paramCanvas, j);
  }
  
  void drawDividersVertical(Canvas paramCanvas) {
    int i = getVirtualChildCount();
    int j;
    for (j = 0; j < i; j++) {
      View view = getVirtualChildAt(j);
      if (view != null && view.getVisibility() != 8 && hasDividerBeforeChildAt(j)) {
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        drawHorizontalDivider(paramCanvas, view.getTop() - layoutParams.topMargin - this.mDividerHeight);
      } 
    } 
    if (hasDividerBeforeChildAt(i)) {
      View view = getVirtualChildAt(i - 1);
      if (view == null) {
        j = getHeight() - getPaddingBottom() - this.mDividerHeight;
      } else {
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        j = view.getBottom() + layoutParams.bottomMargin;
      } 
      drawHorizontalDivider(paramCanvas, j);
    } 
  }
  
  void drawHorizontalDivider(Canvas paramCanvas, int paramInt) {
    this.mDivider.setBounds(getPaddingLeft() + this.mDividerPadding, paramInt, getWidth() - getPaddingRight() - this.mDividerPadding, this.mDividerHeight + paramInt);
    this.mDivider.draw(paramCanvas);
  }
  
  void drawVerticalDivider(Canvas paramCanvas, int paramInt) {
    this.mDivider.setBounds(paramInt, getPaddingTop() + this.mDividerPadding, this.mDividerWidth + paramInt, getHeight() - getPaddingBottom() - this.mDividerPadding);
    this.mDivider.draw(paramCanvas);
  }
  
  protected LayoutParams generateDefaultLayoutParams() {
    int i = this.mOrientation;
    return (i == 0) ? new LayoutParams(-2, -2) : ((i == 1) ? new LayoutParams(-1, -2) : null);
  }
  
  public LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    return new LayoutParams(getContext(), paramAttributeSet);
  }
  
  protected LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return new LayoutParams(paramLayoutParams);
  }
  
  public int getBaseline() {
    if (this.mBaselineAlignedChildIndex < 0)
      return super.getBaseline(); 
    int i = getChildCount();
    int j = this.mBaselineAlignedChildIndex;
    if (i > j) {
      View view = getChildAt(j);
      int k = view.getBaseline();
      if (k == -1) {
        if (this.mBaselineAlignedChildIndex == 0)
          return -1; 
        throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout points to a View that doesn't know how to get its baseline.");
      } 
      i = this.mBaselineChildTop;
      j = i;
      if (this.mOrientation == 1) {
        int m = this.mGravity & 0x70;
        j = i;
        if (m != 48)
          if (m != 16) {
            if (m != 80) {
              j = i;
            } else {
              j = getBottom() - getTop() - getPaddingBottom() - this.mTotalLength;
            } 
          } else {
            j = i + (getBottom() - getTop() - getPaddingTop() - getPaddingBottom() - this.mTotalLength) / 2;
          }  
      } 
      return j + ((LayoutParams)view.getLayoutParams()).topMargin + k;
    } 
    throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout set to an index that is out of bounds.");
  }
  
  public int getBaselineAlignedChildIndex() {
    return this.mBaselineAlignedChildIndex;
  }
  
  int getChildrenSkipCount(View paramView, int paramInt) {
    return 0;
  }
  
  public Drawable getDividerDrawable() {
    return this.mDivider;
  }
  
  public int getDividerPadding() {
    return this.mDividerPadding;
  }
  
  public int getDividerWidth() {
    return this.mDividerWidth;
  }
  
  public int getGravity() {
    return this.mGravity;
  }
  
  int getLocationOffset(View paramView) {
    return 0;
  }
  
  int getNextLocationOffset(View paramView) {
    return 0;
  }
  
  public int getOrientation() {
    return this.mOrientation;
  }
  
  public int getShowDividers() {
    return this.mShowDividers;
  }
  
  View getVirtualChildAt(int paramInt) {
    return getChildAt(paramInt);
  }
  
  int getVirtualChildCount() {
    return getChildCount();
  }
  
  public float getWeightSum() {
    return this.mWeightSum;
  }
  
  protected boolean hasDividerBeforeChildAt(int paramInt) {
    boolean bool1 = false;
    boolean bool2 = false;
    boolean bool3 = false;
    if (paramInt == 0) {
      if ((this.mShowDividers & 0x1) != 0)
        bool3 = true; 
      return bool3;
    } 
    if (paramInt == getChildCount()) {
      bool3 = bool1;
      if ((this.mShowDividers & 0x4) != 0)
        bool3 = true; 
      return bool3;
    } 
    bool3 = bool2;
    if ((this.mShowDividers & 0x2) != 0) {
      paramInt--;
      while (true) {
        bool3 = bool2;
        if (paramInt >= 0) {
          if (getChildAt(paramInt).getVisibility() != 8) {
            bool3 = true;
            break;
          } 
          paramInt--;
          continue;
        } 
        break;
      } 
    } 
    return bool3;
  }
  
  public boolean isBaselineAligned() {
    return this.mBaselineAligned;
  }
  
  public boolean isMeasureWithLargestChildEnabled() {
    return this.mUseLargestChild;
  }
  
  void layoutHorizontal(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    byte b1;
    byte b2;
    boolean bool1 = ViewUtils.isLayoutRtl((View)this);
    int i = getPaddingTop();
    int j = paramInt4 - paramInt2;
    int k = getPaddingBottom();
    int m = getPaddingBottom();
    int n = getVirtualChildCount();
    paramInt4 = this.mGravity;
    paramInt2 = paramInt4 & 0x70;
    boolean bool2 = this.mBaselineAligned;
    int[] arrayOfInt1 = this.mMaxAscent;
    int[] arrayOfInt2 = this.mMaxDescent;
    paramInt4 = GravityCompat.getAbsoluteGravity(0x800007 & paramInt4, ViewCompat.getLayoutDirection((View)this));
    boolean bool = true;
    if (paramInt4 != 1) {
      if (paramInt4 != 5) {
        paramInt1 = getPaddingLeft();
      } else {
        paramInt1 = getPaddingLeft() + paramInt3 - paramInt1 - this.mTotalLength;
      } 
    } else {
      paramInt1 = getPaddingLeft() + (paramInt3 - paramInt1 - this.mTotalLength) / 2;
    } 
    if (bool1) {
      b1 = n - 1;
      b2 = -1;
    } else {
      b1 = 0;
      b2 = 1;
    } 
    paramInt4 = 0;
    paramInt3 = i;
    while (paramInt4 < n) {
      int i1 = b1 + b2 * paramInt4;
      View view = getVirtualChildAt(i1);
      if (view == null) {
        paramInt1 += measureNullChild(i1);
      } else if (view.getVisibility() != 8) {
        int i2 = view.getMeasuredWidth();
        int i3 = view.getMeasuredHeight();
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        if (bool2 && layoutParams.height != -1) {
          i4 = view.getBaseline();
        } else {
          i4 = -1;
        } 
        int i5 = layoutParams.gravity;
        int i6 = i5;
        if (i5 < 0)
          i6 = paramInt2; 
        i6 &= 0x70;
        if (i6 != 16) {
          if (i6 != 48) {
            if (i6 != 80) {
              i6 = paramInt3;
            } else {
              i5 = j - k - i3 - layoutParams.bottomMargin;
              i6 = i5;
              if (i4 != -1) {
                i6 = view.getMeasuredHeight();
                i6 = i5 - arrayOfInt2[2] - i6 - i4;
              } 
            } 
          } else {
            i5 = layoutParams.topMargin + paramInt3;
            i6 = i5;
            if (i4 != -1)
              i6 = i5 + arrayOfInt1[1] - i4; 
          } 
        } else {
          i6 = (j - i - m - i3) / 2 + paramInt3 + layoutParams.topMargin - layoutParams.bottomMargin;
        } 
        bool = true;
        int i4 = paramInt1;
        if (hasDividerBeforeChildAt(i1))
          i4 = paramInt1 + this.mDividerWidth; 
        paramInt1 = layoutParams.leftMargin + i4;
        setChildFrame(view, paramInt1 + getLocationOffset(view), i6, i2, i3);
        i4 = layoutParams.rightMargin;
        i6 = getNextLocationOffset(view);
        paramInt4 += getChildrenSkipCount(view, i1);
        paramInt1 += i2 + i4 + i6;
      } else {
        bool = true;
      } 
      paramInt4++;
    } 
  }
  
  void layoutVertical(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    int i = getPaddingLeft();
    int j = paramInt3 - paramInt1;
    int k = getPaddingRight();
    int m = getPaddingRight();
    int n = getVirtualChildCount();
    int i1 = this.mGravity;
    paramInt1 = i1 & 0x70;
    if (paramInt1 != 16) {
      if (paramInt1 != 80) {
        paramInt1 = getPaddingTop();
      } else {
        paramInt1 = getPaddingTop() + paramInt4 - paramInt2 - this.mTotalLength;
      } 
    } else {
      paramInt1 = getPaddingTop() + (paramInt4 - paramInt2 - this.mTotalLength) / 2;
    } 
    for (paramInt2 = 0; paramInt2 < n; paramInt2++) {
      View view = getVirtualChildAt(paramInt2);
      if (view == null) {
        paramInt3 = paramInt1 + measureNullChild(paramInt2);
      } else {
        paramInt3 = paramInt1;
        if (view.getVisibility() != 8) {
          int i2 = view.getMeasuredWidth();
          int i3 = view.getMeasuredHeight();
          LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
          paramInt4 = layoutParams.gravity;
          paramInt3 = paramInt4;
          if (paramInt4 < 0)
            paramInt3 = i1 & 0x800007; 
          paramInt3 = GravityCompat.getAbsoluteGravity(paramInt3, ViewCompat.getLayoutDirection((View)this)) & 0x7;
          if (paramInt3 != 1) {
            if (paramInt3 != 5) {
              paramInt3 = layoutParams.leftMargin + i;
            } else {
              paramInt4 = j - k - i2;
              paramInt3 = layoutParams.rightMargin;
              paramInt3 = paramInt4 - paramInt3;
            } 
          } else {
            paramInt4 = (j - i - m - i2) / 2 + i + layoutParams.leftMargin;
            paramInt3 = layoutParams.rightMargin;
            paramInt3 = paramInt4 - paramInt3;
          } 
          paramInt4 = paramInt1;
          if (hasDividerBeforeChildAt(paramInt2))
            paramInt4 = paramInt1 + this.mDividerHeight; 
          paramInt1 = paramInt4 + layoutParams.topMargin;
          setChildFrame(view, paramInt3, paramInt1 + getLocationOffset(view), i2, i3);
          paramInt3 = layoutParams.bottomMargin;
          paramInt4 = getNextLocationOffset(view);
          paramInt2 += getChildrenSkipCount(view, paramInt2);
          paramInt1 += i3 + paramInt3 + paramInt4;
          continue;
        } 
      } 
      paramInt1 = paramInt3;
      continue;
    } 
  }
  
  void measureChildBeforeLayout(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    measureChildWithMargins(paramView, paramInt2, paramInt3, paramInt4, paramInt5);
  }
  
  void measureHorizontal(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: iconst_0
    //   2: putfield mTotalLength : I
    //   5: aload_0
    //   6: invokevirtual getVirtualChildCount : ()I
    //   9: istore_3
    //   10: iload_1
    //   11: invokestatic getMode : (I)I
    //   14: istore #4
    //   16: iload_2
    //   17: invokestatic getMode : (I)I
    //   20: istore #5
    //   22: aload_0
    //   23: getfield mMaxAscent : [I
    //   26: ifnull -> 36
    //   29: aload_0
    //   30: getfield mMaxDescent : [I
    //   33: ifnonnull -> 50
    //   36: aload_0
    //   37: iconst_4
    //   38: newarray int
    //   40: putfield mMaxAscent : [I
    //   43: aload_0
    //   44: iconst_4
    //   45: newarray int
    //   47: putfield mMaxDescent : [I
    //   50: aload_0
    //   51: getfield mMaxAscent : [I
    //   54: astore #6
    //   56: aload_0
    //   57: getfield mMaxDescent : [I
    //   60: astore #7
    //   62: aload #6
    //   64: iconst_3
    //   65: iconst_m1
    //   66: iastore
    //   67: aload #6
    //   69: iconst_2
    //   70: iconst_m1
    //   71: iastore
    //   72: aload #6
    //   74: iconst_1
    //   75: iconst_m1
    //   76: iastore
    //   77: aload #6
    //   79: iconst_0
    //   80: iconst_m1
    //   81: iastore
    //   82: aload #7
    //   84: iconst_3
    //   85: iconst_m1
    //   86: iastore
    //   87: aload #7
    //   89: iconst_2
    //   90: iconst_m1
    //   91: iastore
    //   92: aload #7
    //   94: iconst_1
    //   95: iconst_m1
    //   96: iastore
    //   97: aload #7
    //   99: iconst_0
    //   100: iconst_m1
    //   101: iastore
    //   102: aload_0
    //   103: getfield mBaselineAligned : Z
    //   106: istore #8
    //   108: aload_0
    //   109: getfield mUseLargestChild : Z
    //   112: istore #9
    //   114: iload #4
    //   116: ldc 1073741824
    //   118: if_icmpne -> 127
    //   121: iconst_1
    //   122: istore #10
    //   124: goto -> 130
    //   127: iconst_0
    //   128: istore #10
    //   130: iconst_0
    //   131: istore #11
    //   133: iconst_0
    //   134: istore #12
    //   136: iload #12
    //   138: istore #13
    //   140: iload #13
    //   142: istore #14
    //   144: iload #14
    //   146: istore #15
    //   148: iload #15
    //   150: istore #16
    //   152: iload #16
    //   154: istore #17
    //   156: iload #17
    //   158: istore #18
    //   160: iconst_1
    //   161: istore #19
    //   163: fconst_0
    //   164: fstore #20
    //   166: iload #11
    //   168: iload_3
    //   169: if_icmpge -> 855
    //   172: aload_0
    //   173: iload #11
    //   175: invokevirtual getVirtualChildAt : (I)Landroid/view/View;
    //   178: astore #21
    //   180: aload #21
    //   182: ifnonnull -> 207
    //   185: aload_0
    //   186: aload_0
    //   187: getfield mTotalLength : I
    //   190: aload_0
    //   191: iload #11
    //   193: invokevirtual measureNullChild : (I)I
    //   196: iadd
    //   197: putfield mTotalLength : I
    //   200: iload #17
    //   202: istore #22
    //   204: goto -> 845
    //   207: aload #21
    //   209: invokevirtual getVisibility : ()I
    //   212: bipush #8
    //   214: if_icmpne -> 233
    //   217: iload #11
    //   219: aload_0
    //   220: aload #21
    //   222: iload #11
    //   224: invokevirtual getChildrenSkipCount : (Landroid/view/View;I)I
    //   227: iadd
    //   228: istore #11
    //   230: goto -> 200
    //   233: aload_0
    //   234: iload #11
    //   236: invokevirtual hasDividerBeforeChildAt : (I)Z
    //   239: ifeq -> 255
    //   242: aload_0
    //   243: aload_0
    //   244: getfield mTotalLength : I
    //   247: aload_0
    //   248: getfield mDividerWidth : I
    //   251: iadd
    //   252: putfield mTotalLength : I
    //   255: aload #21
    //   257: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   260: checkcast androidx/appcompat/widget/LinearLayoutCompat$LayoutParams
    //   263: astore #23
    //   265: fload #20
    //   267: aload #23
    //   269: getfield weight : F
    //   272: fadd
    //   273: fstore #20
    //   275: iload #4
    //   277: ldc 1073741824
    //   279: if_icmpne -> 391
    //   282: aload #23
    //   284: getfield width : I
    //   287: ifne -> 391
    //   290: aload #23
    //   292: getfield weight : F
    //   295: fconst_0
    //   296: fcmpl
    //   297: ifle -> 391
    //   300: iload #10
    //   302: ifeq -> 328
    //   305: aload_0
    //   306: aload_0
    //   307: getfield mTotalLength : I
    //   310: aload #23
    //   312: getfield leftMargin : I
    //   315: aload #23
    //   317: getfield rightMargin : I
    //   320: iadd
    //   321: iadd
    //   322: putfield mTotalLength : I
    //   325: goto -> 357
    //   328: aload_0
    //   329: getfield mTotalLength : I
    //   332: istore #22
    //   334: aload_0
    //   335: iload #22
    //   337: aload #23
    //   339: getfield leftMargin : I
    //   342: iload #22
    //   344: iadd
    //   345: aload #23
    //   347: getfield rightMargin : I
    //   350: iadd
    //   351: invokestatic max : (II)I
    //   354: putfield mTotalLength : I
    //   357: iload #8
    //   359: ifeq -> 385
    //   362: iconst_0
    //   363: iconst_0
    //   364: invokestatic makeMeasureSpec : (II)I
    //   367: istore #22
    //   369: aload #21
    //   371: iload #22
    //   373: iload #22
    //   375: invokevirtual measure : (II)V
    //   378: iload #12
    //   380: istore #22
    //   382: goto -> 576
    //   385: iconst_1
    //   386: istore #16
    //   388: goto -> 580
    //   391: aload #23
    //   393: getfield width : I
    //   396: ifne -> 422
    //   399: aload #23
    //   401: getfield weight : F
    //   404: fconst_0
    //   405: fcmpl
    //   406: ifle -> 422
    //   409: aload #23
    //   411: bipush #-2
    //   413: putfield width : I
    //   416: iconst_0
    //   417: istore #22
    //   419: goto -> 427
    //   422: ldc_w -2147483648
    //   425: istore #22
    //   427: fload #20
    //   429: fconst_0
    //   430: fcmpl
    //   431: ifne -> 443
    //   434: aload_0
    //   435: getfield mTotalLength : I
    //   438: istore #24
    //   440: goto -> 446
    //   443: iconst_0
    //   444: istore #24
    //   446: aload_0
    //   447: aload #21
    //   449: iload #11
    //   451: iload_1
    //   452: iload #24
    //   454: iload_2
    //   455: iconst_0
    //   456: invokevirtual measureChildBeforeLayout : (Landroid/view/View;IIIII)V
    //   459: iload #22
    //   461: ldc_w -2147483648
    //   464: if_icmpeq -> 474
    //   467: aload #23
    //   469: iload #22
    //   471: putfield width : I
    //   474: aload #21
    //   476: invokevirtual getMeasuredWidth : ()I
    //   479: istore #24
    //   481: iload #10
    //   483: ifeq -> 519
    //   486: aload_0
    //   487: aload_0
    //   488: getfield mTotalLength : I
    //   491: aload #23
    //   493: getfield leftMargin : I
    //   496: iload #24
    //   498: iadd
    //   499: aload #23
    //   501: getfield rightMargin : I
    //   504: iadd
    //   505: aload_0
    //   506: aload #21
    //   508: invokevirtual getNextLocationOffset : (Landroid/view/View;)I
    //   511: iadd
    //   512: iadd
    //   513: putfield mTotalLength : I
    //   516: goto -> 558
    //   519: aload_0
    //   520: getfield mTotalLength : I
    //   523: istore #22
    //   525: aload_0
    //   526: iload #22
    //   528: iload #22
    //   530: iload #24
    //   532: iadd
    //   533: aload #23
    //   535: getfield leftMargin : I
    //   538: iadd
    //   539: aload #23
    //   541: getfield rightMargin : I
    //   544: iadd
    //   545: aload_0
    //   546: aload #21
    //   548: invokevirtual getNextLocationOffset : (Landroid/view/View;)I
    //   551: iadd
    //   552: invokestatic max : (II)I
    //   555: putfield mTotalLength : I
    //   558: iload #12
    //   560: istore #22
    //   562: iload #9
    //   564: ifeq -> 576
    //   567: iload #24
    //   569: iload #12
    //   571: invokestatic max : (II)I
    //   574: istore #22
    //   576: iload #22
    //   578: istore #12
    //   580: iload #5
    //   582: ldc 1073741824
    //   584: if_icmpeq -> 605
    //   587: aload #23
    //   589: getfield height : I
    //   592: iconst_m1
    //   593: if_icmpne -> 605
    //   596: iconst_1
    //   597: istore #22
    //   599: iconst_1
    //   600: istore #18
    //   602: goto -> 608
    //   605: iconst_0
    //   606: istore #22
    //   608: aload #23
    //   610: getfield topMargin : I
    //   613: aload #23
    //   615: getfield bottomMargin : I
    //   618: iadd
    //   619: istore #24
    //   621: aload #21
    //   623: invokevirtual getMeasuredHeight : ()I
    //   626: iload #24
    //   628: iadd
    //   629: istore #25
    //   631: iload #17
    //   633: aload #21
    //   635: invokevirtual getMeasuredState : ()I
    //   638: invokestatic combineMeasuredStates : (II)I
    //   641: istore #26
    //   643: iload #8
    //   645: ifeq -> 732
    //   648: aload #21
    //   650: invokevirtual getBaseline : ()I
    //   653: istore #27
    //   655: iload #27
    //   657: iconst_m1
    //   658: if_icmpeq -> 732
    //   661: aload #23
    //   663: getfield gravity : I
    //   666: ifge -> 678
    //   669: aload_0
    //   670: getfield mGravity : I
    //   673: istore #17
    //   675: goto -> 685
    //   678: aload #23
    //   680: getfield gravity : I
    //   683: istore #17
    //   685: iload #17
    //   687: bipush #112
    //   689: iand
    //   690: iconst_4
    //   691: ishr
    //   692: bipush #-2
    //   694: iand
    //   695: iconst_1
    //   696: ishr
    //   697: istore #17
    //   699: aload #6
    //   701: iload #17
    //   703: aload #6
    //   705: iload #17
    //   707: iaload
    //   708: iload #27
    //   710: invokestatic max : (II)I
    //   713: iastore
    //   714: aload #7
    //   716: iload #17
    //   718: aload #7
    //   720: iload #17
    //   722: iaload
    //   723: iload #25
    //   725: iload #27
    //   727: isub
    //   728: invokestatic max : (II)I
    //   731: iastore
    //   732: iload #13
    //   734: iload #25
    //   736: invokestatic max : (II)I
    //   739: istore #13
    //   741: iload #19
    //   743: ifeq -> 761
    //   746: aload #23
    //   748: getfield height : I
    //   751: iconst_m1
    //   752: if_icmpne -> 761
    //   755: iconst_1
    //   756: istore #19
    //   758: goto -> 764
    //   761: iconst_0
    //   762: istore #19
    //   764: aload #23
    //   766: getfield weight : F
    //   769: fconst_0
    //   770: fcmpl
    //   771: ifle -> 798
    //   774: iload #22
    //   776: ifeq -> 782
    //   779: goto -> 786
    //   782: iload #25
    //   784: istore #24
    //   786: iload #15
    //   788: iload #24
    //   790: invokestatic max : (II)I
    //   793: istore #17
    //   795: goto -> 820
    //   798: iload #22
    //   800: ifeq -> 807
    //   803: iload #24
    //   805: istore #25
    //   807: iload #14
    //   809: iload #25
    //   811: invokestatic max : (II)I
    //   814: istore #14
    //   816: iload #15
    //   818: istore #17
    //   820: aload_0
    //   821: aload #21
    //   823: iload #11
    //   825: invokevirtual getChildrenSkipCount : (Landroid/view/View;I)I
    //   828: istore #15
    //   830: iload #26
    //   832: istore #22
    //   834: iload #15
    //   836: iload #11
    //   838: iadd
    //   839: istore #11
    //   841: iload #17
    //   843: istore #15
    //   845: iinc #11, 1
    //   848: iload #22
    //   850: istore #17
    //   852: goto -> 166
    //   855: iload #13
    //   857: istore #11
    //   859: aload_0
    //   860: getfield mTotalLength : I
    //   863: ifle -> 887
    //   866: aload_0
    //   867: iload_3
    //   868: invokevirtual hasDividerBeforeChildAt : (I)Z
    //   871: ifeq -> 887
    //   874: aload_0
    //   875: aload_0
    //   876: getfield mTotalLength : I
    //   879: aload_0
    //   880: getfield mDividerWidth : I
    //   883: iadd
    //   884: putfield mTotalLength : I
    //   887: aload #6
    //   889: iconst_1
    //   890: iaload
    //   891: iconst_m1
    //   892: if_icmpne -> 925
    //   895: aload #6
    //   897: iconst_0
    //   898: iaload
    //   899: iconst_m1
    //   900: if_icmpne -> 925
    //   903: aload #6
    //   905: iconst_2
    //   906: iaload
    //   907: iconst_m1
    //   908: if_icmpne -> 925
    //   911: aload #6
    //   913: iconst_3
    //   914: iaload
    //   915: iconst_m1
    //   916: if_icmpeq -> 922
    //   919: goto -> 925
    //   922: goto -> 983
    //   925: iload #11
    //   927: aload #6
    //   929: iconst_3
    //   930: iaload
    //   931: aload #6
    //   933: iconst_0
    //   934: iaload
    //   935: aload #6
    //   937: iconst_1
    //   938: iaload
    //   939: aload #6
    //   941: iconst_2
    //   942: iaload
    //   943: invokestatic max : (II)I
    //   946: invokestatic max : (II)I
    //   949: invokestatic max : (II)I
    //   952: aload #7
    //   954: iconst_3
    //   955: iaload
    //   956: aload #7
    //   958: iconst_0
    //   959: iaload
    //   960: aload #7
    //   962: iconst_1
    //   963: iaload
    //   964: aload #7
    //   966: iconst_2
    //   967: iaload
    //   968: invokestatic max : (II)I
    //   971: invokestatic max : (II)I
    //   974: invokestatic max : (II)I
    //   977: iadd
    //   978: invokestatic max : (II)I
    //   981: istore #11
    //   983: iload #17
    //   985: istore #13
    //   987: iload #11
    //   989: istore #22
    //   991: iload #9
    //   993: ifeq -> 1181
    //   996: iload #4
    //   998: ldc_w -2147483648
    //   1001: if_icmpeq -> 1013
    //   1004: iload #11
    //   1006: istore #22
    //   1008: iload #4
    //   1010: ifne -> 1181
    //   1013: aload_0
    //   1014: iconst_0
    //   1015: putfield mTotalLength : I
    //   1018: iconst_0
    //   1019: istore #17
    //   1021: iload #11
    //   1023: istore #22
    //   1025: iload #17
    //   1027: iload_3
    //   1028: if_icmpge -> 1181
    //   1031: aload_0
    //   1032: iload #17
    //   1034: invokevirtual getVirtualChildAt : (I)Landroid/view/View;
    //   1037: astore #21
    //   1039: aload #21
    //   1041: ifnonnull -> 1062
    //   1044: aload_0
    //   1045: aload_0
    //   1046: getfield mTotalLength : I
    //   1049: aload_0
    //   1050: iload #17
    //   1052: invokevirtual measureNullChild : (I)I
    //   1055: iadd
    //   1056: putfield mTotalLength : I
    //   1059: goto -> 1085
    //   1062: aload #21
    //   1064: invokevirtual getVisibility : ()I
    //   1067: bipush #8
    //   1069: if_icmpne -> 1088
    //   1072: iload #17
    //   1074: aload_0
    //   1075: aload #21
    //   1077: iload #17
    //   1079: invokevirtual getChildrenSkipCount : (Landroid/view/View;I)I
    //   1082: iadd
    //   1083: istore #17
    //   1085: goto -> 1175
    //   1088: aload #21
    //   1090: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1093: checkcast androidx/appcompat/widget/LinearLayoutCompat$LayoutParams
    //   1096: astore #23
    //   1098: iload #10
    //   1100: ifeq -> 1136
    //   1103: aload_0
    //   1104: aload_0
    //   1105: getfield mTotalLength : I
    //   1108: aload #23
    //   1110: getfield leftMargin : I
    //   1113: iload #12
    //   1115: iadd
    //   1116: aload #23
    //   1118: getfield rightMargin : I
    //   1121: iadd
    //   1122: aload_0
    //   1123: aload #21
    //   1125: invokevirtual getNextLocationOffset : (Landroid/view/View;)I
    //   1128: iadd
    //   1129: iadd
    //   1130: putfield mTotalLength : I
    //   1133: goto -> 1085
    //   1136: aload_0
    //   1137: getfield mTotalLength : I
    //   1140: istore #22
    //   1142: aload_0
    //   1143: iload #22
    //   1145: iload #22
    //   1147: iload #12
    //   1149: iadd
    //   1150: aload #23
    //   1152: getfield leftMargin : I
    //   1155: iadd
    //   1156: aload #23
    //   1158: getfield rightMargin : I
    //   1161: iadd
    //   1162: aload_0
    //   1163: aload #21
    //   1165: invokevirtual getNextLocationOffset : (Landroid/view/View;)I
    //   1168: iadd
    //   1169: invokestatic max : (II)I
    //   1172: putfield mTotalLength : I
    //   1175: iinc #17, 1
    //   1178: goto -> 1021
    //   1181: aload_0
    //   1182: aload_0
    //   1183: getfield mTotalLength : I
    //   1186: aload_0
    //   1187: invokevirtual getPaddingLeft : ()I
    //   1190: aload_0
    //   1191: invokevirtual getPaddingRight : ()I
    //   1194: iadd
    //   1195: iadd
    //   1196: putfield mTotalLength : I
    //   1199: aload_0
    //   1200: getfield mTotalLength : I
    //   1203: aload_0
    //   1204: invokevirtual getSuggestedMinimumWidth : ()I
    //   1207: invokestatic max : (II)I
    //   1210: iload_1
    //   1211: iconst_0
    //   1212: invokestatic resolveSizeAndState : (III)I
    //   1215: istore #25
    //   1217: ldc_w 16777215
    //   1220: iload #25
    //   1222: iand
    //   1223: aload_0
    //   1224: getfield mTotalLength : I
    //   1227: isub
    //   1228: istore #24
    //   1230: iload #16
    //   1232: ifne -> 1364
    //   1235: iload #24
    //   1237: ifeq -> 1250
    //   1240: fload #20
    //   1242: fconst_0
    //   1243: fcmpl
    //   1244: ifle -> 1250
    //   1247: goto -> 1364
    //   1250: iload #14
    //   1252: iload #15
    //   1254: invokestatic max : (II)I
    //   1257: istore #17
    //   1259: iload #9
    //   1261: ifeq -> 1350
    //   1264: iload #4
    //   1266: ldc 1073741824
    //   1268: if_icmpeq -> 1350
    //   1271: iconst_0
    //   1272: istore #14
    //   1274: iload #14
    //   1276: iload_3
    //   1277: if_icmpge -> 1350
    //   1280: aload_0
    //   1281: iload #14
    //   1283: invokevirtual getVirtualChildAt : (I)Landroid/view/View;
    //   1286: astore #7
    //   1288: aload #7
    //   1290: ifnull -> 1344
    //   1293: aload #7
    //   1295: invokevirtual getVisibility : ()I
    //   1298: bipush #8
    //   1300: if_icmpne -> 1306
    //   1303: goto -> 1344
    //   1306: aload #7
    //   1308: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1311: checkcast androidx/appcompat/widget/LinearLayoutCompat$LayoutParams
    //   1314: getfield weight : F
    //   1317: fconst_0
    //   1318: fcmpl
    //   1319: ifle -> 1344
    //   1322: aload #7
    //   1324: iload #12
    //   1326: ldc 1073741824
    //   1328: invokestatic makeMeasureSpec : (II)I
    //   1331: aload #7
    //   1333: invokevirtual getMeasuredHeight : ()I
    //   1336: ldc 1073741824
    //   1338: invokestatic makeMeasureSpec : (II)I
    //   1341: invokevirtual measure : (II)V
    //   1344: iinc #14, 1
    //   1347: goto -> 1274
    //   1350: iload_3
    //   1351: istore #11
    //   1353: iload #22
    //   1355: istore #12
    //   1357: iload #17
    //   1359: istore #14
    //   1361: goto -> 2103
    //   1364: aload_0
    //   1365: getfield mWeightSum : F
    //   1368: fstore #28
    //   1370: fload #28
    //   1372: fconst_0
    //   1373: fcmpl
    //   1374: ifle -> 1381
    //   1377: fload #28
    //   1379: fstore #20
    //   1381: aload #6
    //   1383: iconst_3
    //   1384: iconst_m1
    //   1385: iastore
    //   1386: aload #6
    //   1388: iconst_2
    //   1389: iconst_m1
    //   1390: iastore
    //   1391: aload #6
    //   1393: iconst_1
    //   1394: iconst_m1
    //   1395: iastore
    //   1396: aload #6
    //   1398: iconst_0
    //   1399: iconst_m1
    //   1400: iastore
    //   1401: aload #7
    //   1403: iconst_3
    //   1404: iconst_m1
    //   1405: iastore
    //   1406: aload #7
    //   1408: iconst_2
    //   1409: iconst_m1
    //   1410: iastore
    //   1411: aload #7
    //   1413: iconst_1
    //   1414: iconst_m1
    //   1415: iastore
    //   1416: aload #7
    //   1418: iconst_0
    //   1419: iconst_m1
    //   1420: iastore
    //   1421: aload_0
    //   1422: iconst_0
    //   1423: putfield mTotalLength : I
    //   1426: iconst_m1
    //   1427: istore #15
    //   1429: iconst_0
    //   1430: istore #16
    //   1432: iload #19
    //   1434: istore #11
    //   1436: iload_3
    //   1437: istore #12
    //   1439: iload #14
    //   1441: istore #17
    //   1443: iload #13
    //   1445: istore #19
    //   1447: iload #24
    //   1449: istore #14
    //   1451: iload #16
    //   1453: istore #13
    //   1455: iload #13
    //   1457: iload #12
    //   1459: if_icmpge -> 1965
    //   1462: aload_0
    //   1463: iload #13
    //   1465: invokevirtual getVirtualChildAt : (I)Landroid/view/View;
    //   1468: astore #21
    //   1470: aload #21
    //   1472: ifnull -> 1959
    //   1475: aload #21
    //   1477: invokevirtual getVisibility : ()I
    //   1480: bipush #8
    //   1482: if_icmpne -> 1488
    //   1485: goto -> 1959
    //   1488: aload #21
    //   1490: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1493: checkcast androidx/appcompat/widget/LinearLayoutCompat$LayoutParams
    //   1496: astore #23
    //   1498: aload #23
    //   1500: getfield weight : F
    //   1503: fstore #28
    //   1505: fload #28
    //   1507: fconst_0
    //   1508: fcmpl
    //   1509: ifle -> 1672
    //   1512: iload #14
    //   1514: i2f
    //   1515: fload #28
    //   1517: fmul
    //   1518: fload #20
    //   1520: fdiv
    //   1521: f2i
    //   1522: istore #22
    //   1524: iload_2
    //   1525: aload_0
    //   1526: invokevirtual getPaddingTop : ()I
    //   1529: aload_0
    //   1530: invokevirtual getPaddingBottom : ()I
    //   1533: iadd
    //   1534: aload #23
    //   1536: getfield topMargin : I
    //   1539: iadd
    //   1540: aload #23
    //   1542: getfield bottomMargin : I
    //   1545: iadd
    //   1546: aload #23
    //   1548: getfield height : I
    //   1551: invokestatic getChildMeasureSpec : (III)I
    //   1554: istore #24
    //   1556: aload #23
    //   1558: getfield width : I
    //   1561: ifne -> 1606
    //   1564: iload #4
    //   1566: ldc 1073741824
    //   1568: if_icmpeq -> 1574
    //   1571: goto -> 1606
    //   1574: iload #22
    //   1576: ifle -> 1586
    //   1579: iload #22
    //   1581: istore #16
    //   1583: goto -> 1589
    //   1586: iconst_0
    //   1587: istore #16
    //   1589: aload #21
    //   1591: iload #16
    //   1593: ldc 1073741824
    //   1595: invokestatic makeMeasureSpec : (II)I
    //   1598: iload #24
    //   1600: invokevirtual measure : (II)V
    //   1603: goto -> 1639
    //   1606: aload #21
    //   1608: invokevirtual getMeasuredWidth : ()I
    //   1611: iload #22
    //   1613: iadd
    //   1614: istore_3
    //   1615: iload_3
    //   1616: istore #16
    //   1618: iload_3
    //   1619: ifge -> 1625
    //   1622: iconst_0
    //   1623: istore #16
    //   1625: aload #21
    //   1627: iload #16
    //   1629: ldc 1073741824
    //   1631: invokestatic makeMeasureSpec : (II)I
    //   1634: iload #24
    //   1636: invokevirtual measure : (II)V
    //   1639: iload #19
    //   1641: aload #21
    //   1643: invokevirtual getMeasuredState : ()I
    //   1646: ldc_w -16777216
    //   1649: iand
    //   1650: invokestatic combineMeasuredStates : (II)I
    //   1653: istore #19
    //   1655: fload #20
    //   1657: fload #28
    //   1659: fsub
    //   1660: fstore #20
    //   1662: iload #14
    //   1664: iload #22
    //   1666: isub
    //   1667: istore #14
    //   1669: goto -> 1672
    //   1672: iload #10
    //   1674: ifeq -> 1713
    //   1677: aload_0
    //   1678: aload_0
    //   1679: getfield mTotalLength : I
    //   1682: aload #21
    //   1684: invokevirtual getMeasuredWidth : ()I
    //   1687: aload #23
    //   1689: getfield leftMargin : I
    //   1692: iadd
    //   1693: aload #23
    //   1695: getfield rightMargin : I
    //   1698: iadd
    //   1699: aload_0
    //   1700: aload #21
    //   1702: invokevirtual getNextLocationOffset : (Landroid/view/View;)I
    //   1705: iadd
    //   1706: iadd
    //   1707: putfield mTotalLength : I
    //   1710: goto -> 1755
    //   1713: aload_0
    //   1714: getfield mTotalLength : I
    //   1717: istore #16
    //   1719: aload_0
    //   1720: iload #16
    //   1722: aload #21
    //   1724: invokevirtual getMeasuredWidth : ()I
    //   1727: iload #16
    //   1729: iadd
    //   1730: aload #23
    //   1732: getfield leftMargin : I
    //   1735: iadd
    //   1736: aload #23
    //   1738: getfield rightMargin : I
    //   1741: iadd
    //   1742: aload_0
    //   1743: aload #21
    //   1745: invokevirtual getNextLocationOffset : (Landroid/view/View;)I
    //   1748: iadd
    //   1749: invokestatic max : (II)I
    //   1752: putfield mTotalLength : I
    //   1755: iload #5
    //   1757: ldc 1073741824
    //   1759: if_icmpeq -> 1777
    //   1762: aload #23
    //   1764: getfield height : I
    //   1767: iconst_m1
    //   1768: if_icmpne -> 1777
    //   1771: iconst_1
    //   1772: istore #16
    //   1774: goto -> 1780
    //   1777: iconst_0
    //   1778: istore #16
    //   1780: aload #23
    //   1782: getfield topMargin : I
    //   1785: aload #23
    //   1787: getfield bottomMargin : I
    //   1790: iadd
    //   1791: istore #24
    //   1793: aload #21
    //   1795: invokevirtual getMeasuredHeight : ()I
    //   1798: iload #24
    //   1800: iadd
    //   1801: istore_3
    //   1802: iload #15
    //   1804: iload_3
    //   1805: invokestatic max : (II)I
    //   1808: istore #22
    //   1810: iload #16
    //   1812: ifeq -> 1822
    //   1815: iload #24
    //   1817: istore #15
    //   1819: goto -> 1825
    //   1822: iload_3
    //   1823: istore #15
    //   1825: iload #17
    //   1827: iload #15
    //   1829: invokestatic max : (II)I
    //   1832: istore #15
    //   1834: iload #11
    //   1836: ifeq -> 1854
    //   1839: aload #23
    //   1841: getfield height : I
    //   1844: iconst_m1
    //   1845: if_icmpne -> 1854
    //   1848: iconst_1
    //   1849: istore #11
    //   1851: goto -> 1857
    //   1854: iconst_0
    //   1855: istore #11
    //   1857: iload #8
    //   1859: ifeq -> 1948
    //   1862: aload #21
    //   1864: invokevirtual getBaseline : ()I
    //   1867: istore #16
    //   1869: iload #16
    //   1871: iconst_m1
    //   1872: if_icmpeq -> 1948
    //   1875: aload #23
    //   1877: getfield gravity : I
    //   1880: ifge -> 1892
    //   1883: aload_0
    //   1884: getfield mGravity : I
    //   1887: istore #17
    //   1889: goto -> 1899
    //   1892: aload #23
    //   1894: getfield gravity : I
    //   1897: istore #17
    //   1899: iload #17
    //   1901: bipush #112
    //   1903: iand
    //   1904: iconst_4
    //   1905: ishr
    //   1906: bipush #-2
    //   1908: iand
    //   1909: iconst_1
    //   1910: ishr
    //   1911: istore #17
    //   1913: aload #6
    //   1915: iload #17
    //   1917: aload #6
    //   1919: iload #17
    //   1921: iaload
    //   1922: iload #16
    //   1924: invokestatic max : (II)I
    //   1927: iastore
    //   1928: aload #7
    //   1930: iload #17
    //   1932: aload #7
    //   1934: iload #17
    //   1936: iaload
    //   1937: iload_3
    //   1938: iload #16
    //   1940: isub
    //   1941: invokestatic max : (II)I
    //   1944: iastore
    //   1945: goto -> 1948
    //   1948: iload #15
    //   1950: istore #17
    //   1952: iload #22
    //   1954: istore #15
    //   1956: goto -> 1959
    //   1959: iinc #13, 1
    //   1962: goto -> 1455
    //   1965: aload_0
    //   1966: aload_0
    //   1967: getfield mTotalLength : I
    //   1970: aload_0
    //   1971: invokevirtual getPaddingLeft : ()I
    //   1974: aload_0
    //   1975: invokevirtual getPaddingRight : ()I
    //   1978: iadd
    //   1979: iadd
    //   1980: putfield mTotalLength : I
    //   1983: aload #6
    //   1985: iconst_1
    //   1986: iaload
    //   1987: iconst_m1
    //   1988: if_icmpne -> 2025
    //   1991: aload #6
    //   1993: iconst_0
    //   1994: iaload
    //   1995: iconst_m1
    //   1996: if_icmpne -> 2025
    //   1999: aload #6
    //   2001: iconst_2
    //   2002: iaload
    //   2003: iconst_m1
    //   2004: if_icmpne -> 2025
    //   2007: aload #6
    //   2009: iconst_3
    //   2010: iaload
    //   2011: iconst_m1
    //   2012: if_icmpeq -> 2018
    //   2015: goto -> 2025
    //   2018: iload #15
    //   2020: istore #14
    //   2022: goto -> 2083
    //   2025: iload #15
    //   2027: aload #6
    //   2029: iconst_3
    //   2030: iaload
    //   2031: aload #6
    //   2033: iconst_0
    //   2034: iaload
    //   2035: aload #6
    //   2037: iconst_1
    //   2038: iaload
    //   2039: aload #6
    //   2041: iconst_2
    //   2042: iaload
    //   2043: invokestatic max : (II)I
    //   2046: invokestatic max : (II)I
    //   2049: invokestatic max : (II)I
    //   2052: aload #7
    //   2054: iconst_3
    //   2055: iaload
    //   2056: aload #7
    //   2058: iconst_0
    //   2059: iaload
    //   2060: aload #7
    //   2062: iconst_1
    //   2063: iaload
    //   2064: aload #7
    //   2066: iconst_2
    //   2067: iaload
    //   2068: invokestatic max : (II)I
    //   2071: invokestatic max : (II)I
    //   2074: invokestatic max : (II)I
    //   2077: iadd
    //   2078: invokestatic max : (II)I
    //   2081: istore #14
    //   2083: iload #19
    //   2085: istore #13
    //   2087: iload #11
    //   2089: istore #19
    //   2091: iload #12
    //   2093: istore #11
    //   2095: iload #14
    //   2097: istore #12
    //   2099: iload #17
    //   2101: istore #14
    //   2103: iload #19
    //   2105: ifne -> 2118
    //   2108: iload #5
    //   2110: ldc 1073741824
    //   2112: if_icmpeq -> 2118
    //   2115: goto -> 2122
    //   2118: iload #12
    //   2120: istore #14
    //   2122: aload_0
    //   2123: iload #25
    //   2125: iload #13
    //   2127: ldc_w -16777216
    //   2130: iand
    //   2131: ior
    //   2132: iload #14
    //   2134: aload_0
    //   2135: invokevirtual getPaddingTop : ()I
    //   2138: aload_0
    //   2139: invokevirtual getPaddingBottom : ()I
    //   2142: iadd
    //   2143: iadd
    //   2144: aload_0
    //   2145: invokevirtual getSuggestedMinimumHeight : ()I
    //   2148: invokestatic max : (II)I
    //   2151: iload_2
    //   2152: iload #13
    //   2154: bipush #16
    //   2156: ishl
    //   2157: invokestatic resolveSizeAndState : (III)I
    //   2160: invokevirtual setMeasuredDimension : (II)V
    //   2163: iload #18
    //   2165: ifeq -> 2175
    //   2168: aload_0
    //   2169: iload #11
    //   2171: iload_1
    //   2172: invokespecial forceUniformHeight : (II)V
    //   2175: return
  }
  
  int measureNullChild(int paramInt) {
    return 0;
  }
  
  void measureVertical(int paramInt1, int paramInt2) {
    this.mTotalLength = 0;
    int i = getVirtualChildCount();
    int j = View.MeasureSpec.getMode(paramInt1);
    int k = View.MeasureSpec.getMode(paramInt2);
    int m = this.mBaselineAlignedChildIndex;
    boolean bool = this.mUseLargestChild;
    int n = 0;
    int i1 = 0;
    int i2 = i1;
    int i3 = i2;
    int i4 = i3;
    int i5 = i4;
    int i6 = i5;
    int i7 = i6;
    float f = 0.0F;
    int i8 = 1;
    while (i5 < i) {
      View view = getVirtualChildAt(i5);
      if (view == null) {
        this.mTotalLength += measureNullChild(i5);
      } else if (view.getVisibility() == 8) {
        i5 += getChildrenSkipCount(view, i5);
      } else {
        if (hasDividerBeforeChildAt(i5))
          this.mTotalLength += this.mDividerHeight; 
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        f += layoutParams.weight;
        if (k == 1073741824 && layoutParams.height == 0 && layoutParams.weight > 0.0F) {
          i6 = this.mTotalLength;
          this.mTotalLength = Math.max(i6, layoutParams.topMargin + i6 + layoutParams.bottomMargin);
          i6 = 1;
        } else {
          if (layoutParams.height == 0 && layoutParams.weight > 0.0F) {
            layoutParams.height = -2;
            i11 = 0;
          } else {
            i11 = Integer.MIN_VALUE;
          } 
          if (f == 0.0F) {
            i12 = this.mTotalLength;
          } else {
            i12 = 0;
          } 
          measureChildBeforeLayout(view, i5, paramInt1, 0, paramInt2, i12);
          if (i11 != Integer.MIN_VALUE)
            layoutParams.height = i11; 
          int i11 = view.getMeasuredHeight();
          int i12 = this.mTotalLength;
          this.mTotalLength = Math.max(i12, i12 + i11 + layoutParams.topMargin + layoutParams.bottomMargin + getNextLocationOffset(view));
          if (bool)
            i2 = Math.max(i11, i2); 
        } 
        if (m >= 0 && m == i5 + 1)
          this.mBaselineChildTop = this.mTotalLength; 
        if (i5 >= m || layoutParams.weight <= 0.0F) {
          if (j != 1073741824 && layoutParams.width == -1) {
            i11 = 1;
            i7 = 1;
          } else {
            i11 = 0;
          } 
          int i13 = layoutParams.leftMargin + layoutParams.rightMargin;
          int i12 = view.getMeasuredWidth() + i13;
          int i14 = Math.max(i1, i12);
          int i15 = View.combineMeasuredStates(n, view.getMeasuredState());
          if (i8 && layoutParams.width == -1) {
            n = 1;
          } else {
            n = 0;
          } 
          if (layoutParams.weight > 0.0F) {
            if (i11)
              i12 = i13; 
            i3 = Math.max(i3, i12);
            i8 = i4;
            i4 = i3;
          } else {
            if (!i11)
              i13 = i12; 
            i8 = Math.max(i4, i13);
            i4 = i3;
          } 
          int i11 = getChildrenSkipCount(view, i5);
          i1 = n;
          i3 = i4;
          i4 = i8;
          n = i15;
          i5 = i11 + i5;
          i11 = i14;
          i8 = i1;
          i1 = i11;
        } else {
          throw new RuntimeException("A child of LinearLayout with index less than mBaselineAlignedChildIndex has weight > 0, which won't work.  Either remove the weight, or don't set mBaselineAlignedChildIndex.");
        } 
      } 
      i5++;
    } 
    if (this.mTotalLength > 0 && hasDividerBeforeChildAt(i))
      this.mTotalLength += this.mDividerHeight; 
    if (bool && (k == Integer.MIN_VALUE || k == 0)) {
      this.mTotalLength = 0;
      for (i5 = 0; i5 < i; i5++) {
        View view = getVirtualChildAt(i5);
        if (view == null) {
          this.mTotalLength += measureNullChild(i5);
        } else if (view.getVisibility() == 8) {
          i5 += getChildrenSkipCount(view, i5);
        } else {
          LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
          int i11 = this.mTotalLength;
          this.mTotalLength = Math.max(i11, i11 + i2 + layoutParams.topMargin + layoutParams.bottomMargin + getNextLocationOffset(view));
        } 
      } 
    } 
    this.mTotalLength += getPaddingTop() + getPaddingBottom();
    int i10 = View.resolveSizeAndState(Math.max(this.mTotalLength, getSuggestedMinimumHeight()), paramInt2, 0);
    int i9 = (0xFFFFFF & i10) - this.mTotalLength;
    if (i6 != 0 || (i9 != 0 && f > 0.0F)) {
      float f1 = this.mWeightSum;
      if (f1 > 0.0F)
        f = f1; 
      this.mTotalLength = 0;
      i5 = 0;
      i3 = i9;
      i2 = i1;
      while (i5 < i) {
        View view = getVirtualChildAt(i5);
        if (view.getVisibility() != 8) {
          LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
          f1 = layoutParams.weight;
          if (f1 > 0.0F) {
            i1 = (int)(i3 * f1 / f);
            int i11 = getPaddingLeft();
            i9 = getPaddingRight();
            i6 = i3 - i1;
            int i12 = layoutParams.leftMargin;
            i3 = layoutParams.rightMargin;
            int i13 = layoutParams.width;
            f -= f1;
            i9 = getChildMeasureSpec(paramInt1, i11 + i9 + i12 + i3, i13);
            if (layoutParams.height != 0 || k != 1073741824) {
              i1 = view.getMeasuredHeight() + i1;
              i3 = i1;
              if (i1 < 0)
                i3 = 0; 
              view.measure(i9, View.MeasureSpec.makeMeasureSpec(i3, 1073741824));
            } else {
              if (i1 > 0) {
                i3 = i1;
              } else {
                i3 = 0;
              } 
              view.measure(i9, View.MeasureSpec.makeMeasureSpec(i3, 1073741824));
            } 
            n = View.combineMeasuredStates(n, view.getMeasuredState() & 0xFFFFFF00);
            i3 = i6;
          } 
          i9 = layoutParams.leftMargin + layoutParams.rightMargin;
          i1 = view.getMeasuredWidth() + i9;
          i6 = Math.max(i2, i1);
          if (j != 1073741824 && layoutParams.width == -1) {
            i2 = 1;
          } else {
            i2 = 0;
          } 
          if (i2 != 0) {
            i2 = i9;
          } else {
            i2 = i1;
          } 
          i4 = Math.max(i4, i2);
          if (i8 != 0 && layoutParams.width == -1) {
            i8 = 1;
          } else {
            i8 = 0;
          } 
          i2 = this.mTotalLength;
          this.mTotalLength = Math.max(i2, view.getMeasuredHeight() + i2 + layoutParams.topMargin + layoutParams.bottomMargin + getNextLocationOffset(view));
          i2 = i6;
        } 
        i5++;
      } 
      this.mTotalLength += getPaddingTop() + getPaddingBottom();
      i3 = i4;
      i4 = n;
      n = i3;
    } else {
      i3 = Math.max(i4, i3);
      if (bool && k != 1073741824)
        for (i4 = 0; i4 < i; i4++) {
          View view = getVirtualChildAt(i4);
          if (view != null && view.getVisibility() != 8 && ((LayoutParams)view.getLayoutParams()).weight > 0.0F)
            view.measure(View.MeasureSpec.makeMeasureSpec(view.getMeasuredWidth(), 1073741824), View.MeasureSpec.makeMeasureSpec(i2, 1073741824)); 
        }  
      i4 = n;
      n = i3;
      i2 = i1;
    } 
    if (i8 != 0 || j == 1073741824)
      n = i2; 
    setMeasuredDimension(View.resolveSizeAndState(Math.max(n + getPaddingLeft() + getPaddingRight(), getSuggestedMinimumWidth()), paramInt1, i4), i10);
    if (i7 != 0)
      forceUniformWidth(i, paramInt2); 
  }
  
  protected void onDraw(Canvas paramCanvas) {
    if (this.mDivider == null)
      return; 
    if (this.mOrientation == 1) {
      drawDividersVertical(paramCanvas);
    } else {
      drawDividersHorizontal(paramCanvas);
    } 
  }
  
  public void onInitializeAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent) {
    super.onInitializeAccessibilityEvent(paramAccessibilityEvent);
    paramAccessibilityEvent.setClassName("androidx.appcompat.widget.LinearLayoutCompat");
  }
  
  public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo paramAccessibilityNodeInfo) {
    super.onInitializeAccessibilityNodeInfo(paramAccessibilityNodeInfo);
    paramAccessibilityNodeInfo.setClassName("androidx.appcompat.widget.LinearLayoutCompat");
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (this.mOrientation == 1) {
      layoutVertical(paramInt1, paramInt2, paramInt3, paramInt4);
    } else {
      layoutHorizontal(paramInt1, paramInt2, paramInt3, paramInt4);
    } 
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    if (this.mOrientation == 1) {
      measureVertical(paramInt1, paramInt2);
    } else {
      measureHorizontal(paramInt1, paramInt2);
    } 
  }
  
  public void setBaselineAligned(boolean paramBoolean) {
    this.mBaselineAligned = paramBoolean;
  }
  
  public void setBaselineAlignedChildIndex(int paramInt) {
    if (paramInt >= 0 && paramInt < getChildCount()) {
      this.mBaselineAlignedChildIndex = paramInt;
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("base aligned child index out of range (0, ");
    stringBuilder.append(getChildCount());
    stringBuilder.append(")");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void setDividerDrawable(Drawable paramDrawable) {
    if (paramDrawable == this.mDivider)
      return; 
    this.mDivider = paramDrawable;
    boolean bool = false;
    if (paramDrawable != null) {
      this.mDividerWidth = paramDrawable.getIntrinsicWidth();
      this.mDividerHeight = paramDrawable.getIntrinsicHeight();
    } else {
      this.mDividerWidth = 0;
      this.mDividerHeight = 0;
    } 
    if (paramDrawable == null)
      bool = true; 
    setWillNotDraw(bool);
    requestLayout();
  }
  
  public void setDividerPadding(int paramInt) {
    this.mDividerPadding = paramInt;
  }
  
  public void setGravity(int paramInt) {
    if (this.mGravity != paramInt) {
      int i = paramInt;
      if ((0x800007 & paramInt) == 0)
        i = paramInt | 0x800003; 
      paramInt = i;
      if ((i & 0x70) == 0)
        paramInt = i | 0x30; 
      this.mGravity = paramInt;
      requestLayout();
    } 
  }
  
  public void setHorizontalGravity(int paramInt) {
    int i = paramInt & 0x800007;
    paramInt = this.mGravity;
    if ((0x800007 & paramInt) != i) {
      this.mGravity = i | 0xFF7FFFF8 & paramInt;
      requestLayout();
    } 
  }
  
  public void setMeasureWithLargestChildEnabled(boolean paramBoolean) {
    this.mUseLargestChild = paramBoolean;
  }
  
  public void setOrientation(int paramInt) {
    if (this.mOrientation != paramInt) {
      this.mOrientation = paramInt;
      requestLayout();
    } 
  }
  
  public void setShowDividers(int paramInt) {
    if (paramInt != this.mShowDividers)
      requestLayout(); 
    this.mShowDividers = paramInt;
  }
  
  public void setVerticalGravity(int paramInt) {
    paramInt &= 0x70;
    int i = this.mGravity;
    if ((i & 0x70) != paramInt) {
      this.mGravity = paramInt | i & 0xFFFFFF8F;
      requestLayout();
    } 
  }
  
  public void setWeightSum(float paramFloat) {
    this.mWeightSum = Math.max(0.0F, paramFloat);
  }
  
  public boolean shouldDelayChildPressedState() {
    return false;
  }
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface DividerMode {}
  
  public static class LayoutParams extends ViewGroup.MarginLayoutParams {
    public int gravity = -1;
    
    public float weight;
    
    public LayoutParams(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
      this.weight = 0.0F;
    }
    
    public LayoutParams(int param1Int1, int param1Int2, float param1Float) {
      super(param1Int1, param1Int2);
      this.weight = param1Float;
    }
    
    public LayoutParams(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
      TypedArray typedArray = param1Context.obtainStyledAttributes(param1AttributeSet, R.styleable.LinearLayoutCompat_Layout);
      this.weight = typedArray.getFloat(R.styleable.LinearLayoutCompat_Layout_android_layout_weight, 0.0F);
      this.gravity = typedArray.getInt(R.styleable.LinearLayoutCompat_Layout_android_layout_gravity, -1);
      typedArray.recycle();
    }
    
    public LayoutParams(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public LayoutParams(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      super(param1MarginLayoutParams);
    }
    
    public LayoutParams(LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
      this.weight = param1LayoutParams.weight;
      this.gravity = param1LayoutParams.gravity;
    }
  }
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface OrientationMode {}
}


/* Location:              /home/brandon/levelMeter_APK/dex2jar-2.x/dex-tools/build/distributions/dex-tools-2.2-SNAPSHOT/classes-dex2jar.jar!/androidx/appcompat/widget/LinearLayoutCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */