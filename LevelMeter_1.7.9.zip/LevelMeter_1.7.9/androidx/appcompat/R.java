package androidx.appcompat;

public final class R {
  public static final class anim {
    public static final int abc_fade_in = 2130771968;
    
    public static final int abc_fade_out = 2130771969;
    
    public static final int abc_grow_fade_in_from_bottom = 2130771970;
    
    public static final int abc_popup_enter = 2130771971;
    
    public static final int abc_popup_exit = 2130771972;
    
    public static final int abc_shrink_fade_out_from_bottom = 2130771973;
    
    public static final int abc_slide_in_bottom = 2130771974;
    
    public static final int abc_slide_in_top = 2130771975;
    
    public static final int abc_slide_out_bottom = 2130771976;
    
    public static final int abc_slide_out_top = 2130771977;
    
    public static final int abc_tooltip_enter = 2130771978;
    
    public static final int abc_tooltip_exit = 2130771979;
    
    public static final int btn_checkbox_to_checked_box_inner_merged_animation = 2130771980;
    
    public static final int btn_checkbox_to_checked_box_outer_merged_animation = 2130771981;
    
    public static final int btn_checkbox_to_checked_icon_null_animation = 2130771982;
    
    public static final int btn_checkbox_to_unchecked_box_inner_merged_animation = 2130771983;
    
    public static final int btn_checkbox_to_unchecked_check_path_merged_animation = 2130771984;
    
    public static final int btn_checkbox_to_unchecked_icon_null_animation = 2130771985;
    
    public static final int btn_radio_to_off_mtrl_dot_group_animation = 2130771986;
    
    public static final int btn_radio_to_off_mtrl_ring_outer_animation = 2130771987;
    
    public static final int btn_radio_to_off_mtrl_ring_outer_path_animation = 2130771988;
    
    public static final int btn_radio_to_on_mtrl_dot_group_animation = 2130771989;
    
    public static final int btn_radio_to_on_mtrl_ring_outer_animation = 2130771990;
    
    public static final int btn_radio_to_on_mtrl_ring_outer_path_animation = 2130771991;
  }
  
  public static final class attr {
    public static final int actionBarDivider = 2130968579;
    
    public static final int actionBarItemBackground = 2130968580;
    
    public static final int actionBarPopupTheme = 2130968581;
    
    public static final int actionBarSize = 2130968582;
    
    public static final int actionBarSplitStyle = 2130968583;
    
    public static final int actionBarStyle = 2130968584;
    
    public static final int actionBarTabBarStyle = 2130968585;
    
    public static final int actionBarTabStyle = 2130968586;
    
    public static final int actionBarTabTextStyle = 2130968587;
    
    public static final int actionBarTheme = 2130968588;
    
    public static final int actionBarWidgetTheme = 2130968589;
    
    public static final int actionButtonStyle = 2130968590;
    
    public static final int actionDropDownStyle = 2130968591;
    
    public static final int actionLayout = 2130968592;
    
    public static final int actionMenuTextAppearance = 2130968593;
    
    public static final int actionMenuTextColor = 2130968594;
    
    public static final int actionModeBackground = 2130968595;
    
    public static final int actionModeCloseButtonStyle = 2130968596;
    
    public static final int actionModeCloseDrawable = 2130968597;
    
    public static final int actionModeCopyDrawable = 2130968598;
    
    public static final int actionModeCutDrawable = 2130968599;
    
    public static final int actionModeFindDrawable = 2130968600;
    
    public static final int actionModePasteDrawable = 2130968601;
    
    public static final int actionModePopupWindowStyle = 2130968602;
    
    public static final int actionModeSelectAllDrawable = 2130968603;
    
    public static final int actionModeShareDrawable = 2130968604;
    
    public static final int actionModeSplitBackground = 2130968605;
    
    public static final int actionModeStyle = 2130968606;
    
    public static final int actionModeWebSearchDrawable = 2130968607;
    
    public static final int actionOverflowButtonStyle = 2130968608;
    
    public static final int actionOverflowMenuStyle = 2130968609;
    
    public static final int actionProviderClass = 2130968610;
    
    public static final int actionViewClass = 2130968612;
    
    public static final int activityChooserViewStyle = 2130968613;
    
    public static final int alertDialogButtonGroupStyle = 2130968614;
    
    public static final int alertDialogCenterButtons = 2130968615;
    
    public static final int alertDialogStyle = 2130968616;
    
    public static final int alertDialogTheme = 2130968617;
    
    public static final int allowStacking = 2130968618;
    
    public static final int alpha = 2130968619;
    
    public static final int alphabeticModifiers = 2130968620;
    
    public static final int arrowHeadLength = 2130968623;
    
    public static final int arrowShaftLength = 2130968624;
    
    public static final int autoCompleteTextViewStyle = 2130968625;
    
    public static final int autoSizeMaxTextSize = 2130968626;
    
    public static final int autoSizeMinTextSize = 2130968627;
    
    public static final int autoSizePresetSizes = 2130968628;
    
    public static final int autoSizeStepGranularity = 2130968629;
    
    public static final int autoSizeTextType = 2130968630;
    
    public static final int background = 2130968631;
    
    public static final int backgroundSplit = 2130968638;
    
    public static final int backgroundStacked = 2130968639;
    
    public static final int backgroundTint = 2130968640;
    
    public static final int backgroundTintMode = 2130968641;
    
    public static final int barLength = 2130968645;
    
    public static final int borderlessButtonStyle = 2130968659;
    
    public static final int buttonBarButtonStyle = 2130968673;
    
    public static final int buttonBarNegativeButtonStyle = 2130968674;
    
    public static final int buttonBarNeutralButtonStyle = 2130968675;
    
    public static final int buttonBarPositiveButtonStyle = 2130968676;
    
    public static final int buttonBarStyle = 2130968677;
    
    public static final int buttonCompat = 2130968678;
    
    public static final int buttonGravity = 2130968679;
    
    public static final int buttonIconDimen = 2130968680;
    
    public static final int buttonPanelSideLayout = 2130968681;
    
    public static final int buttonStyle = 2130968682;
    
    public static final int buttonStyleSmall = 2130968683;
    
    public static final int buttonTint = 2130968684;
    
    public static final int buttonTintMode = 2130968685;
    
    public static final int checkboxStyle = 2130968695;
    
    public static final int checkedTextViewStyle = 2130968702;
    
    public static final int closeIcon = 2130968723;
    
    public static final int closeItemLayout = 2130968730;
    
    public static final int collapseContentDescription = 2130968731;
    
    public static final int collapseIcon = 2130968732;
    
    public static final int color = 2130968735;
    
    public static final int colorAccent = 2130968736;
    
    public static final int colorBackgroundFloating = 2130968737;
    
    public static final int colorButtonNormal = 2130968738;
    
    public static final int colorControlActivated = 2130968739;
    
    public static final int colorControlHighlight = 2130968740;
    
    public static final int colorControlNormal = 2130968741;
    
    public static final int colorError = 2130968742;
    
    public static final int colorPrimary = 2130968749;
    
    public static final int colorPrimaryDark = 2130968750;
    
    public static final int colorSwitchThumbNormal = 2130968756;
    
    public static final int commitIcon = 2130968757;
    
    public static final int contentDescription = 2130968761;
    
    public static final int contentInsetEnd = 2130968762;
    
    public static final int contentInsetEndWithActions = 2130968763;
    
    public static final int contentInsetLeft = 2130968764;
    
    public static final int contentInsetRight = 2130968765;
    
    public static final int contentInsetStart = 2130968766;
    
    public static final int contentInsetStartWithNavigation = 2130968767;
    
    public static final int controlBackground = 2130968774;
    
    public static final int customNavigationLayout = 2130968793;
    
    public static final int defaultQueryHint = 2130968798;
    
    public static final int dialogCornerRadius = 2130968799;
    
    public static final int dialogPreferredPadding = 2130968800;
    
    public static final int dialogTheme = 2130968801;
    
    public static final int displayOptions = 2130968802;
    
    public static final int divider = 2130968803;
    
    public static final int dividerHorizontal = 2130968804;
    
    public static final int dividerPadding = 2130968805;
    
    public static final int dividerVertical = 2130968806;
    
    public static final int drawableBottomCompat = 2130968807;
    
    public static final int drawableEndCompat = 2130968808;
    
    public static final int drawableLeftCompat = 2130968809;
    
    public static final int drawableRightCompat = 2130968810;
    
    public static final int drawableSize = 2130968811;
    
    public static final int drawableStartCompat = 2130968812;
    
    public static final int drawableTint = 2130968813;
    
    public static final int drawableTintMode = 2130968814;
    
    public static final int drawableTopCompat = 2130968815;
    
    public static final int drawerArrowStyle = 2130968816;
    
    public static final int dropDownListViewStyle = 2130968817;
    
    public static final int dropdownListPreferredItemHeight = 2130968818;
    
    public static final int editTextBackground = 2130968819;
    
    public static final int editTextColor = 2130968820;
    
    public static final int editTextStyle = 2130968821;
    
    public static final int elevation = 2130968822;
    
    public static final int expandActivityOverflowButtonDrawable = 2130968841;
    
    public static final int firstBaselineToTopHeight = 2130968864;
    
    public static final int font = 2130968866;
    
    public static final int fontFamily = 2130968867;
    
    public static final int fontProviderAuthority = 2130968868;
    
    public static final int fontProviderCerts = 2130968869;
    
    public static final int fontProviderFetchStrategy = 2130968870;
    
    public static final int fontProviderFetchTimeout = 2130968871;
    
    public static final int fontProviderPackage = 2130968872;
    
    public static final int fontProviderQuery = 2130968873;
    
    public static final int fontStyle = 2130968874;
    
    public static final int fontVariationSettings = 2130968875;
    
    public static final int fontWeight = 2130968876;
    
    public static final int gapBetweenBars = 2130968878;
    
    public static final int goIcon = 2130968879;
    
    public static final int height = 2130968881;
    
    public static final int hideOnContentScroll = 2130968887;
    
    public static final int homeAsUpIndicator = 2130968893;
    
    public static final int homeLayout = 2130968894;
    
    public static final int icon = 2130968896;
    
    public static final int iconTint = 2130968902;
    
    public static final int iconTintMode = 2130968903;
    
    public static final int iconifiedByDefault = 2130968904;
    
    public static final int imageButtonStyle = 2130968905;
    
    public static final int indeterminateProgressStyle = 2130968906;
    
    public static final int initialActivityCount = 2130968907;
    
    public static final int isLightTheme = 2130968909;
    
    public static final int itemPadding = 2130968919;
    
    public static final int lastBaselineToBottomHeight = 2130968937;
    
    public static final int layout = 2130968938;
    
    public static final int lineHeight = 2130969012;
    
    public static final int listChoiceBackgroundIndicator = 2130969014;
    
    public static final int listChoiceIndicatorMultipleAnimated = 2130969015;
    
    public static final int listChoiceIndicatorSingleAnimated = 2130969016;
    
    public static final int listDividerAlertDialog = 2130969017;
    
    public static final int listItemLayout = 2130969018;
    
    public static final int listLayout = 2130969019;
    
    public static final int listMenuViewStyle = 2130969020;
    
    public static final int listPopupWindowStyle = 2130969021;
    
    public static final int listPreferredItemHeight = 2130969022;
    
    public static final int listPreferredItemHeightLarge = 2130969023;
    
    public static final int listPreferredItemHeightSmall = 2130969024;
    
    public static final int listPreferredItemPaddingEnd = 2130969025;
    
    public static final int listPreferredItemPaddingLeft = 2130969026;
    
    public static final int listPreferredItemPaddingRight = 2130969027;
    
    public static final int listPreferredItemPaddingStart = 2130969028;
    
    public static final int logo = 2130969029;
    
    public static final int logoDescription = 2130969030;
    
    public static final int maxButtonHeight = 2130969050;
    
    public static final int measureWithLargestChild = 2130969053;
    
    public static final int menu = 2130969054;
    
    public static final int multiChoiceItemLayout = 2130969056;
    
    public static final int navigationContentDescription = 2130969057;
    
    public static final int navigationIcon = 2130969058;
    
    public static final int navigationMode = 2130969059;
    
    public static final int numericModifiers = 2130969062;
    
    public static final int overlapAnchor = 2130969063;
    
    public static final int paddingBottomNoButtons = 2130969064;
    
    public static final int paddingEnd = 2130969065;
    
    public static final int paddingStart = 2130969066;
    
    public static final int paddingTopNoTitle = 2130969067;
    
    public static final int panelBackground = 2130969068;
    
    public static final int panelMenuListTheme = 2130969069;
    
    public static final int panelMenuListWidth = 2130969070;
    
    public static final int popupMenuStyle = 2130969076;
    
    public static final int popupTheme = 2130969077;
    
    public static final int popupWindowStyle = 2130969078;
    
    public static final int preserveIconSpacing = 2130969079;
    
    public static final int progressBarPadding = 2130969081;
    
    public static final int progressBarStyle = 2130969082;
    
    public static final int queryBackground = 2130969083;
    
    public static final int queryHint = 2130969084;
    
    public static final int radioButtonStyle = 2130969085;
    
    public static final int ratingBarStyle = 2130969087;
    
    public static final int ratingBarStyleIndicator = 2130969088;
    
    public static final int ratingBarStyleSmall = 2130969089;
    
    public static final int searchHintIcon = 2130969095;
    
    public static final int searchIcon = 2130969096;
    
    public static final int searchViewStyle = 2130969097;
    
    public static final int seekBarStyle = 2130969098;
    
    public static final int selectableItemBackground = 2130969099;
    
    public static final int selectableItemBackgroundBorderless = 2130969100;
    
    public static final int showAsAction = 2130969106;
    
    public static final int showDividers = 2130969107;
    
    public static final int showText = 2130969109;
    
    public static final int showTitle = 2130969110;
    
    public static final int singleChoiceItemLayout = 2130969112;
    
    public static final int spinBars = 2130969118;
    
    public static final int spinnerDropDownItemStyle = 2130969119;
    
    public static final int spinnerStyle = 2130969120;
    
    public static final int splitTrack = 2130969121;
    
    public static final int srcCompat = 2130969122;
    
    public static final int state_above_anchor = 2130969129;
    
    public static final int subMenuArrow = 2130969140;
    
    public static final int submitBackground = 2130969141;
    
    public static final int subtitle = 2130969142;
    
    public static final int subtitleTextAppearance = 2130969143;
    
    public static final int subtitleTextColor = 2130969144;
    
    public static final int subtitleTextStyle = 2130969145;
    
    public static final int suggestionRowLayout = 2130969146;
    
    public static final int switchMinWidth = 2130969147;
    
    public static final int switchPadding = 2130969148;
    
    public static final int switchStyle = 2130969149;
    
    public static final int switchTextAppearance = 2130969150;
    
    public static final int textAllCaps = 2130969177;
    
    public static final int textAppearanceLargePopupMenu = 2130969188;
    
    public static final int textAppearanceListItem = 2130969190;
    
    public static final int textAppearanceListItemSecondary = 2130969191;
    
    public static final int textAppearanceListItemSmall = 2130969192;
    
    public static final int textAppearancePopupMenuHeader = 2130969194;
    
    public static final int textAppearanceSearchResultSubtitle = 2130969195;
    
    public static final int textAppearanceSearchResultTitle = 2130969196;
    
    public static final int textAppearanceSmallPopupMenu = 2130969197;
    
    public static final int textColorAlertDialogListItem = 2130969200;
    
    public static final int textColorSearchUrl = 2130969201;
    
    public static final int textLocale = 2130969204;
    
    public static final int theme = 2130969206;
    
    public static final int thickness = 2130969208;
    
    public static final int thumbTextPadding = 2130969209;
    
    public static final int thumbTint = 2130969210;
    
    public static final int thumbTintMode = 2130969211;
    
    public static final int tickMark = 2130969212;
    
    public static final int tickMarkTint = 2130969213;
    
    public static final int tickMarkTintMode = 2130969214;
    
    public static final int tint = 2130969215;
    
    public static final int tintMode = 2130969216;
    
    public static final int title = 2130969217;
    
    public static final int titleMargin = 2130969219;
    
    public static final int titleMarginBottom = 2130969220;
    
    public static final int titleMarginEnd = 2130969221;
    
    public static final int titleMarginStart = 2130969222;
    
    public static final int titleMarginTop = 2130969223;
    
    public static final int titleMargins = 2130969224;
    
    public static final int titleTextAppearance = 2130969225;
    
    public static final int titleTextColor = 2130969226;
    
    public static final int titleTextStyle = 2130969227;
    
    public static final int toolbarNavigationButtonStyle = 2130969229;
    
    public static final int toolbarStyle = 2130969230;
    
    public static final int tooltipForegroundColor = 2130969231;
    
    public static final int tooltipFrameBackground = 2130969232;
    
    public static final int tooltipText = 2130969233;
    
    public static final int track = 2130969234;
    
    public static final int trackTint = 2130969235;
    
    public static final int trackTintMode = 2130969236;
    
    public static final int ttcIndex = 2130969237;
    
    public static final int viewInflaterClass = 2130969240;
    
    public static final int voiceIcon = 2130969241;
    
    public static final int windowActionBar = 2130969242;
    
    public static final int windowActionBarOverlay = 2130969243;
    
    public static final int windowActionModeOverlay = 2130969244;
    
    public static final int windowFixedHeightMajor = 2130969245;
    
    public static final int windowFixedHeightMinor = 2130969246;
    
    public static final int windowFixedWidthMajor = 2130969247;
    
    public static final int windowFixedWidthMinor = 2130969248;
    
    public static final int windowMinWidthMajor = 2130969249;
    
    public static final int windowMinWidthMinor = 2130969250;
    
    public static final int windowNoTitle = 2130969251;
  }
  
  public static final class bool {
    public static final int abc_action_bar_embed_tabs = 2131034112;
    
    public static final int abc_allow_stacked_button_bar = 2131034113;
    
    public static final int abc_config_actionMenuItemAllCaps = 2131034114;
  }
  
  public static final class color {
    public static final int abc_background_cache_hint_selector_material_dark = 2131099648;
    
    public static final int abc_background_cache_hint_selector_material_light = 2131099649;
    
    public static final int abc_btn_colored_borderless_text_material = 2131099650;
    
    public static final int abc_btn_colored_text_material = 2131099651;
    
    public static final int abc_color_highlight_material = 2131099652;
    
    public static final int abc_hint_foreground_material_dark = 2131099653;
    
    public static final int abc_hint_foreground_material_light = 2131099654;
    
    public static final int abc_input_method_navigation_guard = 2131099655;
    
    public static final int abc_primary_text_disable_only_material_dark = 2131099656;
    
    public static final int abc_primary_text_disable_only_material_light = 2131099657;
    
    public static final int abc_primary_text_material_dark = 2131099658;
    
    public static final int abc_primary_text_material_light = 2131099659;
    
    public static final int abc_search_url_text = 2131099660;
    
    public static final int abc_search_url_text_normal = 2131099661;
    
    public static final int abc_search_url_text_pressed = 2131099662;
    
    public static final int abc_search_url_text_selected = 2131099663;
    
    public static final int abc_secondary_text_material_dark = 2131099664;
    
    public static final int abc_secondary_text_material_light = 2131099665;
    
    public static final int abc_tint_btn_checkable = 2131099666;
    
    public static final int abc_tint_default = 2131099667;
    
    public static final int abc_tint_edittext = 2131099668;
    
    public static final int abc_tint_seek_thumb = 2131099669;
    
    public static final int abc_tint_spinner = 2131099670;
    
    public static final int abc_tint_switch_track = 2131099671;
    
    public static final int accent_material_dark = 2131099673;
    
    public static final int accent_material_light = 2131099674;
    
    public static final int background_floating_material_dark = 2131099676;
    
    public static final int background_floating_material_light = 2131099677;
    
    public static final int background_material_dark = 2131099678;
    
    public static final int background_material_light = 2131099679;
    
    public static final int bright_foreground_disabled_material_dark = 2131099681;
    
    public static final int bright_foreground_disabled_material_light = 2131099682;
    
    public static final int bright_foreground_inverse_material_dark = 2131099683;
    
    public static final int bright_foreground_inverse_material_light = 2131099684;
    
    public static final int bright_foreground_material_dark = 2131099685;
    
    public static final int bright_foreground_material_light = 2131099686;
    
    public static final int button_material_dark = 2131099687;
    
    public static final int button_material_light = 2131099688;
    
    public static final int dim_foreground_disabled_material_dark = 2131099733;
    
    public static final int dim_foreground_disabled_material_light = 2131099734;
    
    public static final int dim_foreground_material_dark = 2131099735;
    
    public static final int dim_foreground_material_light = 2131099736;
    
    public static final int error_color_material_dark = 2131099740;
    
    public static final int error_color_material_light = 2131099741;
    
    public static final int foreground_material_dark = 2131099742;
    
    public static final int foreground_material_light = 2131099743;
    
    public static final int highlighted_text_material_dark = 2131099744;
    
    public static final int highlighted_text_material_light = 2131099745;
    
    public static final int material_blue_grey_800 = 2131099750;
    
    public static final int material_blue_grey_900 = 2131099751;
    
    public static final int material_blue_grey_950 = 2131099752;
    
    public static final int material_deep_teal_200 = 2131099753;
    
    public static final int material_deep_teal_500 = 2131099754;
    
    public static final int material_grey_100 = 2131099755;
    
    public static final int material_grey_300 = 2131099756;
    
    public static final int material_grey_50 = 2131099757;
    
    public static final int material_grey_600 = 2131099758;
    
    public static final int material_grey_800 = 2131099759;
    
    public static final int material_grey_850 = 2131099760;
    
    public static final int material_grey_900 = 2131099761;
    
    public static final int notification_action_color_filter = 2131100075;
    
    public static final int notification_icon_bg_color = 2131100076;
    
    public static final int primary_dark_material_dark = 2131100079;
    
    public static final int primary_dark_material_light = 2131100080;
    
    public static final int primary_material_dark = 2131100082;
    
    public static final int primary_material_light = 2131100083;
    
    public static final int primary_text_default_material_dark = 2131100086;
    
    public static final int primary_text_default_material_light = 2131100087;
    
    public static final int primary_text_disabled_material_dark = 2131100088;
    
    public static final int primary_text_disabled_material_light = 2131100089;
    
    public static final int ripple_material_dark = 2131100091;
    
    public static final int ripple_material_light = 2131100092;
    
    public static final int secondary_text_default_material_dark = 2131100095;
    
    public static final int secondary_text_default_material_light = 2131100096;
    
    public static final int secondary_text_disabled_material_dark = 2131100097;
    
    public static final int secondary_text_disabled_material_light = 2131100098;
    
    public static final int switch_thumb_disabled_material_dark = 2131100100;
    
    public static final int switch_thumb_disabled_material_light = 2131100101;
    
    public static final int switch_thumb_material_dark = 2131100102;
    
    public static final int switch_thumb_material_light = 2131100103;
    
    public static final int switch_thumb_normal_material_dark = 2131100104;
    
    public static final int switch_thumb_normal_material_light = 2131100105;
    
    public static final int tooltip_background_dark = 2131100111;
    
    public static final int tooltip_background_light = 2131100112;
  }
  
  public static final class dimen {
    public static final int abc_action_bar_content_inset_material = 2131165184;
    
    public static final int abc_action_bar_content_inset_with_nav = 2131165185;
    
    public static final int abc_action_bar_default_height_material = 2131165186;
    
    public static final int abc_action_bar_default_padding_end_material = 2131165187;
    
    public static final int abc_action_bar_default_padding_start_material = 2131165188;
    
    public static final int abc_action_bar_elevation_material = 2131165189;
    
    public static final int abc_action_bar_icon_vertical_padding_material = 2131165190;
    
    public static final int abc_action_bar_overflow_padding_end_material = 2131165191;
    
    public static final int abc_action_bar_overflow_padding_start_material = 2131165192;
    
    public static final int abc_action_bar_stacked_max_height = 2131165193;
    
    public static final int abc_action_bar_stacked_tab_max_width = 2131165194;
    
    public static final int abc_action_bar_subtitle_bottom_margin_material = 2131165195;
    
    public static final int abc_action_bar_subtitle_top_margin_material = 2131165196;
    
    public static final int abc_action_button_min_height_material = 2131165197;
    
    public static final int abc_action_button_min_width_material = 2131165198;
    
    public static final int abc_action_button_min_width_overflow_material = 2131165199;
    
    public static final int abc_alert_dialog_button_bar_height = 2131165200;
    
    public static final int abc_alert_dialog_button_dimen = 2131165201;
    
    public static final int abc_button_inset_horizontal_material = 2131165202;
    
    public static final int abc_button_inset_vertical_material = 2131165203;
    
    public static final int abc_button_padding_horizontal_material = 2131165204;
    
    public static final int abc_button_padding_vertical_material = 2131165205;
    
    public static final int abc_cascading_menus_min_smallest_width = 2131165206;
    
    public static final int abc_config_prefDialogWidth = 2131165207;
    
    public static final int abc_control_corner_material = 2131165208;
    
    public static final int abc_control_inset_material = 2131165209;
    
    public static final int abc_control_padding_material = 2131165210;
    
    public static final int abc_dialog_corner_radius_material = 2131165211;
    
    public static final int abc_dialog_fixed_height_major = 2131165212;
    
    public static final int abc_dialog_fixed_height_minor = 2131165213;
    
    public static final int abc_dialog_fixed_width_major = 2131165214;
    
    public static final int abc_dialog_fixed_width_minor = 2131165215;
    
    public static final int abc_dialog_list_padding_bottom_no_buttons = 2131165216;
    
    public static final int abc_dialog_list_padding_top_no_title = 2131165217;
    
    public static final int abc_dialog_min_width_major = 2131165218;
    
    public static final int abc_dialog_min_width_minor = 2131165219;
    
    public static final int abc_dialog_padding_material = 2131165220;
    
    public static final int abc_dialog_padding_top_material = 2131165221;
    
    public static final int abc_dialog_title_divider_material = 2131165222;
    
    public static final int abc_disabled_alpha_material_dark = 2131165223;
    
    public static final int abc_disabled_alpha_material_light = 2131165224;
    
    public static final int abc_dropdownitem_icon_width = 2131165225;
    
    public static final int abc_dropdownitem_text_padding_left = 2131165226;
    
    public static final int abc_dropdownitem_text_padding_right = 2131165227;
    
    public static final int abc_edit_text_inset_bottom_material = 2131165228;
    
    public static final int abc_edit_text_inset_horizontal_material = 2131165229;
    
    public static final int abc_edit_text_inset_top_material = 2131165230;
    
    public static final int abc_floating_window_z = 2131165231;
    
    public static final int abc_list_item_height_large_material = 2131165232;
    
    public static final int abc_list_item_height_material = 2131165233;
    
    public static final int abc_list_item_height_small_material = 2131165234;
    
    public static final int abc_list_item_padding_horizontal_material = 2131165235;
    
    public static final int abc_panel_menu_list_width = 2131165236;
    
    public static final int abc_progress_bar_height_material = 2131165237;
    
    public static final int abc_search_view_preferred_height = 2131165238;
    
    public static final int abc_search_view_preferred_width = 2131165239;
    
    public static final int abc_seekbar_track_background_height_material = 2131165240;
    
    public static final int abc_seekbar_track_progress_height_material = 2131165241;
    
    public static final int abc_select_dialog_padding_start_material = 2131165242;
    
    public static final int abc_switch_padding = 2131165243;
    
    public static final int abc_text_size_body_1_material = 2131165244;
    
    public static final int abc_text_size_body_2_material = 2131165245;
    
    public static final int abc_text_size_button_material = 2131165246;
    
    public static final int abc_text_size_caption_material = 2131165247;
    
    public static final int abc_text_size_display_1_material = 2131165248;
    
    public static final int abc_text_size_display_2_material = 2131165249;
    
    public static final int abc_text_size_display_3_material = 2131165250;
    
    public static final int abc_text_size_display_4_material = 2131165251;
    
    public static final int abc_text_size_headline_material = 2131165252;
    
    public static final int abc_text_size_large_material = 2131165253;
    
    public static final int abc_text_size_medium_material = 2131165254;
    
    public static final int abc_text_size_menu_header_material = 2131165255;
    
    public static final int abc_text_size_menu_material = 2131165256;
    
    public static final int abc_text_size_small_material = 2131165257;
    
    public static final int abc_text_size_subhead_material = 2131165258;
    
    public static final int abc_text_size_subtitle_material_toolbar = 2131165259;
    
    public static final int abc_text_size_title_material = 2131165260;
    
    public static final int abc_text_size_title_material_toolbar = 2131165261;
    
    public static final int compat_button_inset_horizontal_material = 2131165269;
    
    public static final int compat_button_inset_vertical_material = 2131165270;
    
    public static final int compat_button_padding_horizontal_material = 2131165271;
    
    public static final int compat_button_padding_vertical_material = 2131165272;
    
    public static final int compat_control_corner_material = 2131165273;
    
    public static final int compat_notification_large_icon_max_height = 2131165274;
    
    public static final int compat_notification_large_icon_max_width = 2131165275;
    
    public static final int disabled_alpha_material_dark = 2131165323;
    
    public static final int disabled_alpha_material_light = 2131165324;
    
    public static final int highlight_alpha_material_colored = 2131165329;
    
    public static final int highlight_alpha_material_dark = 2131165330;
    
    public static final int highlight_alpha_material_light = 2131165331;
    
    public static final int hint_alpha_material_dark = 2131165332;
    
    public static final int hint_alpha_material_light = 2131165333;
    
    public static final int hint_pressed_alpha_material_dark = 2131165334;
    
    public static final int hint_pressed_alpha_material_light = 2131165335;
    
    public static final int notification_action_icon_size = 2131165485;
    
    public static final int notification_action_text_size = 2131165486;
    
    public static final int notification_big_circle_margin = 2131165487;
    
    public static final int notification_content_margin_start = 2131165488;
    
    public static final int notification_large_icon_height = 2131165489;
    
    public static final int notification_large_icon_width = 2131165490;
    
    public static final int notification_main_column_padding_top = 2131165491;
    
    public static final int notification_media_narrow_margin = 2131165492;
    
    public static final int notification_right_icon_size = 2131165493;
    
    public static final int notification_right_side_padding_top = 2131165494;
    
    public static final int notification_small_icon_background_padding = 2131165495;
    
    public static final int notification_small_icon_size_as_large = 2131165496;
    
    public static final int notification_subtext_size = 2131165497;
    
    public static final int notification_top_pad = 2131165498;
    
    public static final int notification_top_pad_large_text = 2131165499;
    
    public static final int tooltip_corner_radius = 2131165501;
    
    public static final int tooltip_horizontal_padding = 2131165502;
    
    public static final int tooltip_margin = 2131165503;
    
    public static final int tooltip_precise_anchor_extra_offset = 2131165504;
    
    public static final int tooltip_precise_anchor_threshold = 2131165505;
    
    public static final int tooltip_vertical_padding = 2131165506;
    
    public static final int tooltip_y_offset_non_touch = 2131165507;
    
    public static final int tooltip_y_offset_touch = 2131165508;
  }
  
  public static final class drawable {
    public static final int abc_ab_share_pack_mtrl_alpha = 2131230726;
    
    public static final int abc_action_bar_item_background_material = 2131230727;
    
    public static final int abc_btn_borderless_material = 2131230728;
    
    public static final int abc_btn_check_material = 2131230729;
    
    public static final int abc_btn_check_material_anim = 2131230730;
    
    public static final int abc_btn_check_to_on_mtrl_000 = 2131230731;
    
    public static final int abc_btn_check_to_on_mtrl_015 = 2131230732;
    
    public static final int abc_btn_colored_material = 2131230733;
    
    public static final int abc_btn_default_mtrl_shape = 2131230734;
    
    public static final int abc_btn_radio_material = 2131230735;
    
    public static final int abc_btn_radio_material_anim = 2131230736;
    
    public static final int abc_btn_radio_to_on_mtrl_000 = 2131230737;
    
    public static final int abc_btn_radio_to_on_mtrl_015 = 2131230738;
    
    public static final int abc_btn_switch_to_on_mtrl_00001 = 2131230739;
    
    public static final int abc_btn_switch_to_on_mtrl_00012 = 2131230740;
    
    public static final int abc_cab_background_internal_bg = 2131230741;
    
    public static final int abc_cab_background_top_material = 2131230742;
    
    public static final int abc_cab_background_top_mtrl_alpha = 2131230743;
    
    public static final int abc_control_background_material = 2131230744;
    
    public static final int abc_dialog_material_background = 2131230745;
    
    public static final int abc_edit_text_material = 2131230746;
    
    public static final int abc_ic_ab_back_material = 2131230747;
    
    public static final int abc_ic_arrow_drop_right_black_24dp = 2131230748;
    
    public static final int abc_ic_clear_material = 2131230749;
    
    public static final int abc_ic_commit_search_api_mtrl_alpha = 2131230750;
    
    public static final int abc_ic_go_search_api_material = 2131230751;
    
    public static final int abc_ic_menu_copy_mtrl_am_alpha = 2131230752;
    
    public static final int abc_ic_menu_cut_mtrl_alpha = 2131230753;
    
    public static final int abc_ic_menu_overflow_material = 2131230754;
    
    public static final int abc_ic_menu_paste_mtrl_am_alpha = 2131230755;
    
    public static final int abc_ic_menu_selectall_mtrl_alpha = 2131230756;
    
    public static final int abc_ic_menu_share_mtrl_alpha = 2131230757;
    
    public static final int abc_ic_search_api_material = 2131230758;
    
    public static final int abc_ic_star_black_16dp = 2131230759;
    
    public static final int abc_ic_star_black_36dp = 2131230760;
    
    public static final int abc_ic_star_black_48dp = 2131230761;
    
    public static final int abc_ic_star_half_black_16dp = 2131230762;
    
    public static final int abc_ic_star_half_black_36dp = 2131230763;
    
    public static final int abc_ic_star_half_black_48dp = 2131230764;
    
    public static final int abc_ic_voice_search_api_material = 2131230765;
    
    public static final int abc_item_background_holo_dark = 2131230766;
    
    public static final int abc_item_background_holo_light = 2131230767;
    
    public static final int abc_list_divider_material = 2131230768;
    
    public static final int abc_list_divider_mtrl_alpha = 2131230769;
    
    public static final int abc_list_focused_holo = 2131230770;
    
    public static final int abc_list_longpressed_holo = 2131230771;
    
    public static final int abc_list_pressed_holo_dark = 2131230772;
    
    public static final int abc_list_pressed_holo_light = 2131230773;
    
    public static final int abc_list_selector_background_transition_holo_dark = 2131230774;
    
    public static final int abc_list_selector_background_transition_holo_light = 2131230775;
    
    public static final int abc_list_selector_disabled_holo_dark = 2131230776;
    
    public static final int abc_list_selector_disabled_holo_light = 2131230777;
    
    public static final int abc_list_selector_holo_dark = 2131230778;
    
    public static final int abc_list_selector_holo_light = 2131230779;
    
    public static final int abc_menu_hardkey_panel_mtrl_mult = 2131230780;
    
    public static final int abc_popup_background_mtrl_mult = 2131230781;
    
    public static final int abc_ratingbar_indicator_material = 2131230782;
    
    public static final int abc_ratingbar_material = 2131230783;
    
    public static final int abc_ratingbar_small_material = 2131230784;
    
    public static final int abc_scrubber_control_off_mtrl_alpha = 2131230785;
    
    public static final int abc_scrubber_control_to_pressed_mtrl_000 = 2131230786;
    
    public static final int abc_scrubber_control_to_pressed_mtrl_005 = 2131230787;
    
    public static final int abc_scrubber_primary_mtrl_alpha = 2131230788;
    
    public static final int abc_scrubber_track_mtrl_alpha = 2131230789;
    
    public static final int abc_seekbar_thumb_material = 2131230790;
    
    public static final int abc_seekbar_tick_mark_material = 2131230791;
    
    public static final int abc_seekbar_track_material = 2131230792;
    
    public static final int abc_spinner_mtrl_am_alpha = 2131230793;
    
    public static final int abc_spinner_textfield_background_material = 2131230794;
    
    public static final int abc_switch_thumb_material = 2131230795;
    
    public static final int abc_switch_track_mtrl_alpha = 2131230796;
    
    public static final int abc_tab_indicator_material = 2131230797;
    
    public static final int abc_tab_indicator_mtrl_alpha = 2131230798;
    
    public static final int abc_text_cursor_material = 2131230799;
    
    public static final int abc_text_select_handle_left_mtrl_dark = 2131230800;
    
    public static final int abc_text_select_handle_left_mtrl_light = 2131230801;
    
    public static final int abc_text_select_handle_middle_mtrl_dark = 2131230802;
    
    public static final int abc_text_select_handle_middle_mtrl_light = 2131230803;
    
    public static final int abc_text_select_handle_right_mtrl_dark = 2131230804;
    
    public static final int abc_text_select_handle_right_mtrl_light = 2131230805;
    
    public static final int abc_textfield_activated_mtrl_alpha = 2131230806;
    
    public static final int abc_textfield_default_mtrl_alpha = 2131230807;
    
    public static final int abc_textfield_search_activated_mtrl_alpha = 2131230808;
    
    public static final int abc_textfield_search_default_mtrl_alpha = 2131230809;
    
    public static final int abc_textfield_search_material = 2131230810;
    
    public static final int abc_vector_test = 2131230811;
    
    public static final int btn_checkbox_checked_mtrl = 2131230815;
    
    public static final int btn_checkbox_checked_to_unchecked_mtrl_animation = 2131230816;
    
    public static final int btn_checkbox_unchecked_mtrl = 2131230817;
    
    public static final int btn_checkbox_unchecked_to_checked_mtrl_animation = 2131230818;
    
    public static final int btn_radio_off_mtrl = 2131230819;
    
    public static final int btn_radio_off_to_on_mtrl_animation = 2131230820;
    
    public static final int btn_radio_on_mtrl = 2131230821;
    
    public static final int btn_radio_on_to_off_mtrl_animation = 2131230822;
    
    public static final int notification_action_background = 2131230859;
    
    public static final int notification_bg = 2131230860;
    
    public static final int notification_bg_low = 2131230861;
    
    public static final int notification_bg_low_normal = 2131230862;
    
    public static final int notification_bg_low_pressed = 2131230863;
    
    public static final int notification_bg_normal = 2131230864;
    
    public static final int notification_bg_normal_pressed = 2131230865;
    
    public static final int notification_icon_background = 2131230866;
    
    public static final int notification_template_icon_bg = 2131230867;
    
    public static final int notification_template_icon_low_bg = 2131230868;
    
    public static final int notification_tile_bg = 2131230869;
    
    public static final int notify_panel_notification_icon_bg = 2131230870;
    
    public static final int tooltip_frame_dark = 2131230877;
    
    public static final int tooltip_frame_light = 2131230878;
  }
  
  public static final class id {
    public static final int accessibility_action_clickable_span = 2131296281;
    
    public static final int accessibility_custom_action_0 = 2131296282;
    
    public static final int accessibility_custom_action_1 = 2131296283;
    
    public static final int accessibility_custom_action_10 = 2131296284;
    
    public static final int accessibility_custom_action_11 = 2131296285;
    
    public static final int accessibility_custom_action_12 = 2131296286;
    
    public static final int accessibility_custom_action_13 = 2131296287;
    
    public static final int accessibility_custom_action_14 = 2131296288;
    
    public static final int accessibility_custom_action_15 = 2131296289;
    
    public static final int accessibility_custom_action_16 = 2131296290;
    
    public static final int accessibility_custom_action_17 = 2131296291;
    
    public static final int accessibility_custom_action_18 = 2131296292;
    
    public static final int accessibility_custom_action_19 = 2131296293;
    
    public static final int accessibility_custom_action_2 = 2131296294;
    
    public static final int accessibility_custom_action_20 = 2131296295;
    
    public static final int accessibility_custom_action_21 = 2131296296;
    
    public static final int accessibility_custom_action_22 = 2131296297;
    
    public static final int accessibility_custom_action_23 = 2131296298;
    
    public static final int accessibility_custom_action_24 = 2131296299;
    
    public static final int accessibility_custom_action_25 = 2131296300;
    
    public static final int accessibility_custom_action_26 = 2131296301;
    
    public static final int accessibility_custom_action_27 = 2131296302;
    
    public static final int accessibility_custom_action_28 = 2131296303;
    
    public static final int accessibility_custom_action_29 = 2131296304;
    
    public static final int accessibility_custom_action_3 = 2131296305;
    
    public static final int accessibility_custom_action_30 = 2131296306;
    
    public static final int accessibility_custom_action_31 = 2131296307;
    
    public static final int accessibility_custom_action_4 = 2131296308;
    
    public static final int accessibility_custom_action_5 = 2131296309;
    
    public static final int accessibility_custom_action_6 = 2131296310;
    
    public static final int accessibility_custom_action_7 = 2131296311;
    
    public static final int accessibility_custom_action_8 = 2131296312;
    
    public static final int accessibility_custom_action_9 = 2131296313;
    
    public static final int action_bar = 2131296314;
    
    public static final int action_bar_activity_content = 2131296315;
    
    public static final int action_bar_container = 2131296316;
    
    public static final int action_bar_root = 2131296317;
    
    public static final int action_bar_spinner = 2131296318;
    
    public static final int action_bar_subtitle = 2131296319;
    
    public static final int action_bar_title = 2131296320;
    
    public static final int action_container = 2131296321;
    
    public static final int action_context_bar = 2131296322;
    
    public static final int action_divider = 2131296326;
    
    public static final int action_image = 2131296327;
    
    public static final int action_menu_divider = 2131296328;
    
    public static final int action_menu_presenter = 2131296329;
    
    public static final int action_mode_bar = 2131296330;
    
    public static final int action_mode_bar_stub = 2131296331;
    
    public static final int action_mode_close_button = 2131296332;
    
    public static final int action_text = 2131296338;
    
    public static final int actions = 2131296339;
    
    public static final int activity_chooser_view_content = 2131296340;
    
    public static final int add = 2131296341;
    
    public static final int alertTitle = 2131296342;
    
    public static final int async = 2131296345;
    
    public static final int blocking = 2131296350;
    
    public static final int buttonPanel = 2131296403;
    
    public static final int checkbox = 2131296411;
    
    public static final int checked = 2131296412;
    
    public static final int chronometer = 2131296415;
    
    public static final int content = 2131296430;
    
    public static final int contentPanel = 2131296431;
    
    public static final int custom = 2131296433;
    
    public static final int customPanel = 2131296434;
    
    public static final int decor_content_parent = 2131296437;
    
    public static final int default_activity_button = 2131296438;
    
    public static final int dialog_button = 2131296445;
    
    public static final int edit_query = 2131296456;
    
    public static final int expand_activities_button = 2131296491;
    
    public static final int expanded_menu = 2131296492;
    
    public static final int forever = 2131296502;
    
    public static final int group_divider = 2131296505;
    
    public static final int home = 2131296508;
    
    public static final int icon = 2131296510;
    
    public static final int icon_group = 2131296511;
    
    public static final int image = 2131296513;
    
    public static final int info = 2131296518;
    
    public static final int italic = 2131296520;
    
    public static final int line1 = 2131296526;
    
    public static final int line3 = 2131296527;
    
    public static final int listMode = 2131296530;
    
    public static final int list_item = 2131296531;
    
    public static final int message = 2131296533;
    
    public static final int multiply = 2131296561;
    
    public static final int none = 2131296565;
    
    public static final int normal = 2131296566;
    
    public static final int notification_background = 2131296567;
    
    public static final int notification_main_column = 2131296568;
    
    public static final int notification_main_column_container = 2131296569;
    
    public static final int off = 2131296570;
    
    public static final int on = 2131296571;
    
    public static final int parentPanel = 2131296576;
    
    public static final int progress_circular = 2131296582;
    
    public static final int progress_horizontal = 2131296583;
    
    public static final int radio = 2131296584;
    
    public static final int right_icon = 2131296598;
    
    public static final int right_side = 2131296599;
    
    public static final int screen = 2131296607;
    
    public static final int scrollIndicatorDown = 2131296609;
    
    public static final int scrollIndicatorUp = 2131296610;
    
    public static final int scrollView = 2131296611;
    
    public static final int search_badge = 2131296614;
    
    public static final int search_bar = 2131296615;
    
    public static final int search_button = 2131296616;
    
    public static final int search_close_btn = 2131296617;
    
    public static final int search_edit_frame = 2131296618;
    
    public static final int search_go_btn = 2131296619;
    
    public static final int search_mag_icon = 2131296620;
    
    public static final int search_plate = 2131296621;
    
    public static final int search_src_text = 2131296622;
    
    public static final int search_voice_btn = 2131296623;
    
    public static final int select_dialog_listview = 2131296624;
    
    public static final int shortcut = 2131296626;
    
    public static final int spacer = 2131296643;
    
    public static final int split_action_bar = 2131296644;
    
    public static final int src_atop = 2131296647;
    
    public static final int src_in = 2131296648;
    
    public static final int src_over = 2131296649;
    
    public static final int submenuarrow = 2131296653;
    
    public static final int submit_area = 2131296654;
    
    public static final int tabMode = 2131296655;
    
    public static final int tag_accessibility_actions = 2131296656;
    
    public static final int tag_accessibility_clickable_spans = 2131296657;
    
    public static final int tag_accessibility_heading = 2131296658;
    
    public static final int tag_accessibility_pane_title = 2131296659;
    
    public static final int tag_screen_reader_focusable = 2131296660;
    
    public static final int tag_transition_group = 2131296661;
    
    public static final int tag_unhandled_key_event_manager = 2131296662;
    
    public static final int tag_unhandled_key_listeners = 2131296663;
    
    public static final int text = 2131296665;
    
    public static final int text2 = 2131296666;
    
    public static final int textSpacerNoButtons = 2131296668;
    
    public static final int textSpacerNoTitle = 2131296669;
    
    public static final int time = 2131296685;
    
    public static final int title = 2131296686;
    
    public static final int titleDividerNoCustom = 2131296687;
    
    public static final int title_template = 2131296688;
    
    public static final int topPanel = 2131296691;
    
    public static final int unchecked = 2131296808;
    
    public static final int uniform = 2131296809;
    
    public static final int up = 2131296811;
    
    public static final int wrap_content = 2131296817;
  }
  
  public static final class integer {
    public static final int abc_config_activityDefaultDur = 2131361792;
    
    public static final int abc_config_activityShortDur = 2131361793;
    
    public static final int cancel_button_image_alpha = 2131361796;
    
    public static final int config_tooltipAnimTime = 2131361797;
    
    public static final int status_bar_notification_info_maxnum = 2131361812;
  }
  
  public static final class interpolator {
    public static final int btn_checkbox_checked_mtrl_animation_interpolator_0 = 2131427328;
    
    public static final int btn_checkbox_checked_mtrl_animation_interpolator_1 = 2131427329;
    
    public static final int btn_checkbox_unchecked_mtrl_animation_interpolator_0 = 2131427330;
    
    public static final int btn_checkbox_unchecked_mtrl_animation_interpolator_1 = 2131427331;
    
    public static final int btn_radio_to_off_mtrl_animation_interpolator_0 = 2131427332;
    
    public static final int btn_radio_to_on_mtrl_animation_interpolator_0 = 2131427333;
    
    public static final int fast_out_slow_in = 2131427334;
  }
  
  public static final class layout {
    public static final int abc_action_bar_title_item = 2131492864;
    
    public static final int abc_action_bar_up_container = 2131492865;
    
    public static final int abc_action_menu_item_layout = 2131492866;
    
    public static final int abc_action_menu_layout = 2131492867;
    
    public static final int abc_action_mode_bar = 2131492868;
    
    public static final int abc_action_mode_close_item_material = 2131492869;
    
    public static final int abc_activity_chooser_view = 2131492870;
    
    public static final int abc_activity_chooser_view_list_item = 2131492871;
    
    public static final int abc_alert_dialog_button_bar_material = 2131492872;
    
    public static final int abc_alert_dialog_material = 2131492873;
    
    public static final int abc_alert_dialog_title_material = 2131492874;
    
    public static final int abc_cascading_menu_item_layout = 2131492875;
    
    public static final int abc_dialog_title_material = 2131492876;
    
    public static final int abc_expanded_menu_layout = 2131492877;
    
    public static final int abc_list_menu_item_checkbox = 2131492878;
    
    public static final int abc_list_menu_item_icon = 2131492879;
    
    public static final int abc_list_menu_item_layout = 2131492880;
    
    public static final int abc_list_menu_item_radio = 2131492881;
    
    public static final int abc_popup_menu_header_item_layout = 2131492882;
    
    public static final int abc_popup_menu_item_layout = 2131492883;
    
    public static final int abc_screen_content_include = 2131492884;
    
    public static final int abc_screen_simple = 2131492885;
    
    public static final int abc_screen_simple_overlay_action_mode = 2131492886;
    
    public static final int abc_screen_toolbar = 2131492887;
    
    public static final int abc_search_dropdown_item_icons_2line = 2131492888;
    
    public static final int abc_search_view = 2131492889;
    
    public static final int abc_select_dialog_material = 2131492890;
    
    public static final int abc_tooltip = 2131492891;
    
    public static final int custom_dialog = 2131492926;
    
    public static final int notification_action = 2131492972;
    
    public static final int notification_action_tombstone = 2131492973;
    
    public static final int notification_template_custom_big = 2131492974;
    
    public static final int notification_template_icon_group = 2131492975;
    
    public static final int notification_template_part_chronometer = 2131492976;
    
    public static final int notification_template_part_time = 2131492977;
    
    public static final int select_dialog_item_material = 2131492978;
    
    public static final int select_dialog_multichoice_material = 2131492979;
    
    public static final int select_dialog_singlechoice_material = 2131492980;
    
    public static final int support_simple_spinner_dropdown_item = 2131492981;
  }
  
  public static final class string {
    public static final int abc_action_bar_home_description = 2131755008;
    
    public static final int abc_action_bar_up_description = 2131755009;
    
    public static final int abc_action_menu_overflow_description = 2131755010;
    
    public static final int abc_action_mode_done = 2131755011;
    
    public static final int abc_activity_chooser_view_see_all = 2131755012;
    
    public static final int abc_activitychooserview_choose_application = 2131755013;
    
    public static final int abc_capital_off = 2131755014;
    
    public static final int abc_capital_on = 2131755015;
    
    public static final int abc_menu_alt_shortcut_label = 2131755016;
    
    public static final int abc_menu_ctrl_shortcut_label = 2131755017;
    
    public static final int abc_menu_delete_shortcut_label = 2131755018;
    
    public static final int abc_menu_enter_shortcut_label = 2131755019;
    
    public static final int abc_menu_function_shortcut_label = 2131755020;
    
    public static final int abc_menu_meta_shortcut_label = 2131755021;
    
    public static final int abc_menu_shift_shortcut_label = 2131755022;
    
    public static final int abc_menu_space_shortcut_label = 2131755023;
    
    public static final int abc_menu_sym_shortcut_label = 2131755024;
    
    public static final int abc_prepend_shortcut_label = 2131755025;
    
    public static final int abc_search_hint = 2131755026;
    
    public static final int abc_searchview_description_clear = 2131755027;
    
    public static final int abc_searchview_description_query = 2131755028;
    
    public static final int abc_searchview_description_search = 2131755029;
    
    public static final int abc_searchview_description_submit = 2131755030;
    
    public static final int abc_searchview_description_voice = 2131755031;
    
    public static final int abc_shareactionprovider_share_with = 2131755032;
    
    public static final int abc_shareactionprovider_share_with_application = 2131755033;
    
    public static final int abc_toolbar_collapse_description = 2131755034;
    
    public static final int search_menu_title = 2131755175;
    
    public static final int status_bar_notification_info_overflow = 2131755189;
  }
  
  public static final class style {
    public static final int AlertDialog_AppCompat = 2131820545;
    
    public static final int AlertDialog_AppCompat_Light = 2131820546;
    
    public static final int Animation_AppCompat_Dialog = 2131820547;
    
    public static final int Animation_AppCompat_DropDownUp = 2131820548;
    
    public static final int Animation_AppCompat_Tooltip = 2131820549;
    
    public static final int Base_AlertDialog_AppCompat = 2131820557;
    
    public static final int Base_AlertDialog_AppCompat_Light = 2131820558;
    
    public static final int Base_Animation_AppCompat_Dialog = 2131820559;
    
    public static final int Base_Animation_AppCompat_DropDownUp = 2131820560;
    
    public static final int Base_Animation_AppCompat_Tooltip = 2131820561;
    
    public static final int Base_DialogWindowTitleBackground_AppCompat = 2131820564;
    
    public static final int Base_DialogWindowTitle_AppCompat = 2131820563;
    
    public static final int Base_TextAppearance_AppCompat = 2131820568;
    
    public static final int Base_TextAppearance_AppCompat_Body1 = 2131820569;
    
    public static final int Base_TextAppearance_AppCompat_Body2 = 2131820570;
    
    public static final int Base_TextAppearance_AppCompat_Button = 2131820571;
    
    public static final int Base_TextAppearance_AppCompat_Caption = 2131820572;
    
    public static final int Base_TextAppearance_AppCompat_Display1 = 2131820573;
    
    public static final int Base_TextAppearance_AppCompat_Display2 = 2131820574;
    
    public static final int Base_TextAppearance_AppCompat_Display3 = 2131820575;
    
    public static final int Base_TextAppearance_AppCompat_Display4 = 2131820576;
    
    public static final int Base_TextAppearance_AppCompat_Headline = 2131820577;
    
    public static final int Base_TextAppearance_AppCompat_Inverse = 2131820578;
    
    public static final int Base_TextAppearance_AppCompat_Large = 2131820579;
    
    public static final int Base_TextAppearance_AppCompat_Large_Inverse = 2131820580;
    
    public static final int Base_TextAppearance_AppCompat_Light_Widget_PopupMenu_Large = 2131820581;
    
    public static final int Base_TextAppearance_AppCompat_Light_Widget_PopupMenu_Small = 2131820582;
    
    public static final int Base_TextAppearance_AppCompat_Medium = 2131820583;
    
    public static final int Base_TextAppearance_AppCompat_Medium_Inverse = 2131820584;
    
    public static final int Base_TextAppearance_AppCompat_Menu = 2131820585;
    
    public static final int Base_TextAppearance_AppCompat_SearchResult = 2131820586;
    
    public static final int Base_TextAppearance_AppCompat_SearchResult_Subtitle = 2131820587;
    
    public static final int Base_TextAppearance_AppCompat_SearchResult_Title = 2131820588;
    
    public static final int Base_TextAppearance_AppCompat_Small = 2131820589;
    
    public static final int Base_TextAppearance_AppCompat_Small_Inverse = 2131820590;
    
    public static final int Base_TextAppearance_AppCompat_Subhead = 2131820591;
    
    public static final int Base_TextAppearance_AppCompat_Subhead_Inverse = 2131820592;
    
    public static final int Base_TextAppearance_AppCompat_Title = 2131820593;
    
    public static final int Base_TextAppearance_AppCompat_Title_Inverse = 2131820594;
    
    public static final int Base_TextAppearance_AppCompat_Tooltip = 2131820595;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Menu = 2131820596;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Subtitle = 2131820597;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Subtitle_Inverse = 2131820598;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Title = 2131820599;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Title_Inverse = 2131820600;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionMode_Subtitle = 2131820601;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionMode_Title = 2131820602;
    
    public static final int Base_TextAppearance_AppCompat_Widget_Button = 2131820603;
    
    public static final int Base_TextAppearance_AppCompat_Widget_Button_Borderless_Colored = 2131820604;
    
    public static final int Base_TextAppearance_AppCompat_Widget_Button_Colored = 2131820605;
    
    public static final int Base_TextAppearance_AppCompat_Widget_Button_Inverse = 2131820606;
    
    public static final int Base_TextAppearance_AppCompat_Widget_DropDownItem = 2131820607;
    
    public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Header = 2131820608;
    
    public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Large = 2131820609;
    
    public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Small = 2131820610;
    
    public static final int Base_TextAppearance_AppCompat_Widget_Switch = 2131820611;
    
    public static final int Base_TextAppearance_AppCompat_Widget_TextView_SpinnerItem = 2131820612;
    
    public static final int Base_TextAppearance_Widget_AppCompat_ExpandedMenu_Item = 2131820617;
    
    public static final int Base_TextAppearance_Widget_AppCompat_Toolbar_Subtitle = 2131820618;
    
    public static final int Base_TextAppearance_Widget_AppCompat_Toolbar_Title = 2131820619;
    
    public static final int Base_ThemeOverlay_AppCompat = 2131820653;
    
    public static final int Base_ThemeOverlay_AppCompat_ActionBar = 2131820654;
    
    public static final int Base_ThemeOverlay_AppCompat_Dark = 2131820655;
    
    public static final int Base_ThemeOverlay_AppCompat_Dark_ActionBar = 2131820656;
    
    public static final int Base_ThemeOverlay_AppCompat_Dialog = 2131820657;
    
    public static final int Base_ThemeOverlay_AppCompat_Dialog_Alert = 2131820658;
    
    public static final int Base_ThemeOverlay_AppCompat_Light = 2131820659;
    
    public static final int Base_Theme_AppCompat = 2131820620;
    
    public static final int Base_Theme_AppCompat_CompactMenu = 2131820621;
    
    public static final int Base_Theme_AppCompat_Dialog = 2131820622;
    
    public static final int Base_Theme_AppCompat_DialogWhenLarge = 2131820626;
    
    public static final int Base_Theme_AppCompat_Dialog_Alert = 2131820623;
    
    public static final int Base_Theme_AppCompat_Dialog_FixedSize = 2131820624;
    
    public static final int Base_Theme_AppCompat_Dialog_MinWidth = 2131820625;
    
    public static final int Base_Theme_AppCompat_Light = 2131820627;
    
    public static final int Base_Theme_AppCompat_Light_DarkActionBar = 2131820628;
    
    public static final int Base_Theme_AppCompat_Light_Dialog = 2131820629;
    
    public static final int Base_Theme_AppCompat_Light_DialogWhenLarge = 2131820633;
    
    public static final int Base_Theme_AppCompat_Light_Dialog_Alert = 2131820630;
    
    public static final int Base_Theme_AppCompat_Light_Dialog_FixedSize = 2131820631;
    
    public static final int Base_Theme_AppCompat_Light_Dialog_MinWidth = 2131820632;
    
    public static final int Base_V21_ThemeOverlay_AppCompat_Dialog = 2131820679;
    
    public static final int Base_V21_Theme_AppCompat = 2131820675;
    
    public static final int Base_V21_Theme_AppCompat_Dialog = 2131820676;
    
    public static final int Base_V21_Theme_AppCompat_Light = 2131820677;
    
    public static final int Base_V21_Theme_AppCompat_Light_Dialog = 2131820678;
    
    public static final int Base_V22_Theme_AppCompat = 2131820680;
    
    public static final int Base_V22_Theme_AppCompat_Light = 2131820681;
    
    public static final int Base_V23_Theme_AppCompat = 2131820682;
    
    public static final int Base_V23_Theme_AppCompat_Light = 2131820683;
    
    public static final int Base_V26_Theme_AppCompat = 2131820684;
    
    public static final int Base_V26_Theme_AppCompat_Light = 2131820685;
    
    public static final int Base_V26_Widget_AppCompat_Toolbar = 2131820686;
    
    public static final int Base_V28_Theme_AppCompat = 2131820687;
    
    public static final int Base_V28_Theme_AppCompat_Light = 2131820688;
    
    public static final int Base_V7_ThemeOverlay_AppCompat_Dialog = 2131820693;
    
    public static final int Base_V7_Theme_AppCompat = 2131820689;
    
    public static final int Base_V7_Theme_AppCompat_Dialog = 2131820690;
    
    public static final int Base_V7_Theme_AppCompat_Light = 2131820691;
    
    public static final int Base_V7_Theme_AppCompat_Light_Dialog = 2131820692;
    
    public static final int Base_V7_Widget_AppCompat_AutoCompleteTextView = 2131820694;
    
    public static final int Base_V7_Widget_AppCompat_EditText = 2131820695;
    
    public static final int Base_V7_Widget_AppCompat_Toolbar = 2131820696;
    
    public static final int Base_Widget_AppCompat_ActionBar = 2131820697;
    
    public static final int Base_Widget_AppCompat_ActionBar_Solid = 2131820698;
    
    public static final int Base_Widget_AppCompat_ActionBar_TabBar = 2131820699;
    
    public static final int Base_Widget_AppCompat_ActionBar_TabText = 2131820700;
    
    public static final int Base_Widget_AppCompat_ActionBar_TabView = 2131820701;
    
    public static final int Base_Widget_AppCompat_ActionButton = 2131820702;
    
    public static final int Base_Widget_AppCompat_ActionButton_CloseMode = 2131820703;
    
    public static final int Base_Widget_AppCompat_ActionButton_Overflow = 2131820704;
    
    public static final int Base_Widget_AppCompat_ActionMode = 2131820705;
    
    public static final int Base_Widget_AppCompat_ActivityChooserView = 2131820706;
    
    public static final int Base_Widget_AppCompat_AutoCompleteTextView = 2131820707;
    
    public static final int Base_Widget_AppCompat_Button = 2131820708;
    
    public static final int Base_Widget_AppCompat_ButtonBar = 2131820714;
    
    public static final int Base_Widget_AppCompat_ButtonBar_AlertDialog = 2131820715;
    
    public static final int Base_Widget_AppCompat_Button_Borderless = 2131820709;
    
    public static final int Base_Widget_AppCompat_Button_Borderless_Colored = 2131820710;
    
    public static final int Base_Widget_AppCompat_Button_ButtonBar_AlertDialog = 2131820711;
    
    public static final int Base_Widget_AppCompat_Button_Colored = 2131820712;
    
    public static final int Base_Widget_AppCompat_Button_Small = 2131820713;
    
    public static final int Base_Widget_AppCompat_CompoundButton_CheckBox = 2131820716;
    
    public static final int Base_Widget_AppCompat_CompoundButton_RadioButton = 2131820717;
    
    public static final int Base_Widget_AppCompat_CompoundButton_Switch = 2131820718;
    
    public static final int Base_Widget_AppCompat_DrawerArrowToggle = 2131820719;
    
    public static final int Base_Widget_AppCompat_DrawerArrowToggle_Common = 2131820720;
    
    public static final int Base_Widget_AppCompat_DropDownItem_Spinner = 2131820721;
    
    public static final int Base_Widget_AppCompat_EditText = 2131820722;
    
    public static final int Base_Widget_AppCompat_ImageButton = 2131820723;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar = 2131820724;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar_Solid = 2131820725;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar_TabBar = 2131820726;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar_TabText = 2131820727;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar_TabText_Inverse = 2131820728;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar_TabView = 2131820729;
    
    public static final int Base_Widget_AppCompat_Light_PopupMenu = 2131820730;
    
    public static final int Base_Widget_AppCompat_Light_PopupMenu_Overflow = 2131820731;
    
    public static final int Base_Widget_AppCompat_ListMenuView = 2131820732;
    
    public static final int Base_Widget_AppCompat_ListPopupWindow = 2131820733;
    
    public static final int Base_Widget_AppCompat_ListView = 2131820734;
    
    public static final int Base_Widget_AppCompat_ListView_DropDown = 2131820735;
    
    public static final int Base_Widget_AppCompat_ListView_Menu = 2131820736;
    
    public static final int Base_Widget_AppCompat_PopupMenu = 2131820737;
    
    public static final int Base_Widget_AppCompat_PopupMenu_Overflow = 2131820738;
    
    public static final int Base_Widget_AppCompat_PopupWindow = 2131820739;
    
    public static final int Base_Widget_AppCompat_ProgressBar = 2131820740;
    
    public static final int Base_Widget_AppCompat_ProgressBar_Horizontal = 2131820741;
    
    public static final int Base_Widget_AppCompat_RatingBar = 2131820742;
    
    public static final int Base_Widget_AppCompat_RatingBar_Indicator = 2131820743;
    
    public static final int Base_Widget_AppCompat_RatingBar_Small = 2131820744;
    
    public static final int Base_Widget_AppCompat_SearchView = 2131820745;
    
    public static final int Base_Widget_AppCompat_SearchView_ActionBar = 2131820746;
    
    public static final int Base_Widget_AppCompat_SeekBar = 2131820747;
    
    public static final int Base_Widget_AppCompat_SeekBar_Discrete = 2131820748;
    
    public static final int Base_Widget_AppCompat_Spinner = 2131820749;
    
    public static final int Base_Widget_AppCompat_Spinner_Underlined = 2131820750;
    
    public static final int Base_Widget_AppCompat_TextView = 2131820751;
    
    public static final int Base_Widget_AppCompat_TextView_SpinnerItem = 2131820752;
    
    public static final int Base_Widget_AppCompat_Toolbar = 2131820753;
    
    public static final int Base_Widget_AppCompat_Toolbar_Button_Navigation = 2131820754;
    
    public static final int Platform_AppCompat = 2131820782;
    
    public static final int Platform_AppCompat_Light = 2131820783;
    
    public static final int Platform_ThemeOverlay_AppCompat = 2131820788;
    
    public static final int Platform_ThemeOverlay_AppCompat_Dark = 2131820789;
    
    public static final int Platform_ThemeOverlay_AppCompat_Light = 2131820790;
    
    public static final int Platform_V21_AppCompat = 2131820791;
    
    public static final int Platform_V21_AppCompat_Light = 2131820792;
    
    public static final int Platform_V25_AppCompat = 2131820793;
    
    public static final int Platform_V25_AppCompat_Light = 2131820794;
    
    public static final int Platform_Widget_AppCompat_Spinner = 2131820795;
    
    public static final int RtlOverlay_DialogWindowTitle_AppCompat = 2131820798;
    
    public static final int RtlOverlay_Widget_AppCompat_ActionBar_TitleItem = 2131820799;
    
    public static final int RtlOverlay_Widget_AppCompat_DialogTitle_Icon = 2131820800;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem = 2131820801;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_InternalGroup = 2131820802;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_Shortcut = 2131820803;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_SubmenuArrow = 2131820804;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_Text = 2131820805;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_Title = 2131820806;
    
    public static final int RtlOverlay_Widget_AppCompat_SearchView_MagIcon = 2131820812;
    
    public static final int RtlOverlay_Widget_AppCompat_Search_DropDown = 2131820807;
    
    public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Icon1 = 2131820808;
    
    public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Icon2 = 2131820809;
    
    public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Query = 2131820810;
    
    public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Text = 2131820811;
    
    public static final int RtlUnderlay_Widget_AppCompat_ActionButton = 2131820813;
    
    public static final int RtlUnderlay_Widget_AppCompat_ActionButton_Overflow = 2131820814;
    
    public static final int TextAppearance_AppCompat = 2131820895;
    
    public static final int TextAppearance_AppCompat_Body1 = 2131820896;
    
    public static final int TextAppearance_AppCompat_Body2 = 2131820897;
    
    public static final int TextAppearance_AppCompat_Button = 2131820898;
    
    public static final int TextAppearance_AppCompat_Caption = 2131820899;
    
    public static final int TextAppearance_AppCompat_Display1 = 2131820900;
    
    public static final int TextAppearance_AppCompat_Display2 = 2131820901;
    
    public static final int TextAppearance_AppCompat_Display3 = 2131820902;
    
    public static final int TextAppearance_AppCompat_Display4 = 2131820903;
    
    public static final int TextAppearance_AppCompat_Headline = 2131820904;
    
    public static final int TextAppearance_AppCompat_Inverse = 2131820905;
    
    public static final int TextAppearance_AppCompat_Large = 2131820906;
    
    public static final int TextAppearance_AppCompat_Large_Inverse = 2131820907;
    
    public static final int TextAppearance_AppCompat_Light_SearchResult_Subtitle = 2131820908;
    
    public static final int TextAppearance_AppCompat_Light_SearchResult_Title = 2131820909;
    
    public static final int TextAppearance_AppCompat_Light_Widget_PopupMenu_Large = 2131820910;
    
    public static final int TextAppearance_AppCompat_Light_Widget_PopupMenu_Small = 2131820911;
    
    public static final int TextAppearance_AppCompat_Medium = 2131820912;
    
    public static final int TextAppearance_AppCompat_Medium_Inverse = 2131820913;
    
    public static final int TextAppearance_AppCompat_Menu = 2131820914;
    
    public static final int TextAppearance_AppCompat_SearchResult_Subtitle = 2131820915;
    
    public static final int TextAppearance_AppCompat_SearchResult_Title = 2131820916;
    
    public static final int TextAppearance_AppCompat_Small = 2131820917;
    
    public static final int TextAppearance_AppCompat_Small_Inverse = 2131820918;
    
    public static final int TextAppearance_AppCompat_Subhead = 2131820919;
    
    public static final int TextAppearance_AppCompat_Subhead_Inverse = 2131820920;
    
    public static final int TextAppearance_AppCompat_Title = 2131820921;
    
    public static final int TextAppearance_AppCompat_Title_Inverse = 2131820922;
    
    public static final int TextAppearance_AppCompat_Tooltip = 2131820923;
    
    public static final int TextAppearance_AppCompat_Widget_ActionBar_Menu = 2131820924;
    
    public static final int TextAppearance_AppCompat_Widget_ActionBar_Subtitle = 2131820925;
    
    public static final int TextAppearance_AppCompat_Widget_ActionBar_Subtitle_Inverse = 2131820926;
    
    public static final int TextAppearance_AppCompat_Widget_ActionBar_Title = 2131820927;
    
    public static final int TextAppearance_AppCompat_Widget_ActionBar_Title_Inverse = 2131820928;
    
    public static final int TextAppearance_AppCompat_Widget_ActionMode_Subtitle = 2131820929;
    
    public static final int TextAppearance_AppCompat_Widget_ActionMode_Subtitle_Inverse = 2131820930;
    
    public static final int TextAppearance_AppCompat_Widget_ActionMode_Title = 2131820931;
    
    public static final int TextAppearance_AppCompat_Widget_ActionMode_Title_Inverse = 2131820932;
    
    public static final int TextAppearance_AppCompat_Widget_Button = 2131820933;
    
    public static final int TextAppearance_AppCompat_Widget_Button_Borderless_Colored = 2131820934;
    
    public static final int TextAppearance_AppCompat_Widget_Button_Colored = 2131820935;
    
    public static final int TextAppearance_AppCompat_Widget_Button_Inverse = 2131820936;
    
    public static final int TextAppearance_AppCompat_Widget_DropDownItem = 2131820937;
    
    public static final int TextAppearance_AppCompat_Widget_PopupMenu_Header = 2131820938;
    
    public static final int TextAppearance_AppCompat_Widget_PopupMenu_Large = 2131820939;
    
    public static final int TextAppearance_AppCompat_Widget_PopupMenu_Small = 2131820940;
    
    public static final int TextAppearance_AppCompat_Widget_Switch = 2131820941;
    
    public static final int TextAppearance_AppCompat_Widget_TextView_SpinnerItem = 2131820942;
    
    public static final int TextAppearance_Compat_Notification = 2131820943;
    
    public static final int TextAppearance_Compat_Notification_Info = 2131820944;
    
    public static final int TextAppearance_Compat_Notification_Line2 = 2131820945;
    
    public static final int TextAppearance_Compat_Notification_Time = 2131820946;
    
    public static final int TextAppearance_Compat_Notification_Title = 2131820947;
    
    public static final int TextAppearance_Widget_AppCompat_ExpandedMenu_Item = 2131820971;
    
    public static final int TextAppearance_Widget_AppCompat_Toolbar_Subtitle = 2131820972;
    
    public static final int TextAppearance_Widget_AppCompat_Toolbar_Title = 2131820973;
    
    public static final int ThemeOverlay_AppCompat = 2131821050;
    
    public static final int ThemeOverlay_AppCompat_ActionBar = 2131821051;
    
    public static final int ThemeOverlay_AppCompat_Dark = 2131821052;
    
    public static final int ThemeOverlay_AppCompat_Dark_ActionBar = 2131821053;
    
    public static final int ThemeOverlay_AppCompat_DayNight = 2131821054;
    
    public static final int ThemeOverlay_AppCompat_DayNight_ActionBar = 2131821055;
    
    public static final int ThemeOverlay_AppCompat_Dialog = 2131821056;
    
    public static final int ThemeOverlay_AppCompat_Dialog_Alert = 2131821057;
    
    public static final int ThemeOverlay_AppCompat_Light = 2131821058;
    
    public static final int Theme_AppCompat = 2131820974;
    
    public static final int Theme_AppCompat_CompactMenu = 2131820975;
    
    public static final int Theme_AppCompat_DayNight = 2131820976;
    
    public static final int Theme_AppCompat_DayNight_DarkActionBar = 2131820977;
    
    public static final int Theme_AppCompat_DayNight_Dialog = 2131820978;
    
    public static final int Theme_AppCompat_DayNight_DialogWhenLarge = 2131820981;
    
    public static final int Theme_AppCompat_DayNight_Dialog_Alert = 2131820979;
    
    public static final int Theme_AppCompat_DayNight_Dialog_MinWidth = 2131820980;
    
    public static final int Theme_AppCompat_DayNight_NoActionBar = 2131820982;
    
    public static final int Theme_AppCompat_Dialog = 2131820983;
    
    public static final int Theme_AppCompat_DialogWhenLarge = 2131820986;
    
    public static final int Theme_AppCompat_Dialog_Alert = 2131820984;
    
    public static final int Theme_AppCompat_Dialog_MinWidth = 2131820985;
    
    public static final int Theme_AppCompat_Light = 2131820987;
    
    public static final int Theme_AppCompat_Light_DarkActionBar = 2131820988;
    
    public static final int Theme_AppCompat_Light_Dialog = 2131820989;
    
    public static final int Theme_AppCompat_Light_DialogWhenLarge = 2131820992;
    
    public static final int Theme_AppCompat_Light_Dialog_Alert = 2131820990;
    
    public static final int Theme_AppCompat_Light_Dialog_MinWidth = 2131820991;
    
    public static final int Theme_AppCompat_Light_NoActionBar = 2131820993;
    
    public static final int Theme_AppCompat_NoActionBar = 2131820994;
    
    public static final int Widget_AppCompat_ActionBar = 2131821095;
    
    public static final int Widget_AppCompat_ActionBar_Solid = 2131821096;
    
    public static final int Widget_AppCompat_ActionBar_TabBar = 2131821097;
    
    public static final int Widget_AppCompat_ActionBar_TabText = 2131821098;
    
    public static final int Widget_AppCompat_ActionBar_TabView = 2131821099;
    
    public static final int Widget_AppCompat_ActionButton = 2131821100;
    
    public static final int Widget_AppCompat_ActionButton_CloseMode = 2131821101;
    
    public static final int Widget_AppCompat_ActionButton_Overflow = 2131821102;
    
    public static final int Widget_AppCompat_ActionMode = 2131821103;
    
    public static final int Widget_AppCompat_ActivityChooserView = 2131821104;
    
    public static final int Widget_AppCompat_AutoCompleteTextView = 2131821105;
    
    public static final int Widget_AppCompat_Button = 2131821106;
    
    public static final int Widget_AppCompat_ButtonBar = 2131821112;
    
    public static final int Widget_AppCompat_ButtonBar_AlertDialog = 2131821113;
    
    public static final int Widget_AppCompat_Button_Borderless = 2131821107;
    
    public static final int Widget_AppCompat_Button_Borderless_Colored = 2131821108;
    
    public static final int Widget_AppCompat_Button_ButtonBar_AlertDialog = 2131821109;
    
    public static final int Widget_AppCompat_Button_Colored = 2131821110;
    
    public static final int Widget_AppCompat_Button_Small = 2131821111;
    
    public static final int Widget_AppCompat_CompoundButton_CheckBox = 2131821114;
    
    public static final int Widget_AppCompat_CompoundButton_RadioButton = 2131821115;
    
    public static final int Widget_AppCompat_CompoundButton_Switch = 2131821116;
    
    public static final int Widget_AppCompat_DrawerArrowToggle = 2131821117;
    
    public static final int Widget_AppCompat_DropDownItem_Spinner = 2131821118;
    
    public static final int Widget_AppCompat_EditText = 2131821119;
    
    public static final int Widget_AppCompat_ImageButton = 2131821120;
    
    public static final int Widget_AppCompat_Light_ActionBar = 2131821121;
    
    public static final int Widget_AppCompat_Light_ActionBar_Solid = 2131821122;
    
    public static final int Widget_AppCompat_Light_ActionBar_Solid_Inverse = 2131821123;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabBar = 2131821124;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabBar_Inverse = 2131821125;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabText = 2131821126;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabText_Inverse = 2131821127;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabView = 2131821128;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabView_Inverse = 2131821129;
    
    public static final int Widget_AppCompat_Light_ActionButton = 2131821130;
    
    public static final int Widget_AppCompat_Light_ActionButton_CloseMode = 2131821131;
    
    public static final int Widget_AppCompat_Light_ActionButton_Overflow = 2131821132;
    
    public static final int Widget_AppCompat_Light_ActionMode_Inverse = 2131821133;
    
    public static final int Widget_AppCompat_Light_ActivityChooserView = 2131821134;
    
    public static final int Widget_AppCompat_Light_AutoCompleteTextView = 2131821135;
    
    public static final int Widget_AppCompat_Light_DropDownItem_Spinner = 2131821136;
    
    public static final int Widget_AppCompat_Light_ListPopupWindow = 2131821137;
    
    public static final int Widget_AppCompat_Light_ListView_DropDown = 2131821138;
    
    public static final int Widget_AppCompat_Light_PopupMenu = 2131821139;
    
    public static final int Widget_AppCompat_Light_PopupMenu_Overflow = 2131821140;
    
    public static final int Widget_AppCompat_Light_SearchView = 2131821141;
    
    public static final int Widget_AppCompat_Light_Spinner_DropDown_ActionBar = 2131821142;
    
    public static final int Widget_AppCompat_ListMenuView = 2131821143;
    
    public static final int Widget_AppCompat_ListPopupWindow = 2131821144;
    
    public static final int Widget_AppCompat_ListView = 2131821145;
    
    public static final int Widget_AppCompat_ListView_DropDown = 2131821146;
    
    public static final int Widget_AppCompat_ListView_Menu = 2131821147;
    
    public static final int Widget_AppCompat_PopupMenu = 2131821148;
    
    public static final int Widget_AppCompat_PopupMenu_Overflow = 2131821149;
    
    public static final int Widget_AppCompat_PopupWindow = 2131821150;
    
    public static final int Widget_AppCompat_ProgressBar = 2131821151;
    
    public static final int Widget_AppCompat_ProgressBar_Horizontal = 2131821152;
    
    public static final int Widget_AppCompat_RatingBar = 2131821153;
    
    public static final int Widget_AppCompat_RatingBar_Indicator = 2131821154;
    
    public static final int Widget_AppCompat_RatingBar_Small = 2131821155;
    
    public static final int Widget_AppCompat_SearchView = 2131821156;
    
    public static final int Widget_AppCompat_SearchView_ActionBar = 2131821157;
    
    public static final int Widget_AppCompat_SeekBar = 2131821158;
    
    public static final int Widget_AppCompat_SeekBar_Discrete = 2131821159;
    
    public static final int Widget_AppCompat_Spinner = 2131821160;
    
    public static final int Widget_AppCompat_Spinner_DropDown = 2131821161;
    
    public static final int Widget_AppCompat_Spinner_DropDown_ActionBar = 2131821162;
    
    public static final int Widget_AppCompat_Spinner_Underlined = 2131821163;
    
    public static final int Widget_AppCompat_TextView = 2131821164;
    
    public static final int Widget_AppCompat_TextView_SpinnerItem = 2131821165;
    
    public static final int Widget_AppCompat_Toolbar = 2131821166;
    
    public static final int Widget_AppCompat_Toolbar_Button_Navigation = 2131821167;
    
    public static final int Widget_Compat_NotificationActionContainer = 2131821168;
    
    public static final int Widget_Compat_NotificationActionText = 2131821169;
  }
  
  public static final class styleable {
    public static final int[] ActionBar = new int[] { 
        2130968631, 2130968638, 2130968639, 2130968762, 2130968763, 2130968764, 2130968765, 2130968766, 2130968767, 2130968793, 
        2130968802, 2130968803, 2130968822, 2130968881, 2130968887, 2130968893, 2130968894, 2130968896, 2130968906, 2130968919, 
        2130969029, 2130969059, 2130969077, 2130969081, 2130969082, 2130969142, 2130969145, 2130969217, 2130969227 };
    
    public static final int[] ActionBarLayout = new int[] { 16842931 };
    
    public static final int ActionBarLayout_android_layout_gravity = 0;
    
    public static final int ActionBar_background = 0;
    
    public static final int ActionBar_backgroundSplit = 1;
    
    public static final int ActionBar_backgroundStacked = 2;
    
    public static final int ActionBar_contentInsetEnd = 3;
    
    public static final int ActionBar_contentInsetEndWithActions = 4;
    
    public static final int ActionBar_contentInsetLeft = 5;
    
    public static final int ActionBar_contentInsetRight = 6;
    
    public static final int ActionBar_contentInsetStart = 7;
    
    public static final int ActionBar_contentInsetStartWithNavigation = 8;
    
    public static final int ActionBar_customNavigationLayout = 9;
    
    public static final int ActionBar_displayOptions = 10;
    
    public static final int ActionBar_divider = 11;
    
    public static final int ActionBar_elevation = 12;
    
    public static final int ActionBar_height = 13;
    
    public static final int ActionBar_hideOnContentScroll = 14;
    
    public static final int ActionBar_homeAsUpIndicator = 15;
    
    public static final int ActionBar_homeLayout = 16;
    
    public static final int ActionBar_icon = 17;
    
    public static final int ActionBar_indeterminateProgressStyle = 18;
    
    public static final int ActionBar_itemPadding = 19;
    
    public static final int ActionBar_logo = 20;
    
    public static final int ActionBar_navigationMode = 21;
    
    public static final int ActionBar_popupTheme = 22;
    
    public static final int ActionBar_progressBarPadding = 23;
    
    public static final int ActionBar_progressBarStyle = 24;
    
    public static final int ActionBar_subtitle = 25;
    
    public static final int ActionBar_subtitleTextStyle = 26;
    
    public static final int ActionBar_title = 27;
    
    public static final int ActionBar_titleTextStyle = 28;
    
    public static final int[] ActionMenuItemView = new int[] { 16843071 };
    
    public static final int ActionMenuItemView_android_minWidth = 0;
    
    public static final int[] ActionMenuView = new int[0];
    
    public static final int[] ActionMode = new int[] { 2130968631, 2130968638, 2130968730, 2130968881, 2130969145, 2130969227 };
    
    public static final int ActionMode_background = 0;
    
    public static final int ActionMode_backgroundSplit = 1;
    
    public static final int ActionMode_closeItemLayout = 2;
    
    public static final int ActionMode_height = 3;
    
    public static final int ActionMode_subtitleTextStyle = 4;
    
    public static final int ActionMode_titleTextStyle = 5;
    
    public static final int[] ActivityChooserView = new int[] { 2130968841, 2130968907 };
    
    public static final int ActivityChooserView_expandActivityOverflowButtonDrawable = 0;
    
    public static final int ActivityChooserView_initialActivityCount = 1;
    
    public static final int[] AlertDialog = new int[] { 16842994, 2130968680, 2130968681, 2130969018, 2130969019, 2130969056, 2130969110, 2130969112 };
    
    public static final int AlertDialog_android_layout = 0;
    
    public static final int AlertDialog_buttonIconDimen = 1;
    
    public static final int AlertDialog_buttonPanelSideLayout = 2;
    
    public static final int AlertDialog_listItemLayout = 3;
    
    public static final int AlertDialog_listLayout = 4;
    
    public static final int AlertDialog_multiChoiceItemLayout = 5;
    
    public static final int AlertDialog_showTitle = 6;
    
    public static final int AlertDialog_singleChoiceItemLayout = 7;
    
    public static final int[] AnimatedStateListDrawableCompat = new int[] { 16843036, 16843156, 16843157, 16843158, 16843532, 16843533 };
    
    public static final int AnimatedStateListDrawableCompat_android_constantSize = 3;
    
    public static final int AnimatedStateListDrawableCompat_android_dither = 0;
    
    public static final int AnimatedStateListDrawableCompat_android_enterFadeDuration = 4;
    
    public static final int AnimatedStateListDrawableCompat_android_exitFadeDuration = 5;
    
    public static final int AnimatedStateListDrawableCompat_android_variablePadding = 2;
    
    public static final int AnimatedStateListDrawableCompat_android_visible = 1;
    
    public static final int[] AnimatedStateListDrawableItem = new int[] { 16842960, 16843161 };
    
    public static final int AnimatedStateListDrawableItem_android_drawable = 1;
    
    public static final int AnimatedStateListDrawableItem_android_id = 0;
    
    public static final int[] AnimatedStateListDrawableTransition = new int[] { 16843161, 16843849, 16843850, 16843851 };
    
    public static final int AnimatedStateListDrawableTransition_android_drawable = 0;
    
    public static final int AnimatedStateListDrawableTransition_android_fromId = 2;
    
    public static final int AnimatedStateListDrawableTransition_android_reversible = 3;
    
    public static final int AnimatedStateListDrawableTransition_android_toId = 1;
    
    public static final int[] AppCompatImageView = new int[] { 16843033, 2130969122, 2130969215, 2130969216 };
    
    public static final int AppCompatImageView_android_src = 0;
    
    public static final int AppCompatImageView_srcCompat = 1;
    
    public static final int AppCompatImageView_tint = 2;
    
    public static final int AppCompatImageView_tintMode = 3;
    
    public static final int[] AppCompatSeekBar = new int[] { 16843074, 2130969212, 2130969213, 2130969214 };
    
    public static final int AppCompatSeekBar_android_thumb = 0;
    
    public static final int AppCompatSeekBar_tickMark = 1;
    
    public static final int AppCompatSeekBar_tickMarkTint = 2;
    
    public static final int AppCompatSeekBar_tickMarkTintMode = 3;
    
    public static final int[] AppCompatTextHelper = new int[] { 16842804, 16843117, 16843118, 16843119, 16843120, 16843666, 16843667 };
    
    public static final int AppCompatTextHelper_android_drawableBottom = 2;
    
    public static final int AppCompatTextHelper_android_drawableEnd = 6;
    
    public static final int AppCompatTextHelper_android_drawableLeft = 3;
    
    public static final int AppCompatTextHelper_android_drawableRight = 4;
    
    public static final int AppCompatTextHelper_android_drawableStart = 5;
    
    public static final int AppCompatTextHelper_android_drawableTop = 1;
    
    public static final int AppCompatTextHelper_android_textAppearance = 0;
    
    public static final int[] AppCompatTextView = new int[] { 
        16842804, 2130968626, 2130968627, 2130968628, 2130968629, 2130968630, 2130968807, 2130968808, 2130968809, 2130968810, 
        2130968812, 2130968813, 2130968814, 2130968815, 2130968864, 2130968867, 2130968875, 2130968937, 2130969012, 2130969177, 
        2130969204 };
    
    public static final int AppCompatTextView_android_textAppearance = 0;
    
    public static final int AppCompatTextView_autoSizeMaxTextSize = 1;
    
    public static final int AppCompatTextView_autoSizeMinTextSize = 2;
    
    public static final int AppCompatTextView_autoSizePresetSizes = 3;
    
    public static final int AppCompatTextView_autoSizeStepGranularity = 4;
    
    public static final int AppCompatTextView_autoSizeTextType = 5;
    
    public static final int AppCompatTextView_drawableBottomCompat = 6;
    
    public static final int AppCompatTextView_drawableEndCompat = 7;
    
    public static final int AppCompatTextView_drawableLeftCompat = 8;
    
    public static final int AppCompatTextView_drawableRightCompat = 9;
    
    public static final int AppCompatTextView_drawableStartCompat = 10;
    
    public static final int AppCompatTextView_drawableTint = 11;
    
    public static final int AppCompatTextView_drawableTintMode = 12;
    
    public static final int AppCompatTextView_drawableTopCompat = 13;
    
    public static final int AppCompatTextView_firstBaselineToTopHeight = 14;
    
    public static final int AppCompatTextView_fontFamily = 15;
    
    public static final int AppCompatTextView_fontVariationSettings = 16;
    
    public static final int AppCompatTextView_lastBaselineToBottomHeight = 17;
    
    public static final int AppCompatTextView_lineHeight = 18;
    
    public static final int AppCompatTextView_textAllCaps = 19;
    
    public static final int AppCompatTextView_textLocale = 20;
    
    public static final int[] AppCompatTheme = new int[] { 
        16842839, 16842926, 2130968579, 2130968580, 2130968581, 2130968582, 2130968583, 2130968584, 2130968585, 2130968586, 
        2130968587, 2130968588, 2130968589, 2130968590, 2130968591, 2130968593, 2130968594, 2130968595, 2130968596, 2130968597, 
        2130968598, 2130968599, 2130968600, 2130968601, 2130968602, 2130968603, 2130968604, 2130968605, 2130968606, 2130968607, 
        2130968608, 2130968609, 2130968613, 2130968614, 2130968615, 2130968616, 2130968617, 2130968625, 2130968659, 2130968673, 
        2130968674, 2130968675, 2130968676, 2130968677, 2130968682, 2130968683, 2130968695, 2130968702, 2130968736, 2130968737, 
        2130968738, 2130968739, 2130968740, 2130968741, 2130968742, 2130968749, 2130968750, 2130968756, 2130968774, 2130968799, 
        2130968800, 2130968801, 2130968804, 2130968806, 2130968817, 2130968818, 2130968819, 2130968820, 2130968821, 2130968893, 
        2130968905, 2130969014, 2130969015, 2130969016, 2130969017, 2130969020, 2130969021, 2130969022, 2130969023, 2130969024, 
        2130969025, 2130969026, 2130969027, 2130969028, 2130969068, 2130969069, 2130969070, 2130969076, 2130969078, 2130969085, 
        2130969087, 2130969088, 2130969089, 2130969097, 2130969098, 2130969099, 2130969100, 2130969119, 2130969120, 2130969149, 
        2130969188, 2130969190, 2130969191, 2130969192, 2130969194, 2130969195, 2130969196, 2130969197, 2130969200, 2130969201, 
        2130969229, 2130969230, 2130969231, 2130969232, 2130969240, 2130969242, 2130969243, 2130969244, 2130969245, 2130969246, 
        2130969247, 2130969248, 2130969249, 2130969250, 2130969251 };
    
    public static final int AppCompatTheme_actionBarDivider = 2;
    
    public static final int AppCompatTheme_actionBarItemBackground = 3;
    
    public static final int AppCompatTheme_actionBarPopupTheme = 4;
    
    public static final int AppCompatTheme_actionBarSize = 5;
    
    public static final int AppCompatTheme_actionBarSplitStyle = 6;
    
    public static final int AppCompatTheme_actionBarStyle = 7;
    
    public static final int AppCompatTheme_actionBarTabBarStyle = 8;
    
    public static final int AppCompatTheme_actionBarTabStyle = 9;
    
    public static final int AppCompatTheme_actionBarTabTextStyle = 10;
    
    public static final int AppCompatTheme_actionBarTheme = 11;
    
    public static final int AppCompatTheme_actionBarWidgetTheme = 12;
    
    public static final int AppCompatTheme_actionButtonStyle = 13;
    
    public static final int AppCompatTheme_actionDropDownStyle = 14;
    
    public static final int AppCompatTheme_actionMenuTextAppearance = 15;
    
    public static final int AppCompatTheme_actionMenuTextColor = 16;
    
    public static final int AppCompatTheme_actionModeBackground = 17;
    
    public static final int AppCompatTheme_actionModeCloseButtonStyle = 18;
    
    public static final int AppCompatTheme_actionModeCloseDrawable = 19;
    
    public static final int AppCompatTheme_actionModeCopyDrawable = 20;
    
    public static final int AppCompatTheme_actionModeCutDrawable = 21;
    
    public static final int AppCompatTheme_actionModeFindDrawable = 22;
    
    public static final int AppCompatTheme_actionModePasteDrawable = 23;
    
    public static final int AppCompatTheme_actionModePopupWindowStyle = 24;
    
    public static final int AppCompatTheme_actionModeSelectAllDrawable = 25;
    
    public static final int AppCompatTheme_actionModeShareDrawable = 26;
    
    public static final int AppCompatTheme_actionModeSplitBackground = 27;
    
    public static final int AppCompatTheme_actionModeStyle = 28;
    
    public static final int AppCompatTheme_actionModeWebSearchDrawable = 29;
    
    public static final int AppCompatTheme_actionOverflowButtonStyle = 30;
    
    public static final int AppCompatTheme_actionOverflowMenuStyle = 31;
    
    public static final int AppCompatTheme_activityChooserViewStyle = 32;
    
    public static final int AppCompatTheme_alertDialogButtonGroupStyle = 33;
    
    public static final int AppCompatTheme_alertDialogCenterButtons = 34;
    
    public static final int AppCompatTheme_alertDialogStyle = 35;
    
    public static final int AppCompatTheme_alertDialogTheme = 36;
    
    public static final int AppCompatTheme_android_windowAnimationStyle = 1;
    
    public static final int AppCompatTheme_android_windowIsFloating = 0;
    
    public static final int AppCompatTheme_autoCompleteTextViewStyle = 37;
    
    public static final int AppCompatTheme_borderlessButtonStyle = 38;
    
    public static final int AppCompatTheme_buttonBarButtonStyle = 39;
    
    public static final int AppCompatTheme_buttonBarNegativeButtonStyle = 40;
    
    public static final int AppCompatTheme_buttonBarNeutralButtonStyle = 41;
    
    public static final int AppCompatTheme_buttonBarPositiveButtonStyle = 42;
    
    public static final int AppCompatTheme_buttonBarStyle = 43;
    
    public static final int AppCompatTheme_buttonStyle = 44;
    
    public static final int AppCompatTheme_buttonStyleSmall = 45;
    
    public static final int AppCompatTheme_checkboxStyle = 46;
    
    public static final int AppCompatTheme_checkedTextViewStyle = 47;
    
    public static final int AppCompatTheme_colorAccent = 48;
    
    public static final int AppCompatTheme_colorBackgroundFloating = 49;
    
    public static final int AppCompatTheme_colorButtonNormal = 50;
    
    public static final int AppCompatTheme_colorControlActivated = 51;
    
    public static final int AppCompatTheme_colorControlHighlight = 52;
    
    public static final int AppCompatTheme_colorControlNormal = 53;
    
    public static final int AppCompatTheme_colorError = 54;
    
    public static final int AppCompatTheme_colorPrimary = 55;
    
    public static final int AppCompatTheme_colorPrimaryDark = 56;
    
    public static final int AppCompatTheme_colorSwitchThumbNormal = 57;
    
    public static final int AppCompatTheme_controlBackground = 58;
    
    public static final int AppCompatTheme_dialogCornerRadius = 59;
    
    public static final int AppCompatTheme_dialogPreferredPadding = 60;
    
    public static final int AppCompatTheme_dialogTheme = 61;
    
    public static final int AppCompatTheme_dividerHorizontal = 62;
    
    public static final int AppCompatTheme_dividerVertical = 63;
    
    public static final int AppCompatTheme_dropDownListViewStyle = 64;
    
    public static final int AppCompatTheme_dropdownListPreferredItemHeight = 65;
    
    public static final int AppCompatTheme_editTextBackground = 66;
    
    public static final int AppCompatTheme_editTextColor = 67;
    
    public static final int AppCompatTheme_editTextStyle = 68;
    
    public static final int AppCompatTheme_homeAsUpIndicator = 69;
    
    public static final int AppCompatTheme_imageButtonStyle = 70;
    
    public static final int AppCompatTheme_listChoiceBackgroundIndicator = 71;
    
    public static final int AppCompatTheme_listChoiceIndicatorMultipleAnimated = 72;
    
    public static final int AppCompatTheme_listChoiceIndicatorSingleAnimated = 73;
    
    public static final int AppCompatTheme_listDividerAlertDialog = 74;
    
    public static final int AppCompatTheme_listMenuViewStyle = 75;
    
    public static final int AppCompatTheme_listPopupWindowStyle = 76;
    
    public static final int AppCompatTheme_listPreferredItemHeight = 77;
    
    public static final int AppCompatTheme_listPreferredItemHeightLarge = 78;
    
    public static final int AppCompatTheme_listPreferredItemHeightSmall = 79;
    
    public static final int AppCompatTheme_listPreferredItemPaddingEnd = 80;
    
    public static final int AppCompatTheme_listPreferredItemPaddingLeft = 81;
    
    public static final int AppCompatTheme_listPreferredItemPaddingRight = 82;
    
    public static final int AppCompatTheme_listPreferredItemPaddingStart = 83;
    
    public static final int AppCompatTheme_panelBackground = 84;
    
    public static final int AppCompatTheme_panelMenuListTheme = 85;
    
    public static final int AppCompatTheme_panelMenuListWidth = 86;
    
    public static final int AppCompatTheme_popupMenuStyle = 87;
    
    public static final int AppCompatTheme_popupWindowStyle = 88;
    
    public static final int AppCompatTheme_radioButtonStyle = 89;
    
    public static final int AppCompatTheme_ratingBarStyle = 90;
    
    public static final int AppCompatTheme_ratingBarStyleIndicator = 91;
    
    public static final int AppCompatTheme_ratingBarStyleSmall = 92;
    
    public static final int AppCompatTheme_searchViewStyle = 93;
    
    public static final int AppCompatTheme_seekBarStyle = 94;
    
    public static final int AppCompatTheme_selectableItemBackground = 95;
    
    public static final int AppCompatTheme_selectableItemBackgroundBorderless = 96;
    
    public static final int AppCompatTheme_spinnerDropDownItemStyle = 97;
    
    public static final int AppCompatTheme_spinnerStyle = 98;
    
    public static final int AppCompatTheme_switchStyle = 99;
    
    public static final int AppCompatTheme_textAppearanceLargePopupMenu = 100;
    
    public static final int AppCompatTheme_textAppearanceListItem = 101;
    
    public static final int AppCompatTheme_textAppearanceListItemSecondary = 102;
    
    public static final int AppCompatTheme_textAppearanceListItemSmall = 103;
    
    public static final int AppCompatTheme_textAppearancePopupMenuHeader = 104;
    
    public static final int AppCompatTheme_textAppearanceSearchResultSubtitle = 105;
    
    public static final int AppCompatTheme_textAppearanceSearchResultTitle = 106;
    
    public static final int AppCompatTheme_textAppearanceSmallPopupMenu = 107;
    
    public static final int AppCompatTheme_textColorAlertDialogListItem = 108;
    
    public static final int AppCompatTheme_textColorSearchUrl = 109;
    
    public static final int AppCompatTheme_toolbarNavigationButtonStyle = 110;
    
    public static final int AppCompatTheme_toolbarStyle = 111;
    
    public static final int AppCompatTheme_tooltipForegroundColor = 112;
    
    public static final int AppCompatTheme_tooltipFrameBackground = 113;
    
    public static final int AppCompatTheme_viewInflaterClass = 114;
    
    public static final int AppCompatTheme_windowActionBar = 115;
    
    public static final int AppCompatTheme_windowActionBarOverlay = 116;
    
    public static final int AppCompatTheme_windowActionModeOverlay = 117;
    
    public static final int AppCompatTheme_windowFixedHeightMajor = 118;
    
    public static final int AppCompatTheme_windowFixedHeightMinor = 119;
    
    public static final int AppCompatTheme_windowFixedWidthMajor = 120;
    
    public static final int AppCompatTheme_windowFixedWidthMinor = 121;
    
    public static final int AppCompatTheme_windowMinWidthMajor = 122;
    
    public static final int AppCompatTheme_windowMinWidthMinor = 123;
    
    public static final int AppCompatTheme_windowNoTitle = 124;
    
    public static final int[] ButtonBarLayout = new int[] { 2130968618 };
    
    public static final int ButtonBarLayout_allowStacking = 0;
    
    public static final int[] ColorStateListItem = new int[] { 16843173, 16843551, 2130968619 };
    
    public static final int ColorStateListItem_alpha = 2;
    
    public static final int ColorStateListItem_android_alpha = 1;
    
    public static final int ColorStateListItem_android_color = 0;
    
    public static final int[] CompoundButton = new int[] { 16843015, 2130968678, 2130968684, 2130968685 };
    
    public static final int CompoundButton_android_button = 0;
    
    public static final int CompoundButton_buttonCompat = 1;
    
    public static final int CompoundButton_buttonTint = 2;
    
    public static final int CompoundButton_buttonTintMode = 3;
    
    public static final int[] DrawerArrowToggle = new int[] { 2130968623, 2130968624, 2130968645, 2130968735, 2130968811, 2130968878, 2130969118, 2130969208 };
    
    public static final int DrawerArrowToggle_arrowHeadLength = 0;
    
    public static final int DrawerArrowToggle_arrowShaftLength = 1;
    
    public static final int DrawerArrowToggle_barLength = 2;
    
    public static final int DrawerArrowToggle_color = 3;
    
    public static final int DrawerArrowToggle_drawableSize = 4;
    
    public static final int DrawerArrowToggle_gapBetweenBars = 5;
    
    public static final int DrawerArrowToggle_spinBars = 6;
    
    public static final int DrawerArrowToggle_thickness = 7;
    
    public static final int[] FontFamily = new int[] { 2130968868, 2130968869, 2130968870, 2130968871, 2130968872, 2130968873 };
    
    public static final int[] FontFamilyFont = new int[] { 16844082, 16844083, 16844095, 16844143, 16844144, 2130968866, 2130968874, 2130968875, 2130968876, 2130969237 };
    
    public static final int FontFamilyFont_android_font = 0;
    
    public static final int FontFamilyFont_android_fontStyle = 2;
    
    public static final int FontFamilyFont_android_fontVariationSettings = 4;
    
    public static final int FontFamilyFont_android_fontWeight = 1;
    
    public static final int FontFamilyFont_android_ttcIndex = 3;
    
    public static final int FontFamilyFont_font = 5;
    
    public static final int FontFamilyFont_fontStyle = 6;
    
    public static final int FontFamilyFont_fontVariationSettings = 7;
    
    public static final int FontFamilyFont_fontWeight = 8;
    
    public static final int FontFamilyFont_ttcIndex = 9;
    
    public static final int FontFamily_fontProviderAuthority = 0;
    
    public static final int FontFamily_fontProviderCerts = 1;
    
    public static final int FontFamily_fontProviderFetchStrategy = 2;
    
    public static final int FontFamily_fontProviderFetchTimeout = 3;
    
    public static final int FontFamily_fontProviderPackage = 4;
    
    public static final int FontFamily_fontProviderQuery = 5;
    
    public static final int[] GradientColor = new int[] { 
        16843165, 16843166, 16843169, 16843170, 16843171, 16843172, 16843265, 16843275, 16844048, 16844049, 
        16844050, 16844051 };
    
    public static final int[] GradientColorItem = new int[] { 16843173, 16844052 };
    
    public static final int GradientColorItem_android_color = 0;
    
    public static final int GradientColorItem_android_offset = 1;
    
    public static final int GradientColor_android_centerColor = 7;
    
    public static final int GradientColor_android_centerX = 3;
    
    public static final int GradientColor_android_centerY = 4;
    
    public static final int GradientColor_android_endColor = 1;
    
    public static final int GradientColor_android_endX = 10;
    
    public static final int GradientColor_android_endY = 11;
    
    public static final int GradientColor_android_gradientRadius = 5;
    
    public static final int GradientColor_android_startColor = 0;
    
    public static final int GradientColor_android_startX = 8;
    
    public static final int GradientColor_android_startY = 9;
    
    public static final int GradientColor_android_tileMode = 6;
    
    public static final int GradientColor_android_type = 2;
    
    public static final int[] LinearLayoutCompat = new int[] { 16842927, 16842948, 16843046, 16843047, 16843048, 2130968803, 2130968805, 2130969053, 2130969107 };
    
    public static final int[] LinearLayoutCompat_Layout = new int[] { 16842931, 16842996, 16842997, 16843137 };
    
    public static final int LinearLayoutCompat_Layout_android_layout_gravity = 0;
    
    public static final int LinearLayoutCompat_Layout_android_layout_height = 2;
    
    public static final int LinearLayoutCompat_Layout_android_layout_weight = 3;
    
    public static final int LinearLayoutCompat_Layout_android_layout_width = 1;
    
    public static final int LinearLayoutCompat_android_baselineAligned = 2;
    
    public static final int LinearLayoutCompat_android_baselineAlignedChildIndex = 3;
    
    public static final int LinearLayoutCompat_android_gravity = 0;
    
    public static final int LinearLayoutCompat_android_orientation = 1;
    
    public static final int LinearLayoutCompat_android_weightSum = 4;
    
    public static final int LinearLayoutCompat_divider = 5;
    
    public static final int LinearLayoutCompat_dividerPadding = 6;
    
    public static final int LinearLayoutCompat_measureWithLargestChild = 7;
    
    public static final int LinearLayoutCompat_showDividers = 8;
    
    public static final int[] ListPopupWindow = new int[] { 16843436, 16843437 };
    
    public static final int ListPopupWindow_android_dropDownHorizontalOffset = 0;
    
    public static final int ListPopupWindow_android_dropDownVerticalOffset = 1;
    
    public static final int[] MenuGroup = new int[] { 16842766, 16842960, 16843156, 16843230, 16843231, 16843232 };
    
    public static final int MenuGroup_android_checkableBehavior = 5;
    
    public static final int MenuGroup_android_enabled = 0;
    
    public static final int MenuGroup_android_id = 1;
    
    public static final int MenuGroup_android_menuCategory = 3;
    
    public static final int MenuGroup_android_orderInCategory = 4;
    
    public static final int MenuGroup_android_visible = 2;
    
    public static final int[] MenuItem = new int[] { 
        16842754, 16842766, 16842960, 16843014, 16843156, 16843230, 16843231, 16843233, 16843234, 16843235, 
        16843236, 16843237, 16843375, 2130968592, 2130968610, 2130968612, 2130968620, 2130968761, 2130968902, 2130968903, 
        2130969062, 2130969106, 2130969233 };
    
    public static final int MenuItem_actionLayout = 13;
    
    public static final int MenuItem_actionProviderClass = 14;
    
    public static final int MenuItem_actionViewClass = 15;
    
    public static final int MenuItem_alphabeticModifiers = 16;
    
    public static final int MenuItem_android_alphabeticShortcut = 9;
    
    public static final int MenuItem_android_checkable = 11;
    
    public static final int MenuItem_android_checked = 3;
    
    public static final int MenuItem_android_enabled = 1;
    
    public static final int MenuItem_android_icon = 0;
    
    public static final int MenuItem_android_id = 2;
    
    public static final int MenuItem_android_menuCategory = 5;
    
    public static final int MenuItem_android_numericShortcut = 10;
    
    public static final int MenuItem_android_onClick = 12;
    
    public static final int MenuItem_android_orderInCategory = 6;
    
    public static final int MenuItem_android_title = 7;
    
    public static final int MenuItem_android_titleCondensed = 8;
    
    public static final int MenuItem_android_visible = 4;
    
    public static final int MenuItem_contentDescription = 17;
    
    public static final int MenuItem_iconTint = 18;
    
    public static final int MenuItem_iconTintMode = 19;
    
    public static final int MenuItem_numericModifiers = 20;
    
    public static final int MenuItem_showAsAction = 21;
    
    public static final int MenuItem_tooltipText = 22;
    
    public static final int[] MenuView = new int[] { 16842926, 16843052, 16843053, 16843054, 16843055, 16843056, 16843057, 2130969079, 2130969140 };
    
    public static final int MenuView_android_headerBackground = 4;
    
    public static final int MenuView_android_horizontalDivider = 2;
    
    public static final int MenuView_android_itemBackground = 5;
    
    public static final int MenuView_android_itemIconDisabledAlpha = 6;
    
    public static final int MenuView_android_itemTextAppearance = 1;
    
    public static final int MenuView_android_verticalDivider = 3;
    
    public static final int MenuView_android_windowAnimationStyle = 0;
    
    public static final int MenuView_preserveIconSpacing = 7;
    
    public static final int MenuView_subMenuArrow = 8;
    
    public static final int[] PopupWindow = new int[] { 16843126, 16843465, 2130969063 };
    
    public static final int[] PopupWindowBackgroundState = new int[] { 2130969129 };
    
    public static final int PopupWindowBackgroundState_state_above_anchor = 0;
    
    public static final int PopupWindow_android_popupAnimationStyle = 1;
    
    public static final int PopupWindow_android_popupBackground = 0;
    
    public static final int PopupWindow_overlapAnchor = 2;
    
    public static final int[] RecycleListView = new int[] { 2130969064, 2130969067 };
    
    public static final int RecycleListView_paddingBottomNoButtons = 0;
    
    public static final int RecycleListView_paddingTopNoTitle = 1;
    
    public static final int[] SearchView = new int[] { 
        16842970, 16843039, 16843296, 16843364, 2130968723, 2130968757, 2130968798, 2130968879, 2130968904, 2130968938, 
        2130969083, 2130969084, 2130969095, 2130969096, 2130969141, 2130969146, 2130969241 };
    
    public static final int SearchView_android_focusable = 0;
    
    public static final int SearchView_android_imeOptions = 3;
    
    public static final int SearchView_android_inputType = 2;
    
    public static final int SearchView_android_maxWidth = 1;
    
    public static final int SearchView_closeIcon = 4;
    
    public static final int SearchView_commitIcon = 5;
    
    public static final int SearchView_defaultQueryHint = 6;
    
    public static final int SearchView_goIcon = 7;
    
    public static final int SearchView_iconifiedByDefault = 8;
    
    public static final int SearchView_layout = 9;
    
    public static final int SearchView_queryBackground = 10;
    
    public static final int SearchView_queryHint = 11;
    
    public static final int SearchView_searchHintIcon = 12;
    
    public static final int SearchView_searchIcon = 13;
    
    public static final int SearchView_submitBackground = 14;
    
    public static final int SearchView_suggestionRowLayout = 15;
    
    public static final int SearchView_voiceIcon = 16;
    
    public static final int[] Spinner = new int[] { 16842930, 16843126, 16843131, 16843362, 2130969077 };
    
    public static final int Spinner_android_dropDownWidth = 3;
    
    public static final int Spinner_android_entries = 0;
    
    public static final int Spinner_android_popupBackground = 1;
    
    public static final int Spinner_android_prompt = 2;
    
    public static final int Spinner_popupTheme = 4;
    
    public static final int[] StateListDrawable = new int[] { 16843036, 16843156, 16843157, 16843158, 16843532, 16843533 };
    
    public static final int[] StateListDrawableItem = new int[] { 16843161 };
    
    public static final int StateListDrawableItem_android_drawable = 0;
    
    public static final int StateListDrawable_android_constantSize = 3;
    
    public static final int StateListDrawable_android_dither = 0;
    
    public static final int StateListDrawable_android_enterFadeDuration = 4;
    
    public static final int StateListDrawable_android_exitFadeDuration = 5;
    
    public static final int StateListDrawable_android_variablePadding = 2;
    
    public static final int StateListDrawable_android_visible = 1;
    
    public static final int[] SwitchCompat = new int[] { 
        16843044, 16843045, 16843074, 2130969109, 2130969121, 2130969147, 2130969148, 2130969150, 2130969209, 2130969210, 
        2130969211, 2130969234, 2130969235, 2130969236 };
    
    public static final int SwitchCompat_android_textOff = 1;
    
    public static final int SwitchCompat_android_textOn = 0;
    
    public static final int SwitchCompat_android_thumb = 2;
    
    public static final int SwitchCompat_showText = 3;
    
    public static final int SwitchCompat_splitTrack = 4;
    
    public static final int SwitchCompat_switchMinWidth = 5;
    
    public static final int SwitchCompat_switchPadding = 6;
    
    public static final int SwitchCompat_switchTextAppearance = 7;
    
    public static final int SwitchCompat_thumbTextPadding = 8;
    
    public static final int SwitchCompat_thumbTint = 9;
    
    public static final int SwitchCompat_thumbTintMode = 10;
    
    public static final int SwitchCompat_track = 11;
    
    public static final int SwitchCompat_trackTint = 12;
    
    public static final int SwitchCompat_trackTintMode = 13;
    
    public static final int[] TextAppearance = new int[] { 
        16842901, 16842902, 16842903, 16842904, 16842906, 16842907, 16843105, 16843106, 16843107, 16843108, 
        16843692, 16844165, 2130968867, 2130968875, 2130969177, 2130969204 };
    
    public static final int TextAppearance_android_fontFamily = 10;
    
    public static final int TextAppearance_android_shadowColor = 6;
    
    public static final int TextAppearance_android_shadowDx = 7;
    
    public static final int TextAppearance_android_shadowDy = 8;
    
    public static final int TextAppearance_android_shadowRadius = 9;
    
    public static final int TextAppearance_android_textColor = 3;
    
    public static final int TextAppearance_android_textColorHint = 4;
    
    public static final int TextAppearance_android_textColorLink = 5;
    
    public static final int TextAppearance_android_textFontWeight = 11;
    
    public static final int TextAppearance_android_textSize = 0;
    
    public static final int TextAppearance_android_textStyle = 2;
    
    public static final int TextAppearance_android_typeface = 1;
    
    public static final int TextAppearance_fontFamily = 12;
    
    public static final int TextAppearance_fontVariationSettings = 13;
    
    public static final int TextAppearance_textAllCaps = 14;
    
    public static final int TextAppearance_textLocale = 15;
    
    public static final int[] Toolbar = new int[] { 
        16842927, 16843072, 2130968679, 2130968731, 2130968732, 2130968762, 2130968763, 2130968764, 2130968765, 2130968766, 
        2130968767, 2130969029, 2130969030, 2130969050, 2130969054, 2130969057, 2130969058, 2130969077, 2130969142, 2130969143, 
        2130969144, 2130969217, 2130969219, 2130969220, 2130969221, 2130969222, 2130969223, 2130969224, 2130969225, 2130969226 };
    
    public static final int Toolbar_android_gravity = 0;
    
    public static final int Toolbar_android_minHeight = 1;
    
    public static final int Toolbar_buttonGravity = 2;
    
    public static final int Toolbar_collapseContentDescription = 3;
    
    public static final int Toolbar_collapseIcon = 4;
    
    public static final int Toolbar_contentInsetEnd = 5;
    
    public static final int Toolbar_contentInsetEndWithActions = 6;
    
    public static final int Toolbar_contentInsetLeft = 7;
    
    public static final int Toolbar_contentInsetRight = 8;
    
    public static final int Toolbar_contentInsetStart = 9;
    
    public static final int Toolbar_contentInsetStartWithNavigation = 10;
    
    public static final int Toolbar_logo = 11;
    
    public static final int Toolbar_logoDescription = 12;
    
    public static final int Toolbar_maxButtonHeight = 13;
    
    public static final int Toolbar_menu = 14;
    
    public static final int Toolbar_navigationContentDescription = 15;
    
    public static final int Toolbar_navigationIcon = 16;
    
    public static final int Toolbar_popupTheme = 17;
    
    public static final int Toolbar_subtitle = 18;
    
    public static final int Toolbar_subtitleTextAppearance = 19;
    
    public static final int Toolbar_subtitleTextColor = 20;
    
    public static final int Toolbar_title = 21;
    
    public static final int Toolbar_titleMargin = 22;
    
    public static final int Toolbar_titleMarginBottom = 23;
    
    public static final int Toolbar_titleMarginEnd = 24;
    
    public static final int Toolbar_titleMarginStart = 25;
    
    public static final int Toolbar_titleMarginTop = 26;
    
    public static final int Toolbar_titleMargins = 27;
    
    public static final int Toolbar_titleTextAppearance = 28;
    
    public static final int Toolbar_titleTextColor = 29;
    
    public static final int[] View = new int[] { 16842752, 16842970, 2130969065, 2130969066, 2130969206 };
    
    public static final int[] ViewBackgroundHelper = new int[] { 16842964, 2130968640, 2130968641 };
    
    public static final int ViewBackgroundHelper_android_background = 0;
    
    public static final int ViewBackgroundHelper_backgroundTint = 1;
    
    public static final int ViewBackgroundHelper_backgroundTintMode = 2;
    
    public static final int[] ViewStubCompat = new int[] { 16842960, 16842994, 16842995 };
    
    public static final int ViewStubCompat_android_id = 0;
    
    public static final int ViewStubCompat_android_inflatedId = 2;
    
    public static final int ViewStubCompat_android_layout = 1;
    
    public static final int View_android_focusable = 1;
    
    public static final int View_android_theme = 0;
    
    public static final int View_paddingEnd = 2;
    
    public static final int View_paddingStart = 3;
    
    public static final int View_theme = 4;
  }
}


/* Location:              /home/brandon/levelMeter_APK/dex2jar-2.x/dex-tools/build/distributions/dex-tools-2.2-SNAPSHOT/classes-dex2jar.jar!/androidx/appcompat/R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */