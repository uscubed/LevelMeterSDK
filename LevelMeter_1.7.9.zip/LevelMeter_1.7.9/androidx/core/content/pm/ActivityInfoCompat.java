package androidx.core.content.pm;

@Deprecated
public final class ActivityInfoCompat {
  @Deprecated
  public static final int CONFIG_UI_MODE = 512;
}


/* Location:              /home/brandon/levelMeter_APK/dex2jar-2.x/dex-tools/build/distributions/dex-tools-2.2-SNAPSHOT/classes-dex2jar.jar!/androidx/core/content/pm/ActivityInfoCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */