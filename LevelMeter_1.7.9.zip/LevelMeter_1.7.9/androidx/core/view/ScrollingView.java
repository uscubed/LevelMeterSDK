package androidx.core.view;

public interface ScrollingView {
  int computeHorizontalScrollExtent();
  
  int computeHorizontalScrollOffset();
  
  int computeHorizontalScrollRange();
  
  int computeVerticalScrollExtent();
  
  int computeVerticalScrollOffset();
  
  int computeVerticalScrollRange();
}


/* Location:              /home/brandon/levelMeter_APK/dex2jar-2.x/dex-tools/build/distributions/dex-tools-2.2-SNAPSHOT/classes-dex2jar.jar!/androidx/core/view/ScrollingView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */