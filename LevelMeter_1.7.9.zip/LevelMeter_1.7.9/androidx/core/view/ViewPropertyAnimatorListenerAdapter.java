package androidx.core.view;

import android.view.View;

public class ViewPropertyAnimatorListenerAdapter implements ViewPropertyAnimatorListener {
  public void onAnimationCancel(View paramView) {}
  
  public void onAnimationEnd(View paramView) {}
  
  public void onAnimationStart(View paramView) {}
}


/* Location:              /home/brandon/levelMeter_APK/dex2jar-2.x/dex-tools/build/distributions/dex-tools-2.2-SNAPSHOT/classes-dex2jar.jar!/androidx/core/view/ViewPropertyAnimatorListenerAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */