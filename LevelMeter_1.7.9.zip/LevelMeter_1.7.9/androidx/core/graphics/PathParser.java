package androidx.core.graphics;

import android.graphics.Path;
import android.util.Log;
import java.util.ArrayList;

public class PathParser {
  private static final String LOGTAG = "PathParser";
  
  private static void addNode(ArrayList<PathDataNode> paramArrayList, char paramChar, float[] paramArrayOffloat) {
    paramArrayList.add(new PathDataNode(paramChar, paramArrayOffloat));
  }
  
  public static boolean canMorph(PathDataNode[] paramArrayOfPathDataNode1, PathDataNode[] paramArrayOfPathDataNode2) {
    if (paramArrayOfPathDataNode1 == null || paramArrayOfPathDataNode2 == null)
      return false; 
    if (paramArrayOfPathDataNode1.length != paramArrayOfPathDataNode2.length)
      return false; 
    for (byte b = 0; b < paramArrayOfPathDataNode1.length; b++) {
      if ((paramArrayOfPathDataNode1[b]).mType != (paramArrayOfPathDataNode2[b]).mType || (paramArrayOfPathDataNode1[b]).mParams.length != (paramArrayOfPathDataNode2[b]).mParams.length)
        return false; 
    } 
    return true;
  }
  
  static float[] copyOfRange(float[] paramArrayOffloat, int paramInt1, int paramInt2) {
    if (paramInt1 <= paramInt2) {
      int i = paramArrayOffloat.length;
      if (paramInt1 >= 0 && paramInt1 <= i) {
        paramInt2 -= paramInt1;
        i = Math.min(paramInt2, i - paramInt1);
        float[] arrayOfFloat = new float[paramInt2];
        System.arraycopy(paramArrayOffloat, paramInt1, arrayOfFloat, 0, i);
        return arrayOfFloat;
      } 
      throw new ArrayIndexOutOfBoundsException();
    } 
    throw new IllegalArgumentException();
  }
  
  public static PathDataNode[] createNodesFromPathData(String paramString) {
    if (paramString == null)
      return null; 
    ArrayList<PathDataNode> arrayList = new ArrayList();
    int i = 1;
    int j = 0;
    while (i < paramString.length()) {
      i = nextStart(paramString, i);
      String str = paramString.substring(j, i).trim();
      if (str.length() > 0) {
        float[] arrayOfFloat = getFloats(str);
        addNode(arrayList, str.charAt(0), arrayOfFloat);
      } 
      j = i;
      i++;
    } 
    if (i - j == 1 && j < paramString.length())
      addNode(arrayList, paramString.charAt(j), new float[0]); 
    return arrayList.<PathDataNode>toArray(new PathDataNode[arrayList.size()]);
  }
  
  public static Path createPathFromPathData(String paramString) {
    Path path = new Path();
    PathDataNode[] arrayOfPathDataNode = createNodesFromPathData(paramString);
    if (arrayOfPathDataNode != null)
      try {
        PathDataNode.nodesToPath(arrayOfPathDataNode, path);
        return path;
      } catch (RuntimeException runtimeException) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Error in parsing ");
        stringBuilder.append(paramString);
        throw new RuntimeException(stringBuilder.toString(), runtimeException);
      }  
    return null;
  }
  
  public static PathDataNode[] deepCopyNodes(PathDataNode[] paramArrayOfPathDataNode) {
    if (paramArrayOfPathDataNode == null)
      return null; 
    PathDataNode[] arrayOfPathDataNode = new PathDataNode[paramArrayOfPathDataNode.length];
    for (byte b = 0; b < paramArrayOfPathDataNode.length; b++)
      arrayOfPathDataNode[b] = new PathDataNode(paramArrayOfPathDataNode[b]); 
    return arrayOfPathDataNode;
  }
  
  private static void extract(String paramString, int paramInt, ExtractFloatResult paramExtractFloatResult) {
    paramExtractFloatResult.mEndWithNegOrDot = false;
    int i = paramInt;
    boolean bool1 = false;
    boolean bool2 = false;
    boolean bool3 = bool2;
    while (i < paramString.length()) {
      char c = paramString.charAt(i);
      if (c != ' ') {
        if (c != 'E' && c != 'e') {
          switch (c) {
            default:
              bool1 = false;
              break;
            case '.':
              if (!bool2) {
                bool1 = false;
                bool2 = true;
                break;
              } 
              paramExtractFloatResult.mEndWithNegOrDot = true;
            case '-':
            
            case ',':
              bool1 = false;
              bool3 = true;
              break;
          } 
        } else {
          bool1 = true;
        } 
        if (bool3)
          break; 
        continue;
      } 
      i++;
    } 
    paramExtractFloatResult.mEndPosition = i;
  }
  
  private static float[] getFloats(String paramString) {
    if (paramString.charAt(0) == 'z' || paramString.charAt(0) == 'Z')
      return new float[0]; 
    try {
      null = new float[paramString.length()];
      ExtractFloatResult extractFloatResult = new ExtractFloatResult();
      this();
      int i = paramString.length();
      int j = 1;
      int k;
      for (k = 0; j < i; k = n) {
        extract(paramString, j, extractFloatResult);
        int m = extractFloatResult.mEndPosition;
        int n = k;
        if (j < m) {
          null[k] = Float.parseFloat(paramString.substring(j, m));
          n = k + 1;
        } 
        if (extractFloatResult.mEndWithNegOrDot) {
          j = m;
          k = n;
          continue;
        } 
        j = m + 1;
      } 
      return copyOfRange(null, 0, k);
    } catch (NumberFormatException numberFormatException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("error in parsing \"");
      stringBuilder.append(paramString);
      stringBuilder.append("\"");
      throw new RuntimeException(stringBuilder.toString(), numberFormatException);
    } 
  }
  
  public static boolean interpolatePathDataNodes(PathDataNode[] paramArrayOfPathDataNode1, PathDataNode[] paramArrayOfPathDataNode2, PathDataNode[] paramArrayOfPathDataNode3, float paramFloat) {
    if (paramArrayOfPathDataNode1 != null && paramArrayOfPathDataNode2 != null && paramArrayOfPathDataNode3 != null) {
      if (paramArrayOfPathDataNode1.length == paramArrayOfPathDataNode2.length && paramArrayOfPathDataNode2.length == paramArrayOfPathDataNode3.length) {
        boolean bool = canMorph(paramArrayOfPathDataNode2, paramArrayOfPathDataNode3);
        byte b = 0;
        if (!bool)
          return false; 
        while (b < paramArrayOfPathDataNode1.length) {
          paramArrayOfPathDataNode1[b].interpolatePathDataNode(paramArrayOfPathDataNode2[b], paramArrayOfPathDataNode3[b], paramFloat);
          b++;
        } 
        return true;
      } 
      throw new IllegalArgumentException("The nodes to be interpolated and resulting nodes must have the same length");
    } 
    throw new IllegalArgumentException("The nodes to be interpolated and resulting nodes cannot be null");
  }
  
  private static int nextStart(String paramString, int paramInt) {
    while (paramInt < paramString.length()) {
      char c = paramString.charAt(paramInt);
      if (((c - 65) * (c - 90) <= 0 || (c - 97) * (c - 122) <= 0) && c != 'e' && c != 'E')
        return paramInt; 
      paramInt++;
    } 
    return paramInt;
  }
  
  public static void updateNodes(PathDataNode[] paramArrayOfPathDataNode1, PathDataNode[] paramArrayOfPathDataNode2) {
    for (byte b = 0; b < paramArrayOfPathDataNode2.length; b++) {
      (paramArrayOfPathDataNode1[b]).mType = (paramArrayOfPathDataNode2[b]).mType;
      for (byte b1 = 0; b1 < (paramArrayOfPathDataNode2[b]).mParams.length; b1++)
        (paramArrayOfPathDataNode1[b]).mParams[b1] = (paramArrayOfPathDataNode2[b]).mParams[b1]; 
    } 
  }
  
  private static class ExtractFloatResult {
    int mEndPosition;
    
    boolean mEndWithNegOrDot;
  }
  
  public static class PathDataNode {
    public float[] mParams;
    
    public char mType;
    
    PathDataNode(char param1Char, float[] param1ArrayOffloat) {
      this.mType = param1Char;
      this.mParams = param1ArrayOffloat;
    }
    
    PathDataNode(PathDataNode param1PathDataNode) {
      this.mType = param1PathDataNode.mType;
      float[] arrayOfFloat = param1PathDataNode.mParams;
      this.mParams = PathParser.copyOfRange(arrayOfFloat, 0, arrayOfFloat.length);
    }
    
    private static void addCommand(Path param1Path, float[] param1ArrayOffloat1, char param1Char1, char param1Char2, float[] param1ArrayOffloat2) {
      // Byte code:
      //   0: aload_1
      //   1: iconst_0
      //   2: faload
      //   3: fstore #5
      //   5: aload_1
      //   6: iconst_1
      //   7: faload
      //   8: fstore #6
      //   10: aload_1
      //   11: iconst_2
      //   12: faload
      //   13: fstore #7
      //   15: aload_1
      //   16: iconst_3
      //   17: faload
      //   18: fstore #8
      //   20: aload_1
      //   21: iconst_4
      //   22: faload
      //   23: fstore #9
      //   25: aload_1
      //   26: iconst_5
      //   27: faload
      //   28: fstore #10
      //   30: fload #5
      //   32: fstore #11
      //   34: fload #6
      //   36: fstore #12
      //   38: fload #7
      //   40: fstore #13
      //   42: fload #8
      //   44: fstore #14
      //   46: iload_3
      //   47: lookupswitch default -> 216, 65 -> 320, 67 -> 313, 72 -> 291, 76 -> 232, 77 -> 232, 81 -> 269, 83 -> 269, 84 -> 232, 86 -> 291, 90 -> 238, 97 -> 320, 99 -> 313, 104 -> 291, 108 -> 232, 109 -> 232, 113 -> 269, 115 -> 269, 116 -> 232, 118 -> 291, 122 -> 238
      //   216: fload #8
      //   218: fstore #14
      //   220: fload #7
      //   222: fstore #13
      //   224: fload #6
      //   226: fstore #12
      //   228: fload #5
      //   230: fstore #11
      //   232: iconst_2
      //   233: istore #15
      //   235: goto -> 340
      //   238: aload_0
      //   239: invokevirtual close : ()V
      //   242: aload_0
      //   243: fload #9
      //   245: fload #10
      //   247: invokevirtual moveTo : (FF)V
      //   250: fload #9
      //   252: fstore #11
      //   254: fload #11
      //   256: fstore #13
      //   258: fload #10
      //   260: fstore #12
      //   262: fload #12
      //   264: fstore #14
      //   266: goto -> 232
      //   269: iconst_4
      //   270: istore #15
      //   272: fload #5
      //   274: fstore #11
      //   276: fload #6
      //   278: fstore #12
      //   280: fload #7
      //   282: fstore #13
      //   284: fload #8
      //   286: fstore #14
      //   288: goto -> 340
      //   291: iconst_1
      //   292: istore #15
      //   294: fload #5
      //   296: fstore #11
      //   298: fload #6
      //   300: fstore #12
      //   302: fload #7
      //   304: fstore #13
      //   306: fload #8
      //   308: fstore #14
      //   310: goto -> 340
      //   313: bipush #6
      //   315: istore #15
      //   317: goto -> 324
      //   320: bipush #7
      //   322: istore #15
      //   324: fload #8
      //   326: fstore #14
      //   328: fload #7
      //   330: fstore #13
      //   332: fload #6
      //   334: fstore #12
      //   336: fload #5
      //   338: fstore #11
      //   340: iconst_0
      //   341: istore #16
      //   343: iload_2
      //   344: istore #17
      //   346: iload #16
      //   348: istore_2
      //   349: iload_2
      //   350: aload #4
      //   352: arraylength
      //   353: if_icmpge -> 2084
      //   356: iload_3
      //   357: bipush #65
      //   359: if_icmpeq -> 1940
      //   362: iload_3
      //   363: bipush #67
      //   365: if_icmpeq -> 1833
      //   368: iload_3
      //   369: bipush #72
      //   371: if_icmpeq -> 1807
      //   374: iload_3
      //   375: bipush #81
      //   377: if_icmpeq -> 1720
      //   380: iload_3
      //   381: bipush #86
      //   383: if_icmpeq -> 1694
      //   386: iload_3
      //   387: bipush #97
      //   389: if_icmpeq -> 1554
      //   392: iload_3
      //   393: bipush #99
      //   395: if_icmpeq -> 1411
      //   398: iload_3
      //   399: bipush #104
      //   401: if_icmpeq -> 1383
      //   404: iload_3
      //   405: bipush #113
      //   407: if_icmpeq -> 1283
      //   410: iload_3
      //   411: bipush #118
      //   413: if_icmpeq -> 1258
      //   416: iload_3
      //   417: bipush #76
      //   419: if_icmpeq -> 1213
      //   422: iload_3
      //   423: bipush #77
      //   425: if_icmpeq -> 1143
      //   428: iload_3
      //   429: bipush #83
      //   431: if_icmpeq -> 998
      //   434: iload_3
      //   435: bipush #84
      //   437: if_icmpeq -> 887
      //   440: iload_3
      //   441: bipush #108
      //   443: if_icmpeq -> 832
      //   446: iload_3
      //   447: bipush #109
      //   449: if_icmpeq -> 764
      //   452: iload_3
      //   453: bipush #115
      //   455: if_icmpeq -> 598
      //   458: iload_3
      //   459: bipush #116
      //   461: if_icmpeq -> 467
      //   464: goto -> 2073
      //   467: iload #17
      //   469: bipush #113
      //   471: if_icmpeq -> 507
      //   474: iload #17
      //   476: bipush #116
      //   478: if_icmpeq -> 507
      //   481: iload #17
      //   483: bipush #81
      //   485: if_icmpeq -> 507
      //   488: iload #17
      //   490: bipush #84
      //   492: if_icmpne -> 498
      //   495: goto -> 507
      //   498: fconst_0
      //   499: fstore #14
      //   501: fconst_0
      //   502: fstore #13
      //   504: goto -> 521
      //   507: fload #11
      //   509: fload #13
      //   511: fsub
      //   512: fstore #13
      //   514: fload #12
      //   516: fload #14
      //   518: fsub
      //   519: fstore #14
      //   521: iload_2
      //   522: iconst_0
      //   523: iadd
      //   524: istore #17
      //   526: aload #4
      //   528: iload #17
      //   530: faload
      //   531: fstore #6
      //   533: iload_2
      //   534: iconst_1
      //   535: iadd
      //   536: istore #16
      //   538: aload_0
      //   539: fload #13
      //   541: fload #14
      //   543: fload #6
      //   545: aload #4
      //   547: iload #16
      //   549: faload
      //   550: invokevirtual rQuadTo : (FFFF)V
      //   553: fload #11
      //   555: aload #4
      //   557: iload #17
      //   559: faload
      //   560: fadd
      //   561: fstore #6
      //   563: fload #12
      //   565: aload #4
      //   567: iload #16
      //   569: faload
      //   570: fadd
      //   571: fstore #7
      //   573: fload #14
      //   575: fload #12
      //   577: fadd
      //   578: fstore #14
      //   580: fload #13
      //   582: fload #11
      //   584: fadd
      //   585: fstore #13
      //   587: fload #7
      //   589: fstore #12
      //   591: fload #6
      //   593: fstore #11
      //   595: goto -> 464
      //   598: iload #17
      //   600: bipush #99
      //   602: if_icmpeq -> 638
      //   605: iload #17
      //   607: bipush #115
      //   609: if_icmpeq -> 638
      //   612: iload #17
      //   614: bipush #67
      //   616: if_icmpeq -> 638
      //   619: iload #17
      //   621: bipush #83
      //   623: if_icmpne -> 629
      //   626: goto -> 638
      //   629: fconst_0
      //   630: fstore #14
      //   632: fconst_0
      //   633: fstore #13
      //   635: goto -> 660
      //   638: fload #12
      //   640: fload #14
      //   642: fsub
      //   643: fstore #14
      //   645: fload #11
      //   647: fload #13
      //   649: fsub
      //   650: fstore #6
      //   652: fload #14
      //   654: fstore #13
      //   656: fload #6
      //   658: fstore #14
      //   660: iload_2
      //   661: iconst_0
      //   662: iadd
      //   663: istore #18
      //   665: aload #4
      //   667: iload #18
      //   669: faload
      //   670: fstore #6
      //   672: iload_2
      //   673: iconst_1
      //   674: iadd
      //   675: istore #19
      //   677: aload #4
      //   679: iload #19
      //   681: faload
      //   682: fstore #7
      //   684: iload_2
      //   685: iconst_2
      //   686: iadd
      //   687: istore #17
      //   689: aload #4
      //   691: iload #17
      //   693: faload
      //   694: fstore #5
      //   696: iload_2
      //   697: iconst_3
      //   698: iadd
      //   699: istore #16
      //   701: aload_0
      //   702: fload #14
      //   704: fload #13
      //   706: fload #6
      //   708: fload #7
      //   710: fload #5
      //   712: aload #4
      //   714: iload #16
      //   716: faload
      //   717: invokevirtual rCubicTo : (FFFFFF)V
      //   720: aload #4
      //   722: iload #18
      //   724: faload
      //   725: fload #11
      //   727: fadd
      //   728: fstore #7
      //   730: aload #4
      //   732: iload #19
      //   734: faload
      //   735: fload #12
      //   737: fadd
      //   738: fstore #13
      //   740: fload #11
      //   742: aload #4
      //   744: iload #17
      //   746: faload
      //   747: fadd
      //   748: fstore #14
      //   750: aload #4
      //   752: iload #16
      //   754: faload
      //   755: fstore #6
      //   757: fload #7
      //   759: fstore #11
      //   761: goto -> 1528
      //   764: iload_2
      //   765: iconst_0
      //   766: iadd
      //   767: istore #16
      //   769: fload #11
      //   771: aload #4
      //   773: iload #16
      //   775: faload
      //   776: fadd
      //   777: fstore #11
      //   779: iload_2
      //   780: iconst_1
      //   781: iadd
      //   782: istore #17
      //   784: fload #12
      //   786: aload #4
      //   788: iload #17
      //   790: faload
      //   791: fadd
      //   792: fstore #12
      //   794: iload_2
      //   795: ifle -> 815
      //   798: aload_0
      //   799: aload #4
      //   801: iload #16
      //   803: faload
      //   804: aload #4
      //   806: iload #17
      //   808: faload
      //   809: invokevirtual rLineTo : (FF)V
      //   812: goto -> 464
      //   815: aload_0
      //   816: aload #4
      //   818: iload #16
      //   820: faload
      //   821: aload #4
      //   823: iload #17
      //   825: faload
      //   826: invokevirtual rMoveTo : (FF)V
      //   829: goto -> 1202
      //   832: iload_2
      //   833: iconst_0
      //   834: iadd
      //   835: istore #17
      //   837: aload #4
      //   839: iload #17
      //   841: faload
      //   842: fstore #6
      //   844: iload_2
      //   845: iconst_1
      //   846: iadd
      //   847: istore #16
      //   849: aload_0
      //   850: fload #6
      //   852: aload #4
      //   854: iload #16
      //   856: faload
      //   857: invokevirtual rLineTo : (FF)V
      //   860: fload #11
      //   862: aload #4
      //   864: iload #17
      //   866: faload
      //   867: fadd
      //   868: fstore #11
      //   870: aload #4
      //   872: iload #16
      //   874: faload
      //   875: fstore #6
      //   877: fload #12
      //   879: fload #6
      //   881: fadd
      //   882: fstore #12
      //   884: goto -> 464
      //   887: iload #17
      //   889: bipush #113
      //   891: if_icmpeq -> 923
      //   894: iload #17
      //   896: bipush #116
      //   898: if_icmpeq -> 923
      //   901: iload #17
      //   903: bipush #81
      //   905: if_icmpeq -> 923
      //   908: fload #12
      //   910: fstore #7
      //   912: fload #11
      //   914: fstore #6
      //   916: iload #17
      //   918: bipush #84
      //   920: if_icmpne -> 941
      //   923: fload #11
      //   925: fconst_2
      //   926: fmul
      //   927: fload #13
      //   929: fsub
      //   930: fstore #6
      //   932: fload #12
      //   934: fconst_2
      //   935: fmul
      //   936: fload #14
      //   938: fsub
      //   939: fstore #7
      //   941: iload_2
      //   942: iconst_0
      //   943: iadd
      //   944: istore #16
      //   946: aload #4
      //   948: iload #16
      //   950: faload
      //   951: fstore #11
      //   953: iload_2
      //   954: iconst_1
      //   955: iadd
      //   956: istore #17
      //   958: aload_0
      //   959: fload #6
      //   961: fload #7
      //   963: fload #11
      //   965: aload #4
      //   967: iload #17
      //   969: faload
      //   970: invokevirtual quadTo : (FFFF)V
      //   973: aload #4
      //   975: iload #16
      //   977: faload
      //   978: fstore #11
      //   980: aload #4
      //   982: iload #17
      //   984: faload
      //   985: fstore #12
      //   987: fload #7
      //   989: fstore #14
      //   991: fload #6
      //   993: fstore #13
      //   995: goto -> 2073
      //   998: iload #17
      //   1000: bipush #99
      //   1002: if_icmpeq -> 1034
      //   1005: iload #17
      //   1007: bipush #115
      //   1009: if_icmpeq -> 1034
      //   1012: iload #17
      //   1014: bipush #67
      //   1016: if_icmpeq -> 1034
      //   1019: fload #12
      //   1021: fstore #7
      //   1023: fload #11
      //   1025: fstore #6
      //   1027: iload #17
      //   1029: bipush #83
      //   1031: if_icmpne -> 1052
      //   1034: fload #11
      //   1036: fconst_2
      //   1037: fmul
      //   1038: fload #13
      //   1040: fsub
      //   1041: fstore #6
      //   1043: fload #12
      //   1045: fconst_2
      //   1046: fmul
      //   1047: fload #14
      //   1049: fsub
      //   1050: fstore #7
      //   1052: iload_2
      //   1053: iconst_0
      //   1054: iadd
      //   1055: istore #17
      //   1057: aload #4
      //   1059: iload #17
      //   1061: faload
      //   1062: fstore #13
      //   1064: iload_2
      //   1065: iconst_1
      //   1066: iadd
      //   1067: istore #18
      //   1069: aload #4
      //   1071: iload #18
      //   1073: faload
      //   1074: fstore #11
      //   1076: iload_2
      //   1077: iconst_2
      //   1078: iadd
      //   1079: istore #16
      //   1081: aload #4
      //   1083: iload #16
      //   1085: faload
      //   1086: fstore #12
      //   1088: iload_2
      //   1089: iconst_3
      //   1090: iadd
      //   1091: istore #19
      //   1093: aload_0
      //   1094: fload #6
      //   1096: fload #7
      //   1098: fload #13
      //   1100: fload #11
      //   1102: fload #12
      //   1104: aload #4
      //   1106: iload #19
      //   1108: faload
      //   1109: invokevirtual cubicTo : (FFFFFF)V
      //   1112: aload #4
      //   1114: iload #17
      //   1116: faload
      //   1117: fstore #11
      //   1119: aload #4
      //   1121: iload #18
      //   1123: faload
      //   1124: fstore #13
      //   1126: aload #4
      //   1128: iload #16
      //   1130: faload
      //   1131: fstore #6
      //   1133: aload #4
      //   1135: iload #19
      //   1137: faload
      //   1138: fstore #12
      //   1140: goto -> 1539
      //   1143: iload_2
      //   1144: iconst_0
      //   1145: iadd
      //   1146: istore #16
      //   1148: aload #4
      //   1150: iload #16
      //   1152: faload
      //   1153: fstore #11
      //   1155: iload_2
      //   1156: iconst_1
      //   1157: iadd
      //   1158: istore #17
      //   1160: aload #4
      //   1162: iload #17
      //   1164: faload
      //   1165: fstore #12
      //   1167: iload_2
      //   1168: ifle -> 1188
      //   1171: aload_0
      //   1172: aload #4
      //   1174: iload #16
      //   1176: faload
      //   1177: aload #4
      //   1179: iload #17
      //   1181: faload
      //   1182: invokevirtual lineTo : (FF)V
      //   1185: goto -> 464
      //   1188: aload_0
      //   1189: aload #4
      //   1191: iload #16
      //   1193: faload
      //   1194: aload #4
      //   1196: iload #17
      //   1198: faload
      //   1199: invokevirtual moveTo : (FF)V
      //   1202: fload #12
      //   1204: fstore #10
      //   1206: fload #11
      //   1208: fstore #9
      //   1210: goto -> 464
      //   1213: iload_2
      //   1214: iconst_0
      //   1215: iadd
      //   1216: istore #16
      //   1218: aload #4
      //   1220: iload #16
      //   1222: faload
      //   1223: fstore #11
      //   1225: iload_2
      //   1226: iconst_1
      //   1227: iadd
      //   1228: istore #17
      //   1230: aload_0
      //   1231: fload #11
      //   1233: aload #4
      //   1235: iload #17
      //   1237: faload
      //   1238: invokevirtual lineTo : (FF)V
      //   1241: aload #4
      //   1243: iload #16
      //   1245: faload
      //   1246: fstore #11
      //   1248: aload #4
      //   1250: iload #17
      //   1252: faload
      //   1253: fstore #12
      //   1255: goto -> 464
      //   1258: iload_2
      //   1259: iconst_0
      //   1260: iadd
      //   1261: istore #17
      //   1263: aload_0
      //   1264: fconst_0
      //   1265: aload #4
      //   1267: iload #17
      //   1269: faload
      //   1270: invokevirtual rLineTo : (FF)V
      //   1273: aload #4
      //   1275: iload #17
      //   1277: faload
      //   1278: fstore #6
      //   1280: goto -> 877
      //   1283: iload_2
      //   1284: iconst_0
      //   1285: iadd
      //   1286: istore #17
      //   1288: aload #4
      //   1290: iload #17
      //   1292: faload
      //   1293: fstore #13
      //   1295: iload_2
      //   1296: iconst_1
      //   1297: iadd
      //   1298: istore #19
      //   1300: aload #4
      //   1302: iload #19
      //   1304: faload
      //   1305: fstore #6
      //   1307: iload_2
      //   1308: iconst_2
      //   1309: iadd
      //   1310: istore #18
      //   1312: aload #4
      //   1314: iload #18
      //   1316: faload
      //   1317: fstore #14
      //   1319: iload_2
      //   1320: iconst_3
      //   1321: iadd
      //   1322: istore #16
      //   1324: aload_0
      //   1325: fload #13
      //   1327: fload #6
      //   1329: fload #14
      //   1331: aload #4
      //   1333: iload #16
      //   1335: faload
      //   1336: invokevirtual rQuadTo : (FFFF)V
      //   1339: aload #4
      //   1341: iload #17
      //   1343: faload
      //   1344: fload #11
      //   1346: fadd
      //   1347: fstore #7
      //   1349: aload #4
      //   1351: iload #19
      //   1353: faload
      //   1354: fload #12
      //   1356: fadd
      //   1357: fstore #13
      //   1359: fload #11
      //   1361: aload #4
      //   1363: iload #18
      //   1365: faload
      //   1366: fadd
      //   1367: fstore #14
      //   1369: aload #4
      //   1371: iload #16
      //   1373: faload
      //   1374: fstore #6
      //   1376: fload #7
      //   1378: fstore #11
      //   1380: goto -> 1528
      //   1383: iload_2
      //   1384: iconst_0
      //   1385: iadd
      //   1386: istore #17
      //   1388: aload_0
      //   1389: aload #4
      //   1391: iload #17
      //   1393: faload
      //   1394: fconst_0
      //   1395: invokevirtual rLineTo : (FF)V
      //   1398: fload #11
      //   1400: aload #4
      //   1402: iload #17
      //   1404: faload
      //   1405: fadd
      //   1406: fstore #11
      //   1408: goto -> 464
      //   1411: aload #4
      //   1413: iload_2
      //   1414: iconst_0
      //   1415: iadd
      //   1416: faload
      //   1417: fstore #13
      //   1419: aload #4
      //   1421: iload_2
      //   1422: iconst_1
      //   1423: iadd
      //   1424: faload
      //   1425: fstore #7
      //   1427: iload_2
      //   1428: iconst_2
      //   1429: iadd
      //   1430: istore #19
      //   1432: aload #4
      //   1434: iload #19
      //   1436: faload
      //   1437: fstore #14
      //   1439: iload_2
      //   1440: iconst_3
      //   1441: iadd
      //   1442: istore #17
      //   1444: aload #4
      //   1446: iload #17
      //   1448: faload
      //   1449: fstore #6
      //   1451: iload_2
      //   1452: iconst_4
      //   1453: iadd
      //   1454: istore #18
      //   1456: aload #4
      //   1458: iload #18
      //   1460: faload
      //   1461: fstore #5
      //   1463: iload_2
      //   1464: iconst_5
      //   1465: iadd
      //   1466: istore #16
      //   1468: aload_0
      //   1469: fload #13
      //   1471: fload #7
      //   1473: fload #14
      //   1475: fload #6
      //   1477: fload #5
      //   1479: aload #4
      //   1481: iload #16
      //   1483: faload
      //   1484: invokevirtual rCubicTo : (FFFFFF)V
      //   1487: aload #4
      //   1489: iload #19
      //   1491: faload
      //   1492: fload #11
      //   1494: fadd
      //   1495: fstore #7
      //   1497: aload #4
      //   1499: iload #17
      //   1501: faload
      //   1502: fload #12
      //   1504: fadd
      //   1505: fstore #13
      //   1507: fload #11
      //   1509: aload #4
      //   1511: iload #18
      //   1513: faload
      //   1514: fadd
      //   1515: fstore #14
      //   1517: aload #4
      //   1519: iload #16
      //   1521: faload
      //   1522: fstore #6
      //   1524: fload #7
      //   1526: fstore #11
      //   1528: fload #12
      //   1530: fload #6
      //   1532: fadd
      //   1533: fstore #12
      //   1535: fload #14
      //   1537: fstore #6
      //   1539: fload #13
      //   1541: fstore #14
      //   1543: fload #11
      //   1545: fstore #13
      //   1547: fload #6
      //   1549: fstore #11
      //   1551: goto -> 464
      //   1554: iload_2
      //   1555: iconst_5
      //   1556: iadd
      //   1557: istore #17
      //   1559: aload #4
      //   1561: iload #17
      //   1563: faload
      //   1564: fstore #7
      //   1566: iload_2
      //   1567: bipush #6
      //   1569: iadd
      //   1570: istore #16
      //   1572: aload #4
      //   1574: iload #16
      //   1576: faload
      //   1577: fstore #6
      //   1579: aload #4
      //   1581: iload_2
      //   1582: iconst_0
      //   1583: iadd
      //   1584: faload
      //   1585: fstore #5
      //   1587: aload #4
      //   1589: iload_2
      //   1590: iconst_1
      //   1591: iadd
      //   1592: faload
      //   1593: fstore #13
      //   1595: aload #4
      //   1597: iload_2
      //   1598: iconst_2
      //   1599: iadd
      //   1600: faload
      //   1601: fstore #14
      //   1603: aload #4
      //   1605: iload_2
      //   1606: iconst_3
      //   1607: iadd
      //   1608: faload
      //   1609: fconst_0
      //   1610: fcmpl
      //   1611: ifeq -> 1620
      //   1614: iconst_1
      //   1615: istore #20
      //   1617: goto -> 1623
      //   1620: iconst_0
      //   1621: istore #20
      //   1623: aload #4
      //   1625: iload_2
      //   1626: iconst_4
      //   1627: iadd
      //   1628: faload
      //   1629: fconst_0
      //   1630: fcmpl
      //   1631: ifeq -> 1640
      //   1634: iconst_1
      //   1635: istore #21
      //   1637: goto -> 1643
      //   1640: iconst_0
      //   1641: istore #21
      //   1643: aload_0
      //   1644: fload #11
      //   1646: fload #12
      //   1648: fload #7
      //   1650: fload #11
      //   1652: fadd
      //   1653: fload #6
      //   1655: fload #12
      //   1657: fadd
      //   1658: fload #5
      //   1660: fload #13
      //   1662: fload #14
      //   1664: iload #20
      //   1666: iload #21
      //   1668: invokestatic drawArc : (Landroid/graphics/Path;FFFFFFFZZ)V
      //   1671: fload #11
      //   1673: aload #4
      //   1675: iload #17
      //   1677: faload
      //   1678: fadd
      //   1679: fstore #11
      //   1681: fload #12
      //   1683: aload #4
      //   1685: iload #16
      //   1687: faload
      //   1688: fadd
      //   1689: fstore #12
      //   1691: goto -> 2065
      //   1694: iload_2
      //   1695: iconst_0
      //   1696: iadd
      //   1697: istore #17
      //   1699: aload_0
      //   1700: fload #11
      //   1702: aload #4
      //   1704: iload #17
      //   1706: faload
      //   1707: invokevirtual lineTo : (FF)V
      //   1710: aload #4
      //   1712: iload #17
      //   1714: faload
      //   1715: fstore #12
      //   1717: goto -> 2073
      //   1720: iload_2
      //   1721: iconst_0
      //   1722: iadd
      //   1723: istore #18
      //   1725: aload #4
      //   1727: iload #18
      //   1729: faload
      //   1730: fstore #11
      //   1732: iload_2
      //   1733: iconst_1
      //   1734: iadd
      //   1735: istore #17
      //   1737: aload #4
      //   1739: iload #17
      //   1741: faload
      //   1742: fstore #12
      //   1744: iload_2
      //   1745: iconst_2
      //   1746: iadd
      //   1747: istore #16
      //   1749: aload #4
      //   1751: iload #16
      //   1753: faload
      //   1754: fstore #13
      //   1756: iload_2
      //   1757: iconst_3
      //   1758: iadd
      //   1759: istore #19
      //   1761: aload_0
      //   1762: fload #11
      //   1764: fload #12
      //   1766: fload #13
      //   1768: aload #4
      //   1770: iload #19
      //   1772: faload
      //   1773: invokevirtual quadTo : (FFFF)V
      //   1776: aload #4
      //   1778: iload #18
      //   1780: faload
      //   1781: fstore #13
      //   1783: aload #4
      //   1785: iload #17
      //   1787: faload
      //   1788: fstore #14
      //   1790: aload #4
      //   1792: iload #16
      //   1794: faload
      //   1795: fstore #11
      //   1797: aload #4
      //   1799: iload #19
      //   1801: faload
      //   1802: fstore #12
      //   1804: goto -> 2073
      //   1807: iload_2
      //   1808: iconst_0
      //   1809: iadd
      //   1810: istore #17
      //   1812: aload_0
      //   1813: aload #4
      //   1815: iload #17
      //   1817: faload
      //   1818: fload #12
      //   1820: invokevirtual lineTo : (FF)V
      //   1823: aload #4
      //   1825: iload #17
      //   1827: faload
      //   1828: fstore #11
      //   1830: goto -> 2073
      //   1833: aload #4
      //   1835: iload_2
      //   1836: iconst_0
      //   1837: iadd
      //   1838: faload
      //   1839: fstore #13
      //   1841: aload #4
      //   1843: iload_2
      //   1844: iconst_1
      //   1845: iadd
      //   1846: faload
      //   1847: fstore #11
      //   1849: iload_2
      //   1850: iconst_2
      //   1851: iadd
      //   1852: istore #17
      //   1854: aload #4
      //   1856: iload #17
      //   1858: faload
      //   1859: fstore #14
      //   1861: iload_2
      //   1862: iconst_3
      //   1863: iadd
      //   1864: istore #18
      //   1866: aload #4
      //   1868: iload #18
      //   1870: faload
      //   1871: fstore #6
      //   1873: iload_2
      //   1874: iconst_4
      //   1875: iadd
      //   1876: istore #19
      //   1878: aload #4
      //   1880: iload #19
      //   1882: faload
      //   1883: fstore #12
      //   1885: iload_2
      //   1886: iconst_5
      //   1887: iadd
      //   1888: istore #16
      //   1890: aload_0
      //   1891: fload #13
      //   1893: fload #11
      //   1895: fload #14
      //   1897: fload #6
      //   1899: fload #12
      //   1901: aload #4
      //   1903: iload #16
      //   1905: faload
      //   1906: invokevirtual cubicTo : (FFFFFF)V
      //   1909: aload #4
      //   1911: iload #19
      //   1913: faload
      //   1914: fstore #11
      //   1916: aload #4
      //   1918: iload #16
      //   1920: faload
      //   1921: fstore #12
      //   1923: aload #4
      //   1925: iload #17
      //   1927: faload
      //   1928: fstore #13
      //   1930: aload #4
      //   1932: iload #18
      //   1934: faload
      //   1935: fstore #14
      //   1937: goto -> 2073
      //   1940: iload_2
      //   1941: iconst_5
      //   1942: iadd
      //   1943: istore #17
      //   1945: aload #4
      //   1947: iload #17
      //   1949: faload
      //   1950: fstore #14
      //   1952: iload_2
      //   1953: bipush #6
      //   1955: iadd
      //   1956: istore #16
      //   1958: aload #4
      //   1960: iload #16
      //   1962: faload
      //   1963: fstore #5
      //   1965: aload #4
      //   1967: iload_2
      //   1968: iconst_0
      //   1969: iadd
      //   1970: faload
      //   1971: fstore #7
      //   1973: aload #4
      //   1975: iload_2
      //   1976: iconst_1
      //   1977: iadd
      //   1978: faload
      //   1979: fstore #6
      //   1981: aload #4
      //   1983: iload_2
      //   1984: iconst_2
      //   1985: iadd
      //   1986: faload
      //   1987: fstore #13
      //   1989: aload #4
      //   1991: iload_2
      //   1992: iconst_3
      //   1993: iadd
      //   1994: faload
      //   1995: fconst_0
      //   1996: fcmpl
      //   1997: ifeq -> 2006
      //   2000: iconst_1
      //   2001: istore #20
      //   2003: goto -> 2009
      //   2006: iconst_0
      //   2007: istore #20
      //   2009: aload #4
      //   2011: iload_2
      //   2012: iconst_4
      //   2013: iadd
      //   2014: faload
      //   2015: fconst_0
      //   2016: fcmpl
      //   2017: ifeq -> 2026
      //   2020: iconst_1
      //   2021: istore #21
      //   2023: goto -> 2029
      //   2026: iconst_0
      //   2027: istore #21
      //   2029: aload_0
      //   2030: fload #11
      //   2032: fload #12
      //   2034: fload #14
      //   2036: fload #5
      //   2038: fload #7
      //   2040: fload #6
      //   2042: fload #13
      //   2044: iload #20
      //   2046: iload #21
      //   2048: invokestatic drawArc : (Landroid/graphics/Path;FFFFFFFZZ)V
      //   2051: aload #4
      //   2053: iload #17
      //   2055: faload
      //   2056: fstore #11
      //   2058: aload #4
      //   2060: iload #16
      //   2062: faload
      //   2063: fstore #12
      //   2065: fload #12
      //   2067: fstore #14
      //   2069: fload #11
      //   2071: fstore #13
      //   2073: iload_2
      //   2074: iload #15
      //   2076: iadd
      //   2077: istore_2
      //   2078: iload_3
      //   2079: istore #17
      //   2081: goto -> 349
      //   2084: aload_1
      //   2085: iconst_0
      //   2086: fload #11
      //   2088: fastore
      //   2089: aload_1
      //   2090: iconst_1
      //   2091: fload #12
      //   2093: fastore
      //   2094: aload_1
      //   2095: iconst_2
      //   2096: fload #13
      //   2098: fastore
      //   2099: aload_1
      //   2100: iconst_3
      //   2101: fload #14
      //   2103: fastore
      //   2104: aload_1
      //   2105: iconst_4
      //   2106: fload #9
      //   2108: fastore
      //   2109: aload_1
      //   2110: iconst_5
      //   2111: fload #10
      //   2113: fastore
      //   2114: return
    }
    
    private static void arcToBezier(Path param1Path, double param1Double1, double param1Double2, double param1Double3, double param1Double4, double param1Double5, double param1Double6, double param1Double7, double param1Double8, double param1Double9) {
      int i = (int)Math.ceil(Math.abs(param1Double9 * 4.0D / Math.PI));
      double d1 = Math.cos(param1Double7);
      double d2 = Math.sin(param1Double7);
      double d3 = Math.cos(param1Double8);
      double d4 = Math.sin(param1Double8);
      param1Double7 = -param1Double3;
      double d5 = param1Double7 * d1;
      double d6 = param1Double4 * d2;
      param1Double7 *= d2;
      double d7 = param1Double4 * d1;
      double d8 = param1Double9 / i;
      param1Double4 = param1Double6;
      param1Double6 = d4 * param1Double7 + d3 * d7;
      param1Double9 = d5 * d4 - d6 * d3;
      byte b = 0;
      d4 = param1Double8;
      param1Double8 = param1Double4;
      param1Double4 = param1Double7;
      param1Double7 = d8;
      while (b < i) {
        double d9 = d4 + param1Double7;
        double d10 = Math.sin(d9);
        double d11 = Math.cos(d9);
        d8 = param1Double1 + param1Double3 * d1 * d11 - d6 * d10;
        double d12 = param1Double2 + param1Double3 * d2 * d11 + d7 * d10;
        d3 = d5 * d10 - d6 * d11;
        d11 = d10 * param1Double4 + d11 * d7;
        d4 = d9 - d4;
        d10 = Math.tan(d4 / 2.0D);
        d4 = Math.sin(d4) * (Math.sqrt(d10 * 3.0D * d10 + 4.0D) - 1.0D) / 3.0D;
        param1Path.rLineTo(0.0F, 0.0F);
        param1Path.cubicTo((float)(param1Double5 + param1Double9 * d4), (float)(param1Double8 + param1Double6 * d4), (float)(d8 - d4 * d3), (float)(d12 - d4 * d11), (float)d8, (float)d12);
        b++;
        param1Double8 = d12;
        d4 = d9;
        param1Double6 = d11;
        param1Double9 = d3;
        param1Double5 = d8;
      } 
    }
    
    private static void drawArc(Path param1Path, float param1Float1, float param1Float2, float param1Float3, float param1Float4, float param1Float5, float param1Float6, float param1Float7, boolean param1Boolean1, boolean param1Boolean2) {
      double d1 = Math.toRadians(param1Float7);
      double d2 = Math.cos(d1);
      double d3 = Math.sin(d1);
      double d4 = param1Float1;
      double d5 = param1Float2;
      double d6 = param1Float5;
      double d7 = (d4 * d2 + d5 * d3) / d6;
      double d8 = -param1Float1;
      double d9 = param1Float6;
      double d10 = (d8 * d3 + d5 * d2) / d9;
      double d11 = param1Float3;
      d8 = param1Float4;
      double d12 = (d11 * d2 + d8 * d3) / d6;
      double d13 = (-param1Float3 * d3 + d8 * d2) / d9;
      double d14 = d7 - d12;
      double d15 = d10 - d13;
      d11 = (d7 + d12) / 2.0D;
      d8 = (d10 + d13) / 2.0D;
      double d16 = d14 * d14 + d15 * d15;
      if (d16 == 0.0D) {
        Log.w("PathParser", " Points are coincident");
        return;
      } 
      double d17 = 1.0D / d16 - 0.25D;
      if (d17 < 0.0D) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Points are too far apart ");
        stringBuilder.append(d16);
        Log.w("PathParser", stringBuilder.toString());
        float f = (float)(Math.sqrt(d16) / 1.99999D);
        drawArc(param1Path, param1Float1, param1Float2, param1Float3, param1Float4, param1Float5 * f, param1Float6 * f, param1Float7, param1Boolean1, param1Boolean2);
        return;
      } 
      d16 = Math.sqrt(d17);
      d14 *= d16;
      d15 = d16 * d15;
      if (param1Boolean1 == param1Boolean2) {
        d11 -= d15;
        d8 += d14;
      } else {
        d11 += d15;
        d8 -= d14;
      } 
      d14 = Math.atan2(d10 - d8, d7 - d11);
      d10 = Math.atan2(d13 - d8, d12 - d11) - d14;
      int i = d10 cmp 0.0D;
      if (i >= 0) {
        param1Boolean1 = true;
      } else {
        param1Boolean1 = false;
      } 
      d7 = d10;
      if (param1Boolean2 != param1Boolean1)
        if (i > 0) {
          d7 = d10 - 6.283185307179586D;
        } else {
          d7 = d10 + 6.283185307179586D;
        }  
      d11 *= d6;
      d8 *= d9;
      arcToBezier(param1Path, d11 * d2 - d8 * d3, d11 * d3 + d8 * d2, d6, d9, d4, d5, d1, d14, d7);
    }
    
    public static void nodesToPath(PathDataNode[] param1ArrayOfPathDataNode, Path param1Path) {
      float[] arrayOfFloat = new float[6];
      char c = 'm';
      for (byte b = 0; b < param1ArrayOfPathDataNode.length; b++) {
        addCommand(param1Path, arrayOfFloat, c, (param1ArrayOfPathDataNode[b]).mType, (param1ArrayOfPathDataNode[b]).mParams);
        c = (param1ArrayOfPathDataNode[b]).mType;
      } 
    }
    
    public void interpolatePathDataNode(PathDataNode param1PathDataNode1, PathDataNode param1PathDataNode2, float param1Float) {
      this.mType = param1PathDataNode1.mType;
      byte b = 0;
      while (true) {
        float[] arrayOfFloat = param1PathDataNode1.mParams;
        if (b < arrayOfFloat.length) {
          this.mParams[b] = arrayOfFloat[b] * (1.0F - param1Float) + param1PathDataNode2.mParams[b] * param1Float;
          b++;
          continue;
        } 
        break;
      } 
    }
  }
}


/* Location:              /home/brandon/levelMeter_APK/dex2jar-2.x/dex-tools/build/distributions/dex-tools-2.2-SNAPSHOT/classes-dex2jar.jar!/androidx/core/graphics/PathParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */