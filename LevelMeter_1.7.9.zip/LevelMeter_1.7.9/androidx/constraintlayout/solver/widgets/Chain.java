package androidx.constraintlayout.solver.widgets;

import androidx.constraintlayout.solver.LinearSystem;

class Chain {
  private static final boolean DEBUG = false;
  
  static void applyChainConstraints(ConstraintWidgetContainer paramConstraintWidgetContainer, LinearSystem paramLinearSystem, int paramInt) {
    int i;
    ChainHead[] arrayOfChainHead;
    byte b2;
    byte b1 = 0;
    if (paramInt == 0) {
      i = paramConstraintWidgetContainer.mHorizontalChainsSize;
      arrayOfChainHead = paramConstraintWidgetContainer.mHorizontalChainsArray;
      b2 = 0;
    } else {
      b2 = 2;
      i = paramConstraintWidgetContainer.mVerticalChainsSize;
      arrayOfChainHead = paramConstraintWidgetContainer.mVerticalChainsArray;
    } 
    while (b1 < i) {
      ChainHead chainHead = arrayOfChainHead[b1];
      chainHead.define();
      if (paramConstraintWidgetContainer.optimizeFor(4)) {
        if (!Optimizer.applyChainOptimized(paramConstraintWidgetContainer, paramLinearSystem, paramInt, b2, chainHead))
          applyChainConstraints(paramConstraintWidgetContainer, paramLinearSystem, paramInt, b2, chainHead); 
      } else {
        applyChainConstraints(paramConstraintWidgetContainer, paramLinearSystem, paramInt, b2, chainHead);
      } 
      b1++;
    } 
  }
  
  static void applyChainConstraints(ConstraintWidgetContainer paramConstraintWidgetContainer, LinearSystem paramLinearSystem, int paramInt1, int paramInt2, ChainHead paramChainHead) {
    // Byte code:
    //   0: aload #4
    //   2: getfield mFirst : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   5: astore #5
    //   7: aload #4
    //   9: getfield mLast : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   12: astore #6
    //   14: aload #4
    //   16: getfield mFirstVisibleWidget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   19: astore #7
    //   21: aload #4
    //   23: getfield mLastVisibleWidget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   26: astore #8
    //   28: aload #4
    //   30: getfield mHead : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   33: astore #9
    //   35: aload #4
    //   37: getfield mTotalWeight : F
    //   40: fstore #10
    //   42: aload #4
    //   44: getfield mFirstMatchConstraintWidget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   47: astore #11
    //   49: aload #4
    //   51: getfield mLastMatchConstraintWidget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   54: astore #11
    //   56: aload_0
    //   57: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   60: iload_2
    //   61: aaload
    //   62: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   65: if_acmpne -> 74
    //   68: iconst_1
    //   69: istore #12
    //   71: goto -> 77
    //   74: iconst_0
    //   75: istore #12
    //   77: iload_2
    //   78: ifne -> 136
    //   81: aload #9
    //   83: getfield mHorizontalChainStyle : I
    //   86: ifne -> 95
    //   89: iconst_1
    //   90: istore #13
    //   92: goto -> 98
    //   95: iconst_0
    //   96: istore #13
    //   98: aload #9
    //   100: getfield mHorizontalChainStyle : I
    //   103: iconst_1
    //   104: if_icmpne -> 113
    //   107: iconst_1
    //   108: istore #14
    //   110: goto -> 116
    //   113: iconst_0
    //   114: istore #14
    //   116: iload #13
    //   118: istore #15
    //   120: iload #14
    //   122: istore #16
    //   124: aload #9
    //   126: getfield mHorizontalChainStyle : I
    //   129: iconst_2
    //   130: if_icmpne -> 202
    //   133: goto -> 188
    //   136: aload #9
    //   138: getfield mVerticalChainStyle : I
    //   141: ifne -> 150
    //   144: iconst_1
    //   145: istore #13
    //   147: goto -> 153
    //   150: iconst_0
    //   151: istore #13
    //   153: aload #9
    //   155: getfield mVerticalChainStyle : I
    //   158: iconst_1
    //   159: if_icmpne -> 168
    //   162: iconst_1
    //   163: istore #14
    //   165: goto -> 171
    //   168: iconst_0
    //   169: istore #14
    //   171: iload #13
    //   173: istore #15
    //   175: iload #14
    //   177: istore #16
    //   179: aload #9
    //   181: getfield mVerticalChainStyle : I
    //   184: iconst_2
    //   185: if_icmpne -> 202
    //   188: iconst_1
    //   189: istore #17
    //   191: iload #13
    //   193: istore #15
    //   195: iload #14
    //   197: istore #16
    //   199: goto -> 205
    //   202: iconst_0
    //   203: istore #17
    //   205: aload #5
    //   207: astore #18
    //   209: iconst_0
    //   210: istore #13
    //   212: aconst_null
    //   213: astore #19
    //   215: iload #13
    //   217: ifne -> 599
    //   220: aload #18
    //   222: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   225: iload_3
    //   226: aaload
    //   227: astore #11
    //   229: iload #12
    //   231: ifne -> 248
    //   234: iload #17
    //   236: ifeq -> 242
    //   239: goto -> 248
    //   242: iconst_4
    //   243: istore #14
    //   245: goto -> 251
    //   248: iconst_1
    //   249: istore #14
    //   251: aload #11
    //   253: invokevirtual getMargin : ()I
    //   256: istore #20
    //   258: iload #20
    //   260: istore #21
    //   262: aload #11
    //   264: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   267: ifnull -> 294
    //   270: iload #20
    //   272: istore #21
    //   274: aload #18
    //   276: aload #5
    //   278: if_acmpeq -> 294
    //   281: iload #20
    //   283: aload #11
    //   285: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   288: invokevirtual getMargin : ()I
    //   291: iadd
    //   292: istore #21
    //   294: iload #17
    //   296: ifeq -> 320
    //   299: aload #18
    //   301: aload #5
    //   303: if_acmpeq -> 320
    //   306: aload #18
    //   308: aload #7
    //   310: if_acmpeq -> 320
    //   313: bipush #6
    //   315: istore #14
    //   317: goto -> 336
    //   320: iload #15
    //   322: ifeq -> 336
    //   325: iload #12
    //   327: ifeq -> 336
    //   330: iconst_4
    //   331: istore #14
    //   333: goto -> 336
    //   336: aload #11
    //   338: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   341: ifnull -> 420
    //   344: aload #18
    //   346: aload #7
    //   348: if_acmpne -> 374
    //   351: aload_1
    //   352: aload #11
    //   354: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   357: aload #11
    //   359: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   362: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   365: iload #21
    //   367: iconst_5
    //   368: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   371: goto -> 395
    //   374: aload_1
    //   375: aload #11
    //   377: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   380: aload #11
    //   382: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   385: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   388: iload #21
    //   390: bipush #6
    //   392: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   395: aload_1
    //   396: aload #11
    //   398: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   401: aload #11
    //   403: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   406: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   409: iload #21
    //   411: iload #14
    //   413: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   416: pop
    //   417: goto -> 420
    //   420: iload #12
    //   422: ifeq -> 505
    //   425: aload #18
    //   427: invokevirtual getVisibility : ()I
    //   430: bipush #8
    //   432: if_icmpeq -> 479
    //   435: aload #18
    //   437: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   440: iload_2
    //   441: aaload
    //   442: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   445: if_acmpne -> 479
    //   448: aload_1
    //   449: aload #18
    //   451: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   454: iload_3
    //   455: iconst_1
    //   456: iadd
    //   457: aaload
    //   458: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   461: aload #18
    //   463: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   466: iload_3
    //   467: aaload
    //   468: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   471: iconst_0
    //   472: iconst_5
    //   473: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   476: goto -> 479
    //   479: aload_1
    //   480: aload #18
    //   482: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   485: iload_3
    //   486: aaload
    //   487: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   490: aload_0
    //   491: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   494: iload_3
    //   495: aaload
    //   496: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   499: iconst_0
    //   500: bipush #6
    //   502: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   505: aload #18
    //   507: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   510: iload_3
    //   511: iconst_1
    //   512: iadd
    //   513: aaload
    //   514: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   517: astore #22
    //   519: aload #19
    //   521: astore #11
    //   523: aload #22
    //   525: ifnull -> 581
    //   528: aload #22
    //   530: getfield mOwner : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   533: astore #22
    //   535: aload #19
    //   537: astore #11
    //   539: aload #22
    //   541: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   544: iload_3
    //   545: aaload
    //   546: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   549: ifnull -> 581
    //   552: aload #22
    //   554: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   557: iload_3
    //   558: aaload
    //   559: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   562: getfield mOwner : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   565: aload #18
    //   567: if_acmpeq -> 577
    //   570: aload #19
    //   572: astore #11
    //   574: goto -> 581
    //   577: aload #22
    //   579: astore #11
    //   581: aload #11
    //   583: ifnull -> 593
    //   586: aload #11
    //   588: astore #18
    //   590: goto -> 596
    //   593: iconst_1
    //   594: istore #13
    //   596: goto -> 212
    //   599: aload #8
    //   601: ifnull -> 670
    //   604: aload #6
    //   606: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   609: astore #11
    //   611: iload_3
    //   612: iconst_1
    //   613: iadd
    //   614: istore #13
    //   616: aload #11
    //   618: iload #13
    //   620: aaload
    //   621: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   624: ifnull -> 670
    //   627: aload #8
    //   629: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   632: iload #13
    //   634: aaload
    //   635: astore #11
    //   637: aload_1
    //   638: aload #11
    //   640: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   643: aload #6
    //   645: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   648: iload #13
    //   650: aaload
    //   651: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   654: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   657: aload #11
    //   659: invokevirtual getMargin : ()I
    //   662: ineg
    //   663: iconst_5
    //   664: invokevirtual addLowerThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   667: goto -> 670
    //   670: iload #12
    //   672: ifeq -> 720
    //   675: aload_0
    //   676: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   679: astore_0
    //   680: iload_3
    //   681: iconst_1
    //   682: iadd
    //   683: istore #13
    //   685: aload_1
    //   686: aload_0
    //   687: iload #13
    //   689: aaload
    //   690: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   693: aload #6
    //   695: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   698: iload #13
    //   700: aaload
    //   701: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   704: aload #6
    //   706: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   709: iload #13
    //   711: aaload
    //   712: invokevirtual getMargin : ()I
    //   715: bipush #6
    //   717: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   720: aload #4
    //   722: getfield mWeightedMatchConstraintsWidgets : Ljava/util/ArrayList;
    //   725: astore_0
    //   726: aload_0
    //   727: ifnull -> 1015
    //   730: aload_0
    //   731: invokevirtual size : ()I
    //   734: istore #14
    //   736: iload #14
    //   738: iconst_1
    //   739: if_icmple -> 1015
    //   742: aload #4
    //   744: getfield mHasUndefinedWeights : Z
    //   747: ifeq -> 769
    //   750: aload #4
    //   752: getfield mHasComplexMatchWeights : Z
    //   755: ifne -> 769
    //   758: aload #4
    //   760: getfield mWidgetsMatchCount : I
    //   763: i2f
    //   764: fstore #23
    //   766: goto -> 773
    //   769: fload #10
    //   771: fstore #23
    //   773: fconst_0
    //   774: fstore #24
    //   776: aconst_null
    //   777: astore #11
    //   779: iconst_0
    //   780: istore #13
    //   782: iload #13
    //   784: iload #14
    //   786: if_icmpge -> 1015
    //   789: aload_0
    //   790: iload #13
    //   792: invokevirtual get : (I)Ljava/lang/Object;
    //   795: checkcast androidx/constraintlayout/solver/widgets/ConstraintWidget
    //   798: astore #18
    //   800: aload #18
    //   802: getfield mWeight : [F
    //   805: iload_2
    //   806: faload
    //   807: fstore #10
    //   809: fload #10
    //   811: fconst_0
    //   812: fcmpg
    //   813: ifge -> 862
    //   816: aload #4
    //   818: getfield mHasComplexMatchWeights : Z
    //   821: ifeq -> 856
    //   824: aload_1
    //   825: aload #18
    //   827: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   830: iload_3
    //   831: iconst_1
    //   832: iadd
    //   833: aaload
    //   834: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   837: aload #18
    //   839: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   842: iload_3
    //   843: aaload
    //   844: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   847: iconst_0
    //   848: iconst_4
    //   849: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   852: pop
    //   853: goto -> 899
    //   856: fconst_1
    //   857: fstore #10
    //   859: goto -> 862
    //   862: fload #10
    //   864: fconst_0
    //   865: fcmpl
    //   866: ifne -> 902
    //   869: aload_1
    //   870: aload #18
    //   872: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   875: iload_3
    //   876: iconst_1
    //   877: iadd
    //   878: aaload
    //   879: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   882: aload #18
    //   884: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   887: iload_3
    //   888: aaload
    //   889: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   892: iconst_0
    //   893: bipush #6
    //   895: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   898: pop
    //   899: goto -> 1009
    //   902: aload #11
    //   904: ifnull -> 1001
    //   907: aload #11
    //   909: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   912: iload_3
    //   913: aaload
    //   914: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   917: astore #19
    //   919: aload #11
    //   921: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   924: astore #11
    //   926: iload_3
    //   927: iconst_1
    //   928: iadd
    //   929: istore #12
    //   931: aload #11
    //   933: iload #12
    //   935: aaload
    //   936: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   939: astore #22
    //   941: aload #18
    //   943: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   946: iload_3
    //   947: aaload
    //   948: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   951: astore #25
    //   953: aload #18
    //   955: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   958: iload #12
    //   960: aaload
    //   961: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   964: astore #11
    //   966: aload_1
    //   967: invokevirtual createRow : ()Landroidx/constraintlayout/solver/ArrayRow;
    //   970: astore #26
    //   972: aload #26
    //   974: fload #24
    //   976: fload #23
    //   978: fload #10
    //   980: aload #19
    //   982: aload #22
    //   984: aload #25
    //   986: aload #11
    //   988: invokevirtual createRowEqualMatchDimensions : (FFFLandroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;)Landroidx/constraintlayout/solver/ArrayRow;
    //   991: pop
    //   992: aload_1
    //   993: aload #26
    //   995: invokevirtual addConstraint : (Landroidx/constraintlayout/solver/ArrayRow;)V
    //   998: goto -> 1001
    //   1001: aload #18
    //   1003: astore #11
    //   1005: fload #10
    //   1007: fstore #24
    //   1009: iinc #13, 1
    //   1012: goto -> 782
    //   1015: aload #7
    //   1017: ifnull -> 1221
    //   1020: aload #7
    //   1022: aload #8
    //   1024: if_acmpeq -> 1032
    //   1027: iload #17
    //   1029: ifeq -> 1221
    //   1032: aload #5
    //   1034: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1037: iload_3
    //   1038: aaload
    //   1039: astore #18
    //   1041: aload #6
    //   1043: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1046: astore_0
    //   1047: iload_3
    //   1048: iconst_1
    //   1049: iadd
    //   1050: istore #13
    //   1052: aload_0
    //   1053: iload #13
    //   1055: aaload
    //   1056: astore #11
    //   1058: aload #5
    //   1060: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1063: iload_3
    //   1064: aaload
    //   1065: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1068: ifnull -> 1088
    //   1071: aload #5
    //   1073: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1076: iload_3
    //   1077: aaload
    //   1078: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1081: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1084: astore_0
    //   1085: goto -> 1090
    //   1088: aconst_null
    //   1089: astore_0
    //   1090: aload #6
    //   1092: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1095: iload #13
    //   1097: aaload
    //   1098: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1101: ifnull -> 1123
    //   1104: aload #6
    //   1106: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1109: iload #13
    //   1111: aaload
    //   1112: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1115: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1118: astore #4
    //   1120: goto -> 1126
    //   1123: aconst_null
    //   1124: astore #4
    //   1126: aload #7
    //   1128: aload #8
    //   1130: if_acmpne -> 1152
    //   1133: aload #7
    //   1135: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1138: iload_3
    //   1139: aaload
    //   1140: astore #18
    //   1142: aload #7
    //   1144: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1147: iload #13
    //   1149: aaload
    //   1150: astore #11
    //   1152: aload_0
    //   1153: ifnull -> 2308
    //   1156: aload #4
    //   1158: ifnull -> 2308
    //   1161: iload_2
    //   1162: ifne -> 1175
    //   1165: aload #9
    //   1167: getfield mHorizontalBiasPercent : F
    //   1170: fstore #10
    //   1172: goto -> 1182
    //   1175: aload #9
    //   1177: getfield mVerticalBiasPercent : F
    //   1180: fstore #10
    //   1182: aload #18
    //   1184: invokevirtual getMargin : ()I
    //   1187: istore_2
    //   1188: aload #11
    //   1190: invokevirtual getMargin : ()I
    //   1193: istore #13
    //   1195: aload_1
    //   1196: aload #18
    //   1198: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1201: aload_0
    //   1202: iload_2
    //   1203: fload #10
    //   1205: aload #4
    //   1207: aload #11
    //   1209: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1212: iload #13
    //   1214: iconst_5
    //   1215: invokevirtual addCentering : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;IFLandroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   1218: goto -> 2308
    //   1221: iload #15
    //   1223: ifeq -> 1721
    //   1226: aload #7
    //   1228: ifnull -> 1721
    //   1231: aload #4
    //   1233: getfield mWidgetsMatchCount : I
    //   1236: ifle -> 1258
    //   1239: aload #4
    //   1241: getfield mWidgetsCount : I
    //   1244: aload #4
    //   1246: getfield mWidgetsMatchCount : I
    //   1249: if_icmpne -> 1258
    //   1252: iconst_1
    //   1253: istore #12
    //   1255: goto -> 1261
    //   1258: iconst_0
    //   1259: istore #12
    //   1261: aload #7
    //   1263: astore #4
    //   1265: aload #4
    //   1267: astore #18
    //   1269: aload #4
    //   1271: ifnull -> 2308
    //   1274: aload #4
    //   1276: getfield mNextChainWidget : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1279: iload_2
    //   1280: aaload
    //   1281: astore #11
    //   1283: aload #11
    //   1285: ifnull -> 1310
    //   1288: aload #11
    //   1290: invokevirtual getVisibility : ()I
    //   1293: bipush #8
    //   1295: if_icmpne -> 1310
    //   1298: aload #11
    //   1300: getfield mNextChainWidget : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1303: iload_2
    //   1304: aaload
    //   1305: astore #11
    //   1307: goto -> 1283
    //   1310: aload #11
    //   1312: ifnonnull -> 1328
    //   1315: aload #4
    //   1317: aload #8
    //   1319: if_acmpne -> 1325
    //   1322: goto -> 1328
    //   1325: goto -> 1700
    //   1328: aload #4
    //   1330: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1333: iload_3
    //   1334: aaload
    //   1335: astore #19
    //   1337: aload #19
    //   1339: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1342: astore #26
    //   1344: aload #19
    //   1346: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1349: ifnull -> 1365
    //   1352: aload #19
    //   1354: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1357: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1360: astore #9
    //   1362: goto -> 1368
    //   1365: aconst_null
    //   1366: astore #9
    //   1368: aload #18
    //   1370: aload #4
    //   1372: if_acmpeq -> 1391
    //   1375: aload #18
    //   1377: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1380: iload_3
    //   1381: iconst_1
    //   1382: iadd
    //   1383: aaload
    //   1384: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1387: astore_0
    //   1388: goto -> 1443
    //   1391: aload #9
    //   1393: astore_0
    //   1394: aload #4
    //   1396: aload #7
    //   1398: if_acmpne -> 1443
    //   1401: aload #9
    //   1403: astore_0
    //   1404: aload #18
    //   1406: aload #4
    //   1408: if_acmpne -> 1443
    //   1411: aload #5
    //   1413: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1416: iload_3
    //   1417: aaload
    //   1418: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1421: ifnull -> 1441
    //   1424: aload #5
    //   1426: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1429: iload_3
    //   1430: aaload
    //   1431: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1434: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1437: astore_0
    //   1438: goto -> 1443
    //   1441: aconst_null
    //   1442: astore_0
    //   1443: aload #19
    //   1445: invokevirtual getMargin : ()I
    //   1448: istore #17
    //   1450: aload #4
    //   1452: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1455: astore #9
    //   1457: iload_3
    //   1458: iconst_1
    //   1459: iadd
    //   1460: istore #21
    //   1462: aload #9
    //   1464: iload #21
    //   1466: aaload
    //   1467: invokevirtual getMargin : ()I
    //   1470: istore #14
    //   1472: aload #11
    //   1474: ifnull -> 1509
    //   1477: aload #11
    //   1479: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1482: iload_3
    //   1483: aaload
    //   1484: astore #9
    //   1486: aload #9
    //   1488: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1491: astore #22
    //   1493: aload #4
    //   1495: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1498: iload #21
    //   1500: aaload
    //   1501: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1504: astore #19
    //   1506: goto -> 1561
    //   1509: aload #6
    //   1511: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1514: iload #21
    //   1516: aaload
    //   1517: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1520: astore #25
    //   1522: aload #25
    //   1524: ifnull -> 1537
    //   1527: aload #25
    //   1529: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1532: astore #9
    //   1534: goto -> 1540
    //   1537: aconst_null
    //   1538: astore #9
    //   1540: aload #4
    //   1542: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1545: iload #21
    //   1547: aaload
    //   1548: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1551: astore #19
    //   1553: aload #9
    //   1555: astore #22
    //   1557: aload #25
    //   1559: astore #9
    //   1561: iload #14
    //   1563: istore #13
    //   1565: aload #9
    //   1567: ifnull -> 1580
    //   1570: iload #14
    //   1572: aload #9
    //   1574: invokevirtual getMargin : ()I
    //   1577: iadd
    //   1578: istore #13
    //   1580: iload #17
    //   1582: istore #14
    //   1584: aload #18
    //   1586: ifnull -> 1605
    //   1589: iload #17
    //   1591: aload #18
    //   1593: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1596: iload #21
    //   1598: aaload
    //   1599: invokevirtual getMargin : ()I
    //   1602: iadd
    //   1603: istore #14
    //   1605: aload #26
    //   1607: ifnull -> 1325
    //   1610: aload_0
    //   1611: ifnull -> 1325
    //   1614: aload #22
    //   1616: ifnull -> 1325
    //   1619: aload #19
    //   1621: ifnull -> 1325
    //   1624: aload #4
    //   1626: aload #7
    //   1628: if_acmpne -> 1643
    //   1631: aload #7
    //   1633: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1636: iload_3
    //   1637: aaload
    //   1638: invokevirtual getMargin : ()I
    //   1641: istore #14
    //   1643: aload #4
    //   1645: aload #8
    //   1647: if_acmpne -> 1666
    //   1650: aload #8
    //   1652: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1655: iload #21
    //   1657: aaload
    //   1658: invokevirtual getMargin : ()I
    //   1661: istore #13
    //   1663: goto -> 1666
    //   1666: iload #12
    //   1668: ifeq -> 1678
    //   1671: bipush #6
    //   1673: istore #17
    //   1675: goto -> 1681
    //   1678: iconst_4
    //   1679: istore #17
    //   1681: aload_1
    //   1682: aload #26
    //   1684: aload_0
    //   1685: iload #14
    //   1687: ldc 0.5
    //   1689: aload #22
    //   1691: aload #19
    //   1693: iload #13
    //   1695: iload #17
    //   1697: invokevirtual addCentering : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;IFLandroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   1700: aload #4
    //   1702: invokevirtual getVisibility : ()I
    //   1705: bipush #8
    //   1707: if_icmpeq -> 1714
    //   1710: aload #4
    //   1712: astore #18
    //   1714: aload #11
    //   1716: astore #4
    //   1718: goto -> 1269
    //   1721: bipush #8
    //   1723: istore #13
    //   1725: iload #16
    //   1727: ifeq -> 2308
    //   1730: aload #7
    //   1732: ifnull -> 2308
    //   1735: aload #4
    //   1737: getfield mWidgetsMatchCount : I
    //   1740: ifle -> 1762
    //   1743: aload #4
    //   1745: getfield mWidgetsCount : I
    //   1748: aload #4
    //   1750: getfield mWidgetsMatchCount : I
    //   1753: if_icmpne -> 1762
    //   1756: iconst_1
    //   1757: istore #14
    //   1759: goto -> 1765
    //   1762: iconst_0
    //   1763: istore #14
    //   1765: aload #7
    //   1767: astore #4
    //   1769: aload #4
    //   1771: astore #11
    //   1773: aload #4
    //   1775: ifnull -> 2148
    //   1778: aload #4
    //   1780: getfield mNextChainWidget : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1783: iload_2
    //   1784: aaload
    //   1785: astore_0
    //   1786: aload_0
    //   1787: ifnull -> 1809
    //   1790: aload_0
    //   1791: invokevirtual getVisibility : ()I
    //   1794: iload #13
    //   1796: if_icmpne -> 1809
    //   1799: aload_0
    //   1800: getfield mNextChainWidget : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1803: iload_2
    //   1804: aaload
    //   1805: astore_0
    //   1806: goto -> 1786
    //   1809: aload #4
    //   1811: aload #7
    //   1813: if_acmpeq -> 2121
    //   1816: aload #4
    //   1818: aload #8
    //   1820: if_acmpeq -> 2121
    //   1823: aload_0
    //   1824: ifnull -> 2121
    //   1827: aload_0
    //   1828: aload #8
    //   1830: if_acmpne -> 1838
    //   1833: aconst_null
    //   1834: astore_0
    //   1835: goto -> 1838
    //   1838: aload #4
    //   1840: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1843: iload_3
    //   1844: aaload
    //   1845: astore #9
    //   1847: aload #9
    //   1849: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1852: astore #25
    //   1854: aload #9
    //   1856: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1859: ifnull -> 1872
    //   1862: aload #9
    //   1864: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1867: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1870: astore #18
    //   1872: aload #11
    //   1874: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1877: astore #18
    //   1879: iload_3
    //   1880: iconst_1
    //   1881: iadd
    //   1882: istore #21
    //   1884: aload #18
    //   1886: iload #21
    //   1888: aaload
    //   1889: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1892: astore #26
    //   1894: aload #9
    //   1896: invokevirtual getMargin : ()I
    //   1899: istore #17
    //   1901: aload #4
    //   1903: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1906: iload #21
    //   1908: aaload
    //   1909: invokevirtual getMargin : ()I
    //   1912: istore #12
    //   1914: aload_0
    //   1915: ifnull -> 1960
    //   1918: aload_0
    //   1919: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1922: iload_3
    //   1923: aaload
    //   1924: astore #18
    //   1926: aload #18
    //   1928: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1931: astore #19
    //   1933: aload #18
    //   1935: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1938: ifnull -> 1954
    //   1941: aload #18
    //   1943: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1946: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1949: astore #9
    //   1951: goto -> 2012
    //   1954: aconst_null
    //   1955: astore #9
    //   1957: goto -> 2012
    //   1960: aload #4
    //   1962: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1965: iload #21
    //   1967: aaload
    //   1968: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1971: astore #22
    //   1973: aload #22
    //   1975: ifnull -> 1988
    //   1978: aload #22
    //   1980: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1983: astore #18
    //   1985: goto -> 1991
    //   1988: aconst_null
    //   1989: astore #18
    //   1991: aload #4
    //   1993: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1996: iload #21
    //   1998: aaload
    //   1999: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2002: astore #9
    //   2004: aload #18
    //   2006: astore #19
    //   2008: aload #22
    //   2010: astore #18
    //   2012: iload #12
    //   2014: istore #13
    //   2016: aload #18
    //   2018: ifnull -> 2031
    //   2021: iload #12
    //   2023: aload #18
    //   2025: invokevirtual getMargin : ()I
    //   2028: iadd
    //   2029: istore #13
    //   2031: iload #17
    //   2033: istore #12
    //   2035: aload #11
    //   2037: ifnull -> 2056
    //   2040: iload #17
    //   2042: aload #11
    //   2044: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2047: iload #21
    //   2049: aaload
    //   2050: invokevirtual getMargin : ()I
    //   2053: iadd
    //   2054: istore #12
    //   2056: iload #14
    //   2058: ifeq -> 2068
    //   2061: bipush #6
    //   2063: istore #17
    //   2065: goto -> 2071
    //   2068: iconst_4
    //   2069: istore #17
    //   2071: aload #25
    //   2073: ifnull -> 2114
    //   2076: aload #26
    //   2078: ifnull -> 2114
    //   2081: aload #19
    //   2083: ifnull -> 2114
    //   2086: aload #9
    //   2088: ifnull -> 2114
    //   2091: aload_1
    //   2092: aload #25
    //   2094: aload #26
    //   2096: iload #12
    //   2098: ldc 0.5
    //   2100: aload #19
    //   2102: aload #9
    //   2104: iload #13
    //   2106: iload #17
    //   2108: invokevirtual addCentering : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;IFLandroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   2111: goto -> 2114
    //   2114: bipush #8
    //   2116: istore #13
    //   2118: goto -> 2121
    //   2121: aload #4
    //   2123: invokevirtual getVisibility : ()I
    //   2126: iload #13
    //   2128: if_icmpeq -> 2134
    //   2131: goto -> 2138
    //   2134: aload #11
    //   2136: astore #4
    //   2138: aload #4
    //   2140: astore #11
    //   2142: aload_0
    //   2143: astore #4
    //   2145: goto -> 1773
    //   2148: aload #7
    //   2150: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2153: iload_3
    //   2154: aaload
    //   2155: astore_0
    //   2156: aload #5
    //   2158: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2161: iload_3
    //   2162: aaload
    //   2163: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2166: astore #4
    //   2168: aload #8
    //   2170: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2173: astore #11
    //   2175: iload_3
    //   2176: iconst_1
    //   2177: iadd
    //   2178: istore_2
    //   2179: aload #11
    //   2181: iload_2
    //   2182: aaload
    //   2183: astore #11
    //   2185: aload #6
    //   2187: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2190: iload_2
    //   2191: aaload
    //   2192: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2195: astore #9
    //   2197: aload #4
    //   2199: ifnull -> 2274
    //   2202: aload #7
    //   2204: aload #8
    //   2206: if_acmpeq -> 2231
    //   2209: aload_1
    //   2210: aload_0
    //   2211: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2214: aload #4
    //   2216: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2219: aload_0
    //   2220: invokevirtual getMargin : ()I
    //   2223: iconst_5
    //   2224: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   2227: pop
    //   2228: goto -> 2274
    //   2231: aload #9
    //   2233: ifnull -> 2274
    //   2236: aload_1
    //   2237: aload_0
    //   2238: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2241: aload #4
    //   2243: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2246: aload_0
    //   2247: invokevirtual getMargin : ()I
    //   2250: ldc 0.5
    //   2252: aload #11
    //   2254: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2257: aload #9
    //   2259: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2262: aload #11
    //   2264: invokevirtual getMargin : ()I
    //   2267: iconst_5
    //   2268: invokevirtual addCentering : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;IFLandroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   2271: goto -> 2274
    //   2274: aload #9
    //   2276: ifnull -> 2308
    //   2279: aload #7
    //   2281: aload #8
    //   2283: if_acmpeq -> 2308
    //   2286: aload_1
    //   2287: aload #11
    //   2289: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2292: aload #9
    //   2294: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2297: aload #11
    //   2299: invokevirtual getMargin : ()I
    //   2302: ineg
    //   2303: iconst_5
    //   2304: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   2307: pop
    //   2308: iload #15
    //   2310: ifne -> 2318
    //   2313: iload #16
    //   2315: ifeq -> 2522
    //   2318: aload #7
    //   2320: ifnull -> 2522
    //   2323: aload #7
    //   2325: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2328: iload_3
    //   2329: aaload
    //   2330: astore #11
    //   2332: aload #8
    //   2334: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2337: astore_0
    //   2338: iload_3
    //   2339: iconst_1
    //   2340: iadd
    //   2341: istore #13
    //   2343: aload_0
    //   2344: iload #13
    //   2346: aaload
    //   2347: astore #9
    //   2349: aload #11
    //   2351: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2354: ifnull -> 2370
    //   2357: aload #11
    //   2359: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2362: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2365: astore #4
    //   2367: goto -> 2373
    //   2370: aconst_null
    //   2371: astore #4
    //   2373: aload #9
    //   2375: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2378: ifnull -> 2393
    //   2381: aload #9
    //   2383: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2386: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2389: astore_0
    //   2390: goto -> 2395
    //   2393: aconst_null
    //   2394: astore_0
    //   2395: aload #6
    //   2397: aload #8
    //   2399: if_acmpeq -> 2431
    //   2402: aload #6
    //   2404: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2407: iload #13
    //   2409: aaload
    //   2410: astore_0
    //   2411: aload_0
    //   2412: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2415: ifnull -> 2429
    //   2418: aload_0
    //   2419: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2422: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2425: astore_0
    //   2426: goto -> 2431
    //   2429: aconst_null
    //   2430: astore_0
    //   2431: aload #7
    //   2433: aload #8
    //   2435: if_acmpne -> 2457
    //   2438: aload #7
    //   2440: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2443: iload_3
    //   2444: aaload
    //   2445: astore #11
    //   2447: aload #7
    //   2449: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2452: iload #13
    //   2454: aaload
    //   2455: astore #9
    //   2457: aload #4
    //   2459: ifnull -> 2522
    //   2462: aload_0
    //   2463: ifnull -> 2522
    //   2466: aload #11
    //   2468: invokevirtual getMargin : ()I
    //   2471: istore_2
    //   2472: aload #8
    //   2474: ifnonnull -> 2484
    //   2477: aload #6
    //   2479: astore #18
    //   2481: goto -> 2488
    //   2484: aload #8
    //   2486: astore #18
    //   2488: aload #18
    //   2490: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2493: iload #13
    //   2495: aaload
    //   2496: invokevirtual getMargin : ()I
    //   2499: istore_3
    //   2500: aload_1
    //   2501: aload #11
    //   2503: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2506: aload #4
    //   2508: iload_2
    //   2509: ldc 0.5
    //   2511: aload_0
    //   2512: aload #9
    //   2514: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2517: iload_3
    //   2518: iconst_5
    //   2519: invokevirtual addCentering : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;IFLandroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   2522: return
  }
}


/* Location:              /home/brandon/levelMeter_APK/dex2jar-2.x/dex-tools/build/distributions/dex-tools-2.2-SNAPSHOT/classes-dex2jar.jar!/androidx/constraintlayout/solver/widgets/Chain.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */