package androidx.constraintlayout.solver.widgets;

import androidx.constraintlayout.solver.Cache;
import androidx.constraintlayout.solver.LinearSystem;
import androidx.constraintlayout.solver.SolverVariable;
import java.util.ArrayList;

public class ConstraintWidget {
  protected static final int ANCHOR_BASELINE = 4;
  
  protected static final int ANCHOR_BOTTOM = 3;
  
  protected static final int ANCHOR_LEFT = 0;
  
  protected static final int ANCHOR_RIGHT = 1;
  
  protected static final int ANCHOR_TOP = 2;
  
  private static final boolean AUTOTAG_CENTER = false;
  
  public static final int CHAIN_PACKED = 2;
  
  public static final int CHAIN_SPREAD = 0;
  
  public static final int CHAIN_SPREAD_INSIDE = 1;
  
  public static float DEFAULT_BIAS = 0.5F;
  
  static final int DIMENSION_HORIZONTAL = 0;
  
  static final int DIMENSION_VERTICAL = 1;
  
  protected static final int DIRECT = 2;
  
  public static final int GONE = 8;
  
  public static final int HORIZONTAL = 0;
  
  public static final int INVISIBLE = 4;
  
  public static final int MATCH_CONSTRAINT_PERCENT = 2;
  
  public static final int MATCH_CONSTRAINT_RATIO = 3;
  
  public static final int MATCH_CONSTRAINT_RATIO_RESOLVED = 4;
  
  public static final int MATCH_CONSTRAINT_SPREAD = 0;
  
  public static final int MATCH_CONSTRAINT_WRAP = 1;
  
  protected static final int SOLVER = 1;
  
  public static final int UNKNOWN = -1;
  
  public static final int VERTICAL = 1;
  
  public static final int VISIBLE = 0;
  
  private static final int WRAP = -2;
  
  protected ArrayList<ConstraintAnchor> mAnchors = new ArrayList<ConstraintAnchor>();
  
  ConstraintAnchor mBaseline = new ConstraintAnchor(this, ConstraintAnchor.Type.BASELINE);
  
  int mBaselineDistance = 0;
  
  ConstraintWidgetGroup mBelongingGroup = null;
  
  ConstraintAnchor mBottom = new ConstraintAnchor(this, ConstraintAnchor.Type.BOTTOM);
  
  boolean mBottomHasCentered;
  
  ConstraintAnchor mCenter = new ConstraintAnchor(this, ConstraintAnchor.Type.CENTER);
  
  ConstraintAnchor mCenterX = new ConstraintAnchor(this, ConstraintAnchor.Type.CENTER_X);
  
  ConstraintAnchor mCenterY = new ConstraintAnchor(this, ConstraintAnchor.Type.CENTER_Y);
  
  private float mCircleConstraintAngle = 0.0F;
  
  private Object mCompanionWidget;
  
  private int mContainerItemSkip;
  
  private String mDebugName;
  
  protected float mDimensionRatio = 0.0F;
  
  protected int mDimensionRatioSide = -1;
  
  int mDistToBottom;
  
  int mDistToLeft;
  
  int mDistToRight;
  
  int mDistToTop;
  
  private int mDrawHeight = 0;
  
  private int mDrawWidth = 0;
  
  private int mDrawX = 0;
  
  private int mDrawY = 0;
  
  boolean mGroupsToSolver;
  
  int mHeight = 0;
  
  float mHorizontalBiasPercent;
  
  boolean mHorizontalChainFixedPosition;
  
  int mHorizontalChainStyle;
  
  ConstraintWidget mHorizontalNextWidget;
  
  public int mHorizontalResolution = -1;
  
  boolean mHorizontalWrapVisited;
  
  boolean mIsHeightWrapContent;
  
  boolean mIsWidthWrapContent;
  
  ConstraintAnchor mLeft = new ConstraintAnchor(this, ConstraintAnchor.Type.LEFT);
  
  boolean mLeftHasCentered;
  
  protected ConstraintAnchor[] mListAnchors = new ConstraintAnchor[] { this.mLeft, this.mRight, this.mTop, this.mBottom, this.mBaseline, this.mCenter };
  
  protected DimensionBehaviour[] mListDimensionBehaviors = new DimensionBehaviour[] { DimensionBehaviour.FIXED, DimensionBehaviour.FIXED };
  
  protected ConstraintWidget[] mListNextMatchConstraintsWidget;
  
  int mMatchConstraintDefaultHeight = 0;
  
  int mMatchConstraintDefaultWidth = 0;
  
  int mMatchConstraintMaxHeight = 0;
  
  int mMatchConstraintMaxWidth = 0;
  
  int mMatchConstraintMinHeight = 0;
  
  int mMatchConstraintMinWidth = 0;
  
  float mMatchConstraintPercentHeight = 1.0F;
  
  float mMatchConstraintPercentWidth = 1.0F;
  
  private int[] mMaxDimension = new int[] { Integer.MAX_VALUE, Integer.MAX_VALUE };
  
  protected int mMinHeight;
  
  protected int mMinWidth;
  
  protected ConstraintWidget[] mNextChainWidget;
  
  protected int mOffsetX = 0;
  
  protected int mOffsetY = 0;
  
  boolean mOptimizerMeasurable;
  
  boolean mOptimizerMeasured;
  
  ConstraintWidget mParent = null;
  
  int mRelX = 0;
  
  int mRelY = 0;
  
  ResolutionDimension mResolutionHeight;
  
  ResolutionDimension mResolutionWidth;
  
  float mResolvedDimensionRatio = 1.0F;
  
  int mResolvedDimensionRatioSide = -1;
  
  int[] mResolvedMatchConstraintDefault = new int[2];
  
  ConstraintAnchor mRight = new ConstraintAnchor(this, ConstraintAnchor.Type.RIGHT);
  
  boolean mRightHasCentered;
  
  ConstraintAnchor mTop = new ConstraintAnchor(this, ConstraintAnchor.Type.TOP);
  
  boolean mTopHasCentered;
  
  private String mType;
  
  float mVerticalBiasPercent;
  
  boolean mVerticalChainFixedPosition;
  
  int mVerticalChainStyle;
  
  ConstraintWidget mVerticalNextWidget;
  
  public int mVerticalResolution = -1;
  
  boolean mVerticalWrapVisited;
  
  private int mVisibility;
  
  float[] mWeight;
  
  int mWidth = 0;
  
  private int mWrapHeight;
  
  private int mWrapWidth;
  
  protected int mX = 0;
  
  protected int mY = 0;
  
  public ConstraintWidget() {
    float f = DEFAULT_BIAS;
    this.mHorizontalBiasPercent = f;
    this.mVerticalBiasPercent = f;
    this.mContainerItemSkip = 0;
    this.mVisibility = 0;
    this.mDebugName = null;
    this.mType = null;
    this.mOptimizerMeasurable = false;
    this.mOptimizerMeasured = false;
    this.mGroupsToSolver = false;
    this.mHorizontalChainStyle = 0;
    this.mVerticalChainStyle = 0;
    this.mWeight = new float[] { -1.0F, -1.0F };
    this.mListNextMatchConstraintsWidget = new ConstraintWidget[] { null, null };
    this.mNextChainWidget = new ConstraintWidget[] { null, null };
    this.mHorizontalNextWidget = null;
    this.mVerticalNextWidget = null;
    addAnchors();
  }
  
  public ConstraintWidget(int paramInt1, int paramInt2) {
    this(0, 0, paramInt1, paramInt2);
  }
  
  public ConstraintWidget(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    float f = DEFAULT_BIAS;
    this.mHorizontalBiasPercent = f;
    this.mVerticalBiasPercent = f;
    this.mContainerItemSkip = 0;
    this.mVisibility = 0;
    this.mDebugName = null;
    this.mType = null;
    this.mOptimizerMeasurable = false;
    this.mOptimizerMeasured = false;
    this.mGroupsToSolver = false;
    this.mHorizontalChainStyle = 0;
    this.mVerticalChainStyle = 0;
    this.mWeight = new float[] { -1.0F, -1.0F };
    this.mListNextMatchConstraintsWidget = new ConstraintWidget[] { null, null };
    this.mNextChainWidget = new ConstraintWidget[] { null, null };
    this.mHorizontalNextWidget = null;
    this.mVerticalNextWidget = null;
    this.mX = paramInt1;
    this.mY = paramInt2;
    this.mWidth = paramInt3;
    this.mHeight = paramInt4;
    addAnchors();
    forceUpdateDrawPosition();
  }
  
  private void addAnchors() {
    this.mAnchors.add(this.mLeft);
    this.mAnchors.add(this.mTop);
    this.mAnchors.add(this.mRight);
    this.mAnchors.add(this.mBottom);
    this.mAnchors.add(this.mCenterX);
    this.mAnchors.add(this.mCenterY);
    this.mAnchors.add(this.mCenter);
    this.mAnchors.add(this.mBaseline);
  }
  
  private void applyConstraints(LinearSystem paramLinearSystem, boolean paramBoolean1, SolverVariable paramSolverVariable1, SolverVariable paramSolverVariable2, DimensionBehaviour paramDimensionBehaviour, boolean paramBoolean2, ConstraintAnchor paramConstraintAnchor1, ConstraintAnchor paramConstraintAnchor2, int paramInt1, int paramInt2, int paramInt3, int paramInt4, float paramFloat1, boolean paramBoolean3, boolean paramBoolean4, int paramInt5, int paramInt6, int paramInt7, float paramFloat2, boolean paramBoolean5) {
    // Byte code:
    //   0: aload_1
    //   1: aload #7
    //   3: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   6: astore #21
    //   8: aload_1
    //   9: aload #8
    //   11: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   14: astore #22
    //   16: aload_1
    //   17: aload #7
    //   19: invokevirtual getTarget : ()Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   22: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   25: astore #23
    //   27: aload_1
    //   28: aload #8
    //   30: invokevirtual getTarget : ()Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   33: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   36: astore #24
    //   38: aload_1
    //   39: getfield graphOptimizer : Z
    //   42: ifeq -> 128
    //   45: aload #7
    //   47: invokevirtual getResolutionNode : ()Landroidx/constraintlayout/solver/widgets/ResolutionAnchor;
    //   50: getfield state : I
    //   53: iconst_1
    //   54: if_icmpne -> 128
    //   57: aload #8
    //   59: invokevirtual getResolutionNode : ()Landroidx/constraintlayout/solver/widgets/ResolutionAnchor;
    //   62: getfield state : I
    //   65: iconst_1
    //   66: if_icmpne -> 128
    //   69: invokestatic getMetrics : ()Landroidx/constraintlayout/solver/Metrics;
    //   72: ifnull -> 89
    //   75: invokestatic getMetrics : ()Landroidx/constraintlayout/solver/Metrics;
    //   78: astore_3
    //   79: aload_3
    //   80: aload_3
    //   81: getfield resolvedWidgets : J
    //   84: lconst_1
    //   85: ladd
    //   86: putfield resolvedWidgets : J
    //   89: aload #7
    //   91: invokevirtual getResolutionNode : ()Landroidx/constraintlayout/solver/widgets/ResolutionAnchor;
    //   94: aload_1
    //   95: invokevirtual addResolvedValue : (Landroidx/constraintlayout/solver/LinearSystem;)V
    //   98: aload #8
    //   100: invokevirtual getResolutionNode : ()Landroidx/constraintlayout/solver/widgets/ResolutionAnchor;
    //   103: aload_1
    //   104: invokevirtual addResolvedValue : (Landroidx/constraintlayout/solver/LinearSystem;)V
    //   107: iload #15
    //   109: ifne -> 127
    //   112: iload_2
    //   113: ifeq -> 127
    //   116: aload_1
    //   117: aload #4
    //   119: aload #22
    //   121: iconst_0
    //   122: bipush #6
    //   124: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   127: return
    //   128: invokestatic getMetrics : ()Landroidx/constraintlayout/solver/Metrics;
    //   131: ifnull -> 151
    //   134: invokestatic getMetrics : ()Landroidx/constraintlayout/solver/Metrics;
    //   137: astore #25
    //   139: aload #25
    //   141: aload #25
    //   143: getfield nonresolvedWidgets : J
    //   146: lconst_1
    //   147: ladd
    //   148: putfield nonresolvedWidgets : J
    //   151: aload #7
    //   153: invokevirtual isConnected : ()Z
    //   156: istore #26
    //   158: aload #8
    //   160: invokevirtual isConnected : ()Z
    //   163: istore #27
    //   165: aload_0
    //   166: getfield mCenter : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   169: invokevirtual isConnected : ()Z
    //   172: istore #28
    //   174: iload #26
    //   176: ifeq -> 185
    //   179: iconst_1
    //   180: istore #29
    //   182: goto -> 188
    //   185: iconst_0
    //   186: istore #29
    //   188: iload #29
    //   190: istore #30
    //   192: iload #27
    //   194: ifeq -> 203
    //   197: iload #29
    //   199: iconst_1
    //   200: iadd
    //   201: istore #30
    //   203: iload #30
    //   205: istore #29
    //   207: iload #28
    //   209: ifeq -> 218
    //   212: iload #30
    //   214: iconst_1
    //   215: iadd
    //   216: istore #29
    //   218: iload #14
    //   220: ifeq -> 229
    //   223: iconst_3
    //   224: istore #30
    //   226: goto -> 233
    //   229: iload #16
    //   231: istore #30
    //   233: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$1.$SwitchMap$androidx$constraintlayout$solver$widgets$ConstraintWidget$DimensionBehaviour : [I
    //   236: aload #5
    //   238: invokevirtual ordinal : ()I
    //   241: iaload
    //   242: istore #16
    //   244: iload #16
    //   246: iconst_1
    //   247: if_icmpeq -> 268
    //   250: iload #16
    //   252: iconst_2
    //   253: if_icmpeq -> 268
    //   256: iload #16
    //   258: iconst_3
    //   259: if_icmpeq -> 268
    //   262: iload #16
    //   264: iconst_4
    //   265: if_icmpeq -> 274
    //   268: iconst_0
    //   269: istore #16
    //   271: goto -> 286
    //   274: iload #30
    //   276: iconst_4
    //   277: if_icmpne -> 283
    //   280: goto -> 268
    //   283: iconst_1
    //   284: istore #16
    //   286: aload_0
    //   287: getfield mVisibility : I
    //   290: bipush #8
    //   292: if_icmpne -> 304
    //   295: iconst_0
    //   296: istore #10
    //   298: iconst_0
    //   299: istore #16
    //   301: goto -> 304
    //   304: iload #20
    //   306: ifeq -> 364
    //   309: iload #26
    //   311: ifne -> 335
    //   314: iload #27
    //   316: ifne -> 335
    //   319: iload #28
    //   321: ifne -> 335
    //   324: aload_1
    //   325: aload #21
    //   327: iload #9
    //   329: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;I)V
    //   332: goto -> 364
    //   335: iload #26
    //   337: ifeq -> 364
    //   340: iload #27
    //   342: ifne -> 364
    //   345: aload_1
    //   346: aload #21
    //   348: aload #23
    //   350: aload #7
    //   352: invokevirtual getMargin : ()I
    //   355: bipush #6
    //   357: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   360: pop
    //   361: goto -> 364
    //   364: iload #16
    //   366: ifne -> 448
    //   369: iload #6
    //   371: ifeq -> 424
    //   374: aload_1
    //   375: aload #22
    //   377: aload #21
    //   379: iconst_0
    //   380: iconst_3
    //   381: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   384: pop
    //   385: iload #11
    //   387: ifle -> 402
    //   390: aload_1
    //   391: aload #22
    //   393: aload #21
    //   395: iload #11
    //   397: bipush #6
    //   399: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   402: iload #12
    //   404: ldc 2147483647
    //   406: if_icmpge -> 421
    //   409: aload_1
    //   410: aload #22
    //   412: aload #21
    //   414: iload #12
    //   416: bipush #6
    //   418: invokevirtual addLowerThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   421: goto -> 437
    //   424: aload_1
    //   425: aload #22
    //   427: aload #21
    //   429: iload #10
    //   431: bipush #6
    //   433: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   436: pop
    //   437: iload #18
    //   439: istore #12
    //   441: iload #17
    //   443: istore #9
    //   445: goto -> 805
    //   448: iload #17
    //   450: bipush #-2
    //   452: if_icmpne -> 462
    //   455: iload #10
    //   457: istore #9
    //   459: goto -> 466
    //   462: iload #17
    //   464: istore #9
    //   466: iload #18
    //   468: istore #12
    //   470: iload #18
    //   472: bipush #-2
    //   474: if_icmpne -> 481
    //   477: iload #10
    //   479: istore #12
    //   481: iload #10
    //   483: istore #17
    //   485: iload #9
    //   487: ifle -> 511
    //   490: aload_1
    //   491: aload #22
    //   493: aload #21
    //   495: iload #9
    //   497: bipush #6
    //   499: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   502: iload #10
    //   504: iload #9
    //   506: invokestatic max : (II)I
    //   509: istore #17
    //   511: iload #17
    //   513: istore #18
    //   515: iload #12
    //   517: ifle -> 541
    //   520: aload_1
    //   521: aload #22
    //   523: aload #21
    //   525: iload #12
    //   527: bipush #6
    //   529: invokevirtual addLowerThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   532: iload #17
    //   534: iload #12
    //   536: invokestatic min : (II)I
    //   539: istore #18
    //   541: iload #30
    //   543: iconst_1
    //   544: if_icmpne -> 602
    //   547: iload_2
    //   548: ifeq -> 567
    //   551: aload_1
    //   552: aload #22
    //   554: aload #21
    //   556: iload #18
    //   558: bipush #6
    //   560: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   563: pop
    //   564: goto -> 735
    //   567: iload #15
    //   569: ifeq -> 587
    //   572: aload_1
    //   573: aload #22
    //   575: aload #21
    //   577: iload #18
    //   579: iconst_4
    //   580: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   583: pop
    //   584: goto -> 735
    //   587: aload_1
    //   588: aload #22
    //   590: aload #21
    //   592: iload #18
    //   594: iconst_1
    //   595: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   598: pop
    //   599: goto -> 735
    //   602: iload #30
    //   604: iconst_2
    //   605: if_icmpne -> 735
    //   608: aload #7
    //   610: invokevirtual getType : ()Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   613: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.TOP : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   616: if_acmpeq -> 672
    //   619: aload #7
    //   621: invokevirtual getType : ()Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   624: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   627: if_acmpne -> 633
    //   630: goto -> 672
    //   633: aload_1
    //   634: aload_0
    //   635: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   638: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.LEFT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   641: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   644: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   647: astore #5
    //   649: aload_0
    //   650: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   653: astore #25
    //   655: aload_1
    //   656: aload #25
    //   658: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.RIGHT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   661: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   664: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   667: astore #25
    //   669: goto -> 708
    //   672: aload_1
    //   673: aload_0
    //   674: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   677: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.TOP : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   680: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   683: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   686: astore #5
    //   688: aload_0
    //   689: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   692: astore #25
    //   694: aload_1
    //   695: aload #25
    //   697: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   700: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   703: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   706: astore #25
    //   708: aload_1
    //   709: aload_1
    //   710: invokevirtual createRow : ()Landroidx/constraintlayout/solver/ArrayRow;
    //   713: aload #22
    //   715: aload #21
    //   717: aload #25
    //   719: aload #5
    //   721: fload #19
    //   723: invokevirtual createRowDimensionRatio : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;F)Landroidx/constraintlayout/solver/ArrayRow;
    //   726: invokevirtual addConstraint : (Landroidx/constraintlayout/solver/ArrayRow;)V
    //   729: iconst_0
    //   730: istore #10
    //   732: goto -> 739
    //   735: iload #16
    //   737: istore #10
    //   739: iload #10
    //   741: ifeq -> 801
    //   744: iload #29
    //   746: iconst_2
    //   747: if_icmpeq -> 801
    //   750: iload #14
    //   752: ifne -> 801
    //   755: iload #9
    //   757: iload #18
    //   759: invokestatic max : (II)I
    //   762: istore #16
    //   764: iload #16
    //   766: istore #10
    //   768: iload #12
    //   770: ifle -> 782
    //   773: iload #12
    //   775: iload #16
    //   777: invokestatic min : (II)I
    //   780: istore #10
    //   782: aload_1
    //   783: aload #22
    //   785: aload #21
    //   787: iload #10
    //   789: bipush #6
    //   791: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   794: pop
    //   795: iconst_0
    //   796: istore #16
    //   798: goto -> 805
    //   801: iload #10
    //   803: istore #16
    //   805: iload #20
    //   807: ifeq -> 1420
    //   810: iload #15
    //   812: ifeq -> 818
    //   815: goto -> 1420
    //   818: iload #26
    //   820: ifne -> 850
    //   823: iload #27
    //   825: ifne -> 850
    //   828: iload #28
    //   830: ifne -> 850
    //   833: iload_2
    //   834: ifeq -> 1401
    //   837: aload_1
    //   838: aload #4
    //   840: aload #22
    //   842: iconst_0
    //   843: iconst_5
    //   844: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   847: goto -> 1401
    //   850: iload #26
    //   852: ifeq -> 877
    //   855: iload #27
    //   857: ifne -> 877
    //   860: iload_2
    //   861: ifeq -> 1401
    //   864: aload_1
    //   865: aload #4
    //   867: aload #22
    //   869: iconst_0
    //   870: iconst_5
    //   871: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   874: goto -> 1401
    //   877: iload #26
    //   879: ifne -> 920
    //   882: iload #27
    //   884: ifeq -> 920
    //   887: aload_1
    //   888: aload #22
    //   890: aload #24
    //   892: aload #8
    //   894: invokevirtual getMargin : ()I
    //   897: ineg
    //   898: bipush #6
    //   900: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   903: pop
    //   904: iload_2
    //   905: ifeq -> 1401
    //   908: aload_1
    //   909: aload #21
    //   911: aload_3
    //   912: iconst_0
    //   913: iconst_5
    //   914: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   917: goto -> 1401
    //   920: iload #26
    //   922: ifeq -> 1401
    //   925: iload #27
    //   927: ifeq -> 1401
    //   930: iload #16
    //   932: ifeq -> 1168
    //   935: iload_2
    //   936: ifeq -> 955
    //   939: iload #11
    //   941: ifne -> 955
    //   944: aload_1
    //   945: aload #22
    //   947: aload #21
    //   949: iconst_0
    //   950: bipush #6
    //   952: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   955: iload #30
    //   957: ifne -> 1058
    //   960: iload #12
    //   962: ifgt -> 983
    //   965: iload #9
    //   967: ifle -> 973
    //   970: goto -> 983
    //   973: iconst_0
    //   974: istore #10
    //   976: bipush #6
    //   978: istore #11
    //   980: goto -> 989
    //   983: iconst_4
    //   984: istore #11
    //   986: iconst_1
    //   987: istore #10
    //   989: aload_1
    //   990: aload #21
    //   992: aload #23
    //   994: aload #7
    //   996: invokevirtual getMargin : ()I
    //   999: iload #11
    //   1001: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   1004: pop
    //   1005: aload_1
    //   1006: aload #22
    //   1008: aload #24
    //   1010: aload #8
    //   1012: invokevirtual getMargin : ()I
    //   1015: ineg
    //   1016: iload #11
    //   1018: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   1021: pop
    //   1022: iload #12
    //   1024: ifgt -> 1041
    //   1027: iload #9
    //   1029: ifle -> 1035
    //   1032: goto -> 1041
    //   1035: iconst_0
    //   1036: istore #11
    //   1038: goto -> 1044
    //   1041: iconst_1
    //   1042: istore #11
    //   1044: iconst_5
    //   1045: istore #12
    //   1047: iload #10
    //   1049: istore #9
    //   1051: iload #12
    //   1053: istore #10
    //   1055: goto -> 1177
    //   1058: iload #30
    //   1060: iconst_1
    //   1061: if_icmpne -> 1074
    //   1064: bipush #6
    //   1066: istore #10
    //   1068: iconst_1
    //   1069: istore #9
    //   1071: goto -> 1153
    //   1074: iload #30
    //   1076: iconst_3
    //   1077: if_icmpne -> 1147
    //   1080: iload #14
    //   1082: ifne -> 1105
    //   1085: aload_0
    //   1086: getfield mResolvedDimensionRatioSide : I
    //   1089: iconst_m1
    //   1090: if_icmpeq -> 1105
    //   1093: iload #12
    //   1095: ifgt -> 1105
    //   1098: bipush #6
    //   1100: istore #9
    //   1102: goto -> 1108
    //   1105: iconst_4
    //   1106: istore #9
    //   1108: aload_1
    //   1109: aload #21
    //   1111: aload #23
    //   1113: aload #7
    //   1115: invokevirtual getMargin : ()I
    //   1118: iload #9
    //   1120: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   1123: pop
    //   1124: aload_1
    //   1125: aload #22
    //   1127: aload #24
    //   1129: aload #8
    //   1131: invokevirtual getMargin : ()I
    //   1134: ineg
    //   1135: iload #9
    //   1137: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   1140: pop
    //   1141: iconst_5
    //   1142: istore #10
    //   1144: goto -> 1068
    //   1147: iconst_5
    //   1148: istore #10
    //   1150: iconst_0
    //   1151: istore #9
    //   1153: iload #9
    //   1155: istore #12
    //   1157: iload #9
    //   1159: istore #11
    //   1161: iload #12
    //   1163: istore #9
    //   1165: goto -> 1177
    //   1168: iconst_5
    //   1169: istore #10
    //   1171: iconst_1
    //   1172: istore #11
    //   1174: iconst_0
    //   1175: istore #9
    //   1177: iload #11
    //   1179: ifeq -> 1288
    //   1182: aload #7
    //   1184: invokevirtual getMargin : ()I
    //   1187: istore #12
    //   1189: aload #8
    //   1191: invokevirtual getMargin : ()I
    //   1194: istore #11
    //   1196: iconst_1
    //   1197: istore #6
    //   1199: aload_1
    //   1200: aload #21
    //   1202: aload #23
    //   1204: iload #12
    //   1206: fload #13
    //   1208: aload #24
    //   1210: aload #22
    //   1212: iload #11
    //   1214: iload #10
    //   1216: invokevirtual addCentering : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;IFLandroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   1219: aload #7
    //   1221: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1224: getfield mOwner : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1227: instanceof androidx/constraintlayout/solver/widgets/Barrier
    //   1230: istore #15
    //   1232: aload #8
    //   1234: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1237: getfield mOwner : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1240: instanceof androidx/constraintlayout/solver/widgets/Barrier
    //   1243: istore #14
    //   1245: iload #15
    //   1247: ifeq -> 1271
    //   1250: iload #14
    //   1252: ifne -> 1271
    //   1255: iconst_1
    //   1256: istore #14
    //   1258: iconst_5
    //   1259: istore #11
    //   1261: bipush #6
    //   1263: istore #10
    //   1265: iload_2
    //   1266: istore #6
    //   1268: goto -> 1300
    //   1271: iload #15
    //   1273: ifne -> 1288
    //   1276: iload #14
    //   1278: ifeq -> 1288
    //   1281: bipush #6
    //   1283: istore #11
    //   1285: goto -> 1294
    //   1288: iload_2
    //   1289: istore #6
    //   1291: iconst_5
    //   1292: istore #11
    //   1294: iload_2
    //   1295: istore #14
    //   1297: iconst_5
    //   1298: istore #10
    //   1300: iload #9
    //   1302: ifeq -> 1313
    //   1305: bipush #6
    //   1307: istore #11
    //   1309: bipush #6
    //   1311: istore #10
    //   1313: iload #16
    //   1315: ifne -> 1323
    //   1318: iload #6
    //   1320: ifne -> 1328
    //   1323: iload #9
    //   1325: ifeq -> 1343
    //   1328: aload_1
    //   1329: aload #21
    //   1331: aload #23
    //   1333: aload #7
    //   1335: invokevirtual getMargin : ()I
    //   1338: iload #11
    //   1340: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   1343: iload #16
    //   1345: ifne -> 1353
    //   1348: iload #14
    //   1350: ifne -> 1358
    //   1353: iload #9
    //   1355: ifeq -> 1374
    //   1358: aload_1
    //   1359: aload #22
    //   1361: aload #24
    //   1363: aload #8
    //   1365: invokevirtual getMargin : ()I
    //   1368: ineg
    //   1369: iload #10
    //   1371: invokevirtual addLowerThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   1374: iload_2
    //   1375: ifeq -> 1395
    //   1378: aload #22
    //   1380: astore #5
    //   1382: aload_1
    //   1383: aload #21
    //   1385: aload_3
    //   1386: iconst_0
    //   1387: bipush #6
    //   1389: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   1392: goto -> 1404
    //   1395: aload #22
    //   1397: astore_3
    //   1398: goto -> 1404
    //   1401: aload #22
    //   1403: astore_3
    //   1404: iload_2
    //   1405: ifeq -> 1419
    //   1408: aload_1
    //   1409: aload #4
    //   1411: aload #22
    //   1413: iconst_0
    //   1414: bipush #6
    //   1416: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   1419: return
    //   1420: iload #29
    //   1422: iconst_2
    //   1423: if_icmpge -> 1451
    //   1426: iload_2
    //   1427: ifeq -> 1451
    //   1430: aload_1
    //   1431: aload #21
    //   1433: aload_3
    //   1434: iconst_0
    //   1435: bipush #6
    //   1437: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   1440: aload_1
    //   1441: aload #4
    //   1443: aload #22
    //   1445: iconst_0
    //   1446: bipush #6
    //   1448: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   1451: return
  }
  
  private boolean isChainHead(int paramInt) {
    paramInt *= 2;
    ConstraintAnchor constraintAnchor = (this.mListAnchors[paramInt]).mTarget;
    null = true;
    if (constraintAnchor != null) {
      ConstraintAnchor constraintAnchor1 = (this.mListAnchors[paramInt]).mTarget.mTarget;
      ConstraintAnchor[] arrayOfConstraintAnchor = this.mListAnchors;
      if (constraintAnchor1 != arrayOfConstraintAnchor[paramInt])
        if ((arrayOfConstraintAnchor[++paramInt]).mTarget != null && (this.mListAnchors[paramInt]).mTarget.mTarget == this.mListAnchors[paramInt])
          return null;  
    } 
    return false;
  }
  
  public void addToSolver(LinearSystem paramLinearSystem) {
    // Byte code:
    //   0: aload_1
    //   1: aload_0
    //   2: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   5: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   8: astore_2
    //   9: aload_1
    //   10: aload_0
    //   11: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   14: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   17: astore_3
    //   18: aload_1
    //   19: aload_0
    //   20: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   23: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   26: astore #4
    //   28: aload_1
    //   29: aload_0
    //   30: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   33: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   36: astore #5
    //   38: aload_1
    //   39: aload_0
    //   40: getfield mBaseline : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   43: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   46: astore #6
    //   48: aload_0
    //   49: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   52: astore #7
    //   54: aload #7
    //   56: ifnull -> 314
    //   59: aload #7
    //   61: ifnull -> 83
    //   64: aload #7
    //   66: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   69: iconst_0
    //   70: aaload
    //   71: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   74: if_acmpne -> 83
    //   77: iconst_1
    //   78: istore #8
    //   80: goto -> 86
    //   83: iconst_0
    //   84: istore #8
    //   86: aload_0
    //   87: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   90: astore #7
    //   92: aload #7
    //   94: ifnull -> 116
    //   97: aload #7
    //   99: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   102: iconst_1
    //   103: aaload
    //   104: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   107: if_acmpne -> 116
    //   110: iconst_1
    //   111: istore #9
    //   113: goto -> 119
    //   116: iconst_0
    //   117: istore #9
    //   119: aload_0
    //   120: iconst_0
    //   121: invokespecial isChainHead : (I)Z
    //   124: ifeq -> 145
    //   127: aload_0
    //   128: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   131: checkcast androidx/constraintlayout/solver/widgets/ConstraintWidgetContainer
    //   134: aload_0
    //   135: iconst_0
    //   136: invokevirtual addChain : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;I)V
    //   139: iconst_1
    //   140: istore #10
    //   142: goto -> 151
    //   145: aload_0
    //   146: invokevirtual isInHorizontalChain : ()Z
    //   149: istore #10
    //   151: aload_0
    //   152: iconst_1
    //   153: invokespecial isChainHead : (I)Z
    //   156: ifeq -> 177
    //   159: aload_0
    //   160: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   163: checkcast androidx/constraintlayout/solver/widgets/ConstraintWidgetContainer
    //   166: aload_0
    //   167: iconst_1
    //   168: invokevirtual addChain : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;I)V
    //   171: iconst_1
    //   172: istore #11
    //   174: goto -> 183
    //   177: aload_0
    //   178: invokevirtual isInVerticalChain : ()Z
    //   181: istore #11
    //   183: iload #8
    //   185: ifeq -> 235
    //   188: aload_0
    //   189: getfield mVisibility : I
    //   192: bipush #8
    //   194: if_icmpeq -> 235
    //   197: aload_0
    //   198: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   201: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   204: ifnonnull -> 235
    //   207: aload_0
    //   208: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   211: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   214: ifnonnull -> 235
    //   217: aload_1
    //   218: aload_1
    //   219: aload_0
    //   220: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   223: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   226: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   229: aload_3
    //   230: iconst_0
    //   231: iconst_1
    //   232: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   235: iload #9
    //   237: ifeq -> 295
    //   240: aload_0
    //   241: getfield mVisibility : I
    //   244: bipush #8
    //   246: if_icmpeq -> 295
    //   249: aload_0
    //   250: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   253: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   256: ifnonnull -> 295
    //   259: aload_0
    //   260: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   263: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   266: ifnonnull -> 295
    //   269: aload_0
    //   270: getfield mBaseline : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   273: ifnonnull -> 295
    //   276: aload_1
    //   277: aload_1
    //   278: aload_0
    //   279: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   282: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   285: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   288: aload #5
    //   290: iconst_0
    //   291: iconst_1
    //   292: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   295: iload #11
    //   297: istore #12
    //   299: iload #8
    //   301: istore #11
    //   303: iload #9
    //   305: istore #8
    //   307: iload #12
    //   309: istore #9
    //   311: goto -> 340
    //   314: iconst_0
    //   315: istore #12
    //   317: iconst_0
    //   318: istore #11
    //   320: iload #11
    //   322: istore #8
    //   324: iload #8
    //   326: istore #9
    //   328: iload #8
    //   330: istore #10
    //   332: iload #11
    //   334: istore #8
    //   336: iload #12
    //   338: istore #11
    //   340: aload_0
    //   341: getfield mWidth : I
    //   344: istore #13
    //   346: aload_0
    //   347: getfield mMinWidth : I
    //   350: istore #14
    //   352: iload #13
    //   354: istore #15
    //   356: iload #13
    //   358: iload #14
    //   360: if_icmpge -> 367
    //   363: iload #14
    //   365: istore #15
    //   367: aload_0
    //   368: getfield mHeight : I
    //   371: istore #16
    //   373: aload_0
    //   374: getfield mMinHeight : I
    //   377: istore #14
    //   379: iload #16
    //   381: istore #13
    //   383: iload #16
    //   385: iload #14
    //   387: if_icmpge -> 394
    //   390: iload #14
    //   392: istore #13
    //   394: aload_0
    //   395: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   398: iconst_0
    //   399: aaload
    //   400: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   403: if_acmpeq -> 412
    //   406: iconst_1
    //   407: istore #12
    //   409: goto -> 415
    //   412: iconst_0
    //   413: istore #12
    //   415: aload_0
    //   416: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   419: iconst_1
    //   420: aaload
    //   421: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   424: if_acmpeq -> 433
    //   427: iconst_1
    //   428: istore #17
    //   430: goto -> 436
    //   433: iconst_0
    //   434: istore #17
    //   436: aload_0
    //   437: aload_0
    //   438: getfield mDimensionRatioSide : I
    //   441: putfield mResolvedDimensionRatioSide : I
    //   444: aload_0
    //   445: getfield mDimensionRatio : F
    //   448: fstore #18
    //   450: aload_0
    //   451: fload #18
    //   453: putfield mResolvedDimensionRatio : F
    //   456: aload_0
    //   457: getfield mMatchConstraintDefaultWidth : I
    //   460: istore #19
    //   462: aload_0
    //   463: getfield mMatchConstraintDefaultHeight : I
    //   466: istore #20
    //   468: fload #18
    //   470: fconst_0
    //   471: fcmpl
    //   472: ifle -> 805
    //   475: aload_0
    //   476: getfield mVisibility : I
    //   479: bipush #8
    //   481: if_icmpeq -> 805
    //   484: iload #19
    //   486: istore #16
    //   488: aload_0
    //   489: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   492: iconst_0
    //   493: aaload
    //   494: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   497: if_acmpne -> 512
    //   500: iload #19
    //   502: istore #16
    //   504: iload #19
    //   506: ifne -> 512
    //   509: iconst_3
    //   510: istore #16
    //   512: iload #20
    //   514: istore #14
    //   516: aload_0
    //   517: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   520: iconst_1
    //   521: aaload
    //   522: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   525: if_acmpne -> 540
    //   528: iload #20
    //   530: istore #14
    //   532: iload #20
    //   534: ifne -> 540
    //   537: iconst_3
    //   538: istore #14
    //   540: aload_0
    //   541: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   544: iconst_0
    //   545: aaload
    //   546: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   549: if_acmpne -> 591
    //   552: aload_0
    //   553: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   556: iconst_1
    //   557: aaload
    //   558: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   561: if_acmpne -> 591
    //   564: iload #16
    //   566: iconst_3
    //   567: if_icmpne -> 591
    //   570: iload #14
    //   572: iconst_3
    //   573: if_icmpne -> 591
    //   576: aload_0
    //   577: iload #11
    //   579: iload #8
    //   581: iload #12
    //   583: iload #17
    //   585: invokevirtual setupDimensionRatio : (ZZZZ)V
    //   588: goto -> 787
    //   591: aload_0
    //   592: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   595: iconst_0
    //   596: aaload
    //   597: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   600: if_acmpne -> 683
    //   603: iload #16
    //   605: iconst_3
    //   606: if_icmpne -> 683
    //   609: aload_0
    //   610: iconst_0
    //   611: putfield mResolvedDimensionRatioSide : I
    //   614: aload_0
    //   615: getfield mResolvedDimensionRatio : F
    //   618: aload_0
    //   619: getfield mHeight : I
    //   622: i2f
    //   623: fmul
    //   624: f2i
    //   625: istore #20
    //   627: aload_0
    //   628: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   631: iconst_1
    //   632: aaload
    //   633: astore #21
    //   635: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   638: astore #7
    //   640: aload #21
    //   642: aload #7
    //   644: if_acmpeq -> 665
    //   647: iload #13
    //   649: istore #16
    //   651: iload #14
    //   653: istore #15
    //   655: iconst_4
    //   656: istore #13
    //   658: iload #20
    //   660: istore #14
    //   662: goto -> 821
    //   665: iload #16
    //   667: istore #15
    //   669: iconst_1
    //   670: istore #16
    //   672: iload #20
    //   674: istore #19
    //   676: iload #13
    //   678: istore #20
    //   680: goto -> 844
    //   683: aload_0
    //   684: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   687: iconst_1
    //   688: aaload
    //   689: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   692: if_acmpne -> 787
    //   695: iload #14
    //   697: iconst_3
    //   698: if_icmpne -> 787
    //   701: aload_0
    //   702: iconst_1
    //   703: putfield mResolvedDimensionRatioSide : I
    //   706: aload_0
    //   707: getfield mDimensionRatioSide : I
    //   710: iconst_m1
    //   711: if_icmpne -> 724
    //   714: aload_0
    //   715: fconst_1
    //   716: aload_0
    //   717: getfield mResolvedDimensionRatio : F
    //   720: fdiv
    //   721: putfield mResolvedDimensionRatio : F
    //   724: aload_0
    //   725: getfield mResolvedDimensionRatio : F
    //   728: aload_0
    //   729: getfield mWidth : I
    //   732: i2f
    //   733: fmul
    //   734: f2i
    //   735: istore #20
    //   737: aload_0
    //   738: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   741: iconst_0
    //   742: aaload
    //   743: astore #7
    //   745: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   748: astore #21
    //   750: iload #16
    //   752: istore #22
    //   754: iload #15
    //   756: istore #19
    //   758: iload #20
    //   760: istore #13
    //   762: aload #7
    //   764: aload #21
    //   766: if_acmpeq -> 787
    //   769: iconst_4
    //   770: istore #15
    //   772: iload #22
    //   774: istore #13
    //   776: iload #19
    //   778: istore #14
    //   780: iload #20
    //   782: istore #16
    //   784: goto -> 821
    //   787: iload #15
    //   789: istore #19
    //   791: iload #16
    //   793: istore #15
    //   795: iconst_1
    //   796: istore #16
    //   798: iload #13
    //   800: istore #20
    //   802: goto -> 844
    //   805: iload #13
    //   807: istore #16
    //   809: iload #15
    //   811: istore #14
    //   813: iload #20
    //   815: istore #15
    //   817: iload #19
    //   819: istore #13
    //   821: iconst_0
    //   822: istore #22
    //   824: iload #16
    //   826: istore #20
    //   828: iload #14
    //   830: istore #19
    //   832: iload #22
    //   834: istore #16
    //   836: iload #15
    //   838: istore #14
    //   840: iload #13
    //   842: istore #15
    //   844: aload_0
    //   845: getfield mResolvedMatchConstraintDefault : [I
    //   848: astore #7
    //   850: aload #7
    //   852: iconst_0
    //   853: iload #15
    //   855: iastore
    //   856: aload #7
    //   858: iconst_1
    //   859: iload #14
    //   861: iastore
    //   862: iload #16
    //   864: ifeq -> 890
    //   867: aload_0
    //   868: getfield mResolvedDimensionRatioSide : I
    //   871: istore #13
    //   873: iload #13
    //   875: ifeq -> 884
    //   878: iload #13
    //   880: iconst_m1
    //   881: if_icmpne -> 890
    //   884: iconst_1
    //   885: istore #12
    //   887: goto -> 893
    //   890: iconst_0
    //   891: istore #12
    //   893: aload_0
    //   894: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   897: iconst_0
    //   898: aaload
    //   899: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   902: if_acmpne -> 918
    //   905: aload_0
    //   906: instanceof androidx/constraintlayout/solver/widgets/ConstraintWidgetContainer
    //   909: ifeq -> 918
    //   912: iconst_1
    //   913: istore #17
    //   915: goto -> 921
    //   918: iconst_0
    //   919: istore #17
    //   921: aload_0
    //   922: getfield mCenter : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   925: invokevirtual isConnected : ()Z
    //   928: iconst_1
    //   929: ixor
    //   930: istore #23
    //   932: aload_0
    //   933: getfield mHorizontalResolution : I
    //   936: iconst_2
    //   937: if_icmpeq -> 1066
    //   940: aload_0
    //   941: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   944: astore #7
    //   946: aload #7
    //   948: ifnull -> 965
    //   951: aload_1
    //   952: aload #7
    //   954: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   957: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   960: astore #7
    //   962: goto -> 968
    //   965: aconst_null
    //   966: astore #7
    //   968: aload_0
    //   969: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   972: astore #21
    //   974: aload #21
    //   976: ifnull -> 993
    //   979: aload_1
    //   980: aload #21
    //   982: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   985: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   988: astore #21
    //   990: goto -> 996
    //   993: aconst_null
    //   994: astore #21
    //   996: aload_0
    //   997: aload_1
    //   998: iload #11
    //   1000: aload #21
    //   1002: aload #7
    //   1004: aload_0
    //   1005: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1008: iconst_0
    //   1009: aaload
    //   1010: iload #17
    //   1012: aload_0
    //   1013: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1016: aload_0
    //   1017: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1020: aload_0
    //   1021: getfield mX : I
    //   1024: iload #19
    //   1026: aload_0
    //   1027: getfield mMinWidth : I
    //   1030: aload_0
    //   1031: getfield mMaxDimension : [I
    //   1034: iconst_0
    //   1035: iaload
    //   1036: aload_0
    //   1037: getfield mHorizontalBiasPercent : F
    //   1040: iload #12
    //   1042: iload #10
    //   1044: iload #15
    //   1046: aload_0
    //   1047: getfield mMatchConstraintMinWidth : I
    //   1050: aload_0
    //   1051: getfield mMatchConstraintMaxWidth : I
    //   1054: aload_0
    //   1055: getfield mMatchConstraintPercentWidth : F
    //   1058: iload #23
    //   1060: invokespecial applyConstraints : (Landroidx/constraintlayout/solver/LinearSystem;ZLandroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;ZLandroidx/constraintlayout/solver/widgets/ConstraintAnchor;Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;IIIIFZZIIIFZ)V
    //   1063: goto -> 1066
    //   1066: aload_0
    //   1067: getfield mVerticalResolution : I
    //   1070: iconst_2
    //   1071: if_icmpne -> 1075
    //   1074: return
    //   1075: aload_0
    //   1076: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1079: iconst_1
    //   1080: aaload
    //   1081: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1084: if_acmpne -> 1100
    //   1087: aload_0
    //   1088: instanceof androidx/constraintlayout/solver/widgets/ConstraintWidgetContainer
    //   1091: ifeq -> 1100
    //   1094: iconst_1
    //   1095: istore #10
    //   1097: goto -> 1103
    //   1100: iconst_0
    //   1101: istore #10
    //   1103: iload #16
    //   1105: ifeq -> 1132
    //   1108: aload_0
    //   1109: getfield mResolvedDimensionRatioSide : I
    //   1112: istore #13
    //   1114: iload #13
    //   1116: iconst_1
    //   1117: if_icmpeq -> 1126
    //   1120: iload #13
    //   1122: iconst_m1
    //   1123: if_icmpne -> 1132
    //   1126: iconst_1
    //   1127: istore #11
    //   1129: goto -> 1135
    //   1132: iconst_0
    //   1133: istore #11
    //   1135: aload_0
    //   1136: getfield mBaselineDistance : I
    //   1139: ifle -> 1222
    //   1142: aload_0
    //   1143: getfield mBaseline : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1146: invokevirtual getResolutionNode : ()Landroidx/constraintlayout/solver/widgets/ResolutionAnchor;
    //   1149: getfield state : I
    //   1152: iconst_1
    //   1153: if_icmpne -> 1170
    //   1156: aload_0
    //   1157: getfield mBaseline : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1160: invokevirtual getResolutionNode : ()Landroidx/constraintlayout/solver/widgets/ResolutionAnchor;
    //   1163: aload_1
    //   1164: invokevirtual addResolvedValue : (Landroidx/constraintlayout/solver/LinearSystem;)V
    //   1167: goto -> 1222
    //   1170: aload_1
    //   1171: aload #6
    //   1173: aload #4
    //   1175: aload_0
    //   1176: invokevirtual getBaselineDistance : ()I
    //   1179: bipush #6
    //   1181: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   1184: pop
    //   1185: aload_0
    //   1186: getfield mBaseline : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1189: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1192: ifnull -> 1222
    //   1195: aload_1
    //   1196: aload #6
    //   1198: aload_1
    //   1199: aload_0
    //   1200: getfield mBaseline : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1203: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1206: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   1209: iconst_0
    //   1210: bipush #6
    //   1212: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   1215: pop
    //   1216: iconst_0
    //   1217: istore #12
    //   1219: goto -> 1226
    //   1222: iload #23
    //   1224: istore #12
    //   1226: aload_0
    //   1227: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1230: astore #7
    //   1232: aload #7
    //   1234: ifnull -> 1251
    //   1237: aload_1
    //   1238: aload #7
    //   1240: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1243: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   1246: astore #7
    //   1248: goto -> 1254
    //   1251: aconst_null
    //   1252: astore #7
    //   1254: aload_0
    //   1255: getfield mParent : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1258: astore #21
    //   1260: aload #21
    //   1262: ifnull -> 1279
    //   1265: aload_1
    //   1266: aload #21
    //   1268: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1271: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/solver/SolverVariable;
    //   1274: astore #21
    //   1276: goto -> 1282
    //   1279: aconst_null
    //   1280: astore #21
    //   1282: aload_0
    //   1283: aload_1
    //   1284: iload #8
    //   1286: aload #21
    //   1288: aload #7
    //   1290: aload_0
    //   1291: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1294: iconst_1
    //   1295: aaload
    //   1296: iload #10
    //   1298: aload_0
    //   1299: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1302: aload_0
    //   1303: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1306: aload_0
    //   1307: getfield mY : I
    //   1310: iload #20
    //   1312: aload_0
    //   1313: getfield mMinHeight : I
    //   1316: aload_0
    //   1317: getfield mMaxDimension : [I
    //   1320: iconst_1
    //   1321: iaload
    //   1322: aload_0
    //   1323: getfield mVerticalBiasPercent : F
    //   1326: iload #11
    //   1328: iload #9
    //   1330: iload #14
    //   1332: aload_0
    //   1333: getfield mMatchConstraintMinHeight : I
    //   1336: aload_0
    //   1337: getfield mMatchConstraintMaxHeight : I
    //   1340: aload_0
    //   1341: getfield mMatchConstraintPercentHeight : F
    //   1344: iload #12
    //   1346: invokespecial applyConstraints : (Landroidx/constraintlayout/solver/LinearSystem;ZLandroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;ZLandroidx/constraintlayout/solver/widgets/ConstraintAnchor;Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;IIIIFZZIIIFZ)V
    //   1349: iload #16
    //   1351: ifeq -> 1400
    //   1354: aload_0
    //   1355: getfield mResolvedDimensionRatioSide : I
    //   1358: iconst_1
    //   1359: if_icmpne -> 1381
    //   1362: aload_1
    //   1363: aload #5
    //   1365: aload #4
    //   1367: aload_3
    //   1368: aload_2
    //   1369: aload_0
    //   1370: getfield mResolvedDimensionRatio : F
    //   1373: bipush #6
    //   1375: invokevirtual addRatio : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;FI)V
    //   1378: goto -> 1400
    //   1381: aload_1
    //   1382: aload_3
    //   1383: aload_2
    //   1384: aload #5
    //   1386: aload #4
    //   1388: aload_0
    //   1389: getfield mResolvedDimensionRatio : F
    //   1392: bipush #6
    //   1394: invokevirtual addRatio : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;FI)V
    //   1397: goto -> 1400
    //   1400: aload_0
    //   1401: getfield mCenter : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1404: invokevirtual isConnected : ()Z
    //   1407: ifeq -> 1445
    //   1410: aload_1
    //   1411: aload_0
    //   1412: aload_0
    //   1413: getfield mCenter : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1416: invokevirtual getTarget : ()Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1419: invokevirtual getOwner : ()Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1422: aload_0
    //   1423: getfield mCircleConstraintAngle : F
    //   1426: ldc_w 90.0
    //   1429: fadd
    //   1430: f2d
    //   1431: invokestatic toRadians : (D)D
    //   1434: d2f
    //   1435: aload_0
    //   1436: getfield mCenter : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1439: invokevirtual getMargin : ()I
    //   1442: invokevirtual addCenterPoint : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/ConstraintWidget;FI)V
    //   1445: return
  }
  
  public boolean allowedInBarrier() {
    boolean bool;
    if (this.mVisibility != 8) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public void analyze(int paramInt) {
    Optimizer.analyze(paramInt, this);
  }
  
  public void connect(ConstraintAnchor.Type paramType1, ConstraintWidget paramConstraintWidget, ConstraintAnchor.Type paramType2) {
    connect(paramType1, paramConstraintWidget, paramType2, 0, ConstraintAnchor.Strength.STRONG);
  }
  
  public void connect(ConstraintAnchor.Type paramType1, ConstraintWidget paramConstraintWidget, ConstraintAnchor.Type paramType2, int paramInt) {
    connect(paramType1, paramConstraintWidget, paramType2, paramInt, ConstraintAnchor.Strength.STRONG);
  }
  
  public void connect(ConstraintAnchor.Type paramType1, ConstraintWidget paramConstraintWidget, ConstraintAnchor.Type paramType2, int paramInt, ConstraintAnchor.Strength paramStrength) {
    connect(paramType1, paramConstraintWidget, paramType2, paramInt, paramStrength, 0);
  }
  
  public void connect(ConstraintAnchor.Type paramType1, ConstraintWidget paramConstraintWidget, ConstraintAnchor.Type paramType2, int paramInt1, ConstraintAnchor.Strength paramStrength, int paramInt2) {
    ConstraintAnchor constraintAnchor;
    ConstraintAnchor.Type type = ConstraintAnchor.Type.CENTER;
    boolean bool = false;
    if (paramType1 == type) {
      if (paramType2 == ConstraintAnchor.Type.CENTER) {
        ConstraintAnchor constraintAnchor2 = getAnchor(ConstraintAnchor.Type.LEFT);
        ConstraintAnchor constraintAnchor1 = getAnchor(ConstraintAnchor.Type.RIGHT);
        constraintAnchor = getAnchor(ConstraintAnchor.Type.TOP);
        ConstraintAnchor constraintAnchor3 = getAnchor(ConstraintAnchor.Type.BOTTOM);
        bool = true;
        if ((constraintAnchor2 != null && constraintAnchor2.isConnected()) || (constraintAnchor1 != null && constraintAnchor1.isConnected())) {
          paramInt1 = 0;
        } else {
          connect(ConstraintAnchor.Type.LEFT, paramConstraintWidget, ConstraintAnchor.Type.LEFT, 0, paramStrength, paramInt2);
          connect(ConstraintAnchor.Type.RIGHT, paramConstraintWidget, ConstraintAnchor.Type.RIGHT, 0, paramStrength, paramInt2);
          paramInt1 = 1;
        } 
        if ((constraintAnchor != null && constraintAnchor.isConnected()) || (constraintAnchor3 != null && constraintAnchor3.isConnected())) {
          bool = false;
        } else {
          connect(ConstraintAnchor.Type.TOP, paramConstraintWidget, ConstraintAnchor.Type.TOP, 0, paramStrength, paramInt2);
          connect(ConstraintAnchor.Type.BOTTOM, paramConstraintWidget, ConstraintAnchor.Type.BOTTOM, 0, paramStrength, paramInt2);
        } 
        if (paramInt1 != 0 && bool) {
          getAnchor(ConstraintAnchor.Type.CENTER).connect(paramConstraintWidget.getAnchor(ConstraintAnchor.Type.CENTER), 0, paramInt2);
        } else if (paramInt1 != 0) {
          getAnchor(ConstraintAnchor.Type.CENTER_X).connect(paramConstraintWidget.getAnchor(ConstraintAnchor.Type.CENTER_X), 0, paramInt2);
        } else if (bool) {
          getAnchor(ConstraintAnchor.Type.CENTER_Y).connect(paramConstraintWidget.getAnchor(ConstraintAnchor.Type.CENTER_Y), 0, paramInt2);
        } 
      } else {
        if (constraintAnchor == ConstraintAnchor.Type.LEFT || constraintAnchor == ConstraintAnchor.Type.RIGHT) {
          connect(ConstraintAnchor.Type.LEFT, paramConstraintWidget, (ConstraintAnchor.Type)constraintAnchor, 0, paramStrength, paramInt2);
          paramType1 = ConstraintAnchor.Type.RIGHT;
          try {
            connect(paramType1, paramConstraintWidget, (ConstraintAnchor.Type)constraintAnchor, 0, paramStrength, paramInt2);
            getAnchor(ConstraintAnchor.Type.CENTER).connect(paramConstraintWidget.getAnchor((ConstraintAnchor.Type)constraintAnchor), 0, paramInt2);
            return;
          } finally {}
        } 
        if (constraintAnchor == ConstraintAnchor.Type.TOP || constraintAnchor == ConstraintAnchor.Type.BOTTOM) {
          connect(ConstraintAnchor.Type.TOP, paramConstraintWidget, (ConstraintAnchor.Type)constraintAnchor, 0, paramStrength, paramInt2);
          connect(ConstraintAnchor.Type.BOTTOM, paramConstraintWidget, (ConstraintAnchor.Type)constraintAnchor, 0, paramStrength, paramInt2);
          getAnchor(ConstraintAnchor.Type.CENTER).connect(paramConstraintWidget.getAnchor((ConstraintAnchor.Type)constraintAnchor), 0, paramInt2);
        } 
      } 
    } else {
      ConstraintAnchor constraintAnchor1;
      ConstraintAnchor constraintAnchor2;
      if (paramType1 == ConstraintAnchor.Type.CENTER_X && (constraintAnchor == ConstraintAnchor.Type.LEFT || constraintAnchor == ConstraintAnchor.Type.RIGHT)) {
        constraintAnchor1 = getAnchor(ConstraintAnchor.Type.LEFT);
        constraintAnchor = paramConstraintWidget.getAnchor((ConstraintAnchor.Type)constraintAnchor);
        constraintAnchor2 = getAnchor(ConstraintAnchor.Type.RIGHT);
        constraintAnchor1.connect(constraintAnchor, 0, paramInt2);
        constraintAnchor2.connect(constraintAnchor, 0, paramInt2);
        getAnchor(ConstraintAnchor.Type.CENTER_X).connect(constraintAnchor, 0, paramInt2);
      } else if (constraintAnchor1 == ConstraintAnchor.Type.CENTER_Y && (constraintAnchor == ConstraintAnchor.Type.TOP || constraintAnchor == ConstraintAnchor.Type.BOTTOM)) {
        constraintAnchor1 = constraintAnchor2.getAnchor((ConstraintAnchor.Type)constraintAnchor);
        getAnchor(ConstraintAnchor.Type.TOP).connect(constraintAnchor1, 0, paramInt2);
        getAnchor(ConstraintAnchor.Type.BOTTOM).connect(constraintAnchor1, 0, paramInt2);
        getAnchor(ConstraintAnchor.Type.CENTER_Y).connect(constraintAnchor1, 0, paramInt2);
      } else if (constraintAnchor1 == ConstraintAnchor.Type.CENTER_X && constraintAnchor == ConstraintAnchor.Type.CENTER_X) {
        getAnchor(ConstraintAnchor.Type.LEFT).connect(constraintAnchor2.getAnchor(ConstraintAnchor.Type.LEFT), 0, paramInt2);
        getAnchor(ConstraintAnchor.Type.RIGHT).connect(constraintAnchor2.getAnchor(ConstraintAnchor.Type.RIGHT), 0, paramInt2);
        getAnchor(ConstraintAnchor.Type.CENTER_X).connect(constraintAnchor2.getAnchor((ConstraintAnchor.Type)constraintAnchor), 0, paramInt2);
      } else if (constraintAnchor1 == ConstraintAnchor.Type.CENTER_Y && constraintAnchor == ConstraintAnchor.Type.CENTER_Y) {
        getAnchor(ConstraintAnchor.Type.TOP).connect(constraintAnchor2.getAnchor(ConstraintAnchor.Type.TOP), 0, paramInt2);
        getAnchor(ConstraintAnchor.Type.BOTTOM).connect(constraintAnchor2.getAnchor(ConstraintAnchor.Type.BOTTOM), 0, paramInt2);
        getAnchor(ConstraintAnchor.Type.CENTER_Y).connect(constraintAnchor2.getAnchor((ConstraintAnchor.Type)constraintAnchor), 0, paramInt2);
      } else {
        ConstraintAnchor constraintAnchor3 = getAnchor((ConstraintAnchor.Type)constraintAnchor1);
        constraintAnchor2 = constraintAnchor2.getAnchor((ConstraintAnchor.Type)constraintAnchor);
        if (constraintAnchor3.isValidConnection(constraintAnchor2)) {
          if (constraintAnchor1 == ConstraintAnchor.Type.BASELINE) {
            constraintAnchor = getAnchor(ConstraintAnchor.Type.TOP);
            constraintAnchor1 = getAnchor(ConstraintAnchor.Type.BOTTOM);
            if (constraintAnchor != null)
              constraintAnchor.reset(); 
            paramInt1 = bool;
            if (constraintAnchor1 != null) {
              constraintAnchor1.reset();
              paramInt1 = bool;
            } 
          } else if (constraintAnchor1 == ConstraintAnchor.Type.TOP || constraintAnchor1 == ConstraintAnchor.Type.BOTTOM) {
            constraintAnchor = getAnchor(ConstraintAnchor.Type.BASELINE);
            if (constraintAnchor != null)
              constraintAnchor.reset(); 
            constraintAnchor = getAnchor(ConstraintAnchor.Type.CENTER);
            if (constraintAnchor.getTarget() != constraintAnchor2)
              constraintAnchor.reset(); 
            constraintAnchor = getAnchor((ConstraintAnchor.Type)constraintAnchor1).getOpposite();
            constraintAnchor1 = getAnchor(ConstraintAnchor.Type.CENTER_Y);
            if (constraintAnchor1.isConnected()) {
              constraintAnchor.reset();
              constraintAnchor1.reset();
            } 
          } else if (constraintAnchor1 == ConstraintAnchor.Type.LEFT || constraintAnchor1 == ConstraintAnchor.Type.RIGHT) {
            constraintAnchor = getAnchor(ConstraintAnchor.Type.CENTER);
            if (constraintAnchor.getTarget() != constraintAnchor2)
              constraintAnchor.reset(); 
            constraintAnchor1 = getAnchor((ConstraintAnchor.Type)constraintAnchor1).getOpposite();
            constraintAnchor = getAnchor(ConstraintAnchor.Type.CENTER_X);
            if (constraintAnchor.isConnected()) {
              constraintAnchor1.reset();
              constraintAnchor.reset();
            } 
          } 
          constraintAnchor3.connect(constraintAnchor2, paramInt1, paramStrength, paramInt2);
          constraintAnchor2.getOwner().connectedTo(constraintAnchor3.getOwner());
        } 
      } 
    } 
  }
  
  public void connect(ConstraintAnchor paramConstraintAnchor1, ConstraintAnchor paramConstraintAnchor2, int paramInt) {
    connect(paramConstraintAnchor1, paramConstraintAnchor2, paramInt, ConstraintAnchor.Strength.STRONG, 0);
  }
  
  public void connect(ConstraintAnchor paramConstraintAnchor1, ConstraintAnchor paramConstraintAnchor2, int paramInt1, int paramInt2) {
    connect(paramConstraintAnchor1, paramConstraintAnchor2, paramInt1, ConstraintAnchor.Strength.STRONG, paramInt2);
  }
  
  public void connect(ConstraintAnchor paramConstraintAnchor1, ConstraintAnchor paramConstraintAnchor2, int paramInt1, ConstraintAnchor.Strength paramStrength, int paramInt2) {
    if (paramConstraintAnchor1.getOwner() == this)
      connect(paramConstraintAnchor1.getType(), paramConstraintAnchor2.getOwner(), paramConstraintAnchor2.getType(), paramInt1, paramStrength, paramInt2); 
  }
  
  public void connectCircularConstraint(ConstraintWidget paramConstraintWidget, float paramFloat, int paramInt) {
    immediateConnect(ConstraintAnchor.Type.CENTER, paramConstraintWidget, ConstraintAnchor.Type.CENTER, paramInt, 0);
    this.mCircleConstraintAngle = paramFloat;
  }
  
  public void connectedTo(ConstraintWidget paramConstraintWidget) {}
  
  public void createObjectVariables(LinearSystem paramLinearSystem) {
    paramLinearSystem.createObjectVariable(this.mLeft);
    paramLinearSystem.createObjectVariable(this.mTop);
    paramLinearSystem.createObjectVariable(this.mRight);
    paramLinearSystem.createObjectVariable(this.mBottom);
    if (this.mBaselineDistance > 0)
      paramLinearSystem.createObjectVariable(this.mBaseline); 
  }
  
  public void disconnectUnlockedWidget(ConstraintWidget paramConstraintWidget) {
    ArrayList<ConstraintAnchor> arrayList = getAnchors();
    int i = arrayList.size();
    for (byte b = 0; b < i; b++) {
      ConstraintAnchor constraintAnchor = arrayList.get(b);
      if (constraintAnchor.isConnected() && constraintAnchor.getTarget().getOwner() == paramConstraintWidget && constraintAnchor.getConnectionCreator() == 2)
        constraintAnchor.reset(); 
    } 
  }
  
  public void disconnectWidget(ConstraintWidget paramConstraintWidget) {
    ArrayList<ConstraintAnchor> arrayList = getAnchors();
    int i = arrayList.size();
    for (byte b = 0; b < i; b++) {
      ConstraintAnchor constraintAnchor = arrayList.get(b);
      if (constraintAnchor.isConnected() && constraintAnchor.getTarget().getOwner() == paramConstraintWidget)
        constraintAnchor.reset(); 
    } 
  }
  
  public void forceUpdateDrawPosition() {
    int i = this.mX;
    int j = this.mY;
    int k = this.mWidth;
    int m = this.mHeight;
    this.mDrawX = i;
    this.mDrawY = j;
    this.mDrawWidth = k + i - i;
    this.mDrawHeight = m + j - j;
  }
  
  public ConstraintAnchor getAnchor(ConstraintAnchor.Type paramType) {
    switch (paramType) {
      default:
        throw new AssertionError(paramType.name());
      case null:
        return null;
      case null:
        return this.mCenterY;
      case null:
        return this.mCenterX;
      case null:
        return this.mCenter;
      case null:
        return this.mBaseline;
      case MATCH_CONSTRAINT:
        return this.mBottom;
      case MATCH_PARENT:
        return this.mRight;
      case WRAP_CONTENT:
        return this.mTop;
      case FIXED:
        break;
    } 
    return this.mLeft;
  }
  
  public ArrayList<ConstraintAnchor> getAnchors() {
    return this.mAnchors;
  }
  
  public int getBaselineDistance() {
    return this.mBaselineDistance;
  }
  
  public float getBiasPercent(int paramInt) {
    return (paramInt == 0) ? this.mHorizontalBiasPercent : ((paramInt == 1) ? this.mVerticalBiasPercent : -1.0F);
  }
  
  public int getBottom() {
    return getY() + this.mHeight;
  }
  
  public Object getCompanionWidget() {
    return this.mCompanionWidget;
  }
  
  public int getContainerItemSkip() {
    return this.mContainerItemSkip;
  }
  
  public String getDebugName() {
    return this.mDebugName;
  }
  
  public DimensionBehaviour getDimensionBehaviour(int paramInt) {
    return (paramInt == 0) ? getHorizontalDimensionBehaviour() : ((paramInt == 1) ? getVerticalDimensionBehaviour() : null);
  }
  
  public float getDimensionRatio() {
    return this.mDimensionRatio;
  }
  
  public int getDimensionRatioSide() {
    return this.mDimensionRatioSide;
  }
  
  public int getDrawBottom() {
    return getDrawY() + this.mDrawHeight;
  }
  
  public int getDrawHeight() {
    return this.mDrawHeight;
  }
  
  public int getDrawRight() {
    return getDrawX() + this.mDrawWidth;
  }
  
  public int getDrawWidth() {
    return this.mDrawWidth;
  }
  
  public int getDrawX() {
    return this.mDrawX + this.mOffsetX;
  }
  
  public int getDrawY() {
    return this.mDrawY + this.mOffsetY;
  }
  
  public int getHeight() {
    return (this.mVisibility == 8) ? 0 : this.mHeight;
  }
  
  public float getHorizontalBiasPercent() {
    return this.mHorizontalBiasPercent;
  }
  
  public ConstraintWidget getHorizontalChainControlWidget() {
    ConstraintWidget constraintWidget;
    if (isInHorizontalChain()) {
      ConstraintWidget constraintWidget1 = this;
      ConstraintAnchor constraintAnchor = null;
      while (true) {
        constraintWidget = (ConstraintWidget)constraintAnchor;
        if (constraintAnchor == null) {
          constraintWidget = (ConstraintWidget)constraintAnchor;
          if (constraintWidget1 != null) {
            ConstraintWidget constraintWidget2;
            ConstraintAnchor constraintAnchor1;
            constraintWidget = (ConstraintWidget)constraintWidget1.getAnchor(ConstraintAnchor.Type.LEFT);
            if (constraintWidget == null) {
              constraintWidget = null;
            } else {
              constraintWidget = (ConstraintWidget)constraintWidget.getTarget();
            } 
            if (constraintWidget == null) {
              constraintWidget = null;
            } else {
              constraintWidget2 = constraintWidget.getOwner();
            } 
            if (constraintWidget2 == getParent()) {
              constraintWidget2 = constraintWidget1;
              break;
            } 
            if (constraintWidget2 == null) {
              constraintAnchor1 = null;
            } else {
              constraintAnchor1 = constraintWidget2.getAnchor(ConstraintAnchor.Type.RIGHT).getTarget();
            } 
            if (constraintAnchor1 != null && constraintAnchor1.getOwner() != constraintWidget1) {
              ConstraintWidget constraintWidget3 = constraintWidget1;
              continue;
            } 
            constraintWidget1 = constraintWidget2;
            continue;
          } 
        } 
        break;
      } 
    } else {
      constraintWidget = null;
    } 
    return constraintWidget;
  }
  
  public int getHorizontalChainStyle() {
    return this.mHorizontalChainStyle;
  }
  
  public DimensionBehaviour getHorizontalDimensionBehaviour() {
    return this.mListDimensionBehaviors[0];
  }
  
  public int getInternalDrawBottom() {
    return this.mDrawY + this.mDrawHeight;
  }
  
  public int getInternalDrawRight() {
    return this.mDrawX + this.mDrawWidth;
  }
  
  int getInternalDrawX() {
    return this.mDrawX;
  }
  
  int getInternalDrawY() {
    return this.mDrawY;
  }
  
  public int getLeft() {
    return getX();
  }
  
  public int getLength(int paramInt) {
    return (paramInt == 0) ? getWidth() : ((paramInt == 1) ? getHeight() : 0);
  }
  
  public int getMaxHeight() {
    return this.mMaxDimension[1];
  }
  
  public int getMaxWidth() {
    return this.mMaxDimension[0];
  }
  
  public int getMinHeight() {
    return this.mMinHeight;
  }
  
  public int getMinWidth() {
    return this.mMinWidth;
  }
  
  public int getOptimizerWrapHeight() {
    int i = this.mHeight;
    int j = i;
    if (this.mListDimensionBehaviors[1] == DimensionBehaviour.MATCH_CONSTRAINT) {
      if (this.mMatchConstraintDefaultHeight == 1) {
        i = Math.max(this.mMatchConstraintMinHeight, i);
      } else {
        i = this.mMatchConstraintMinHeight;
        if (i > 0) {
          this.mHeight = i;
        } else {
          i = 0;
        } 
      } 
      int k = this.mMatchConstraintMaxHeight;
      j = i;
      if (k > 0) {
        j = i;
        if (k < i)
          j = k; 
      } 
    } 
    return j;
  }
  
  public int getOptimizerWrapWidth() {
    int i = this.mWidth;
    int j = i;
    if (this.mListDimensionBehaviors[0] == DimensionBehaviour.MATCH_CONSTRAINT) {
      if (this.mMatchConstraintDefaultWidth == 1) {
        i = Math.max(this.mMatchConstraintMinWidth, i);
      } else {
        i = this.mMatchConstraintMinWidth;
        if (i > 0) {
          this.mWidth = i;
        } else {
          i = 0;
        } 
      } 
      int k = this.mMatchConstraintMaxWidth;
      j = i;
      if (k > 0) {
        j = i;
        if (k < i)
          j = k; 
      } 
    } 
    return j;
  }
  
  public ConstraintWidget getParent() {
    return this.mParent;
  }
  
  int getRelativePositioning(int paramInt) {
    return (paramInt == 0) ? this.mRelX : ((paramInt == 1) ? this.mRelY : 0);
  }
  
  public ResolutionDimension getResolutionHeight() {
    if (this.mResolutionHeight == null)
      this.mResolutionHeight = new ResolutionDimension(); 
    return this.mResolutionHeight;
  }
  
  public ResolutionDimension getResolutionWidth() {
    if (this.mResolutionWidth == null)
      this.mResolutionWidth = new ResolutionDimension(); 
    return this.mResolutionWidth;
  }
  
  public int getRight() {
    return getX() + this.mWidth;
  }
  
  public WidgetContainer getRootWidgetContainer() {
    ConstraintWidget constraintWidget;
    for (constraintWidget = this; constraintWidget.getParent() != null; constraintWidget = constraintWidget.getParent());
    return (constraintWidget instanceof WidgetContainer) ? (WidgetContainer)constraintWidget : null;
  }
  
  protected int getRootX() {
    return this.mX + this.mOffsetX;
  }
  
  protected int getRootY() {
    return this.mY + this.mOffsetY;
  }
  
  public int getTop() {
    return getY();
  }
  
  public String getType() {
    return this.mType;
  }
  
  public float getVerticalBiasPercent() {
    return this.mVerticalBiasPercent;
  }
  
  public ConstraintWidget getVerticalChainControlWidget() {
    ConstraintWidget constraintWidget;
    if (isInVerticalChain()) {
      ConstraintWidget constraintWidget1 = this;
      ConstraintAnchor constraintAnchor = null;
      while (true) {
        constraintWidget = (ConstraintWidget)constraintAnchor;
        if (constraintAnchor == null) {
          constraintWidget = (ConstraintWidget)constraintAnchor;
          if (constraintWidget1 != null) {
            ConstraintWidget constraintWidget2;
            ConstraintAnchor constraintAnchor1;
            constraintWidget = (ConstraintWidget)constraintWidget1.getAnchor(ConstraintAnchor.Type.TOP);
            if (constraintWidget == null) {
              constraintWidget = null;
            } else {
              constraintWidget = (ConstraintWidget)constraintWidget.getTarget();
            } 
            if (constraintWidget == null) {
              constraintWidget = null;
            } else {
              constraintWidget2 = constraintWidget.getOwner();
            } 
            if (constraintWidget2 == getParent()) {
              constraintWidget2 = constraintWidget1;
              break;
            } 
            if (constraintWidget2 == null) {
              constraintAnchor1 = null;
            } else {
              constraintAnchor1 = constraintWidget2.getAnchor(ConstraintAnchor.Type.BOTTOM).getTarget();
            } 
            if (constraintAnchor1 != null && constraintAnchor1.getOwner() != constraintWidget1) {
              ConstraintWidget constraintWidget3 = constraintWidget1;
              continue;
            } 
            constraintWidget1 = constraintWidget2;
            continue;
          } 
        } 
        break;
      } 
    } else {
      constraintWidget = null;
    } 
    return constraintWidget;
  }
  
  public int getVerticalChainStyle() {
    return this.mVerticalChainStyle;
  }
  
  public DimensionBehaviour getVerticalDimensionBehaviour() {
    return this.mListDimensionBehaviors[1];
  }
  
  public int getVisibility() {
    return this.mVisibility;
  }
  
  public int getWidth() {
    return (this.mVisibility == 8) ? 0 : this.mWidth;
  }
  
  public int getWrapHeight() {
    return this.mWrapHeight;
  }
  
  public int getWrapWidth() {
    return this.mWrapWidth;
  }
  
  public int getX() {
    return this.mX;
  }
  
  public int getY() {
    return this.mY;
  }
  
  public boolean hasAncestor(ConstraintWidget paramConstraintWidget) {
    ConstraintWidget constraintWidget1 = getParent();
    if (constraintWidget1 == paramConstraintWidget)
      return true; 
    ConstraintWidget constraintWidget2 = constraintWidget1;
    if (constraintWidget1 == paramConstraintWidget.getParent())
      return false; 
    while (constraintWidget2 != null) {
      if (constraintWidget2 == paramConstraintWidget)
        return true; 
      if (constraintWidget2 == paramConstraintWidget.getParent())
        return true; 
      constraintWidget2 = constraintWidget2.getParent();
    } 
    return false;
  }
  
  public boolean hasBaseline() {
    boolean bool;
    if (this.mBaselineDistance > 0) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public void immediateConnect(ConstraintAnchor.Type paramType1, ConstraintWidget paramConstraintWidget, ConstraintAnchor.Type paramType2, int paramInt1, int paramInt2) {
    getAnchor(paramType1).connect(paramConstraintWidget.getAnchor(paramType2), paramInt1, paramInt2, ConstraintAnchor.Strength.STRONG, 0, true);
  }
  
  public boolean isFullyResolved() {
    return ((this.mLeft.getResolutionNode()).state == 1 && (this.mRight.getResolutionNode()).state == 1 && (this.mTop.getResolutionNode()).state == 1 && (this.mBottom.getResolutionNode()).state == 1);
  }
  
  public boolean isHeightWrapContent() {
    return this.mIsHeightWrapContent;
  }
  
  public boolean isInHorizontalChain() {
    return ((this.mLeft.mTarget != null && this.mLeft.mTarget.mTarget == this.mLeft) || (this.mRight.mTarget != null && this.mRight.mTarget.mTarget == this.mRight));
  }
  
  public boolean isInVerticalChain() {
    return ((this.mTop.mTarget != null && this.mTop.mTarget.mTarget == this.mTop) || (this.mBottom.mTarget != null && this.mBottom.mTarget.mTarget == this.mBottom));
  }
  
  public boolean isInsideConstraintLayout() {
    ConstraintWidget constraintWidget1 = getParent();
    ConstraintWidget constraintWidget2 = constraintWidget1;
    if (constraintWidget1 == null)
      return false; 
    while (constraintWidget2 != null) {
      if (constraintWidget2 instanceof ConstraintWidgetContainer)
        return true; 
      constraintWidget2 = constraintWidget2.getParent();
    } 
    return false;
  }
  
  public boolean isRoot() {
    boolean bool;
    if (this.mParent == null) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public boolean isRootContainer() {
    if (this instanceof ConstraintWidgetContainer) {
      ConstraintWidget constraintWidget = this.mParent;
      if (constraintWidget == null || !(constraintWidget instanceof ConstraintWidgetContainer))
        return true; 
    } 
    return false;
  }
  
  public boolean isSpreadHeight() {
    int i = this.mMatchConstraintDefaultHeight;
    boolean bool = true;
    if (i != 0 || this.mDimensionRatio != 0.0F || this.mMatchConstraintMinHeight != 0 || this.mMatchConstraintMaxHeight != 0 || this.mListDimensionBehaviors[1] != DimensionBehaviour.MATCH_CONSTRAINT)
      bool = false; 
    return bool;
  }
  
  public boolean isSpreadWidth() {
    int i = this.mMatchConstraintDefaultWidth;
    boolean bool1 = false;
    boolean bool2 = bool1;
    if (i == 0) {
      bool2 = bool1;
      if (this.mDimensionRatio == 0.0F) {
        bool2 = bool1;
        if (this.mMatchConstraintMinWidth == 0) {
          bool2 = bool1;
          if (this.mMatchConstraintMaxWidth == 0) {
            bool2 = bool1;
            if (this.mListDimensionBehaviors[0] == DimensionBehaviour.MATCH_CONSTRAINT)
              bool2 = true; 
          } 
        } 
      } 
    } 
    return bool2;
  }
  
  public boolean isWidthWrapContent() {
    return this.mIsWidthWrapContent;
  }
  
  public void reset() {
    this.mLeft.reset();
    this.mTop.reset();
    this.mRight.reset();
    this.mBottom.reset();
    this.mBaseline.reset();
    this.mCenterX.reset();
    this.mCenterY.reset();
    this.mCenter.reset();
    this.mParent = null;
    this.mCircleConstraintAngle = 0.0F;
    this.mWidth = 0;
    this.mHeight = 0;
    this.mDimensionRatio = 0.0F;
    this.mDimensionRatioSide = -1;
    this.mX = 0;
    this.mY = 0;
    this.mDrawX = 0;
    this.mDrawY = 0;
    this.mDrawWidth = 0;
    this.mDrawHeight = 0;
    this.mOffsetX = 0;
    this.mOffsetY = 0;
    this.mBaselineDistance = 0;
    this.mMinWidth = 0;
    this.mMinHeight = 0;
    this.mWrapWidth = 0;
    this.mWrapHeight = 0;
    float f = DEFAULT_BIAS;
    this.mHorizontalBiasPercent = f;
    this.mVerticalBiasPercent = f;
    this.mListDimensionBehaviors[0] = DimensionBehaviour.FIXED;
    this.mListDimensionBehaviors[1] = DimensionBehaviour.FIXED;
    this.mCompanionWidget = null;
    this.mContainerItemSkip = 0;
    this.mVisibility = 0;
    this.mType = null;
    this.mHorizontalWrapVisited = false;
    this.mVerticalWrapVisited = false;
    this.mHorizontalChainStyle = 0;
    this.mVerticalChainStyle = 0;
    this.mHorizontalChainFixedPosition = false;
    this.mVerticalChainFixedPosition = false;
    float[] arrayOfFloat = this.mWeight;
    arrayOfFloat[0] = -1.0F;
    arrayOfFloat[1] = -1.0F;
    this.mHorizontalResolution = -1;
    this.mVerticalResolution = -1;
    int[] arrayOfInt = this.mMaxDimension;
    arrayOfInt[0] = Integer.MAX_VALUE;
    arrayOfInt[1] = Integer.MAX_VALUE;
    this.mMatchConstraintDefaultWidth = 0;
    this.mMatchConstraintDefaultHeight = 0;
    this.mMatchConstraintPercentWidth = 1.0F;
    this.mMatchConstraintPercentHeight = 1.0F;
    this.mMatchConstraintMaxWidth = Integer.MAX_VALUE;
    this.mMatchConstraintMaxHeight = Integer.MAX_VALUE;
    this.mMatchConstraintMinWidth = 0;
    this.mMatchConstraintMinHeight = 0;
    this.mResolvedDimensionRatioSide = -1;
    this.mResolvedDimensionRatio = 1.0F;
    ResolutionDimension resolutionDimension = this.mResolutionWidth;
    if (resolutionDimension != null)
      resolutionDimension.reset(); 
    resolutionDimension = this.mResolutionHeight;
    if (resolutionDimension != null)
      resolutionDimension.reset(); 
    this.mBelongingGroup = null;
    this.mOptimizerMeasurable = false;
    this.mOptimizerMeasured = false;
    this.mGroupsToSolver = false;
  }
  
  public void resetAllConstraints() {
    resetAnchors();
    setVerticalBiasPercent(DEFAULT_BIAS);
    setHorizontalBiasPercent(DEFAULT_BIAS);
    if (this instanceof ConstraintWidgetContainer)
      return; 
    if (getHorizontalDimensionBehaviour() == DimensionBehaviour.MATCH_CONSTRAINT)
      if (getWidth() == getWrapWidth()) {
        setHorizontalDimensionBehaviour(DimensionBehaviour.WRAP_CONTENT);
      } else if (getWidth() > getMinWidth()) {
        setHorizontalDimensionBehaviour(DimensionBehaviour.FIXED);
      }  
    if (getVerticalDimensionBehaviour() == DimensionBehaviour.MATCH_CONSTRAINT)
      if (getHeight() == getWrapHeight()) {
        setVerticalDimensionBehaviour(DimensionBehaviour.WRAP_CONTENT);
      } else if (getHeight() > getMinHeight()) {
        setVerticalDimensionBehaviour(DimensionBehaviour.FIXED);
      }  
  }
  
  public void resetAnchor(ConstraintAnchor paramConstraintAnchor) {
    if (getParent() != null && getParent() instanceof ConstraintWidgetContainer && ((ConstraintWidgetContainer)getParent()).handlesInternalConstraints())
      return; 
    ConstraintAnchor constraintAnchor1 = getAnchor(ConstraintAnchor.Type.LEFT);
    ConstraintAnchor constraintAnchor2 = getAnchor(ConstraintAnchor.Type.RIGHT);
    ConstraintAnchor constraintAnchor3 = getAnchor(ConstraintAnchor.Type.TOP);
    ConstraintAnchor constraintAnchor4 = getAnchor(ConstraintAnchor.Type.BOTTOM);
    ConstraintAnchor constraintAnchor5 = getAnchor(ConstraintAnchor.Type.CENTER);
    ConstraintAnchor constraintAnchor6 = getAnchor(ConstraintAnchor.Type.CENTER_X);
    ConstraintAnchor constraintAnchor7 = getAnchor(ConstraintAnchor.Type.CENTER_Y);
    if (paramConstraintAnchor == constraintAnchor5) {
      if (constraintAnchor1.isConnected() && constraintAnchor2.isConnected() && constraintAnchor1.getTarget() == constraintAnchor2.getTarget()) {
        constraintAnchor1.reset();
        constraintAnchor2.reset();
      } 
      if (constraintAnchor3.isConnected() && constraintAnchor4.isConnected() && constraintAnchor3.getTarget() == constraintAnchor4.getTarget()) {
        constraintAnchor3.reset();
        constraintAnchor4.reset();
      } 
      this.mHorizontalBiasPercent = 0.5F;
      this.mVerticalBiasPercent = 0.5F;
    } else if (paramConstraintAnchor == constraintAnchor6) {
      if (constraintAnchor1.isConnected() && constraintAnchor2.isConnected() && constraintAnchor1.getTarget().getOwner() == constraintAnchor2.getTarget().getOwner()) {
        constraintAnchor1.reset();
        constraintAnchor2.reset();
      } 
      this.mHorizontalBiasPercent = 0.5F;
    } else if (paramConstraintAnchor == constraintAnchor7) {
      if (constraintAnchor3.isConnected() && constraintAnchor4.isConnected() && constraintAnchor3.getTarget().getOwner() == constraintAnchor4.getTarget().getOwner()) {
        constraintAnchor3.reset();
        constraintAnchor4.reset();
      } 
      this.mVerticalBiasPercent = 0.5F;
    } else if (paramConstraintAnchor == constraintAnchor1 || paramConstraintAnchor == constraintAnchor2) {
      if (constraintAnchor1.isConnected() && constraintAnchor1.getTarget() == constraintAnchor2.getTarget())
        constraintAnchor5.reset(); 
    } else if ((paramConstraintAnchor == constraintAnchor3 || paramConstraintAnchor == constraintAnchor4) && constraintAnchor3.isConnected() && constraintAnchor3.getTarget() == constraintAnchor4.getTarget()) {
      constraintAnchor5.reset();
    } 
    paramConstraintAnchor.reset();
  }
  
  public void resetAnchors() {
    ConstraintWidget constraintWidget = getParent();
    if (constraintWidget != null && constraintWidget instanceof ConstraintWidgetContainer && ((ConstraintWidgetContainer)getParent()).handlesInternalConstraints())
      return; 
    byte b = 0;
    int i = this.mAnchors.size();
    while (b < i) {
      ((ConstraintAnchor)this.mAnchors.get(b)).reset();
      b++;
    } 
  }
  
  public void resetAnchors(int paramInt) {
    ConstraintWidget constraintWidget = getParent();
    if (constraintWidget != null && constraintWidget instanceof ConstraintWidgetContainer && ((ConstraintWidgetContainer)getParent()).handlesInternalConstraints())
      return; 
    byte b = 0;
    int i = this.mAnchors.size();
    while (b < i) {
      ConstraintAnchor constraintAnchor = this.mAnchors.get(b);
      if (paramInt == constraintAnchor.getConnectionCreator()) {
        if (constraintAnchor.isVerticalAnchor()) {
          setVerticalBiasPercent(DEFAULT_BIAS);
        } else {
          setHorizontalBiasPercent(DEFAULT_BIAS);
        } 
        constraintAnchor.reset();
      } 
      b++;
    } 
  }
  
  public void resetResolutionNodes() {
    for (byte b = 0; b < 6; b++)
      this.mListAnchors[b].getResolutionNode().reset(); 
  }
  
  public void resetSolverVariables(Cache paramCache) {
    this.mLeft.resetSolverVariable(paramCache);
    this.mTop.resetSolverVariable(paramCache);
    this.mRight.resetSolverVariable(paramCache);
    this.mBottom.resetSolverVariable(paramCache);
    this.mBaseline.resetSolverVariable(paramCache);
    this.mCenter.resetSolverVariable(paramCache);
    this.mCenterX.resetSolverVariable(paramCache);
    this.mCenterY.resetSolverVariable(paramCache);
  }
  
  public void resolve() {}
  
  public void setBaselineDistance(int paramInt) {
    this.mBaselineDistance = paramInt;
  }
  
  public void setCompanionWidget(Object paramObject) {
    this.mCompanionWidget = paramObject;
  }
  
  public void setContainerItemSkip(int paramInt) {
    if (paramInt >= 0) {
      this.mContainerItemSkip = paramInt;
    } else {
      this.mContainerItemSkip = 0;
    } 
  }
  
  public void setDebugName(String paramString) {
    this.mDebugName = paramString;
  }
  
  public void setDebugSolverName(LinearSystem paramLinearSystem, String paramString) {
    this.mDebugName = paramString;
    SolverVariable solverVariable1 = paramLinearSystem.createObjectVariable(this.mLeft);
    SolverVariable solverVariable2 = paramLinearSystem.createObjectVariable(this.mTop);
    SolverVariable solverVariable3 = paramLinearSystem.createObjectVariable(this.mRight);
    SolverVariable solverVariable4 = paramLinearSystem.createObjectVariable(this.mBottom);
    StringBuilder stringBuilder4 = new StringBuilder();
    stringBuilder4.append(paramString);
    stringBuilder4.append(".left");
    solverVariable1.setName(stringBuilder4.toString());
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append(paramString);
    stringBuilder1.append(".top");
    solverVariable2.setName(stringBuilder1.toString());
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append(paramString);
    stringBuilder2.append(".right");
    solverVariable3.setName(stringBuilder2.toString());
    StringBuilder stringBuilder3 = new StringBuilder();
    stringBuilder3.append(paramString);
    stringBuilder3.append(".bottom");
    solverVariable4.setName(stringBuilder3.toString());
    if (this.mBaselineDistance > 0) {
      solverVariable4 = paramLinearSystem.createObjectVariable(this.mBaseline);
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(paramString);
      stringBuilder.append(".baseline");
      solverVariable4.setName(stringBuilder.toString());
    } 
  }
  
  public void setDimension(int paramInt1, int paramInt2) {
    this.mWidth = paramInt1;
    int i = this.mWidth;
    paramInt1 = this.mMinWidth;
    if (i < paramInt1)
      this.mWidth = paramInt1; 
    this.mHeight = paramInt2;
    paramInt1 = this.mHeight;
    paramInt2 = this.mMinHeight;
    if (paramInt1 < paramInt2)
      this.mHeight = paramInt2; 
  }
  
  public void setDimensionRatio(float paramFloat, int paramInt) {
    this.mDimensionRatio = paramFloat;
    this.mDimensionRatioSide = paramInt;
  }
  
  public void setDimensionRatio(String paramString) {
    // Byte code:
    //   0: aload_1
    //   1: ifnull -> 263
    //   4: aload_1
    //   5: invokevirtual length : ()I
    //   8: ifne -> 14
    //   11: goto -> 263
    //   14: iconst_m1
    //   15: istore_2
    //   16: aload_1
    //   17: invokevirtual length : ()I
    //   20: istore_3
    //   21: aload_1
    //   22: bipush #44
    //   24: invokevirtual indexOf : (I)I
    //   27: istore #4
    //   29: iconst_0
    //   30: istore #5
    //   32: iload_2
    //   33: istore #6
    //   35: iload #5
    //   37: istore #7
    //   39: iload #4
    //   41: ifle -> 108
    //   44: iload_2
    //   45: istore #6
    //   47: iload #5
    //   49: istore #7
    //   51: iload #4
    //   53: iload_3
    //   54: iconst_1
    //   55: isub
    //   56: if_icmpge -> 108
    //   59: aload_1
    //   60: iconst_0
    //   61: iload #4
    //   63: invokevirtual substring : (II)Ljava/lang/String;
    //   66: astore #8
    //   68: aload #8
    //   70: ldc_w 'W'
    //   73: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   76: ifeq -> 85
    //   79: iconst_0
    //   80: istore #6
    //   82: goto -> 102
    //   85: iload_2
    //   86: istore #6
    //   88: aload #8
    //   90: ldc_w 'H'
    //   93: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   96: ifeq -> 102
    //   99: iconst_1
    //   100: istore #6
    //   102: iload #4
    //   104: iconst_1
    //   105: iadd
    //   106: istore #7
    //   108: aload_1
    //   109: bipush #58
    //   111: invokevirtual indexOf : (I)I
    //   114: istore_2
    //   115: iload_2
    //   116: iflt -> 217
    //   119: iload_2
    //   120: iload_3
    //   121: iconst_1
    //   122: isub
    //   123: if_icmpge -> 217
    //   126: aload_1
    //   127: iload #7
    //   129: iload_2
    //   130: invokevirtual substring : (II)Ljava/lang/String;
    //   133: astore #8
    //   135: aload_1
    //   136: iload_2
    //   137: iconst_1
    //   138: iadd
    //   139: invokevirtual substring : (I)Ljava/lang/String;
    //   142: astore_1
    //   143: aload #8
    //   145: invokevirtual length : ()I
    //   148: ifle -> 240
    //   151: aload_1
    //   152: invokevirtual length : ()I
    //   155: ifle -> 240
    //   158: aload #8
    //   160: invokestatic parseFloat : (Ljava/lang/String;)F
    //   163: fstore #9
    //   165: aload_1
    //   166: invokestatic parseFloat : (Ljava/lang/String;)F
    //   169: fstore #10
    //   171: fload #9
    //   173: fconst_0
    //   174: fcmpl
    //   175: ifle -> 240
    //   178: fload #10
    //   180: fconst_0
    //   181: fcmpl
    //   182: ifle -> 240
    //   185: iload #6
    //   187: iconst_1
    //   188: if_icmpne -> 204
    //   191: fload #10
    //   193: fload #9
    //   195: fdiv
    //   196: invokestatic abs : (F)F
    //   199: fstore #10
    //   201: goto -> 243
    //   204: fload #9
    //   206: fload #10
    //   208: fdiv
    //   209: invokestatic abs : (F)F
    //   212: fstore #10
    //   214: goto -> 243
    //   217: aload_1
    //   218: iload #7
    //   220: invokevirtual substring : (I)Ljava/lang/String;
    //   223: astore_1
    //   224: aload_1
    //   225: invokevirtual length : ()I
    //   228: ifle -> 240
    //   231: aload_1
    //   232: invokestatic parseFloat : (Ljava/lang/String;)F
    //   235: fstore #10
    //   237: goto -> 243
    //   240: fconst_0
    //   241: fstore #10
    //   243: fload #10
    //   245: fconst_0
    //   246: fcmpl
    //   247: ifle -> 262
    //   250: aload_0
    //   251: fload #10
    //   253: putfield mDimensionRatio : F
    //   256: aload_0
    //   257: iload #6
    //   259: putfield mDimensionRatioSide : I
    //   262: return
    //   263: aload_0
    //   264: fconst_0
    //   265: putfield mDimensionRatio : F
    //   268: return
    //   269: astore_1
    //   270: goto -> 240
    // Exception table:
    //   from	to	target	type
    //   158	171	269	java/lang/NumberFormatException
    //   191	201	269	java/lang/NumberFormatException
    //   204	214	269	java/lang/NumberFormatException
    //   231	237	269	java/lang/NumberFormatException
  }
  
  public void setDrawHeight(int paramInt) {
    this.mDrawHeight = paramInt;
  }
  
  public void setDrawOrigin(int paramInt1, int paramInt2) {
    this.mDrawX = paramInt1 - this.mOffsetX;
    this.mDrawY = paramInt2 - this.mOffsetY;
    this.mX = this.mDrawX;
    this.mY = this.mDrawY;
  }
  
  public void setDrawWidth(int paramInt) {
    this.mDrawWidth = paramInt;
  }
  
  public void setDrawX(int paramInt) {
    this.mDrawX = paramInt - this.mOffsetX;
    this.mX = this.mDrawX;
  }
  
  public void setDrawY(int paramInt) {
    this.mDrawY = paramInt - this.mOffsetY;
    this.mY = this.mDrawY;
  }
  
  public void setFrame(int paramInt1, int paramInt2, int paramInt3) {
    if (paramInt3 == 0) {
      setHorizontalDimension(paramInt1, paramInt2);
    } else if (paramInt3 == 1) {
      setVerticalDimension(paramInt1, paramInt2);
    } 
    this.mOptimizerMeasured = true;
  }
  
  public void setFrame(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    // Byte code:
    //   0: iload_3
    //   1: iload_1
    //   2: isub
    //   3: istore #5
    //   5: iload #4
    //   7: iload_2
    //   8: isub
    //   9: istore_3
    //   10: aload_0
    //   11: iload_1
    //   12: putfield mX : I
    //   15: aload_0
    //   16: iload_2
    //   17: putfield mY : I
    //   20: aload_0
    //   21: getfield mVisibility : I
    //   24: bipush #8
    //   26: if_icmpne -> 40
    //   29: aload_0
    //   30: iconst_0
    //   31: putfield mWidth : I
    //   34: aload_0
    //   35: iconst_0
    //   36: putfield mHeight : I
    //   39: return
    //   40: aload_0
    //   41: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   44: iconst_0
    //   45: aaload
    //   46: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   49: if_acmpne -> 66
    //   52: aload_0
    //   53: getfield mWidth : I
    //   56: istore_1
    //   57: iload #5
    //   59: iload_1
    //   60: if_icmpge -> 66
    //   63: goto -> 69
    //   66: iload #5
    //   68: istore_1
    //   69: aload_0
    //   70: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   73: iconst_1
    //   74: aaload
    //   75: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   78: if_acmpne -> 94
    //   81: aload_0
    //   82: getfield mHeight : I
    //   85: istore_2
    //   86: iload_3
    //   87: iload_2
    //   88: if_icmpge -> 94
    //   91: goto -> 96
    //   94: iload_3
    //   95: istore_2
    //   96: aload_0
    //   97: iload_1
    //   98: putfield mWidth : I
    //   101: aload_0
    //   102: iload_2
    //   103: putfield mHeight : I
    //   106: aload_0
    //   107: getfield mHeight : I
    //   110: istore_1
    //   111: aload_0
    //   112: getfield mMinHeight : I
    //   115: istore_2
    //   116: iload_1
    //   117: iload_2
    //   118: if_icmpge -> 126
    //   121: aload_0
    //   122: iload_2
    //   123: putfield mHeight : I
    //   126: aload_0
    //   127: getfield mWidth : I
    //   130: istore_1
    //   131: aload_0
    //   132: getfield mMinWidth : I
    //   135: istore_2
    //   136: iload_1
    //   137: iload_2
    //   138: if_icmpge -> 146
    //   141: aload_0
    //   142: iload_2
    //   143: putfield mWidth : I
    //   146: aload_0
    //   147: iconst_1
    //   148: putfield mOptimizerMeasured : Z
    //   151: return
  }
  
  public void setGoneMargin(ConstraintAnchor.Type paramType, int paramInt) {
    int i = null.$SwitchMap$androidx$constraintlayout$solver$widgets$ConstraintAnchor$Type[paramType.ordinal()];
    if (i != 1) {
      if (i != 2) {
        if (i != 3) {
          if (i == 4)
            this.mBottom.mGoneMargin = paramInt; 
        } else {
          this.mRight.mGoneMargin = paramInt;
        } 
      } else {
        this.mTop.mGoneMargin = paramInt;
      } 
    } else {
      this.mLeft.mGoneMargin = paramInt;
    } 
  }
  
  public void setHeight(int paramInt) {
    this.mHeight = paramInt;
    int i = this.mHeight;
    paramInt = this.mMinHeight;
    if (i < paramInt)
      this.mHeight = paramInt; 
  }
  
  public void setHeightWrapContent(boolean paramBoolean) {
    this.mIsHeightWrapContent = paramBoolean;
  }
  
  public void setHorizontalBiasPercent(float paramFloat) {
    this.mHorizontalBiasPercent = paramFloat;
  }
  
  public void setHorizontalChainStyle(int paramInt) {
    this.mHorizontalChainStyle = paramInt;
  }
  
  public void setHorizontalDimension(int paramInt1, int paramInt2) {
    this.mX = paramInt1;
    this.mWidth = paramInt2 - paramInt1;
    paramInt1 = this.mWidth;
    paramInt2 = this.mMinWidth;
    if (paramInt1 < paramInt2)
      this.mWidth = paramInt2; 
  }
  
  public void setHorizontalDimensionBehaviour(DimensionBehaviour paramDimensionBehaviour) {
    this.mListDimensionBehaviors[0] = paramDimensionBehaviour;
    if (paramDimensionBehaviour == DimensionBehaviour.WRAP_CONTENT)
      setWidth(this.mWrapWidth); 
  }
  
  public void setHorizontalMatchStyle(int paramInt1, int paramInt2, int paramInt3, float paramFloat) {
    this.mMatchConstraintDefaultWidth = paramInt1;
    this.mMatchConstraintMinWidth = paramInt2;
    this.mMatchConstraintMaxWidth = paramInt3;
    this.mMatchConstraintPercentWidth = paramFloat;
    if (paramFloat < 1.0F && this.mMatchConstraintDefaultWidth == 0)
      this.mMatchConstraintDefaultWidth = 2; 
  }
  
  public void setHorizontalWeight(float paramFloat) {
    this.mWeight[0] = paramFloat;
  }
  
  public void setLength(int paramInt1, int paramInt2) {
    if (paramInt2 == 0) {
      setWidth(paramInt1);
    } else if (paramInt2 == 1) {
      setHeight(paramInt1);
    } 
  }
  
  public void setMaxHeight(int paramInt) {
    this.mMaxDimension[1] = paramInt;
  }
  
  public void setMaxWidth(int paramInt) {
    this.mMaxDimension[0] = paramInt;
  }
  
  public void setMinHeight(int paramInt) {
    if (paramInt < 0) {
      this.mMinHeight = 0;
    } else {
      this.mMinHeight = paramInt;
    } 
  }
  
  public void setMinWidth(int paramInt) {
    if (paramInt < 0) {
      this.mMinWidth = 0;
    } else {
      this.mMinWidth = paramInt;
    } 
  }
  
  public void setOffset(int paramInt1, int paramInt2) {
    this.mOffsetX = paramInt1;
    this.mOffsetY = paramInt2;
  }
  
  public void setOrigin(int paramInt1, int paramInt2) {
    this.mX = paramInt1;
    this.mY = paramInt2;
  }
  
  public void setParent(ConstraintWidget paramConstraintWidget) {
    this.mParent = paramConstraintWidget;
  }
  
  void setRelativePositioning(int paramInt1, int paramInt2) {
    if (paramInt2 == 0) {
      this.mRelX = paramInt1;
    } else if (paramInt2 == 1) {
      this.mRelY = paramInt1;
    } 
  }
  
  public void setType(String paramString) {
    this.mType = paramString;
  }
  
  public void setVerticalBiasPercent(float paramFloat) {
    this.mVerticalBiasPercent = paramFloat;
  }
  
  public void setVerticalChainStyle(int paramInt) {
    this.mVerticalChainStyle = paramInt;
  }
  
  public void setVerticalDimension(int paramInt1, int paramInt2) {
    this.mY = paramInt1;
    this.mHeight = paramInt2 - paramInt1;
    paramInt1 = this.mHeight;
    paramInt2 = this.mMinHeight;
    if (paramInt1 < paramInt2)
      this.mHeight = paramInt2; 
  }
  
  public void setVerticalDimensionBehaviour(DimensionBehaviour paramDimensionBehaviour) {
    this.mListDimensionBehaviors[1] = paramDimensionBehaviour;
    if (paramDimensionBehaviour == DimensionBehaviour.WRAP_CONTENT)
      setHeight(this.mWrapHeight); 
  }
  
  public void setVerticalMatchStyle(int paramInt1, int paramInt2, int paramInt3, float paramFloat) {
    this.mMatchConstraintDefaultHeight = paramInt1;
    this.mMatchConstraintMinHeight = paramInt2;
    this.mMatchConstraintMaxHeight = paramInt3;
    this.mMatchConstraintPercentHeight = paramFloat;
    if (paramFloat < 1.0F && this.mMatchConstraintDefaultHeight == 0)
      this.mMatchConstraintDefaultHeight = 2; 
  }
  
  public void setVerticalWeight(float paramFloat) {
    this.mWeight[1] = paramFloat;
  }
  
  public void setVisibility(int paramInt) {
    this.mVisibility = paramInt;
  }
  
  public void setWidth(int paramInt) {
    this.mWidth = paramInt;
    int i = this.mWidth;
    paramInt = this.mMinWidth;
    if (i < paramInt)
      this.mWidth = paramInt; 
  }
  
  public void setWidthWrapContent(boolean paramBoolean) {
    this.mIsWidthWrapContent = paramBoolean;
  }
  
  public void setWrapHeight(int paramInt) {
    this.mWrapHeight = paramInt;
  }
  
  public void setWrapWidth(int paramInt) {
    this.mWrapWidth = paramInt;
  }
  
  public void setX(int paramInt) {
    this.mX = paramInt;
  }
  
  public void setY(int paramInt) {
    this.mY = paramInt;
  }
  
  public void setupDimensionRatio(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4) {
    if (this.mResolvedDimensionRatioSide == -1)
      if (paramBoolean3 && !paramBoolean4) {
        this.mResolvedDimensionRatioSide = 0;
      } else if (!paramBoolean3 && paramBoolean4) {
        this.mResolvedDimensionRatioSide = 1;
        if (this.mDimensionRatioSide == -1)
          this.mResolvedDimensionRatio = 1.0F / this.mResolvedDimensionRatio; 
      }  
    if (this.mResolvedDimensionRatioSide == 0 && (!this.mTop.isConnected() || !this.mBottom.isConnected())) {
      this.mResolvedDimensionRatioSide = 1;
    } else if (this.mResolvedDimensionRatioSide == 1 && (!this.mLeft.isConnected() || !this.mRight.isConnected())) {
      this.mResolvedDimensionRatioSide = 0;
    } 
    if (this.mResolvedDimensionRatioSide == -1 && (!this.mTop.isConnected() || !this.mBottom.isConnected() || !this.mLeft.isConnected() || !this.mRight.isConnected()))
      if (this.mTop.isConnected() && this.mBottom.isConnected()) {
        this.mResolvedDimensionRatioSide = 0;
      } else if (this.mLeft.isConnected() && this.mRight.isConnected()) {
        this.mResolvedDimensionRatio = 1.0F / this.mResolvedDimensionRatio;
        this.mResolvedDimensionRatioSide = 1;
      }  
    if (this.mResolvedDimensionRatioSide == -1)
      if (paramBoolean1 && !paramBoolean2) {
        this.mResolvedDimensionRatioSide = 0;
      } else if (!paramBoolean1 && paramBoolean2) {
        this.mResolvedDimensionRatio = 1.0F / this.mResolvedDimensionRatio;
        this.mResolvedDimensionRatioSide = 1;
      }  
    if (this.mResolvedDimensionRatioSide == -1)
      if (this.mMatchConstraintMinWidth > 0 && this.mMatchConstraintMinHeight == 0) {
        this.mResolvedDimensionRatioSide = 0;
      } else if (this.mMatchConstraintMinWidth == 0 && this.mMatchConstraintMinHeight > 0) {
        this.mResolvedDimensionRatio = 1.0F / this.mResolvedDimensionRatio;
        this.mResolvedDimensionRatioSide = 1;
      }  
    if (this.mResolvedDimensionRatioSide == -1 && paramBoolean1 && paramBoolean2) {
      this.mResolvedDimensionRatio = 1.0F / this.mResolvedDimensionRatio;
      this.mResolvedDimensionRatioSide = 1;
    } 
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    String str1 = this.mType;
    String str2 = "";
    if (str1 != null) {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("type: ");
      stringBuilder1.append(this.mType);
      stringBuilder1.append(" ");
      String str = stringBuilder1.toString();
    } else {
      str1 = "";
    } 
    stringBuilder.append(str1);
    str1 = str2;
    if (this.mDebugName != null) {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("id: ");
      stringBuilder1.append(this.mDebugName);
      stringBuilder1.append(" ");
      str1 = stringBuilder1.toString();
    } 
    stringBuilder.append(str1);
    stringBuilder.append("(");
    stringBuilder.append(this.mX);
    stringBuilder.append(", ");
    stringBuilder.append(this.mY);
    stringBuilder.append(") - (");
    stringBuilder.append(this.mWidth);
    stringBuilder.append(" x ");
    stringBuilder.append(this.mHeight);
    stringBuilder.append(") wrap: (");
    stringBuilder.append(this.mWrapWidth);
    stringBuilder.append(" x ");
    stringBuilder.append(this.mWrapHeight);
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
  
  public void updateDrawPosition() {
    int i = this.mX;
    int j = this.mY;
    int k = this.mWidth;
    int m = this.mHeight;
    this.mDrawX = i;
    this.mDrawY = j;
    this.mDrawWidth = k + i - i;
    this.mDrawHeight = m + j - j;
  }
  
  public void updateFromSolver(LinearSystem paramLinearSystem) {
    // Byte code:
    //   0: aload_1
    //   1: aload_0
    //   2: getfield mLeft : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   5: invokevirtual getObjectVariableValue : (Ljava/lang/Object;)I
    //   8: istore_2
    //   9: aload_1
    //   10: aload_0
    //   11: getfield mTop : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   14: invokevirtual getObjectVariableValue : (Ljava/lang/Object;)I
    //   17: istore_3
    //   18: aload_1
    //   19: aload_0
    //   20: getfield mRight : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   23: invokevirtual getObjectVariableValue : (Ljava/lang/Object;)I
    //   26: istore #4
    //   28: aload_1
    //   29: aload_0
    //   30: getfield mBottom : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   33: invokevirtual getObjectVariableValue : (Ljava/lang/Object;)I
    //   36: istore #5
    //   38: iload #4
    //   40: iload_2
    //   41: isub
    //   42: iflt -> 112
    //   45: iload #5
    //   47: iload_3
    //   48: isub
    //   49: iflt -> 112
    //   52: iload_2
    //   53: ldc_w -2147483648
    //   56: if_icmpeq -> 112
    //   59: iload_2
    //   60: ldc 2147483647
    //   62: if_icmpeq -> 112
    //   65: iload_3
    //   66: ldc_w -2147483648
    //   69: if_icmpeq -> 112
    //   72: iload_3
    //   73: ldc 2147483647
    //   75: if_icmpeq -> 112
    //   78: iload #4
    //   80: ldc_w -2147483648
    //   83: if_icmpeq -> 112
    //   86: iload #4
    //   88: ldc 2147483647
    //   90: if_icmpeq -> 112
    //   93: iload #5
    //   95: ldc_w -2147483648
    //   98: if_icmpeq -> 112
    //   101: iload #5
    //   103: istore #6
    //   105: iload #5
    //   107: ldc 2147483647
    //   109: if_icmpne -> 122
    //   112: iconst_0
    //   113: istore #6
    //   115: iconst_0
    //   116: istore_2
    //   117: iload_2
    //   118: istore_3
    //   119: iload_3
    //   120: istore #4
    //   122: aload_0
    //   123: iload_2
    //   124: iload_3
    //   125: iload #4
    //   127: iload #6
    //   129: invokevirtual setFrame : (IIII)V
    //   132: return
  }
  
  public void updateResolutionNodes() {
    for (byte b = 0; b < 6; b++)
      this.mListAnchors[b].getResolutionNode().update(); 
  }
  
  public enum ContentAlignment {
    BEGIN, BOTTOM, END, LEFT, MIDDLE, RIGHT, TOP, VERTICAL_MIDDLE;
    
    private static final ContentAlignment[] $VALUES;
    
    static {
      BOTTOM = new ContentAlignment("BOTTOM", 5);
      LEFT = new ContentAlignment("LEFT", 6);
      RIGHT = new ContentAlignment("RIGHT", 7);
      $VALUES = new ContentAlignment[] { BEGIN, MIDDLE, END, TOP, VERTICAL_MIDDLE, BOTTOM, LEFT, RIGHT };
    }
  }
  
  public enum DimensionBehaviour {
    FIXED, MATCH_CONSTRAINT, MATCH_PARENT, WRAP_CONTENT;
    
    private static final DimensionBehaviour[] $VALUES;
    
    static {
      $VALUES = new DimensionBehaviour[] { FIXED, WRAP_CONTENT, MATCH_CONSTRAINT, MATCH_PARENT };
    }
  }
}


/* Location:              /home/brandon/levelMeter_APK/dex2jar-2.x/dex-tools/build/distributions/dex-tools-2.2-SNAPSHOT/classes-dex2jar.jar!/androidx/constraintlayout/solver/widgets/ConstraintWidget.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */