package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Build;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.util.SparseIntArray;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.solver.Metrics;
import androidx.constraintlayout.solver.widgets.Analyzer;
import androidx.constraintlayout.solver.widgets.ConstraintAnchor;
import androidx.constraintlayout.solver.widgets.ConstraintWidget;
import androidx.constraintlayout.solver.widgets.ConstraintWidgetContainer;
import androidx.constraintlayout.solver.widgets.Guideline;
import java.util.ArrayList;
import java.util.HashMap;

public class ConstraintLayout extends ViewGroup {
  static final boolean ALLOWS_EMBEDDED = false;
  
  private static final boolean CACHE_MEASURED_DIMENSION = false;
  
  private static final boolean DEBUG = false;
  
  public static final int DESIGN_INFO_ID = 0;
  
  private static final String TAG = "ConstraintLayout";
  
  private static final boolean USE_CONSTRAINTS_HELPER = true;
  
  public static final String VERSION = "ConstraintLayout-1.1.3";
  
  SparseArray<View> mChildrenByIds = new SparseArray();
  
  private ArrayList<ConstraintHelper> mConstraintHelpers = new ArrayList<ConstraintHelper>(4);
  
  private ConstraintSet mConstraintSet = null;
  
  private int mConstraintSetId = -1;
  
  private HashMap<String, Integer> mDesignIds = new HashMap<String, Integer>();
  
  private boolean mDirtyHierarchy = true;
  
  private int mLastMeasureHeight = -1;
  
  int mLastMeasureHeightMode = 0;
  
  int mLastMeasureHeightSize = -1;
  
  private int mLastMeasureWidth = -1;
  
  int mLastMeasureWidthMode = 0;
  
  int mLastMeasureWidthSize = -1;
  
  ConstraintWidgetContainer mLayoutWidget = new ConstraintWidgetContainer();
  
  private int mMaxHeight = Integer.MAX_VALUE;
  
  private int mMaxWidth = Integer.MAX_VALUE;
  
  private Metrics mMetrics;
  
  private int mMinHeight = 0;
  
  private int mMinWidth = 0;
  
  private int mOptimizationLevel = 7;
  
  private final ArrayList<ConstraintWidget> mVariableDimensionsWidgets = new ArrayList<ConstraintWidget>(100);
  
  public ConstraintLayout(Context paramContext) {
    super(paramContext);
    init((AttributeSet)null);
  }
  
  public ConstraintLayout(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    init(paramAttributeSet);
  }
  
  public ConstraintLayout(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    init(paramAttributeSet);
  }
  
  private final ConstraintWidget getTargetWidget(int paramInt) {
    ConstraintWidget constraintWidget;
    if (paramInt == 0)
      return (ConstraintWidget)this.mLayoutWidget; 
    View view1 = (View)this.mChildrenByIds.get(paramInt);
    View view2 = view1;
    if (view1 == null) {
      view1 = findViewById(paramInt);
      view2 = view1;
      if (view1 != null) {
        view2 = view1;
        if (view1 != this) {
          view2 = view1;
          if (view1.getParent() == this) {
            onViewAdded(view1);
            view2 = view1;
          } 
        } 
      } 
    } 
    if (view2 == this)
      return (ConstraintWidget)this.mLayoutWidget; 
    if (view2 == null) {
      view2 = null;
    } else {
      constraintWidget = ((LayoutParams)view2.getLayoutParams()).widget;
    } 
    return constraintWidget;
  }
  
  private void init(AttributeSet paramAttributeSet) {
    this.mLayoutWidget.setCompanionWidget(this);
    this.mChildrenByIds.put(getId(), this);
    this.mConstraintSet = null;
    if (paramAttributeSet != null) {
      TypedArray typedArray = getContext().obtainStyledAttributes(paramAttributeSet, R.styleable.ConstraintLayout_Layout);
      int i = typedArray.getIndexCount();
      for (byte b = 0; b < i; b++) {
        int j = typedArray.getIndex(b);
        if (j == R.styleable.ConstraintLayout_Layout_android_minWidth) {
          this.mMinWidth = typedArray.getDimensionPixelOffset(j, this.mMinWidth);
        } else if (j == R.styleable.ConstraintLayout_Layout_android_minHeight) {
          this.mMinHeight = typedArray.getDimensionPixelOffset(j, this.mMinHeight);
        } else if (j == R.styleable.ConstraintLayout_Layout_android_maxWidth) {
          this.mMaxWidth = typedArray.getDimensionPixelOffset(j, this.mMaxWidth);
        } else if (j == R.styleable.ConstraintLayout_Layout_android_maxHeight) {
          this.mMaxHeight = typedArray.getDimensionPixelOffset(j, this.mMaxHeight);
        } else if (j == R.styleable.ConstraintLayout_Layout_layout_optimizationLevel) {
          this.mOptimizationLevel = typedArray.getInt(j, this.mOptimizationLevel);
        } else if (j == R.styleable.ConstraintLayout_Layout_constraintSet) {
          j = typedArray.getResourceId(j, 0);
          try {
            ConstraintSet constraintSet = new ConstraintSet();
            this();
            this.mConstraintSet = constraintSet;
            this.mConstraintSet.load(getContext(), j);
          } catch (android.content.res.Resources.NotFoundException notFoundException) {
            this.mConstraintSet = null;
          } 
          this.mConstraintSetId = j;
        } 
      } 
      typedArray.recycle();
    } 
    this.mLayoutWidget.setOptimizationLevel(this.mOptimizationLevel);
  }
  
  private void internalMeasureChildren(int paramInt1, int paramInt2) {
    int i = getPaddingTop() + getPaddingBottom();
    int j = getPaddingLeft() + getPaddingRight();
    int k = getChildCount();
    for (byte b = 0; b < k; b++) {
      View view = getChildAt(b);
      if (view.getVisibility() != 8) {
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        ConstraintWidget constraintWidget = layoutParams.widget;
        if (!layoutParams.isGuideline && !layoutParams.isHelper) {
          int i1;
          int i2;
          int i3;
          boolean bool;
          constraintWidget.setVisibility(view.getVisibility());
          int m = layoutParams.width;
          int n = layoutParams.height;
          if (layoutParams.horizontalDimensionFixed || layoutParams.verticalDimensionFixed || (!layoutParams.horizontalDimensionFixed && layoutParams.matchConstraintDefaultWidth == 1) || layoutParams.width == -1 || (!layoutParams.verticalDimensionFixed && (layoutParams.matchConstraintDefaultHeight == 1 || layoutParams.height == -1))) {
            i1 = 1;
          } else {
            i1 = 0;
          } 
          if (i1) {
            boolean bool1;
            if (m == 0) {
              i2 = getChildMeasureSpec(paramInt1, j, -2);
              i1 = 1;
            } else if (m == -1) {
              i2 = getChildMeasureSpec(paramInt1, j, -1);
              i1 = 0;
            } else {
              if (m == -2) {
                i1 = 1;
              } else {
                i1 = 0;
              } 
              i2 = getChildMeasureSpec(paramInt1, j, m);
            } 
            if (n == 0) {
              i3 = getChildMeasureSpec(paramInt2, i, -2);
              bool = true;
            } else if (n == -1) {
              i3 = getChildMeasureSpec(paramInt2, i, -1);
              bool = false;
            } else {
              if (n == -2) {
                bool = true;
              } else {
                bool = false;
              } 
              i3 = getChildMeasureSpec(paramInt2, i, n);
            } 
            view.measure(i2, i3);
            Metrics metrics = this.mMetrics;
            if (metrics != null)
              metrics.measures++; 
            if (m == -2) {
              bool1 = true;
            } else {
              bool1 = false;
            } 
            constraintWidget.setWidthWrapContent(bool1);
            if (n == -2) {
              bool1 = true;
            } else {
              bool1 = false;
            } 
            constraintWidget.setHeightWrapContent(bool1);
            i2 = view.getMeasuredWidth();
            i3 = view.getMeasuredHeight();
          } else {
            i1 = 0;
            bool = false;
            i3 = n;
            i2 = m;
          } 
          constraintWidget.setWidth(i2);
          constraintWidget.setHeight(i3);
          if (i1)
            constraintWidget.setWrapWidth(i2); 
          if (bool)
            constraintWidget.setWrapHeight(i3); 
          if (layoutParams.needsBaseline) {
            i1 = view.getBaseline();
            if (i1 != -1)
              constraintWidget.setBaselineDistance(i1); 
          } 
        } 
      } 
    } 
  }
  
  private void internalMeasureDimensions(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: astore_3
    //   2: aload_0
    //   3: invokevirtual getPaddingTop : ()I
    //   6: aload_0
    //   7: invokevirtual getPaddingBottom : ()I
    //   10: iadd
    //   11: istore #4
    //   13: aload_0
    //   14: invokevirtual getPaddingLeft : ()I
    //   17: aload_0
    //   18: invokevirtual getPaddingRight : ()I
    //   21: iadd
    //   22: istore #5
    //   24: aload_0
    //   25: invokevirtual getChildCount : ()I
    //   28: istore #6
    //   30: iconst_0
    //   31: istore #7
    //   33: lconst_1
    //   34: lstore #8
    //   36: iload #7
    //   38: iload #6
    //   40: if_icmpge -> 407
    //   43: aload_3
    //   44: iload #7
    //   46: invokevirtual getChildAt : (I)Landroid/view/View;
    //   49: astore #10
    //   51: aload #10
    //   53: invokevirtual getVisibility : ()I
    //   56: bipush #8
    //   58: if_icmpne -> 64
    //   61: goto -> 401
    //   64: aload #10
    //   66: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   69: checkcast androidx/constraintlayout/widget/ConstraintLayout$LayoutParams
    //   72: astore #11
    //   74: aload #11
    //   76: getfield widget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   79: astore #12
    //   81: aload #11
    //   83: getfield isGuideline : Z
    //   86: ifne -> 401
    //   89: aload #11
    //   91: getfield isHelper : Z
    //   94: ifeq -> 100
    //   97: goto -> 401
    //   100: aload #12
    //   102: aload #10
    //   104: invokevirtual getVisibility : ()I
    //   107: invokevirtual setVisibility : (I)V
    //   110: aload #11
    //   112: getfield width : I
    //   115: istore #13
    //   117: aload #11
    //   119: getfield height : I
    //   122: istore #14
    //   124: iload #13
    //   126: ifeq -> 382
    //   129: iload #14
    //   131: ifne -> 137
    //   134: goto -> 382
    //   137: iload #13
    //   139: bipush #-2
    //   141: if_icmpne -> 150
    //   144: iconst_1
    //   145: istore #15
    //   147: goto -> 153
    //   150: iconst_0
    //   151: istore #15
    //   153: iload_1
    //   154: iload #5
    //   156: iload #13
    //   158: invokestatic getChildMeasureSpec : (III)I
    //   161: istore #16
    //   163: iload #14
    //   165: bipush #-2
    //   167: if_icmpne -> 176
    //   170: iconst_1
    //   171: istore #17
    //   173: goto -> 179
    //   176: iconst_0
    //   177: istore #17
    //   179: aload #10
    //   181: iload #16
    //   183: iload_2
    //   184: iload #4
    //   186: iload #14
    //   188: invokestatic getChildMeasureSpec : (III)I
    //   191: invokevirtual measure : (II)V
    //   194: aload_3
    //   195: getfield mMetrics : Landroidx/constraintlayout/solver/Metrics;
    //   198: astore #18
    //   200: aload #18
    //   202: ifnull -> 217
    //   205: aload #18
    //   207: aload #18
    //   209: getfield measures : J
    //   212: lconst_1
    //   213: ladd
    //   214: putfield measures : J
    //   217: iload #13
    //   219: bipush #-2
    //   221: if_icmpne -> 230
    //   224: iconst_1
    //   225: istore #19
    //   227: goto -> 233
    //   230: iconst_0
    //   231: istore #19
    //   233: aload #12
    //   235: iload #19
    //   237: invokevirtual setWidthWrapContent : (Z)V
    //   240: iload #14
    //   242: bipush #-2
    //   244: if_icmpne -> 253
    //   247: iconst_1
    //   248: istore #19
    //   250: goto -> 256
    //   253: iconst_0
    //   254: istore #19
    //   256: aload #12
    //   258: iload #19
    //   260: invokevirtual setHeightWrapContent : (Z)V
    //   263: aload #10
    //   265: invokevirtual getMeasuredWidth : ()I
    //   268: istore #14
    //   270: aload #10
    //   272: invokevirtual getMeasuredHeight : ()I
    //   275: istore #13
    //   277: aload #12
    //   279: iload #14
    //   281: invokevirtual setWidth : (I)V
    //   284: aload #12
    //   286: iload #13
    //   288: invokevirtual setHeight : (I)V
    //   291: iload #15
    //   293: ifeq -> 303
    //   296: aload #12
    //   298: iload #14
    //   300: invokevirtual setWrapWidth : (I)V
    //   303: iload #17
    //   305: ifeq -> 315
    //   308: aload #12
    //   310: iload #13
    //   312: invokevirtual setWrapHeight : (I)V
    //   315: aload #11
    //   317: getfield needsBaseline : Z
    //   320: ifeq -> 343
    //   323: aload #10
    //   325: invokevirtual getBaseline : ()I
    //   328: istore #15
    //   330: iload #15
    //   332: iconst_m1
    //   333: if_icmpeq -> 343
    //   336: aload #12
    //   338: iload #15
    //   340: invokevirtual setBaselineDistance : (I)V
    //   343: aload #11
    //   345: getfield horizontalDimensionFixed : Z
    //   348: ifeq -> 401
    //   351: aload #11
    //   353: getfield verticalDimensionFixed : Z
    //   356: ifeq -> 401
    //   359: aload #12
    //   361: invokevirtual getResolutionWidth : ()Landroidx/constraintlayout/solver/widgets/ResolutionDimension;
    //   364: iload #14
    //   366: invokevirtual resolve : (I)V
    //   369: aload #12
    //   371: invokevirtual getResolutionHeight : ()Landroidx/constraintlayout/solver/widgets/ResolutionDimension;
    //   374: iload #13
    //   376: invokevirtual resolve : (I)V
    //   379: goto -> 401
    //   382: aload #12
    //   384: invokevirtual getResolutionWidth : ()Landroidx/constraintlayout/solver/widgets/ResolutionDimension;
    //   387: invokevirtual invalidate : ()V
    //   390: aload #12
    //   392: invokevirtual getResolutionHeight : ()Landroidx/constraintlayout/solver/widgets/ResolutionDimension;
    //   395: invokevirtual invalidate : ()V
    //   398: goto -> 401
    //   401: iinc #7, 1
    //   404: goto -> 33
    //   407: aload_3
    //   408: getfield mLayoutWidget : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
    //   411: invokevirtual solveGraph : ()V
    //   414: iconst_0
    //   415: istore #20
    //   417: iload #20
    //   419: iload #6
    //   421: if_icmpge -> 1320
    //   424: aload_3
    //   425: iload #20
    //   427: invokevirtual getChildAt : (I)Landroid/view/View;
    //   430: astore #11
    //   432: aload #11
    //   434: invokevirtual getVisibility : ()I
    //   437: bipush #8
    //   439: if_icmpne -> 445
    //   442: goto -> 1308
    //   445: aload #11
    //   447: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   450: checkcast androidx/constraintlayout/widget/ConstraintLayout$LayoutParams
    //   453: astore #18
    //   455: aload #18
    //   457: getfield widget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   460: astore #12
    //   462: aload #18
    //   464: getfield isGuideline : Z
    //   467: ifne -> 1308
    //   470: aload #18
    //   472: getfield isHelper : Z
    //   475: ifeq -> 481
    //   478: goto -> 1308
    //   481: aload #12
    //   483: aload #11
    //   485: invokevirtual getVisibility : ()I
    //   488: invokevirtual setVisibility : (I)V
    //   491: aload #18
    //   493: getfield width : I
    //   496: istore #14
    //   498: aload #18
    //   500: getfield height : I
    //   503: istore #16
    //   505: iload #14
    //   507: ifeq -> 518
    //   510: iload #16
    //   512: ifeq -> 518
    //   515: goto -> 1308
    //   518: aload #12
    //   520: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.LEFT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   523: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   526: invokevirtual getResolutionNode : ()Landroidx/constraintlayout/solver/widgets/ResolutionAnchor;
    //   529: astore #10
    //   531: aload #12
    //   533: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.RIGHT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   536: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   539: invokevirtual getResolutionNode : ()Landroidx/constraintlayout/solver/widgets/ResolutionAnchor;
    //   542: astore #21
    //   544: aload #12
    //   546: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.LEFT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   549: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   552: invokevirtual getTarget : ()Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   555: ifnull -> 578
    //   558: aload #12
    //   560: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.RIGHT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   563: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   566: invokevirtual getTarget : ()Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   569: ifnull -> 578
    //   572: iconst_1
    //   573: istore #15
    //   575: goto -> 581
    //   578: iconst_0
    //   579: istore #15
    //   581: aload #12
    //   583: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.TOP : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   586: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   589: invokevirtual getResolutionNode : ()Landroidx/constraintlayout/solver/widgets/ResolutionAnchor;
    //   592: astore #22
    //   594: aload #12
    //   596: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   599: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   602: invokevirtual getResolutionNode : ()Landroidx/constraintlayout/solver/widgets/ResolutionAnchor;
    //   605: astore #23
    //   607: aload #12
    //   609: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.TOP : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   612: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   615: invokevirtual getTarget : ()Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   618: ifnull -> 641
    //   621: aload #12
    //   623: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   626: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   629: invokevirtual getTarget : ()Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   632: ifnull -> 641
    //   635: iconst_1
    //   636: istore #24
    //   638: goto -> 644
    //   641: iconst_0
    //   642: istore #24
    //   644: iload #14
    //   646: ifne -> 673
    //   649: iload #16
    //   651: ifne -> 673
    //   654: iload #15
    //   656: ifeq -> 673
    //   659: iload #24
    //   661: ifeq -> 673
    //   664: lconst_1
    //   665: lstore #8
    //   667: aload_3
    //   668: astore #18
    //   670: goto -> 1311
    //   673: aload_3
    //   674: getfield mLayoutWidget : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
    //   677: invokevirtual getHorizontalDimensionBehaviour : ()Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   680: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   683: if_acmpeq -> 692
    //   686: iconst_1
    //   687: istore #13
    //   689: goto -> 695
    //   692: iconst_0
    //   693: istore #13
    //   695: aload_3
    //   696: getfield mLayoutWidget : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
    //   699: invokevirtual getVerticalDimensionBehaviour : ()Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   702: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   705: if_acmpeq -> 714
    //   708: iconst_1
    //   709: istore #7
    //   711: goto -> 717
    //   714: iconst_0
    //   715: istore #7
    //   717: iload #13
    //   719: ifne -> 730
    //   722: aload #12
    //   724: invokevirtual getResolutionWidth : ()Landroidx/constraintlayout/solver/widgets/ResolutionDimension;
    //   727: invokevirtual invalidate : ()V
    //   730: iload #7
    //   732: ifne -> 743
    //   735: aload #12
    //   737: invokevirtual getResolutionHeight : ()Landroidx/constraintlayout/solver/widgets/ResolutionDimension;
    //   740: invokevirtual invalidate : ()V
    //   743: iload #14
    //   745: ifne -> 842
    //   748: iload #13
    //   750: ifeq -> 819
    //   753: aload #12
    //   755: invokevirtual isSpreadWidth : ()Z
    //   758: ifeq -> 819
    //   761: iload #15
    //   763: ifeq -> 819
    //   766: aload #10
    //   768: invokevirtual isResolved : ()Z
    //   771: ifeq -> 819
    //   774: aload #21
    //   776: invokevirtual isResolved : ()Z
    //   779: ifeq -> 819
    //   782: aload #21
    //   784: invokevirtual getResolvedValue : ()F
    //   787: aload #10
    //   789: invokevirtual getResolvedValue : ()F
    //   792: fsub
    //   793: f2i
    //   794: istore #14
    //   796: aload #12
    //   798: invokevirtual getResolutionWidth : ()Landroidx/constraintlayout/solver/widgets/ResolutionDimension;
    //   801: iload #14
    //   803: invokevirtual resolve : (I)V
    //   806: iload_1
    //   807: iload #5
    //   809: iload #14
    //   811: invokestatic getChildMeasureSpec : (III)I
    //   814: istore #17
    //   816: goto -> 857
    //   819: iload_1
    //   820: iload #5
    //   822: bipush #-2
    //   824: invokestatic getChildMeasureSpec : (III)I
    //   827: istore #17
    //   829: iconst_1
    //   830: istore #15
    //   832: iconst_0
    //   833: istore #25
    //   835: iload #14
    //   837: istore #26
    //   839: goto -> 905
    //   842: iload #14
    //   844: iconst_m1
    //   845: if_icmpne -> 871
    //   848: iload_1
    //   849: iload #5
    //   851: iconst_m1
    //   852: invokestatic getChildMeasureSpec : (III)I
    //   855: istore #17
    //   857: iconst_0
    //   858: istore #15
    //   860: iload #13
    //   862: istore #25
    //   864: iload #14
    //   866: istore #26
    //   868: goto -> 905
    //   871: iload #14
    //   873: bipush #-2
    //   875: if_icmpne -> 884
    //   878: iconst_1
    //   879: istore #15
    //   881: goto -> 887
    //   884: iconst_0
    //   885: istore #15
    //   887: iload_1
    //   888: iload #5
    //   890: iload #14
    //   892: invokestatic getChildMeasureSpec : (III)I
    //   895: istore #17
    //   897: iload #14
    //   899: istore #26
    //   901: iload #13
    //   903: istore #25
    //   905: iload #16
    //   907: ifne -> 1000
    //   910: iload #7
    //   912: ifeq -> 981
    //   915: aload #12
    //   917: invokevirtual isSpreadHeight : ()Z
    //   920: ifeq -> 981
    //   923: iload #24
    //   925: ifeq -> 981
    //   928: aload #22
    //   930: invokevirtual isResolved : ()Z
    //   933: ifeq -> 981
    //   936: aload #23
    //   938: invokevirtual isResolved : ()Z
    //   941: ifeq -> 981
    //   944: aload #23
    //   946: invokevirtual getResolvedValue : ()F
    //   949: aload #22
    //   951: invokevirtual getResolvedValue : ()F
    //   954: fsub
    //   955: f2i
    //   956: istore #16
    //   958: aload #12
    //   960: invokevirtual getResolutionHeight : ()Landroidx/constraintlayout/solver/widgets/ResolutionDimension;
    //   963: iload #16
    //   965: invokevirtual resolve : (I)V
    //   968: iload_2
    //   969: iload #4
    //   971: iload #16
    //   973: invokestatic getChildMeasureSpec : (III)I
    //   976: istore #13
    //   978: goto -> 1015
    //   981: iload_2
    //   982: iload #4
    //   984: bipush #-2
    //   986: invokestatic getChildMeasureSpec : (III)I
    //   989: istore #13
    //   991: iconst_1
    //   992: istore #7
    //   994: iconst_0
    //   995: istore #14
    //   997: goto -> 1063
    //   1000: iload #16
    //   1002: iconst_m1
    //   1003: if_icmpne -> 1025
    //   1006: iload_2
    //   1007: iload #4
    //   1009: iconst_m1
    //   1010: invokestatic getChildMeasureSpec : (III)I
    //   1013: istore #13
    //   1015: iload #7
    //   1017: istore #14
    //   1019: iconst_0
    //   1020: istore #7
    //   1022: goto -> 1063
    //   1025: iload #16
    //   1027: bipush #-2
    //   1029: if_icmpne -> 1038
    //   1032: iconst_1
    //   1033: istore #13
    //   1035: goto -> 1041
    //   1038: iconst_0
    //   1039: istore #13
    //   1041: iload_2
    //   1042: iload #4
    //   1044: iload #16
    //   1046: invokestatic getChildMeasureSpec : (III)I
    //   1049: istore #24
    //   1051: iload #7
    //   1053: istore #14
    //   1055: iload #13
    //   1057: istore #7
    //   1059: iload #24
    //   1061: istore #13
    //   1063: aload #11
    //   1065: iload #17
    //   1067: iload #13
    //   1069: invokevirtual measure : (II)V
    //   1072: aload_0
    //   1073: astore_3
    //   1074: aload_3
    //   1075: getfield mMetrics : Landroidx/constraintlayout/solver/Metrics;
    //   1078: astore #10
    //   1080: aload #10
    //   1082: ifnull -> 1100
    //   1085: aload #10
    //   1087: aload #10
    //   1089: getfield measures : J
    //   1092: lconst_1
    //   1093: ladd
    //   1094: putfield measures : J
    //   1097: goto -> 1100
    //   1100: lconst_1
    //   1101: lstore #27
    //   1103: iload #26
    //   1105: bipush #-2
    //   1107: if_icmpne -> 1116
    //   1110: iconst_1
    //   1111: istore #19
    //   1113: goto -> 1119
    //   1116: iconst_0
    //   1117: istore #19
    //   1119: aload #12
    //   1121: iload #19
    //   1123: invokevirtual setWidthWrapContent : (Z)V
    //   1126: iload #16
    //   1128: bipush #-2
    //   1130: if_icmpne -> 1139
    //   1133: iconst_1
    //   1134: istore #19
    //   1136: goto -> 1142
    //   1139: iconst_0
    //   1140: istore #19
    //   1142: aload #12
    //   1144: iload #19
    //   1146: invokevirtual setHeightWrapContent : (Z)V
    //   1149: aload #11
    //   1151: invokevirtual getMeasuredWidth : ()I
    //   1154: istore #17
    //   1156: aload #11
    //   1158: invokevirtual getMeasuredHeight : ()I
    //   1161: istore #13
    //   1163: aload #12
    //   1165: iload #17
    //   1167: invokevirtual setWidth : (I)V
    //   1170: aload #12
    //   1172: iload #13
    //   1174: invokevirtual setHeight : (I)V
    //   1177: iload #15
    //   1179: ifeq -> 1189
    //   1182: aload #12
    //   1184: iload #17
    //   1186: invokevirtual setWrapWidth : (I)V
    //   1189: iload #7
    //   1191: ifeq -> 1201
    //   1194: aload #12
    //   1196: iload #13
    //   1198: invokevirtual setWrapHeight : (I)V
    //   1201: iload #25
    //   1203: ifeq -> 1219
    //   1206: aload #12
    //   1208: invokevirtual getResolutionWidth : ()Landroidx/constraintlayout/solver/widgets/ResolutionDimension;
    //   1211: iload #17
    //   1213: invokevirtual resolve : (I)V
    //   1216: goto -> 1227
    //   1219: aload #12
    //   1221: invokevirtual getResolutionWidth : ()Landroidx/constraintlayout/solver/widgets/ResolutionDimension;
    //   1224: invokevirtual remove : ()V
    //   1227: iload #14
    //   1229: ifeq -> 1245
    //   1232: aload #12
    //   1234: invokevirtual getResolutionHeight : ()Landroidx/constraintlayout/solver/widgets/ResolutionDimension;
    //   1237: iload #13
    //   1239: invokevirtual resolve : (I)V
    //   1242: goto -> 1253
    //   1245: aload #12
    //   1247: invokevirtual getResolutionHeight : ()Landroidx/constraintlayout/solver/widgets/ResolutionDimension;
    //   1250: invokevirtual remove : ()V
    //   1253: aload #18
    //   1255: getfield needsBaseline : Z
    //   1258: ifeq -> 1298
    //   1261: aload #11
    //   1263: invokevirtual getBaseline : ()I
    //   1266: istore #7
    //   1268: aload_3
    //   1269: astore #18
    //   1271: lload #27
    //   1273: lstore #8
    //   1275: iload #7
    //   1277: iconst_m1
    //   1278: if_icmpeq -> 1311
    //   1281: aload #12
    //   1283: iload #7
    //   1285: invokevirtual setBaselineDistance : (I)V
    //   1288: aload_3
    //   1289: astore #18
    //   1291: lload #27
    //   1293: lstore #8
    //   1295: goto -> 1311
    //   1298: aload_3
    //   1299: astore #18
    //   1301: lload #27
    //   1303: lstore #8
    //   1305: goto -> 1311
    //   1308: aload_3
    //   1309: astore #18
    //   1311: iinc #20, 1
    //   1314: aload #18
    //   1316: astore_3
    //   1317: goto -> 417
    //   1320: return
  }
  
  private void setChildrenConstraints() {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual isInEditMode : ()Z
    //   4: istore_1
    //   5: aload_0
    //   6: invokevirtual getChildCount : ()I
    //   9: istore_2
    //   10: iconst_0
    //   11: istore_3
    //   12: iload_1
    //   13: ifeq -> 112
    //   16: iconst_0
    //   17: istore #4
    //   19: iload #4
    //   21: iload_2
    //   22: if_icmpge -> 112
    //   25: aload_0
    //   26: iload #4
    //   28: invokevirtual getChildAt : (I)Landroid/view/View;
    //   31: astore #5
    //   33: aload_0
    //   34: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   37: aload #5
    //   39: invokevirtual getId : ()I
    //   42: invokevirtual getResourceName : (I)Ljava/lang/String;
    //   45: astore #6
    //   47: aload_0
    //   48: iconst_0
    //   49: aload #6
    //   51: aload #5
    //   53: invokevirtual getId : ()I
    //   56: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   59: invokevirtual setDesignInformation : (ILjava/lang/Object;Ljava/lang/Object;)V
    //   62: aload #6
    //   64: bipush #47
    //   66: invokevirtual indexOf : (I)I
    //   69: istore #7
    //   71: aload #6
    //   73: astore #8
    //   75: iload #7
    //   77: iconst_m1
    //   78: if_icmpeq -> 92
    //   81: aload #6
    //   83: iload #7
    //   85: iconst_1
    //   86: iadd
    //   87: invokevirtual substring : (I)Ljava/lang/String;
    //   90: astore #8
    //   92: aload_0
    //   93: aload #5
    //   95: invokevirtual getId : ()I
    //   98: invokespecial getTargetWidget : (I)Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   101: aload #8
    //   103: invokevirtual setDebugName : (Ljava/lang/String;)V
    //   106: iinc #4, 1
    //   109: goto -> 19
    //   112: iconst_0
    //   113: istore #4
    //   115: iload #4
    //   117: iload_2
    //   118: if_icmpge -> 152
    //   121: aload_0
    //   122: aload_0
    //   123: iload #4
    //   125: invokevirtual getChildAt : (I)Landroid/view/View;
    //   128: invokevirtual getViewWidget : (Landroid/view/View;)Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   131: astore #8
    //   133: aload #8
    //   135: ifnonnull -> 141
    //   138: goto -> 146
    //   141: aload #8
    //   143: invokevirtual reset : ()V
    //   146: iinc #4, 1
    //   149: goto -> 115
    //   152: aload_0
    //   153: getfield mConstraintSetId : I
    //   156: iconst_m1
    //   157: if_icmpeq -> 215
    //   160: iconst_0
    //   161: istore #4
    //   163: iload #4
    //   165: iload_2
    //   166: if_icmpge -> 215
    //   169: aload_0
    //   170: iload #4
    //   172: invokevirtual getChildAt : (I)Landroid/view/View;
    //   175: astore #8
    //   177: aload #8
    //   179: invokevirtual getId : ()I
    //   182: aload_0
    //   183: getfield mConstraintSetId : I
    //   186: if_icmpne -> 209
    //   189: aload #8
    //   191: instanceof androidx/constraintlayout/widget/Constraints
    //   194: ifeq -> 209
    //   197: aload_0
    //   198: aload #8
    //   200: checkcast androidx/constraintlayout/widget/Constraints
    //   203: invokevirtual getConstraintSet : ()Landroidx/constraintlayout/widget/ConstraintSet;
    //   206: putfield mConstraintSet : Landroidx/constraintlayout/widget/ConstraintSet;
    //   209: iinc #4, 1
    //   212: goto -> 163
    //   215: aload_0
    //   216: getfield mConstraintSet : Landroidx/constraintlayout/widget/ConstraintSet;
    //   219: astore #8
    //   221: aload #8
    //   223: ifnull -> 232
    //   226: aload #8
    //   228: aload_0
    //   229: invokevirtual applyToInternal : (Landroidx/constraintlayout/widget/ConstraintLayout;)V
    //   232: aload_0
    //   233: getfield mLayoutWidget : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
    //   236: invokevirtual removeAllChildren : ()V
    //   239: aload_0
    //   240: getfield mConstraintHelpers : Ljava/util/ArrayList;
    //   243: invokevirtual size : ()I
    //   246: istore #7
    //   248: iload #7
    //   250: ifle -> 285
    //   253: iconst_0
    //   254: istore #4
    //   256: iload #4
    //   258: iload #7
    //   260: if_icmpge -> 285
    //   263: aload_0
    //   264: getfield mConstraintHelpers : Ljava/util/ArrayList;
    //   267: iload #4
    //   269: invokevirtual get : (I)Ljava/lang/Object;
    //   272: checkcast androidx/constraintlayout/widget/ConstraintHelper
    //   275: aload_0
    //   276: invokevirtual updatePreLayout : (Landroidx/constraintlayout/widget/ConstraintLayout;)V
    //   279: iinc #4, 1
    //   282: goto -> 256
    //   285: iconst_0
    //   286: istore #4
    //   288: iload #4
    //   290: iload_2
    //   291: if_icmpge -> 325
    //   294: aload_0
    //   295: iload #4
    //   297: invokevirtual getChildAt : (I)Landroid/view/View;
    //   300: astore #8
    //   302: aload #8
    //   304: instanceof androidx/constraintlayout/widget/Placeholder
    //   307: ifeq -> 319
    //   310: aload #8
    //   312: checkcast androidx/constraintlayout/widget/Placeholder
    //   315: aload_0
    //   316: invokevirtual updatePreLayout : (Landroidx/constraintlayout/widget/ConstraintLayout;)V
    //   319: iinc #4, 1
    //   322: goto -> 288
    //   325: iconst_0
    //   326: istore #7
    //   328: iload_3
    //   329: istore #4
    //   331: iload #7
    //   333: iload_2
    //   334: if_icmpge -> 2041
    //   337: aload_0
    //   338: iload #7
    //   340: invokevirtual getChildAt : (I)Landroid/view/View;
    //   343: astore #5
    //   345: aload_0
    //   346: aload #5
    //   348: invokevirtual getViewWidget : (Landroid/view/View;)Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   351: astore #6
    //   353: aload #6
    //   355: ifnonnull -> 365
    //   358: iload #4
    //   360: istore #9
    //   362: goto -> 2031
    //   365: aload #5
    //   367: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   370: checkcast androidx/constraintlayout/widget/ConstraintLayout$LayoutParams
    //   373: astore #8
    //   375: aload #8
    //   377: invokevirtual validate : ()V
    //   380: aload #8
    //   382: getfield helped : Z
    //   385: ifeq -> 398
    //   388: aload #8
    //   390: iload #4
    //   392: putfield helped : Z
    //   395: goto -> 463
    //   398: iload_1
    //   399: ifeq -> 463
    //   402: aload_0
    //   403: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   406: aload #5
    //   408: invokevirtual getId : ()I
    //   411: invokevirtual getResourceName : (I)Ljava/lang/String;
    //   414: astore #10
    //   416: aload_0
    //   417: iload #4
    //   419: aload #10
    //   421: aload #5
    //   423: invokevirtual getId : ()I
    //   426: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   429: invokevirtual setDesignInformation : (ILjava/lang/Object;Ljava/lang/Object;)V
    //   432: aload #10
    //   434: aload #10
    //   436: ldc_w 'id/'
    //   439: invokevirtual indexOf : (Ljava/lang/String;)I
    //   442: iconst_3
    //   443: iadd
    //   444: invokevirtual substring : (I)Ljava/lang/String;
    //   447: astore #10
    //   449: aload_0
    //   450: aload #5
    //   452: invokevirtual getId : ()I
    //   455: invokespecial getTargetWidget : (I)Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   458: aload #10
    //   460: invokevirtual setDebugName : (Ljava/lang/String;)V
    //   463: aload #6
    //   465: aload #5
    //   467: invokevirtual getVisibility : ()I
    //   470: invokevirtual setVisibility : (I)V
    //   473: aload #8
    //   475: getfield isInPlaceholder : Z
    //   478: ifeq -> 488
    //   481: aload #6
    //   483: bipush #8
    //   485: invokevirtual setVisibility : (I)V
    //   488: aload #6
    //   490: aload #5
    //   492: invokevirtual setCompanionWidget : (Ljava/lang/Object;)V
    //   495: aload_0
    //   496: getfield mLayoutWidget : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
    //   499: aload #6
    //   501: invokevirtual add : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;)V
    //   504: aload #8
    //   506: getfield verticalDimensionFixed : Z
    //   509: ifeq -> 520
    //   512: aload #8
    //   514: getfield horizontalDimensionFixed : Z
    //   517: ifne -> 530
    //   520: aload_0
    //   521: getfield mVariableDimensionsWidgets : Ljava/util/ArrayList;
    //   524: aload #6
    //   526: invokevirtual add : (Ljava/lang/Object;)Z
    //   529: pop
    //   530: aload #8
    //   532: getfield isGuideline : Z
    //   535: ifeq -> 658
    //   538: aload #6
    //   540: checkcast androidx/constraintlayout/solver/widgets/Guideline
    //   543: astore #6
    //   545: aload #8
    //   547: getfield resolvedGuideBegin : I
    //   550: istore #9
    //   552: aload #8
    //   554: getfield resolvedGuideEnd : I
    //   557: istore_3
    //   558: aload #8
    //   560: getfield resolvedGuidePercent : F
    //   563: fstore #11
    //   565: getstatic android/os/Build$VERSION.SDK_INT : I
    //   568: bipush #17
    //   570: if_icmpge -> 593
    //   573: aload #8
    //   575: getfield guideBegin : I
    //   578: istore #9
    //   580: aload #8
    //   582: getfield guideEnd : I
    //   585: istore_3
    //   586: aload #8
    //   588: getfield guidePercent : F
    //   591: fstore #11
    //   593: fload #11
    //   595: ldc_w -1.0
    //   598: fcmpl
    //   599: ifeq -> 616
    //   602: aload #6
    //   604: fload #11
    //   606: invokevirtual setGuidePercent : (F)V
    //   609: iload #4
    //   611: istore #9
    //   613: goto -> 2031
    //   616: iload #9
    //   618: iconst_m1
    //   619: if_icmpeq -> 636
    //   622: aload #6
    //   624: iload #9
    //   626: invokevirtual setGuideBegin : (I)V
    //   629: iload #4
    //   631: istore #9
    //   633: goto -> 2031
    //   636: iload #4
    //   638: istore #9
    //   640: iload_3
    //   641: iconst_m1
    //   642: if_icmpeq -> 2031
    //   645: aload #6
    //   647: iload_3
    //   648: invokevirtual setGuideEnd : (I)V
    //   651: iload #4
    //   653: istore #9
    //   655: goto -> 2031
    //   658: aload #8
    //   660: getfield leftToLeft : I
    //   663: iconst_m1
    //   664: if_icmpne -> 824
    //   667: aload #8
    //   669: getfield leftToRight : I
    //   672: iconst_m1
    //   673: if_icmpne -> 824
    //   676: aload #8
    //   678: getfield rightToLeft : I
    //   681: iconst_m1
    //   682: if_icmpne -> 824
    //   685: aload #8
    //   687: getfield rightToRight : I
    //   690: iconst_m1
    //   691: if_icmpne -> 824
    //   694: aload #8
    //   696: getfield startToStart : I
    //   699: iconst_m1
    //   700: if_icmpne -> 824
    //   703: aload #8
    //   705: getfield startToEnd : I
    //   708: iconst_m1
    //   709: if_icmpne -> 824
    //   712: aload #8
    //   714: getfield endToStart : I
    //   717: iconst_m1
    //   718: if_icmpne -> 824
    //   721: aload #8
    //   723: getfield endToEnd : I
    //   726: iconst_m1
    //   727: if_icmpne -> 824
    //   730: aload #8
    //   732: getfield topToTop : I
    //   735: iconst_m1
    //   736: if_icmpne -> 824
    //   739: aload #8
    //   741: getfield topToBottom : I
    //   744: iconst_m1
    //   745: if_icmpne -> 824
    //   748: aload #8
    //   750: getfield bottomToTop : I
    //   753: iconst_m1
    //   754: if_icmpne -> 824
    //   757: aload #8
    //   759: getfield bottomToBottom : I
    //   762: iconst_m1
    //   763: if_icmpne -> 824
    //   766: aload #8
    //   768: getfield baselineToBaseline : I
    //   771: iconst_m1
    //   772: if_icmpne -> 824
    //   775: aload #8
    //   777: getfield editorAbsoluteX : I
    //   780: iconst_m1
    //   781: if_icmpne -> 824
    //   784: aload #8
    //   786: getfield editorAbsoluteY : I
    //   789: iconst_m1
    //   790: if_icmpne -> 824
    //   793: aload #8
    //   795: getfield circleConstraint : I
    //   798: iconst_m1
    //   799: if_icmpne -> 824
    //   802: aload #8
    //   804: getfield width : I
    //   807: iconst_m1
    //   808: if_icmpeq -> 824
    //   811: iload #4
    //   813: istore #9
    //   815: aload #8
    //   817: getfield height : I
    //   820: iconst_m1
    //   821: if_icmpne -> 2031
    //   824: aload #8
    //   826: getfield resolvedLeftToLeft : I
    //   829: istore #12
    //   831: aload #8
    //   833: getfield resolvedLeftToRight : I
    //   836: istore #13
    //   838: aload #8
    //   840: getfield resolvedRightToLeft : I
    //   843: istore_3
    //   844: aload #8
    //   846: getfield resolvedRightToRight : I
    //   849: istore #4
    //   851: aload #8
    //   853: getfield resolveGoneLeftMargin : I
    //   856: istore #14
    //   858: aload #8
    //   860: getfield resolveGoneRightMargin : I
    //   863: istore #9
    //   865: aload #8
    //   867: getfield resolvedHorizontalBias : F
    //   870: fstore #11
    //   872: getstatic android/os/Build$VERSION.SDK_INT : I
    //   875: bipush #17
    //   877: if_icmpge -> 1095
    //   880: aload #8
    //   882: getfield leftToLeft : I
    //   885: istore #13
    //   887: aload #8
    //   889: getfield leftToRight : I
    //   892: istore #9
    //   894: aload #8
    //   896: getfield rightToLeft : I
    //   899: istore #15
    //   901: aload #8
    //   903: getfield rightToRight : I
    //   906: istore #12
    //   908: aload #8
    //   910: getfield goneLeftMargin : I
    //   913: istore #14
    //   915: aload #8
    //   917: getfield goneRightMargin : I
    //   920: istore #16
    //   922: aload #8
    //   924: getfield horizontalBias : F
    //   927: fstore #11
    //   929: iload #13
    //   931: istore_3
    //   932: iload #9
    //   934: istore #4
    //   936: iload #13
    //   938: iconst_m1
    //   939: if_icmpne -> 1003
    //   942: iload #13
    //   944: istore_3
    //   945: iload #9
    //   947: istore #4
    //   949: iload #9
    //   951: iconst_m1
    //   952: if_icmpne -> 1003
    //   955: aload #8
    //   957: getfield startToStart : I
    //   960: iconst_m1
    //   961: if_icmpeq -> 977
    //   964: aload #8
    //   966: getfield startToStart : I
    //   969: istore_3
    //   970: iload #9
    //   972: istore #4
    //   974: goto -> 1003
    //   977: iload #13
    //   979: istore_3
    //   980: iload #9
    //   982: istore #4
    //   984: aload #8
    //   986: getfield startToEnd : I
    //   989: iconst_m1
    //   990: if_icmpeq -> 1003
    //   993: aload #8
    //   995: getfield startToEnd : I
    //   998: istore #4
    //   1000: iload #13
    //   1002: istore_3
    //   1003: iload_3
    //   1004: istore #9
    //   1006: iload #4
    //   1008: istore #13
    //   1010: iload #15
    //   1012: istore_3
    //   1013: iload #12
    //   1015: istore #4
    //   1017: iload #15
    //   1019: iconst_m1
    //   1020: if_icmpne -> 1084
    //   1023: iload #15
    //   1025: istore_3
    //   1026: iload #12
    //   1028: istore #4
    //   1030: iload #12
    //   1032: iconst_m1
    //   1033: if_icmpne -> 1084
    //   1036: aload #8
    //   1038: getfield endToStart : I
    //   1041: iconst_m1
    //   1042: if_icmpeq -> 1058
    //   1045: aload #8
    //   1047: getfield endToStart : I
    //   1050: istore_3
    //   1051: iload #12
    //   1053: istore #4
    //   1055: goto -> 1084
    //   1058: iload #15
    //   1060: istore_3
    //   1061: iload #12
    //   1063: istore #4
    //   1065: aload #8
    //   1067: getfield endToEnd : I
    //   1070: iconst_m1
    //   1071: if_icmpeq -> 1084
    //   1074: aload #8
    //   1076: getfield endToEnd : I
    //   1079: istore #4
    //   1081: iload #15
    //   1083: istore_3
    //   1084: iload #9
    //   1086: istore #12
    //   1088: iload #16
    //   1090: istore #9
    //   1092: goto -> 1095
    //   1095: aload #8
    //   1097: getfield circleConstraint : I
    //   1100: iconst_m1
    //   1101: if_icmpeq -> 1140
    //   1104: aload_0
    //   1105: aload #8
    //   1107: getfield circleConstraint : I
    //   1110: invokespecial getTargetWidget : (I)Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1113: astore #5
    //   1115: aload #5
    //   1117: ifnull -> 1693
    //   1120: aload #6
    //   1122: aload #5
    //   1124: aload #8
    //   1126: getfield circleAngle : F
    //   1129: aload #8
    //   1131: getfield circleRadius : I
    //   1134: invokevirtual connectCircularConstraint : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget;FI)V
    //   1137: goto -> 1693
    //   1140: iload #12
    //   1142: iconst_m1
    //   1143: if_icmpeq -> 1189
    //   1146: aload_0
    //   1147: iload #12
    //   1149: invokespecial getTargetWidget : (I)Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1152: astore #5
    //   1154: aload #5
    //   1156: ifnull -> 1182
    //   1159: aload #6
    //   1161: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.LEFT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   1164: aload #5
    //   1166: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.LEFT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   1169: aload #8
    //   1171: getfield leftMargin : I
    //   1174: iload #14
    //   1176: invokevirtual immediateConnect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;II)V
    //   1179: goto -> 1182
    //   1182: iload #4
    //   1184: istore #13
    //   1186: goto -> 1232
    //   1189: iload #4
    //   1191: istore #16
    //   1193: iload #13
    //   1195: iconst_m1
    //   1196: if_icmpeq -> 1232
    //   1199: aload_0
    //   1200: iload #13
    //   1202: invokespecial getTargetWidget : (I)Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1205: astore #5
    //   1207: aload #5
    //   1209: ifnull -> 1232
    //   1212: aload #6
    //   1214: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.LEFT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   1217: aload #5
    //   1219: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.RIGHT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   1222: aload #8
    //   1224: getfield leftMargin : I
    //   1227: iload #14
    //   1229: invokevirtual immediateConnect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;II)V
    //   1232: iload_3
    //   1233: iconst_m1
    //   1234: if_icmpeq -> 1272
    //   1237: aload_0
    //   1238: iload_3
    //   1239: invokespecial getTargetWidget : (I)Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1242: astore #5
    //   1244: aload #5
    //   1246: ifnull -> 1311
    //   1249: aload #6
    //   1251: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.RIGHT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   1254: aload #5
    //   1256: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.LEFT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   1259: aload #8
    //   1261: getfield rightMargin : I
    //   1264: iload #9
    //   1266: invokevirtual immediateConnect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;II)V
    //   1269: goto -> 1311
    //   1272: iload #4
    //   1274: iconst_m1
    //   1275: if_icmpeq -> 1311
    //   1278: aload_0
    //   1279: iload #4
    //   1281: invokespecial getTargetWidget : (I)Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1284: astore #5
    //   1286: aload #5
    //   1288: ifnull -> 1311
    //   1291: aload #6
    //   1293: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.RIGHT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   1296: aload #5
    //   1298: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.RIGHT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   1301: aload #8
    //   1303: getfield rightMargin : I
    //   1306: iload #9
    //   1308: invokevirtual immediateConnect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;II)V
    //   1311: aload #8
    //   1313: getfield topToTop : I
    //   1316: iconst_m1
    //   1317: if_icmpeq -> 1362
    //   1320: aload_0
    //   1321: aload #8
    //   1323: getfield topToTop : I
    //   1326: invokespecial getTargetWidget : (I)Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1329: astore #5
    //   1331: aload #5
    //   1333: ifnull -> 1410
    //   1336: aload #6
    //   1338: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.TOP : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   1341: aload #5
    //   1343: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.TOP : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   1346: aload #8
    //   1348: getfield topMargin : I
    //   1351: aload #8
    //   1353: getfield goneTopMargin : I
    //   1356: invokevirtual immediateConnect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;II)V
    //   1359: goto -> 1410
    //   1362: aload #8
    //   1364: getfield topToBottom : I
    //   1367: iconst_m1
    //   1368: if_icmpeq -> 1410
    //   1371: aload_0
    //   1372: aload #8
    //   1374: getfield topToBottom : I
    //   1377: invokespecial getTargetWidget : (I)Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1380: astore #5
    //   1382: aload #5
    //   1384: ifnull -> 1410
    //   1387: aload #6
    //   1389: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.TOP : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   1392: aload #5
    //   1394: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   1397: aload #8
    //   1399: getfield topMargin : I
    //   1402: aload #8
    //   1404: getfield goneTopMargin : I
    //   1407: invokevirtual immediateConnect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;II)V
    //   1410: aload #8
    //   1412: getfield bottomToTop : I
    //   1415: iconst_m1
    //   1416: if_icmpeq -> 1461
    //   1419: aload_0
    //   1420: aload #8
    //   1422: getfield bottomToTop : I
    //   1425: invokespecial getTargetWidget : (I)Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1428: astore #5
    //   1430: aload #5
    //   1432: ifnull -> 1509
    //   1435: aload #6
    //   1437: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   1440: aload #5
    //   1442: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.TOP : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   1445: aload #8
    //   1447: getfield bottomMargin : I
    //   1450: aload #8
    //   1452: getfield goneBottomMargin : I
    //   1455: invokevirtual immediateConnect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;II)V
    //   1458: goto -> 1509
    //   1461: aload #8
    //   1463: getfield bottomToBottom : I
    //   1466: iconst_m1
    //   1467: if_icmpeq -> 1509
    //   1470: aload_0
    //   1471: aload #8
    //   1473: getfield bottomToBottom : I
    //   1476: invokespecial getTargetWidget : (I)Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1479: astore #5
    //   1481: aload #5
    //   1483: ifnull -> 1509
    //   1486: aload #6
    //   1488: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   1491: aload #5
    //   1493: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   1496: aload #8
    //   1498: getfield bottomMargin : I
    //   1501: aload #8
    //   1503: getfield goneBottomMargin : I
    //   1506: invokevirtual immediateConnect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;Landroidx/constraintlayout/solver/widgets/ConstraintWidget;Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;II)V
    //   1509: aload #8
    //   1511: getfield baselineToBaseline : I
    //   1514: iconst_m1
    //   1515: if_icmpeq -> 1638
    //   1518: aload_0
    //   1519: getfield mChildrenByIds : Landroid/util/SparseArray;
    //   1522: aload #8
    //   1524: getfield baselineToBaseline : I
    //   1527: invokevirtual get : (I)Ljava/lang/Object;
    //   1530: checkcast android/view/View
    //   1533: astore #10
    //   1535: aload_0
    //   1536: aload #8
    //   1538: getfield baselineToBaseline : I
    //   1541: invokespecial getTargetWidget : (I)Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1544: astore #5
    //   1546: aload #5
    //   1548: ifnull -> 1638
    //   1551: aload #10
    //   1553: ifnull -> 1638
    //   1556: aload #10
    //   1558: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1561: instanceof androidx/constraintlayout/widget/ConstraintLayout$LayoutParams
    //   1564: ifeq -> 1638
    //   1567: aload #10
    //   1569: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1572: checkcast androidx/constraintlayout/widget/ConstraintLayout$LayoutParams
    //   1575: astore #10
    //   1577: aload #8
    //   1579: iconst_1
    //   1580: putfield needsBaseline : Z
    //   1583: aload #10
    //   1585: iconst_1
    //   1586: putfield needsBaseline : Z
    //   1589: aload #6
    //   1591: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BASELINE : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   1594: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1597: aload #5
    //   1599: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BASELINE : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   1602: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1605: iconst_0
    //   1606: iconst_m1
    //   1607: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Strength.STRONG : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Strength;
    //   1610: iconst_0
    //   1611: iconst_1
    //   1612: invokevirtual connect : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;IILandroidx/constraintlayout/solver/widgets/ConstraintAnchor$Strength;IZ)Z
    //   1615: pop
    //   1616: aload #6
    //   1618: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.TOP : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   1621: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1624: invokevirtual reset : ()V
    //   1627: aload #6
    //   1629: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   1632: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1635: invokevirtual reset : ()V
    //   1638: fload #11
    //   1640: fconst_0
    //   1641: fcmpl
    //   1642: iflt -> 1661
    //   1645: fload #11
    //   1647: ldc_w 0.5
    //   1650: fcmpl
    //   1651: ifeq -> 1661
    //   1654: aload #6
    //   1656: fload #11
    //   1658: invokevirtual setHorizontalBiasPercent : (F)V
    //   1661: aload #8
    //   1663: getfield verticalBias : F
    //   1666: fconst_0
    //   1667: fcmpl
    //   1668: iflt -> 1693
    //   1671: aload #8
    //   1673: getfield verticalBias : F
    //   1676: ldc_w 0.5
    //   1679: fcmpl
    //   1680: ifeq -> 1693
    //   1683: aload #6
    //   1685: aload #8
    //   1687: getfield verticalBias : F
    //   1690: invokevirtual setVerticalBiasPercent : (F)V
    //   1693: iload_1
    //   1694: ifeq -> 1730
    //   1697: aload #8
    //   1699: getfield editorAbsoluteX : I
    //   1702: iconst_m1
    //   1703: if_icmpne -> 1715
    //   1706: aload #8
    //   1708: getfield editorAbsoluteY : I
    //   1711: iconst_m1
    //   1712: if_icmpeq -> 1730
    //   1715: aload #6
    //   1717: aload #8
    //   1719: getfield editorAbsoluteX : I
    //   1722: aload #8
    //   1724: getfield editorAbsoluteY : I
    //   1727: invokevirtual setOrigin : (II)V
    //   1730: aload #8
    //   1732: getfield horizontalDimensionFixed : Z
    //   1735: ifne -> 1807
    //   1738: aload #8
    //   1740: getfield width : I
    //   1743: iconst_m1
    //   1744: if_icmpne -> 1790
    //   1747: aload #6
    //   1749: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_PARENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1752: invokevirtual setHorizontalDimensionBehaviour : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;)V
    //   1755: aload #6
    //   1757: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.LEFT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   1760: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1763: aload #8
    //   1765: getfield leftMargin : I
    //   1768: putfield mMargin : I
    //   1771: aload #6
    //   1773: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.RIGHT : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   1776: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1779: aload #8
    //   1781: getfield rightMargin : I
    //   1784: putfield mMargin : I
    //   1787: goto -> 1825
    //   1790: aload #6
    //   1792: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1795: invokevirtual setHorizontalDimensionBehaviour : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;)V
    //   1798: aload #6
    //   1800: iconst_0
    //   1801: invokevirtual setWidth : (I)V
    //   1804: goto -> 1825
    //   1807: aload #6
    //   1809: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1812: invokevirtual setHorizontalDimensionBehaviour : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;)V
    //   1815: aload #6
    //   1817: aload #8
    //   1819: getfield width : I
    //   1822: invokevirtual setWidth : (I)V
    //   1825: aload #8
    //   1827: getfield verticalDimensionFixed : Z
    //   1830: ifne -> 1902
    //   1833: aload #8
    //   1835: getfield height : I
    //   1838: iconst_m1
    //   1839: if_icmpne -> 1885
    //   1842: aload #6
    //   1844: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_PARENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1847: invokevirtual setVerticalDimensionBehaviour : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;)V
    //   1850: aload #6
    //   1852: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.TOP : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   1855: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1858: aload #8
    //   1860: getfield topMargin : I
    //   1863: putfield mMargin : I
    //   1866: aload #6
    //   1868: getstatic androidx/constraintlayout/solver/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;
    //   1871: invokevirtual getAnchor : (Landroidx/constraintlayout/solver/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1874: aload #8
    //   1876: getfield bottomMargin : I
    //   1879: putfield mMargin : I
    //   1882: goto -> 1920
    //   1885: aload #6
    //   1887: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1890: invokevirtual setVerticalDimensionBehaviour : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;)V
    //   1893: aload #6
    //   1895: iconst_0
    //   1896: invokevirtual setHeight : (I)V
    //   1899: goto -> 1920
    //   1902: aload #6
    //   1904: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   1907: invokevirtual setVerticalDimensionBehaviour : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;)V
    //   1910: aload #6
    //   1912: aload #8
    //   1914: getfield height : I
    //   1917: invokevirtual setHeight : (I)V
    //   1920: iconst_0
    //   1921: istore #9
    //   1923: aload #8
    //   1925: getfield dimensionRatio : Ljava/lang/String;
    //   1928: ifnull -> 1941
    //   1931: aload #6
    //   1933: aload #8
    //   1935: getfield dimensionRatio : Ljava/lang/String;
    //   1938: invokevirtual setDimensionRatio : (Ljava/lang/String;)V
    //   1941: aload #6
    //   1943: aload #8
    //   1945: getfield horizontalWeight : F
    //   1948: invokevirtual setHorizontalWeight : (F)V
    //   1951: aload #6
    //   1953: aload #8
    //   1955: getfield verticalWeight : F
    //   1958: invokevirtual setVerticalWeight : (F)V
    //   1961: aload #6
    //   1963: aload #8
    //   1965: getfield horizontalChainStyle : I
    //   1968: invokevirtual setHorizontalChainStyle : (I)V
    //   1971: aload #6
    //   1973: aload #8
    //   1975: getfield verticalChainStyle : I
    //   1978: invokevirtual setVerticalChainStyle : (I)V
    //   1981: aload #6
    //   1983: aload #8
    //   1985: getfield matchConstraintDefaultWidth : I
    //   1988: aload #8
    //   1990: getfield matchConstraintMinWidth : I
    //   1993: aload #8
    //   1995: getfield matchConstraintMaxWidth : I
    //   1998: aload #8
    //   2000: getfield matchConstraintPercentWidth : F
    //   2003: invokevirtual setHorizontalMatchStyle : (IIIF)V
    //   2006: aload #6
    //   2008: aload #8
    //   2010: getfield matchConstraintDefaultHeight : I
    //   2013: aload #8
    //   2015: getfield matchConstraintMinHeight : I
    //   2018: aload #8
    //   2020: getfield matchConstraintMaxHeight : I
    //   2023: aload #8
    //   2025: getfield matchConstraintPercentHeight : F
    //   2028: invokevirtual setVerticalMatchStyle : (IIIF)V
    //   2031: iinc #7, 1
    //   2034: iload #9
    //   2036: istore #4
    //   2038: goto -> 331
    //   2041: return
    //   2042: astore #8
    //   2044: goto -> 106
    //   2047: astore #10
    //   2049: goto -> 463
    // Exception table:
    //   from	to	target	type
    //   33	71	2042	android/content/res/Resources$NotFoundException
    //   81	92	2042	android/content/res/Resources$NotFoundException
    //   92	106	2042	android/content/res/Resources$NotFoundException
    //   402	463	2047	android/content/res/Resources$NotFoundException
  }
  
  private void setSelfDimensionBehaviour(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: iload_1
    //   1: invokestatic getMode : (I)I
    //   4: istore_3
    //   5: iload_1
    //   6: invokestatic getSize : (I)I
    //   9: istore_1
    //   10: iload_2
    //   11: invokestatic getMode : (I)I
    //   14: istore #4
    //   16: iload_2
    //   17: invokestatic getSize : (I)I
    //   20: istore_2
    //   21: aload_0
    //   22: invokevirtual getPaddingTop : ()I
    //   25: istore #5
    //   27: aload_0
    //   28: invokevirtual getPaddingBottom : ()I
    //   31: istore #6
    //   33: aload_0
    //   34: invokevirtual getPaddingLeft : ()I
    //   37: istore #7
    //   39: aload_0
    //   40: invokevirtual getPaddingRight : ()I
    //   43: istore #8
    //   45: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   48: astore #9
    //   50: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   53: astore #10
    //   55: aload_0
    //   56: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   59: pop
    //   60: iload_3
    //   61: ldc_w -2147483648
    //   64: if_icmpeq -> 109
    //   67: iload_3
    //   68: ifeq -> 101
    //   71: iload_3
    //   72: ldc_w 1073741824
    //   75: if_icmpeq -> 83
    //   78: iconst_0
    //   79: istore_1
    //   80: goto -> 114
    //   83: aload_0
    //   84: getfield mMaxWidth : I
    //   87: iload_1
    //   88: invokestatic min : (II)I
    //   91: iload #7
    //   93: iload #8
    //   95: iadd
    //   96: isub
    //   97: istore_1
    //   98: goto -> 114
    //   101: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   104: astore #9
    //   106: goto -> 78
    //   109: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   112: astore #9
    //   114: iload #4
    //   116: ldc_w -2147483648
    //   119: if_icmpeq -> 166
    //   122: iload #4
    //   124: ifeq -> 158
    //   127: iload #4
    //   129: ldc_w 1073741824
    //   132: if_icmpeq -> 140
    //   135: iconst_0
    //   136: istore_2
    //   137: goto -> 171
    //   140: aload_0
    //   141: getfield mMaxHeight : I
    //   144: iload_2
    //   145: invokestatic min : (II)I
    //   148: iload #5
    //   150: iload #6
    //   152: iadd
    //   153: isub
    //   154: istore_2
    //   155: goto -> 171
    //   158: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   161: astore #10
    //   163: goto -> 135
    //   166: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   169: astore #10
    //   171: aload_0
    //   172: getfield mLayoutWidget : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
    //   175: iconst_0
    //   176: invokevirtual setMinWidth : (I)V
    //   179: aload_0
    //   180: getfield mLayoutWidget : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
    //   183: iconst_0
    //   184: invokevirtual setMinHeight : (I)V
    //   187: aload_0
    //   188: getfield mLayoutWidget : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
    //   191: aload #9
    //   193: invokevirtual setHorizontalDimensionBehaviour : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;)V
    //   196: aload_0
    //   197: getfield mLayoutWidget : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
    //   200: iload_1
    //   201: invokevirtual setWidth : (I)V
    //   204: aload_0
    //   205: getfield mLayoutWidget : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
    //   208: aload #10
    //   210: invokevirtual setVerticalDimensionBehaviour : (Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;)V
    //   213: aload_0
    //   214: getfield mLayoutWidget : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
    //   217: iload_2
    //   218: invokevirtual setHeight : (I)V
    //   221: aload_0
    //   222: getfield mLayoutWidget : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
    //   225: aload_0
    //   226: getfield mMinWidth : I
    //   229: aload_0
    //   230: invokevirtual getPaddingLeft : ()I
    //   233: isub
    //   234: aload_0
    //   235: invokevirtual getPaddingRight : ()I
    //   238: isub
    //   239: invokevirtual setMinWidth : (I)V
    //   242: aload_0
    //   243: getfield mLayoutWidget : Landroidx/constraintlayout/solver/widgets/ConstraintWidgetContainer;
    //   246: aload_0
    //   247: getfield mMinHeight : I
    //   250: aload_0
    //   251: invokevirtual getPaddingTop : ()I
    //   254: isub
    //   255: aload_0
    //   256: invokevirtual getPaddingBottom : ()I
    //   259: isub
    //   260: invokevirtual setMinHeight : (I)V
    //   263: return
  }
  
  private void updateHierarchy() {
    boolean bool2;
    int i = getChildCount();
    boolean bool1 = false;
    byte b = 0;
    while (true) {
      bool2 = bool1;
      if (b < i) {
        if (getChildAt(b).isLayoutRequested()) {
          bool2 = true;
          break;
        } 
        b++;
        continue;
      } 
      break;
    } 
    if (bool2) {
      this.mVariableDimensionsWidgets.clear();
      setChildrenConstraints();
    } 
  }
  
  private void updatePostMeasures() {
    int i = getChildCount();
    boolean bool = false;
    byte b;
    for (b = 0; b < i; b++) {
      View view = getChildAt(b);
      if (view instanceof Placeholder)
        ((Placeholder)view).updatePostMeasure(this); 
    } 
    i = this.mConstraintHelpers.size();
    if (i > 0)
      for (b = bool; b < i; b++)
        ((ConstraintHelper)this.mConstraintHelpers.get(b)).updatePostMeasure(this);  
  }
  
  public void addView(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams) {
    super.addView(paramView, paramInt, paramLayoutParams);
    if (Build.VERSION.SDK_INT < 14)
      onViewAdded(paramView); 
  }
  
  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return paramLayoutParams instanceof LayoutParams;
  }
  
  public void dispatchDraw(Canvas paramCanvas) {
    super.dispatchDraw(paramCanvas);
    if (isInEditMode()) {
      int i = getChildCount();
      float f1 = getWidth();
      float f2 = getHeight();
      for (byte b = 0; b < i; b++) {
        View view = getChildAt(b);
        if (view.getVisibility() != 8) {
          Object object = view.getTag();
          if (object != null && object instanceof String) {
            object = ((String)object).split(",");
            if (object.length == 4) {
              int j = Integer.parseInt((String)object[0]);
              int k = Integer.parseInt((String)object[1]);
              int m = Integer.parseInt((String)object[2]);
              int n = Integer.parseInt((String)object[3]);
              j = (int)(j / 1080.0F * f1);
              k = (int)(k / 1920.0F * f2);
              m = (int)(m / 1080.0F * f1);
              n = (int)(n / 1920.0F * f2);
              object = new Paint();
              object.setColor(-65536);
              float f3 = j;
              float f4 = k;
              float f5 = (j + m);
              paramCanvas.drawLine(f3, f4, f5, f4, (Paint)object);
              float f6 = (k + n);
              paramCanvas.drawLine(f5, f4, f5, f6, (Paint)object);
              paramCanvas.drawLine(f5, f6, f3, f6, (Paint)object);
              paramCanvas.drawLine(f3, f6, f3, f4, (Paint)object);
              object.setColor(-16711936);
              paramCanvas.drawLine(f3, f4, f5, f6, (Paint)object);
              paramCanvas.drawLine(f3, f6, f5, f4, (Paint)object);
            } 
          } 
        } 
      } 
    } 
  }
  
  public void fillMetrics(Metrics paramMetrics) {
    this.mMetrics = paramMetrics;
    this.mLayoutWidget.fillMetrics(paramMetrics);
  }
  
  protected LayoutParams generateDefaultLayoutParams() {
    return new LayoutParams(-2, -2);
  }
  
  protected ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (ViewGroup.LayoutParams)new LayoutParams(paramLayoutParams);
  }
  
  public LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    return new LayoutParams(getContext(), paramAttributeSet);
  }
  
  public Object getDesignInformation(int paramInt, Object<String, Integer> paramObject) {
    if (paramInt == 0 && paramObject instanceof String) {
      String str = (String)paramObject;
      paramObject = (Object<String, Integer>)this.mDesignIds;
      if (paramObject != null && paramObject.containsKey(str))
        return this.mDesignIds.get(str); 
    } 
    return null;
  }
  
  public int getMaxHeight() {
    return this.mMaxHeight;
  }
  
  public int getMaxWidth() {
    return this.mMaxWidth;
  }
  
  public int getMinHeight() {
    return this.mMinHeight;
  }
  
  public int getMinWidth() {
    return this.mMinWidth;
  }
  
  public int getOptimizationLevel() {
    return this.mLayoutWidget.getOptimizationLevel();
  }
  
  public View getViewById(int paramInt) {
    return (View)this.mChildrenByIds.get(paramInt);
  }
  
  public final ConstraintWidget getViewWidget(View paramView) {
    ConstraintWidget constraintWidget;
    if (paramView == this)
      return (ConstraintWidget)this.mLayoutWidget; 
    if (paramView == null) {
      paramView = null;
    } else {
      constraintWidget = ((LayoutParams)paramView.getLayoutParams()).widget;
    } 
    return constraintWidget;
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    paramInt3 = getChildCount();
    paramBoolean = isInEditMode();
    paramInt2 = 0;
    for (paramInt1 = 0; paramInt1 < paramInt3; paramInt1++) {
      View view = getChildAt(paramInt1);
      LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
      ConstraintWidget constraintWidget = layoutParams.widget;
      if ((view.getVisibility() != 8 || layoutParams.isGuideline || layoutParams.isHelper || paramBoolean) && !layoutParams.isInPlaceholder) {
        int i = constraintWidget.getDrawX();
        int j = constraintWidget.getDrawY();
        int k = constraintWidget.getWidth() + i;
        paramInt4 = constraintWidget.getHeight() + j;
        view.layout(i, j, k, paramInt4);
        if (view instanceof Placeholder) {
          View view1 = ((Placeholder)view).getContent();
          if (view1 != null) {
            view1.setVisibility(0);
            view1.layout(i, j, k, paramInt4);
          } 
        } 
      } 
    } 
    paramInt3 = this.mConstraintHelpers.size();
    if (paramInt3 > 0)
      for (paramInt1 = paramInt2; paramInt1 < paramInt3; paramInt1++)
        ((ConstraintHelper)this.mConstraintHelpers.get(paramInt1)).updatePostLayout(this);  
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    int i4;
    boolean bool;
    System.currentTimeMillis();
    int i = View.MeasureSpec.getMode(paramInt1);
    int j = View.MeasureSpec.getSize(paramInt1);
    int k = View.MeasureSpec.getMode(paramInt2);
    int m = View.MeasureSpec.getSize(paramInt2);
    int n = getPaddingLeft();
    int i1 = getPaddingTop();
    this.mLayoutWidget.setX(n);
    this.mLayoutWidget.setY(i1);
    this.mLayoutWidget.setMaxWidth(this.mMaxWidth);
    this.mLayoutWidget.setMaxHeight(this.mMaxHeight);
    if (Build.VERSION.SDK_INT >= 17) {
      boolean bool1;
      ConstraintWidgetContainer constraintWidgetContainer = this.mLayoutWidget;
      if (getLayoutDirection() == 1) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      constraintWidgetContainer.setRtl(bool1);
    } 
    setSelfDimensionBehaviour(paramInt1, paramInt2);
    int i2 = this.mLayoutWidget.getWidth();
    int i3 = this.mLayoutWidget.getHeight();
    if (this.mDirtyHierarchy) {
      this.mDirtyHierarchy = false;
      updateHierarchy();
      i4 = 1;
    } else {
      i4 = 0;
    } 
    if ((this.mOptimizationLevel & 0x8) == 8) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      this.mLayoutWidget.preOptimize();
      this.mLayoutWidget.optimizeForDimensions(i2, i3);
      internalMeasureDimensions(paramInt1, paramInt2);
    } else {
      internalMeasureChildren(paramInt1, paramInt2);
    } 
    updatePostMeasures();
    if (getChildCount() > 0 && i4)
      Analyzer.determineGroups(this.mLayoutWidget); 
    if (this.mLayoutWidget.mGroupsWrapOptimized) {
      if (this.mLayoutWidget.mHorizontalWrapOptimized && i == Integer.MIN_VALUE) {
        if (this.mLayoutWidget.mWrapFixedWidth < j) {
          ConstraintWidgetContainer constraintWidgetContainer = this.mLayoutWidget;
          constraintWidgetContainer.setWidth(constraintWidgetContainer.mWrapFixedWidth);
        } 
        this.mLayoutWidget.setHorizontalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.FIXED);
      } 
      if (this.mLayoutWidget.mVerticalWrapOptimized && k == Integer.MIN_VALUE) {
        if (this.mLayoutWidget.mWrapFixedHeight < m) {
          ConstraintWidgetContainer constraintWidgetContainer = this.mLayoutWidget;
          constraintWidgetContainer.setHeight(constraintWidgetContainer.mWrapFixedHeight);
        } 
        this.mLayoutWidget.setVerticalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.FIXED);
      } 
    } 
    if ((this.mOptimizationLevel & 0x20) == 32) {
      i4 = this.mLayoutWidget.getWidth();
      int i8 = this.mLayoutWidget.getHeight();
      if (this.mLastMeasureWidth != i4 && i == 1073741824)
        Analyzer.setPosition(this.mLayoutWidget.mWidgetGroups, 0, i4); 
      if (this.mLastMeasureHeight != i8 && k == 1073741824)
        Analyzer.setPosition(this.mLayoutWidget.mWidgetGroups, 1, i8); 
      if (this.mLayoutWidget.mHorizontalWrapOptimized && this.mLayoutWidget.mWrapFixedWidth > j)
        Analyzer.setPosition(this.mLayoutWidget.mWidgetGroups, 0, j); 
      if (this.mLayoutWidget.mVerticalWrapOptimized && this.mLayoutWidget.mWrapFixedHeight > m)
        Analyzer.setPosition(this.mLayoutWidget.mWidgetGroups, 1, m); 
    } 
    if (getChildCount() > 0)
      solveLinearSystem("First pass"); 
    int i5 = this.mVariableDimensionsWidgets.size();
    int i6 = i1 + getPaddingBottom();
    int i7 = n + getPaddingRight();
    if (i5 > 0) {
      if (this.mLayoutWidget.getHorizontalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT) {
        m = 1;
      } else {
        m = 0;
      } 
      if (this.mLayoutWidget.getVerticalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT) {
        k = 1;
      } else {
        k = 0;
      } 
      i1 = Math.max(this.mLayoutWidget.getWidth(), this.mMinWidth);
      n = Math.max(this.mLayoutWidget.getHeight(), this.mMinHeight);
      byte b = 0;
      i = 0;
      i4 = 0;
      while (b < i5) {
        ConstraintWidget constraintWidget = this.mVariableDimensionsWidgets.get(b);
        View view = (View)constraintWidget.getCompanionWidget();
        if (view != null) {
          LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
          if (!layoutParams.isHelper && !layoutParams.isGuideline) {
            int i8 = view.getVisibility();
            j = i;
            if (i8 != 8 && (!bool || !constraintWidget.getResolutionWidth().isResolved() || !constraintWidget.getResolutionHeight().isResolved())) {
              if (layoutParams.width == -2 && layoutParams.horizontalDimensionFixed) {
                i = getChildMeasureSpec(paramInt1, i7, layoutParams.width);
              } else {
                i = View.MeasureSpec.makeMeasureSpec(constraintWidget.getWidth(), 1073741824);
              } 
              if (layoutParams.height == -2 && layoutParams.verticalDimensionFixed) {
                i8 = getChildMeasureSpec(paramInt2, i6, layoutParams.height);
              } else {
                i8 = View.MeasureSpec.makeMeasureSpec(constraintWidget.getHeight(), 1073741824);
              } 
              view.measure(i, i8);
              Metrics metrics = this.mMetrics;
              if (metrics != null)
                metrics.additionalMeasures++; 
              int i9 = view.getMeasuredWidth();
              i8 = view.getMeasuredHeight();
              i = i1;
              if (i9 != constraintWidget.getWidth()) {
                constraintWidget.setWidth(i9);
                if (bool)
                  constraintWidget.getResolutionWidth().resolve(i9); 
                i = i1;
                if (m != 0) {
                  i = i1;
                  if (constraintWidget.getRight() > i1)
                    i = Math.max(i1, constraintWidget.getRight() + constraintWidget.getAnchor(ConstraintAnchor.Type.RIGHT).getMargin()); 
                } 
                j = 1;
              } 
              i1 = n;
              if (i8 != constraintWidget.getHeight()) {
                constraintWidget.setHeight(i8);
                if (bool)
                  constraintWidget.getResolutionHeight().resolve(i8); 
                i1 = n;
                if (k != 0) {
                  i1 = n;
                  if (constraintWidget.getBottom() > n)
                    i1 = Math.max(n, constraintWidget.getBottom() + constraintWidget.getAnchor(ConstraintAnchor.Type.BOTTOM).getMargin()); 
                } 
                j = 1;
              } 
              n = j;
              if (layoutParams.needsBaseline) {
                i8 = view.getBaseline();
                n = j;
                if (i8 != -1) {
                  n = j;
                  if (i8 != constraintWidget.getBaselineDistance()) {
                    constraintWidget.setBaselineDistance(i8);
                    n = 1;
                  } 
                } 
              } 
              if (Build.VERSION.SDK_INT >= 11) {
                i4 = combineMeasuredStates(i4, view.getMeasuredState());
                j = i1;
                i1 = i;
                i = n;
              } else {
                j = i1;
                i1 = i;
                i = n;
              } 
              continue;
            } 
          } 
        } 
        j = n;
        continue;
        b++;
        n = j;
      } 
      j = i4;
      if (i != 0) {
        this.mLayoutWidget.setWidth(i2);
        this.mLayoutWidget.setHeight(i3);
        if (bool)
          this.mLayoutWidget.solveGraph(); 
        solveLinearSystem("2nd pass");
        if (this.mLayoutWidget.getWidth() < i1) {
          this.mLayoutWidget.setWidth(i1);
          i4 = 1;
        } else {
          i4 = 0;
        } 
        if (this.mLayoutWidget.getHeight() < n) {
          this.mLayoutWidget.setHeight(n);
          i4 = 1;
        } 
        if (i4 != 0)
          solveLinearSystem("3rd pass"); 
      } 
      n = 0;
      while (true) {
        i4 = j;
        if (n < i5) {
          ConstraintWidget constraintWidget = this.mVariableDimensionsWidgets.get(n);
          View view = (View)constraintWidget.getCompanionWidget();
          if (view != null && (view.getMeasuredWidth() != constraintWidget.getWidth() || view.getMeasuredHeight() != constraintWidget.getHeight()) && constraintWidget.getVisibility() != 8) {
            view.measure(View.MeasureSpec.makeMeasureSpec(constraintWidget.getWidth(), 1073741824), View.MeasureSpec.makeMeasureSpec(constraintWidget.getHeight(), 1073741824));
            Metrics metrics = this.mMetrics;
            if (metrics != null)
              metrics.additionalMeasures++; 
          } 
          n++;
          continue;
        } 
        break;
      } 
    } else {
      i4 = 0;
    } 
    n = this.mLayoutWidget.getWidth() + i7;
    i1 = this.mLayoutWidget.getHeight() + i6;
    if (Build.VERSION.SDK_INT >= 11) {
      paramInt1 = resolveSizeAndState(n, paramInt1, i4);
      i4 = resolveSizeAndState(i1, paramInt2, i4 << 16);
      paramInt2 = Math.min(this.mMaxWidth, paramInt1 & 0xFFFFFF);
      i4 = Math.min(this.mMaxHeight, i4 & 0xFFFFFF);
      paramInt1 = paramInt2;
      if (this.mLayoutWidget.isWidthMeasuredTooSmall())
        paramInt1 = paramInt2 | 0x1000000; 
      paramInt2 = i4;
      if (this.mLayoutWidget.isHeightMeasuredTooSmall())
        paramInt2 = i4 | 0x1000000; 
      setMeasuredDimension(paramInt1, paramInt2);
      this.mLastMeasureWidth = paramInt1;
      this.mLastMeasureHeight = paramInt2;
    } else {
      setMeasuredDimension(n, i1);
      this.mLastMeasureWidth = n;
      this.mLastMeasureHeight = i1;
    } 
  }
  
  public void onViewAdded(View paramView) {
    if (Build.VERSION.SDK_INT >= 14)
      super.onViewAdded(paramView); 
    ConstraintWidget constraintWidget = getViewWidget(paramView);
    if (paramView instanceof Guideline && !(constraintWidget instanceof Guideline)) {
      LayoutParams layoutParams = (LayoutParams)paramView.getLayoutParams();
      layoutParams.widget = (ConstraintWidget)new Guideline();
      layoutParams.isGuideline = true;
      ((Guideline)layoutParams.widget).setOrientation(layoutParams.orientation);
    } 
    if (paramView instanceof ConstraintHelper) {
      ConstraintHelper constraintHelper = (ConstraintHelper)paramView;
      constraintHelper.validateParams();
      ((LayoutParams)paramView.getLayoutParams()).isHelper = true;
      if (!this.mConstraintHelpers.contains(constraintHelper))
        this.mConstraintHelpers.add(constraintHelper); 
    } 
    this.mChildrenByIds.put(paramView.getId(), paramView);
    this.mDirtyHierarchy = true;
  }
  
  public void onViewRemoved(View paramView) {
    if (Build.VERSION.SDK_INT >= 14)
      super.onViewRemoved(paramView); 
    this.mChildrenByIds.remove(paramView.getId());
    ConstraintWidget constraintWidget = getViewWidget(paramView);
    this.mLayoutWidget.remove(constraintWidget);
    this.mConstraintHelpers.remove(paramView);
    this.mVariableDimensionsWidgets.remove(constraintWidget);
    this.mDirtyHierarchy = true;
  }
  
  public void removeView(View paramView) {
    super.removeView(paramView);
    if (Build.VERSION.SDK_INT < 14)
      onViewRemoved(paramView); 
  }
  
  public void requestLayout() {
    super.requestLayout();
    this.mDirtyHierarchy = true;
    this.mLastMeasureWidth = -1;
    this.mLastMeasureHeight = -1;
    this.mLastMeasureWidthSize = -1;
    this.mLastMeasureHeightSize = -1;
    this.mLastMeasureWidthMode = 0;
    this.mLastMeasureHeightMode = 0;
  }
  
  public void setConstraintSet(ConstraintSet paramConstraintSet) {
    this.mConstraintSet = paramConstraintSet;
  }
  
  public void setDesignInformation(int paramInt, Object paramObject1, Object paramObject2) {
    if (paramInt == 0 && paramObject1 instanceof String && paramObject2 instanceof Integer) {
      if (this.mDesignIds == null)
        this.mDesignIds = new HashMap<String, Integer>(); 
      String str = (String)paramObject1;
      paramInt = str.indexOf("/");
      paramObject1 = str;
      if (paramInt != -1)
        paramObject1 = str.substring(paramInt + 1); 
      paramInt = ((Integer)paramObject2).intValue();
      this.mDesignIds.put(paramObject1, Integer.valueOf(paramInt));
    } 
  }
  
  public void setId(int paramInt) {
    this.mChildrenByIds.remove(getId());
    super.setId(paramInt);
    this.mChildrenByIds.put(getId(), this);
  }
  
  public void setMaxHeight(int paramInt) {
    if (paramInt == this.mMaxHeight)
      return; 
    this.mMaxHeight = paramInt;
    requestLayout();
  }
  
  public void setMaxWidth(int paramInt) {
    if (paramInt == this.mMaxWidth)
      return; 
    this.mMaxWidth = paramInt;
    requestLayout();
  }
  
  public void setMinHeight(int paramInt) {
    if (paramInt == this.mMinHeight)
      return; 
    this.mMinHeight = paramInt;
    requestLayout();
  }
  
  public void setMinWidth(int paramInt) {
    if (paramInt == this.mMinWidth)
      return; 
    this.mMinWidth = paramInt;
    requestLayout();
  }
  
  public void setOptimizationLevel(int paramInt) {
    this.mLayoutWidget.setOptimizationLevel(paramInt);
  }
  
  public boolean shouldDelayChildPressedState() {
    return false;
  }
  
  protected void solveLinearSystem(String paramString) {
    this.mLayoutWidget.layout();
    Metrics metrics = this.mMetrics;
    if (metrics != null)
      metrics.resolutions++; 
  }
  
  public static class LayoutParams extends ViewGroup.MarginLayoutParams {
    public static final int BASELINE = 5;
    
    public static final int BOTTOM = 4;
    
    public static final int CHAIN_PACKED = 2;
    
    public static final int CHAIN_SPREAD = 0;
    
    public static final int CHAIN_SPREAD_INSIDE = 1;
    
    public static final int END = 7;
    
    public static final int HORIZONTAL = 0;
    
    public static final int LEFT = 1;
    
    public static final int MATCH_CONSTRAINT = 0;
    
    public static final int MATCH_CONSTRAINT_PERCENT = 2;
    
    public static final int MATCH_CONSTRAINT_SPREAD = 0;
    
    public static final int MATCH_CONSTRAINT_WRAP = 1;
    
    public static final int PARENT_ID = 0;
    
    public static final int RIGHT = 2;
    
    public static final int START = 6;
    
    public static final int TOP = 3;
    
    public static final int UNSET = -1;
    
    public static final int VERTICAL = 1;
    
    public int baselineToBaseline = -1;
    
    public int bottomToBottom = -1;
    
    public int bottomToTop = -1;
    
    public float circleAngle = 0.0F;
    
    public int circleConstraint = -1;
    
    public int circleRadius = 0;
    
    public boolean constrainedHeight = false;
    
    public boolean constrainedWidth = false;
    
    public String dimensionRatio = null;
    
    int dimensionRatioSide = 1;
    
    float dimensionRatioValue = 0.0F;
    
    public int editorAbsoluteX = -1;
    
    public int editorAbsoluteY = -1;
    
    public int endToEnd = -1;
    
    public int endToStart = -1;
    
    public int goneBottomMargin = -1;
    
    public int goneEndMargin = -1;
    
    public int goneLeftMargin = -1;
    
    public int goneRightMargin = -1;
    
    public int goneStartMargin = -1;
    
    public int goneTopMargin = -1;
    
    public int guideBegin = -1;
    
    public int guideEnd = -1;
    
    public float guidePercent = -1.0F;
    
    public boolean helped = false;
    
    public float horizontalBias = 0.5F;
    
    public int horizontalChainStyle = 0;
    
    boolean horizontalDimensionFixed = true;
    
    public float horizontalWeight = -1.0F;
    
    boolean isGuideline = false;
    
    boolean isHelper = false;
    
    boolean isInPlaceholder = false;
    
    public int leftToLeft = -1;
    
    public int leftToRight = -1;
    
    public int matchConstraintDefaultHeight = 0;
    
    public int matchConstraintDefaultWidth = 0;
    
    public int matchConstraintMaxHeight = 0;
    
    public int matchConstraintMaxWidth = 0;
    
    public int matchConstraintMinHeight = 0;
    
    public int matchConstraintMinWidth = 0;
    
    public float matchConstraintPercentHeight = 1.0F;
    
    public float matchConstraintPercentWidth = 1.0F;
    
    boolean needsBaseline = false;
    
    public int orientation = -1;
    
    int resolveGoneLeftMargin = -1;
    
    int resolveGoneRightMargin = -1;
    
    int resolvedGuideBegin;
    
    int resolvedGuideEnd;
    
    float resolvedGuidePercent;
    
    float resolvedHorizontalBias = 0.5F;
    
    int resolvedLeftToLeft = -1;
    
    int resolvedLeftToRight = -1;
    
    int resolvedRightToLeft = -1;
    
    int resolvedRightToRight = -1;
    
    public int rightToLeft = -1;
    
    public int rightToRight = -1;
    
    public int startToEnd = -1;
    
    public int startToStart = -1;
    
    public int topToBottom = -1;
    
    public int topToTop = -1;
    
    public float verticalBias = 0.5F;
    
    public int verticalChainStyle = 0;
    
    boolean verticalDimensionFixed = true;
    
    public float verticalWeight = -1.0F;
    
    ConstraintWidget widget = new ConstraintWidget();
    
    public LayoutParams(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
    }
    
    public LayoutParams(Context param1Context, AttributeSet param1AttributeSet) {
      // Byte code:
      //   0: aload_0
      //   1: aload_1
      //   2: aload_2
      //   3: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;)V
      //   6: aload_0
      //   7: iconst_m1
      //   8: putfield guideBegin : I
      //   11: aload_0
      //   12: iconst_m1
      //   13: putfield guideEnd : I
      //   16: aload_0
      //   17: ldc -1.0
      //   19: putfield guidePercent : F
      //   22: aload_0
      //   23: iconst_m1
      //   24: putfield leftToLeft : I
      //   27: aload_0
      //   28: iconst_m1
      //   29: putfield leftToRight : I
      //   32: aload_0
      //   33: iconst_m1
      //   34: putfield rightToLeft : I
      //   37: aload_0
      //   38: iconst_m1
      //   39: putfield rightToRight : I
      //   42: aload_0
      //   43: iconst_m1
      //   44: putfield topToTop : I
      //   47: aload_0
      //   48: iconst_m1
      //   49: putfield topToBottom : I
      //   52: aload_0
      //   53: iconst_m1
      //   54: putfield bottomToTop : I
      //   57: aload_0
      //   58: iconst_m1
      //   59: putfield bottomToBottom : I
      //   62: aload_0
      //   63: iconst_m1
      //   64: putfield baselineToBaseline : I
      //   67: aload_0
      //   68: iconst_m1
      //   69: putfield circleConstraint : I
      //   72: aload_0
      //   73: iconst_0
      //   74: putfield circleRadius : I
      //   77: aload_0
      //   78: fconst_0
      //   79: putfield circleAngle : F
      //   82: aload_0
      //   83: iconst_m1
      //   84: putfield startToEnd : I
      //   87: aload_0
      //   88: iconst_m1
      //   89: putfield startToStart : I
      //   92: aload_0
      //   93: iconst_m1
      //   94: putfield endToStart : I
      //   97: aload_0
      //   98: iconst_m1
      //   99: putfield endToEnd : I
      //   102: aload_0
      //   103: iconst_m1
      //   104: putfield goneLeftMargin : I
      //   107: aload_0
      //   108: iconst_m1
      //   109: putfield goneTopMargin : I
      //   112: aload_0
      //   113: iconst_m1
      //   114: putfield goneRightMargin : I
      //   117: aload_0
      //   118: iconst_m1
      //   119: putfield goneBottomMargin : I
      //   122: aload_0
      //   123: iconst_m1
      //   124: putfield goneStartMargin : I
      //   127: aload_0
      //   128: iconst_m1
      //   129: putfield goneEndMargin : I
      //   132: aload_0
      //   133: ldc 0.5
      //   135: putfield horizontalBias : F
      //   138: aload_0
      //   139: ldc 0.5
      //   141: putfield verticalBias : F
      //   144: aload_0
      //   145: aconst_null
      //   146: putfield dimensionRatio : Ljava/lang/String;
      //   149: aload_0
      //   150: fconst_0
      //   151: putfield dimensionRatioValue : F
      //   154: aload_0
      //   155: iconst_1
      //   156: putfield dimensionRatioSide : I
      //   159: aload_0
      //   160: ldc -1.0
      //   162: putfield horizontalWeight : F
      //   165: aload_0
      //   166: ldc -1.0
      //   168: putfield verticalWeight : F
      //   171: aload_0
      //   172: iconst_0
      //   173: putfield horizontalChainStyle : I
      //   176: aload_0
      //   177: iconst_0
      //   178: putfield verticalChainStyle : I
      //   181: aload_0
      //   182: iconst_0
      //   183: putfield matchConstraintDefaultWidth : I
      //   186: aload_0
      //   187: iconst_0
      //   188: putfield matchConstraintDefaultHeight : I
      //   191: aload_0
      //   192: iconst_0
      //   193: putfield matchConstraintMinWidth : I
      //   196: aload_0
      //   197: iconst_0
      //   198: putfield matchConstraintMinHeight : I
      //   201: aload_0
      //   202: iconst_0
      //   203: putfield matchConstraintMaxWidth : I
      //   206: aload_0
      //   207: iconst_0
      //   208: putfield matchConstraintMaxHeight : I
      //   211: aload_0
      //   212: fconst_1
      //   213: putfield matchConstraintPercentWidth : F
      //   216: aload_0
      //   217: fconst_1
      //   218: putfield matchConstraintPercentHeight : F
      //   221: aload_0
      //   222: iconst_m1
      //   223: putfield editorAbsoluteX : I
      //   226: aload_0
      //   227: iconst_m1
      //   228: putfield editorAbsoluteY : I
      //   231: aload_0
      //   232: iconst_m1
      //   233: putfield orientation : I
      //   236: aload_0
      //   237: iconst_0
      //   238: putfield constrainedWidth : Z
      //   241: aload_0
      //   242: iconst_0
      //   243: putfield constrainedHeight : Z
      //   246: aload_0
      //   247: iconst_1
      //   248: putfield horizontalDimensionFixed : Z
      //   251: aload_0
      //   252: iconst_1
      //   253: putfield verticalDimensionFixed : Z
      //   256: aload_0
      //   257: iconst_0
      //   258: putfield needsBaseline : Z
      //   261: aload_0
      //   262: iconst_0
      //   263: putfield isGuideline : Z
      //   266: aload_0
      //   267: iconst_0
      //   268: putfield isHelper : Z
      //   271: aload_0
      //   272: iconst_0
      //   273: putfield isInPlaceholder : Z
      //   276: aload_0
      //   277: iconst_m1
      //   278: putfield resolvedLeftToLeft : I
      //   281: aload_0
      //   282: iconst_m1
      //   283: putfield resolvedLeftToRight : I
      //   286: aload_0
      //   287: iconst_m1
      //   288: putfield resolvedRightToLeft : I
      //   291: aload_0
      //   292: iconst_m1
      //   293: putfield resolvedRightToRight : I
      //   296: aload_0
      //   297: iconst_m1
      //   298: putfield resolveGoneLeftMargin : I
      //   301: aload_0
      //   302: iconst_m1
      //   303: putfield resolveGoneRightMargin : I
      //   306: aload_0
      //   307: ldc 0.5
      //   309: putfield resolvedHorizontalBias : F
      //   312: aload_0
      //   313: new androidx/constraintlayout/solver/widgets/ConstraintWidget
      //   316: dup
      //   317: invokespecial <init> : ()V
      //   320: putfield widget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
      //   323: aload_0
      //   324: iconst_0
      //   325: putfield helped : Z
      //   328: aload_1
      //   329: aload_2
      //   330: getstatic androidx/constraintlayout/widget/R$styleable.ConstraintLayout_Layout : [I
      //   333: invokevirtual obtainStyledAttributes : (Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;
      //   336: astore_1
      //   337: aload_1
      //   338: invokevirtual getIndexCount : ()I
      //   341: istore_3
      //   342: iconst_0
      //   343: istore #4
      //   345: iload #4
      //   347: iload_3
      //   348: if_icmpge -> 2040
      //   351: aload_1
      //   352: iload #4
      //   354: invokevirtual getIndex : (I)I
      //   357: istore #5
      //   359: getstatic androidx/constraintlayout/widget/ConstraintLayout$LayoutParams$Table.map : Landroid/util/SparseIntArray;
      //   362: iload #5
      //   364: invokevirtual get : (I)I
      //   367: tableswitch default -> 584, 0 -> 2034, 1 -> 2020, 2 -> 1984, 3 -> 1967, 4 -> 1919, 5 -> 1902, 6 -> 1885, 7 -> 1868, 8 -> 1832, 9 -> 1796, 10 -> 1760, 11 -> 1724, 12 -> 1688, 13 -> 1652, 14 -> 1616, 15 -> 1580, 16 -> 1544, 17 -> 1508, 18 -> 1472, 19 -> 1436, 20 -> 1400, 21 -> 1383, 22 -> 1366, 23 -> 1349, 24 -> 1332, 25 -> 1315, 26 -> 1298, 27 -> 1281, 28 -> 1264, 29 -> 1247, 30 -> 1230, 31 -> 1198, 32 -> 1166, 33 -> 1124, 34 -> 1082, 35 -> 1061, 36 -> 1019, 37 -> 977, 38 -> 956, 39 -> 2034, 40 -> 2034, 41 -> 2034, 42 -> 2034, 43 -> 584, 44 -> 683, 45 -> 666, 46 -> 649, 47 -> 635, 48 -> 621, 49 -> 604, 50 -> 587
      //   584: goto -> 2034
      //   587: aload_0
      //   588: aload_1
      //   589: iload #5
      //   591: aload_0
      //   592: getfield editorAbsoluteY : I
      //   595: invokevirtual getDimensionPixelOffset : (II)I
      //   598: putfield editorAbsoluteY : I
      //   601: goto -> 2034
      //   604: aload_0
      //   605: aload_1
      //   606: iload #5
      //   608: aload_0
      //   609: getfield editorAbsoluteX : I
      //   612: invokevirtual getDimensionPixelOffset : (II)I
      //   615: putfield editorAbsoluteX : I
      //   618: goto -> 2034
      //   621: aload_0
      //   622: aload_1
      //   623: iload #5
      //   625: iconst_0
      //   626: invokevirtual getInt : (II)I
      //   629: putfield verticalChainStyle : I
      //   632: goto -> 2034
      //   635: aload_0
      //   636: aload_1
      //   637: iload #5
      //   639: iconst_0
      //   640: invokevirtual getInt : (II)I
      //   643: putfield horizontalChainStyle : I
      //   646: goto -> 2034
      //   649: aload_0
      //   650: aload_1
      //   651: iload #5
      //   653: aload_0
      //   654: getfield verticalWeight : F
      //   657: invokevirtual getFloat : (IF)F
      //   660: putfield verticalWeight : F
      //   663: goto -> 2034
      //   666: aload_0
      //   667: aload_1
      //   668: iload #5
      //   670: aload_0
      //   671: getfield horizontalWeight : F
      //   674: invokevirtual getFloat : (IF)F
      //   677: putfield horizontalWeight : F
      //   680: goto -> 2034
      //   683: aload_0
      //   684: aload_1
      //   685: iload #5
      //   687: invokevirtual getString : (I)Ljava/lang/String;
      //   690: putfield dimensionRatio : Ljava/lang/String;
      //   693: aload_0
      //   694: ldc_w NaN
      //   697: putfield dimensionRatioValue : F
      //   700: aload_0
      //   701: iconst_m1
      //   702: putfield dimensionRatioSide : I
      //   705: aload_0
      //   706: getfield dimensionRatio : Ljava/lang/String;
      //   709: astore_2
      //   710: aload_2
      //   711: ifnull -> 2034
      //   714: aload_2
      //   715: invokevirtual length : ()I
      //   718: istore #6
      //   720: aload_0
      //   721: getfield dimensionRatio : Ljava/lang/String;
      //   724: bipush #44
      //   726: invokevirtual indexOf : (I)I
      //   729: istore #5
      //   731: iload #5
      //   733: ifle -> 795
      //   736: iload #5
      //   738: iload #6
      //   740: iconst_1
      //   741: isub
      //   742: if_icmpge -> 795
      //   745: aload_0
      //   746: getfield dimensionRatio : Ljava/lang/String;
      //   749: iconst_0
      //   750: iload #5
      //   752: invokevirtual substring : (II)Ljava/lang/String;
      //   755: astore_2
      //   756: aload_2
      //   757: ldc_w 'W'
      //   760: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
      //   763: ifeq -> 774
      //   766: aload_0
      //   767: iconst_0
      //   768: putfield dimensionRatioSide : I
      //   771: goto -> 789
      //   774: aload_2
      //   775: ldc_w 'H'
      //   778: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
      //   781: ifeq -> 789
      //   784: aload_0
      //   785: iconst_1
      //   786: putfield dimensionRatioSide : I
      //   789: iinc #5, 1
      //   792: goto -> 798
      //   795: iconst_0
      //   796: istore #5
      //   798: aload_0
      //   799: getfield dimensionRatio : Ljava/lang/String;
      //   802: bipush #58
      //   804: invokevirtual indexOf : (I)I
      //   807: istore #7
      //   809: iload #7
      //   811: iflt -> 928
      //   814: iload #7
      //   816: iload #6
      //   818: iconst_1
      //   819: isub
      //   820: if_icmpge -> 928
      //   823: aload_0
      //   824: getfield dimensionRatio : Ljava/lang/String;
      //   827: iload #5
      //   829: iload #7
      //   831: invokevirtual substring : (II)Ljava/lang/String;
      //   834: astore #8
      //   836: aload_0
      //   837: getfield dimensionRatio : Ljava/lang/String;
      //   840: iload #7
      //   842: iconst_1
      //   843: iadd
      //   844: invokevirtual substring : (I)Ljava/lang/String;
      //   847: astore_2
      //   848: aload #8
      //   850: invokevirtual length : ()I
      //   853: ifle -> 2034
      //   856: aload_2
      //   857: invokevirtual length : ()I
      //   860: ifle -> 2034
      //   863: aload #8
      //   865: invokestatic parseFloat : (Ljava/lang/String;)F
      //   868: fstore #9
      //   870: aload_2
      //   871: invokestatic parseFloat : (Ljava/lang/String;)F
      //   874: fstore #10
      //   876: fload #9
      //   878: fconst_0
      //   879: fcmpl
      //   880: ifle -> 2034
      //   883: fload #10
      //   885: fconst_0
      //   886: fcmpl
      //   887: ifle -> 2034
      //   890: aload_0
      //   891: getfield dimensionRatioSide : I
      //   894: iconst_1
      //   895: if_icmpne -> 913
      //   898: aload_0
      //   899: fload #10
      //   901: fload #9
      //   903: fdiv
      //   904: invokestatic abs : (F)F
      //   907: putfield dimensionRatioValue : F
      //   910: goto -> 2034
      //   913: aload_0
      //   914: fload #9
      //   916: fload #10
      //   918: fdiv
      //   919: invokestatic abs : (F)F
      //   922: putfield dimensionRatioValue : F
      //   925: goto -> 2034
      //   928: aload_0
      //   929: getfield dimensionRatio : Ljava/lang/String;
      //   932: iload #5
      //   934: invokevirtual substring : (I)Ljava/lang/String;
      //   937: astore_2
      //   938: aload_2
      //   939: invokevirtual length : ()I
      //   942: ifle -> 2034
      //   945: aload_0
      //   946: aload_2
      //   947: invokestatic parseFloat : (Ljava/lang/String;)F
      //   950: putfield dimensionRatioValue : F
      //   953: goto -> 2034
      //   956: aload_0
      //   957: fconst_0
      //   958: aload_1
      //   959: iload #5
      //   961: aload_0
      //   962: getfield matchConstraintPercentHeight : F
      //   965: invokevirtual getFloat : (IF)F
      //   968: invokestatic max : (FF)F
      //   971: putfield matchConstraintPercentHeight : F
      //   974: goto -> 2034
      //   977: aload_0
      //   978: aload_1
      //   979: iload #5
      //   981: aload_0
      //   982: getfield matchConstraintMaxHeight : I
      //   985: invokevirtual getDimensionPixelSize : (II)I
      //   988: putfield matchConstraintMaxHeight : I
      //   991: goto -> 2034
      //   994: astore_2
      //   995: aload_1
      //   996: iload #5
      //   998: aload_0
      //   999: getfield matchConstraintMaxHeight : I
      //   1002: invokevirtual getInt : (II)I
      //   1005: bipush #-2
      //   1007: if_icmpne -> 2034
      //   1010: aload_0
      //   1011: bipush #-2
      //   1013: putfield matchConstraintMaxHeight : I
      //   1016: goto -> 2034
      //   1019: aload_0
      //   1020: aload_1
      //   1021: iload #5
      //   1023: aload_0
      //   1024: getfield matchConstraintMinHeight : I
      //   1027: invokevirtual getDimensionPixelSize : (II)I
      //   1030: putfield matchConstraintMinHeight : I
      //   1033: goto -> 2034
      //   1036: astore_2
      //   1037: aload_1
      //   1038: iload #5
      //   1040: aload_0
      //   1041: getfield matchConstraintMinHeight : I
      //   1044: invokevirtual getInt : (II)I
      //   1047: bipush #-2
      //   1049: if_icmpne -> 2034
      //   1052: aload_0
      //   1053: bipush #-2
      //   1055: putfield matchConstraintMinHeight : I
      //   1058: goto -> 2034
      //   1061: aload_0
      //   1062: fconst_0
      //   1063: aload_1
      //   1064: iload #5
      //   1066: aload_0
      //   1067: getfield matchConstraintPercentWidth : F
      //   1070: invokevirtual getFloat : (IF)F
      //   1073: invokestatic max : (FF)F
      //   1076: putfield matchConstraintPercentWidth : F
      //   1079: goto -> 2034
      //   1082: aload_0
      //   1083: aload_1
      //   1084: iload #5
      //   1086: aload_0
      //   1087: getfield matchConstraintMaxWidth : I
      //   1090: invokevirtual getDimensionPixelSize : (II)I
      //   1093: putfield matchConstraintMaxWidth : I
      //   1096: goto -> 2034
      //   1099: astore_2
      //   1100: aload_1
      //   1101: iload #5
      //   1103: aload_0
      //   1104: getfield matchConstraintMaxWidth : I
      //   1107: invokevirtual getInt : (II)I
      //   1110: bipush #-2
      //   1112: if_icmpne -> 2034
      //   1115: aload_0
      //   1116: bipush #-2
      //   1118: putfield matchConstraintMaxWidth : I
      //   1121: goto -> 2034
      //   1124: aload_0
      //   1125: aload_1
      //   1126: iload #5
      //   1128: aload_0
      //   1129: getfield matchConstraintMinWidth : I
      //   1132: invokevirtual getDimensionPixelSize : (II)I
      //   1135: putfield matchConstraintMinWidth : I
      //   1138: goto -> 2034
      //   1141: astore_2
      //   1142: aload_1
      //   1143: iload #5
      //   1145: aload_0
      //   1146: getfield matchConstraintMinWidth : I
      //   1149: invokevirtual getInt : (II)I
      //   1152: bipush #-2
      //   1154: if_icmpne -> 2034
      //   1157: aload_0
      //   1158: bipush #-2
      //   1160: putfield matchConstraintMinWidth : I
      //   1163: goto -> 2034
      //   1166: aload_0
      //   1167: aload_1
      //   1168: iload #5
      //   1170: iconst_0
      //   1171: invokevirtual getInt : (II)I
      //   1174: putfield matchConstraintDefaultHeight : I
      //   1177: aload_0
      //   1178: getfield matchConstraintDefaultHeight : I
      //   1181: iconst_1
      //   1182: if_icmpne -> 2034
      //   1185: ldc_w 'ConstraintLayout'
      //   1188: ldc_w 'layout_constraintHeight_default="wrap" is deprecated.\\nUse layout_height="WRAP_CONTENT" and layout_constrainedHeight="true" instead.'
      //   1191: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
      //   1194: pop
      //   1195: goto -> 2034
      //   1198: aload_0
      //   1199: aload_1
      //   1200: iload #5
      //   1202: iconst_0
      //   1203: invokevirtual getInt : (II)I
      //   1206: putfield matchConstraintDefaultWidth : I
      //   1209: aload_0
      //   1210: getfield matchConstraintDefaultWidth : I
      //   1213: iconst_1
      //   1214: if_icmpne -> 2034
      //   1217: ldc_w 'ConstraintLayout'
      //   1220: ldc_w 'layout_constraintWidth_default="wrap" is deprecated.\\nUse layout_width="WRAP_CONTENT" and layout_constrainedWidth="true" instead.'
      //   1223: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
      //   1226: pop
      //   1227: goto -> 2034
      //   1230: aload_0
      //   1231: aload_1
      //   1232: iload #5
      //   1234: aload_0
      //   1235: getfield verticalBias : F
      //   1238: invokevirtual getFloat : (IF)F
      //   1241: putfield verticalBias : F
      //   1244: goto -> 2034
      //   1247: aload_0
      //   1248: aload_1
      //   1249: iload #5
      //   1251: aload_0
      //   1252: getfield horizontalBias : F
      //   1255: invokevirtual getFloat : (IF)F
      //   1258: putfield horizontalBias : F
      //   1261: goto -> 2034
      //   1264: aload_0
      //   1265: aload_1
      //   1266: iload #5
      //   1268: aload_0
      //   1269: getfield constrainedHeight : Z
      //   1272: invokevirtual getBoolean : (IZ)Z
      //   1275: putfield constrainedHeight : Z
      //   1278: goto -> 2034
      //   1281: aload_0
      //   1282: aload_1
      //   1283: iload #5
      //   1285: aload_0
      //   1286: getfield constrainedWidth : Z
      //   1289: invokevirtual getBoolean : (IZ)Z
      //   1292: putfield constrainedWidth : Z
      //   1295: goto -> 2034
      //   1298: aload_0
      //   1299: aload_1
      //   1300: iload #5
      //   1302: aload_0
      //   1303: getfield goneEndMargin : I
      //   1306: invokevirtual getDimensionPixelSize : (II)I
      //   1309: putfield goneEndMargin : I
      //   1312: goto -> 2034
      //   1315: aload_0
      //   1316: aload_1
      //   1317: iload #5
      //   1319: aload_0
      //   1320: getfield goneStartMargin : I
      //   1323: invokevirtual getDimensionPixelSize : (II)I
      //   1326: putfield goneStartMargin : I
      //   1329: goto -> 2034
      //   1332: aload_0
      //   1333: aload_1
      //   1334: iload #5
      //   1336: aload_0
      //   1337: getfield goneBottomMargin : I
      //   1340: invokevirtual getDimensionPixelSize : (II)I
      //   1343: putfield goneBottomMargin : I
      //   1346: goto -> 2034
      //   1349: aload_0
      //   1350: aload_1
      //   1351: iload #5
      //   1353: aload_0
      //   1354: getfield goneRightMargin : I
      //   1357: invokevirtual getDimensionPixelSize : (II)I
      //   1360: putfield goneRightMargin : I
      //   1363: goto -> 2034
      //   1366: aload_0
      //   1367: aload_1
      //   1368: iload #5
      //   1370: aload_0
      //   1371: getfield goneTopMargin : I
      //   1374: invokevirtual getDimensionPixelSize : (II)I
      //   1377: putfield goneTopMargin : I
      //   1380: goto -> 2034
      //   1383: aload_0
      //   1384: aload_1
      //   1385: iload #5
      //   1387: aload_0
      //   1388: getfield goneLeftMargin : I
      //   1391: invokevirtual getDimensionPixelSize : (II)I
      //   1394: putfield goneLeftMargin : I
      //   1397: goto -> 2034
      //   1400: aload_0
      //   1401: aload_1
      //   1402: iload #5
      //   1404: aload_0
      //   1405: getfield endToEnd : I
      //   1408: invokevirtual getResourceId : (II)I
      //   1411: putfield endToEnd : I
      //   1414: aload_0
      //   1415: getfield endToEnd : I
      //   1418: iconst_m1
      //   1419: if_icmpne -> 2034
      //   1422: aload_0
      //   1423: aload_1
      //   1424: iload #5
      //   1426: iconst_m1
      //   1427: invokevirtual getInt : (II)I
      //   1430: putfield endToEnd : I
      //   1433: goto -> 2034
      //   1436: aload_0
      //   1437: aload_1
      //   1438: iload #5
      //   1440: aload_0
      //   1441: getfield endToStart : I
      //   1444: invokevirtual getResourceId : (II)I
      //   1447: putfield endToStart : I
      //   1450: aload_0
      //   1451: getfield endToStart : I
      //   1454: iconst_m1
      //   1455: if_icmpne -> 2034
      //   1458: aload_0
      //   1459: aload_1
      //   1460: iload #5
      //   1462: iconst_m1
      //   1463: invokevirtual getInt : (II)I
      //   1466: putfield endToStart : I
      //   1469: goto -> 2034
      //   1472: aload_0
      //   1473: aload_1
      //   1474: iload #5
      //   1476: aload_0
      //   1477: getfield startToStart : I
      //   1480: invokevirtual getResourceId : (II)I
      //   1483: putfield startToStart : I
      //   1486: aload_0
      //   1487: getfield startToStart : I
      //   1490: iconst_m1
      //   1491: if_icmpne -> 2034
      //   1494: aload_0
      //   1495: aload_1
      //   1496: iload #5
      //   1498: iconst_m1
      //   1499: invokevirtual getInt : (II)I
      //   1502: putfield startToStart : I
      //   1505: goto -> 2034
      //   1508: aload_0
      //   1509: aload_1
      //   1510: iload #5
      //   1512: aload_0
      //   1513: getfield startToEnd : I
      //   1516: invokevirtual getResourceId : (II)I
      //   1519: putfield startToEnd : I
      //   1522: aload_0
      //   1523: getfield startToEnd : I
      //   1526: iconst_m1
      //   1527: if_icmpne -> 2034
      //   1530: aload_0
      //   1531: aload_1
      //   1532: iload #5
      //   1534: iconst_m1
      //   1535: invokevirtual getInt : (II)I
      //   1538: putfield startToEnd : I
      //   1541: goto -> 2034
      //   1544: aload_0
      //   1545: aload_1
      //   1546: iload #5
      //   1548: aload_0
      //   1549: getfield baselineToBaseline : I
      //   1552: invokevirtual getResourceId : (II)I
      //   1555: putfield baselineToBaseline : I
      //   1558: aload_0
      //   1559: getfield baselineToBaseline : I
      //   1562: iconst_m1
      //   1563: if_icmpne -> 2034
      //   1566: aload_0
      //   1567: aload_1
      //   1568: iload #5
      //   1570: iconst_m1
      //   1571: invokevirtual getInt : (II)I
      //   1574: putfield baselineToBaseline : I
      //   1577: goto -> 2034
      //   1580: aload_0
      //   1581: aload_1
      //   1582: iload #5
      //   1584: aload_0
      //   1585: getfield bottomToBottom : I
      //   1588: invokevirtual getResourceId : (II)I
      //   1591: putfield bottomToBottom : I
      //   1594: aload_0
      //   1595: getfield bottomToBottom : I
      //   1598: iconst_m1
      //   1599: if_icmpne -> 2034
      //   1602: aload_0
      //   1603: aload_1
      //   1604: iload #5
      //   1606: iconst_m1
      //   1607: invokevirtual getInt : (II)I
      //   1610: putfield bottomToBottom : I
      //   1613: goto -> 2034
      //   1616: aload_0
      //   1617: aload_1
      //   1618: iload #5
      //   1620: aload_0
      //   1621: getfield bottomToTop : I
      //   1624: invokevirtual getResourceId : (II)I
      //   1627: putfield bottomToTop : I
      //   1630: aload_0
      //   1631: getfield bottomToTop : I
      //   1634: iconst_m1
      //   1635: if_icmpne -> 2034
      //   1638: aload_0
      //   1639: aload_1
      //   1640: iload #5
      //   1642: iconst_m1
      //   1643: invokevirtual getInt : (II)I
      //   1646: putfield bottomToTop : I
      //   1649: goto -> 2034
      //   1652: aload_0
      //   1653: aload_1
      //   1654: iload #5
      //   1656: aload_0
      //   1657: getfield topToBottom : I
      //   1660: invokevirtual getResourceId : (II)I
      //   1663: putfield topToBottom : I
      //   1666: aload_0
      //   1667: getfield topToBottom : I
      //   1670: iconst_m1
      //   1671: if_icmpne -> 2034
      //   1674: aload_0
      //   1675: aload_1
      //   1676: iload #5
      //   1678: iconst_m1
      //   1679: invokevirtual getInt : (II)I
      //   1682: putfield topToBottom : I
      //   1685: goto -> 2034
      //   1688: aload_0
      //   1689: aload_1
      //   1690: iload #5
      //   1692: aload_0
      //   1693: getfield topToTop : I
      //   1696: invokevirtual getResourceId : (II)I
      //   1699: putfield topToTop : I
      //   1702: aload_0
      //   1703: getfield topToTop : I
      //   1706: iconst_m1
      //   1707: if_icmpne -> 2034
      //   1710: aload_0
      //   1711: aload_1
      //   1712: iload #5
      //   1714: iconst_m1
      //   1715: invokevirtual getInt : (II)I
      //   1718: putfield topToTop : I
      //   1721: goto -> 2034
      //   1724: aload_0
      //   1725: aload_1
      //   1726: iload #5
      //   1728: aload_0
      //   1729: getfield rightToRight : I
      //   1732: invokevirtual getResourceId : (II)I
      //   1735: putfield rightToRight : I
      //   1738: aload_0
      //   1739: getfield rightToRight : I
      //   1742: iconst_m1
      //   1743: if_icmpne -> 2034
      //   1746: aload_0
      //   1747: aload_1
      //   1748: iload #5
      //   1750: iconst_m1
      //   1751: invokevirtual getInt : (II)I
      //   1754: putfield rightToRight : I
      //   1757: goto -> 2034
      //   1760: aload_0
      //   1761: aload_1
      //   1762: iload #5
      //   1764: aload_0
      //   1765: getfield rightToLeft : I
      //   1768: invokevirtual getResourceId : (II)I
      //   1771: putfield rightToLeft : I
      //   1774: aload_0
      //   1775: getfield rightToLeft : I
      //   1778: iconst_m1
      //   1779: if_icmpne -> 2034
      //   1782: aload_0
      //   1783: aload_1
      //   1784: iload #5
      //   1786: iconst_m1
      //   1787: invokevirtual getInt : (II)I
      //   1790: putfield rightToLeft : I
      //   1793: goto -> 2034
      //   1796: aload_0
      //   1797: aload_1
      //   1798: iload #5
      //   1800: aload_0
      //   1801: getfield leftToRight : I
      //   1804: invokevirtual getResourceId : (II)I
      //   1807: putfield leftToRight : I
      //   1810: aload_0
      //   1811: getfield leftToRight : I
      //   1814: iconst_m1
      //   1815: if_icmpne -> 2034
      //   1818: aload_0
      //   1819: aload_1
      //   1820: iload #5
      //   1822: iconst_m1
      //   1823: invokevirtual getInt : (II)I
      //   1826: putfield leftToRight : I
      //   1829: goto -> 2034
      //   1832: aload_0
      //   1833: aload_1
      //   1834: iload #5
      //   1836: aload_0
      //   1837: getfield leftToLeft : I
      //   1840: invokevirtual getResourceId : (II)I
      //   1843: putfield leftToLeft : I
      //   1846: aload_0
      //   1847: getfield leftToLeft : I
      //   1850: iconst_m1
      //   1851: if_icmpne -> 2034
      //   1854: aload_0
      //   1855: aload_1
      //   1856: iload #5
      //   1858: iconst_m1
      //   1859: invokevirtual getInt : (II)I
      //   1862: putfield leftToLeft : I
      //   1865: goto -> 2034
      //   1868: aload_0
      //   1869: aload_1
      //   1870: iload #5
      //   1872: aload_0
      //   1873: getfield guidePercent : F
      //   1876: invokevirtual getFloat : (IF)F
      //   1879: putfield guidePercent : F
      //   1882: goto -> 2034
      //   1885: aload_0
      //   1886: aload_1
      //   1887: iload #5
      //   1889: aload_0
      //   1890: getfield guideEnd : I
      //   1893: invokevirtual getDimensionPixelOffset : (II)I
      //   1896: putfield guideEnd : I
      //   1899: goto -> 2034
      //   1902: aload_0
      //   1903: aload_1
      //   1904: iload #5
      //   1906: aload_0
      //   1907: getfield guideBegin : I
      //   1910: invokevirtual getDimensionPixelOffset : (II)I
      //   1913: putfield guideBegin : I
      //   1916: goto -> 2034
      //   1919: aload_0
      //   1920: aload_1
      //   1921: iload #5
      //   1923: aload_0
      //   1924: getfield circleAngle : F
      //   1927: invokevirtual getFloat : (IF)F
      //   1930: ldc_w 360.0
      //   1933: frem
      //   1934: putfield circleAngle : F
      //   1937: aload_0
      //   1938: getfield circleAngle : F
      //   1941: fstore #9
      //   1943: fload #9
      //   1945: fconst_0
      //   1946: fcmpg
      //   1947: ifge -> 2034
      //   1950: aload_0
      //   1951: ldc_w 360.0
      //   1954: fload #9
      //   1956: fsub
      //   1957: ldc_w 360.0
      //   1960: frem
      //   1961: putfield circleAngle : F
      //   1964: goto -> 2034
      //   1967: aload_0
      //   1968: aload_1
      //   1969: iload #5
      //   1971: aload_0
      //   1972: getfield circleRadius : I
      //   1975: invokevirtual getDimensionPixelSize : (II)I
      //   1978: putfield circleRadius : I
      //   1981: goto -> 2034
      //   1984: aload_0
      //   1985: aload_1
      //   1986: iload #5
      //   1988: aload_0
      //   1989: getfield circleConstraint : I
      //   1992: invokevirtual getResourceId : (II)I
      //   1995: putfield circleConstraint : I
      //   1998: aload_0
      //   1999: getfield circleConstraint : I
      //   2002: iconst_m1
      //   2003: if_icmpne -> 2034
      //   2006: aload_0
      //   2007: aload_1
      //   2008: iload #5
      //   2010: iconst_m1
      //   2011: invokevirtual getInt : (II)I
      //   2014: putfield circleConstraint : I
      //   2017: goto -> 2034
      //   2020: aload_0
      //   2021: aload_1
      //   2022: iload #5
      //   2024: aload_0
      //   2025: getfield orientation : I
      //   2028: invokevirtual getInt : (II)I
      //   2031: putfield orientation : I
      //   2034: iinc #4, 1
      //   2037: goto -> 345
      //   2040: aload_1
      //   2041: invokevirtual recycle : ()V
      //   2044: aload_0
      //   2045: invokevirtual validate : ()V
      //   2048: return
      //   2049: astore_2
      //   2050: goto -> 2034
      // Exception table:
      //   from	to	target	type
      //   863	876	2049	java/lang/NumberFormatException
      //   890	910	2049	java/lang/NumberFormatException
      //   913	925	2049	java/lang/NumberFormatException
      //   945	953	2049	java/lang/NumberFormatException
      //   977	991	994	java/lang/Exception
      //   1019	1033	1036	java/lang/Exception
      //   1082	1096	1099	java/lang/Exception
      //   1124	1138	1141	java/lang/Exception
    }
    
    public LayoutParams(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public LayoutParams(LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
      this.guideBegin = param1LayoutParams.guideBegin;
      this.guideEnd = param1LayoutParams.guideEnd;
      this.guidePercent = param1LayoutParams.guidePercent;
      this.leftToLeft = param1LayoutParams.leftToLeft;
      this.leftToRight = param1LayoutParams.leftToRight;
      this.rightToLeft = param1LayoutParams.rightToLeft;
      this.rightToRight = param1LayoutParams.rightToRight;
      this.topToTop = param1LayoutParams.topToTop;
      this.topToBottom = param1LayoutParams.topToBottom;
      this.bottomToTop = param1LayoutParams.bottomToTop;
      this.bottomToBottom = param1LayoutParams.bottomToBottom;
      this.baselineToBaseline = param1LayoutParams.baselineToBaseline;
      this.circleConstraint = param1LayoutParams.circleConstraint;
      this.circleRadius = param1LayoutParams.circleRadius;
      this.circleAngle = param1LayoutParams.circleAngle;
      this.startToEnd = param1LayoutParams.startToEnd;
      this.startToStart = param1LayoutParams.startToStart;
      this.endToStart = param1LayoutParams.endToStart;
      this.endToEnd = param1LayoutParams.endToEnd;
      this.goneLeftMargin = param1LayoutParams.goneLeftMargin;
      this.goneTopMargin = param1LayoutParams.goneTopMargin;
      this.goneRightMargin = param1LayoutParams.goneRightMargin;
      this.goneBottomMargin = param1LayoutParams.goneBottomMargin;
      this.goneStartMargin = param1LayoutParams.goneStartMargin;
      this.goneEndMargin = param1LayoutParams.goneEndMargin;
      this.horizontalBias = param1LayoutParams.horizontalBias;
      this.verticalBias = param1LayoutParams.verticalBias;
      this.dimensionRatio = param1LayoutParams.dimensionRatio;
      this.dimensionRatioValue = param1LayoutParams.dimensionRatioValue;
      this.dimensionRatioSide = param1LayoutParams.dimensionRatioSide;
      this.horizontalWeight = param1LayoutParams.horizontalWeight;
      this.verticalWeight = param1LayoutParams.verticalWeight;
      this.horizontalChainStyle = param1LayoutParams.horizontalChainStyle;
      this.verticalChainStyle = param1LayoutParams.verticalChainStyle;
      this.constrainedWidth = param1LayoutParams.constrainedWidth;
      this.constrainedHeight = param1LayoutParams.constrainedHeight;
      this.matchConstraintDefaultWidth = param1LayoutParams.matchConstraintDefaultWidth;
      this.matchConstraintDefaultHeight = param1LayoutParams.matchConstraintDefaultHeight;
      this.matchConstraintMinWidth = param1LayoutParams.matchConstraintMinWidth;
      this.matchConstraintMaxWidth = param1LayoutParams.matchConstraintMaxWidth;
      this.matchConstraintMinHeight = param1LayoutParams.matchConstraintMinHeight;
      this.matchConstraintMaxHeight = param1LayoutParams.matchConstraintMaxHeight;
      this.matchConstraintPercentWidth = param1LayoutParams.matchConstraintPercentWidth;
      this.matchConstraintPercentHeight = param1LayoutParams.matchConstraintPercentHeight;
      this.editorAbsoluteX = param1LayoutParams.editorAbsoluteX;
      this.editorAbsoluteY = param1LayoutParams.editorAbsoluteY;
      this.orientation = param1LayoutParams.orientation;
      this.horizontalDimensionFixed = param1LayoutParams.horizontalDimensionFixed;
      this.verticalDimensionFixed = param1LayoutParams.verticalDimensionFixed;
      this.needsBaseline = param1LayoutParams.needsBaseline;
      this.isGuideline = param1LayoutParams.isGuideline;
      this.resolvedLeftToLeft = param1LayoutParams.resolvedLeftToLeft;
      this.resolvedLeftToRight = param1LayoutParams.resolvedLeftToRight;
      this.resolvedRightToLeft = param1LayoutParams.resolvedRightToLeft;
      this.resolvedRightToRight = param1LayoutParams.resolvedRightToRight;
      this.resolveGoneLeftMargin = param1LayoutParams.resolveGoneLeftMargin;
      this.resolveGoneRightMargin = param1LayoutParams.resolveGoneRightMargin;
      this.resolvedHorizontalBias = param1LayoutParams.resolvedHorizontalBias;
      this.widget = param1LayoutParams.widget;
    }
    
    public void reset() {
      ConstraintWidget constraintWidget = this.widget;
      if (constraintWidget != null)
        constraintWidget.reset(); 
    }
    
    public void resolveLayoutDirection(int param1Int) {
      // Byte code:
      //   0: aload_0
      //   1: getfield leftMargin : I
      //   4: istore_2
      //   5: aload_0
      //   6: getfield rightMargin : I
      //   9: istore_3
      //   10: aload_0
      //   11: iload_1
      //   12: invokespecial resolveLayoutDirection : (I)V
      //   15: aload_0
      //   16: iconst_m1
      //   17: putfield resolvedRightToLeft : I
      //   20: aload_0
      //   21: iconst_m1
      //   22: putfield resolvedRightToRight : I
      //   25: aload_0
      //   26: iconst_m1
      //   27: putfield resolvedLeftToLeft : I
      //   30: aload_0
      //   31: iconst_m1
      //   32: putfield resolvedLeftToRight : I
      //   35: aload_0
      //   36: iconst_m1
      //   37: putfield resolveGoneLeftMargin : I
      //   40: aload_0
      //   41: iconst_m1
      //   42: putfield resolveGoneRightMargin : I
      //   45: aload_0
      //   46: aload_0
      //   47: getfield goneLeftMargin : I
      //   50: putfield resolveGoneLeftMargin : I
      //   53: aload_0
      //   54: aload_0
      //   55: getfield goneRightMargin : I
      //   58: putfield resolveGoneRightMargin : I
      //   61: aload_0
      //   62: aload_0
      //   63: getfield horizontalBias : F
      //   66: putfield resolvedHorizontalBias : F
      //   69: aload_0
      //   70: aload_0
      //   71: getfield guideBegin : I
      //   74: putfield resolvedGuideBegin : I
      //   77: aload_0
      //   78: aload_0
      //   79: getfield guideEnd : I
      //   82: putfield resolvedGuideEnd : I
      //   85: aload_0
      //   86: aload_0
      //   87: getfield guidePercent : F
      //   90: putfield resolvedGuidePercent : F
      //   93: aload_0
      //   94: invokevirtual getLayoutDirection : ()I
      //   97: istore_1
      //   98: iconst_0
      //   99: istore #4
      //   101: iconst_1
      //   102: iload_1
      //   103: if_icmpne -> 111
      //   106: iconst_1
      //   107: istore_1
      //   108: goto -> 113
      //   111: iconst_0
      //   112: istore_1
      //   113: iload_1
      //   114: ifeq -> 359
      //   117: aload_0
      //   118: getfield startToEnd : I
      //   121: istore_1
      //   122: iload_1
      //   123: iconst_m1
      //   124: if_icmpeq -> 137
      //   127: aload_0
      //   128: iload_1
      //   129: putfield resolvedRightToLeft : I
      //   132: iconst_1
      //   133: istore_1
      //   134: goto -> 161
      //   137: aload_0
      //   138: getfield startToStart : I
      //   141: istore #5
      //   143: iload #4
      //   145: istore_1
      //   146: iload #5
      //   148: iconst_m1
      //   149: if_icmpeq -> 161
      //   152: aload_0
      //   153: iload #5
      //   155: putfield resolvedRightToRight : I
      //   158: goto -> 132
      //   161: aload_0
      //   162: getfield endToStart : I
      //   165: istore #4
      //   167: iload #4
      //   169: iconst_m1
      //   170: if_icmpeq -> 181
      //   173: aload_0
      //   174: iload #4
      //   176: putfield resolvedLeftToRight : I
      //   179: iconst_1
      //   180: istore_1
      //   181: aload_0
      //   182: getfield endToEnd : I
      //   185: istore #4
      //   187: iload #4
      //   189: iconst_m1
      //   190: if_icmpeq -> 201
      //   193: aload_0
      //   194: iload #4
      //   196: putfield resolvedLeftToLeft : I
      //   199: iconst_1
      //   200: istore_1
      //   201: aload_0
      //   202: getfield goneStartMargin : I
      //   205: istore #4
      //   207: iload #4
      //   209: iconst_m1
      //   210: if_icmpeq -> 219
      //   213: aload_0
      //   214: iload #4
      //   216: putfield resolveGoneRightMargin : I
      //   219: aload_0
      //   220: getfield goneEndMargin : I
      //   223: istore #4
      //   225: iload #4
      //   227: iconst_m1
      //   228: if_icmpeq -> 237
      //   231: aload_0
      //   232: iload #4
      //   234: putfield resolveGoneLeftMargin : I
      //   237: iload_1
      //   238: ifeq -> 251
      //   241: aload_0
      //   242: fconst_1
      //   243: aload_0
      //   244: getfield horizontalBias : F
      //   247: fsub
      //   248: putfield resolvedHorizontalBias : F
      //   251: aload_0
      //   252: getfield isGuideline : Z
      //   255: ifeq -> 449
      //   258: aload_0
      //   259: getfield orientation : I
      //   262: iconst_1
      //   263: if_icmpne -> 449
      //   266: aload_0
      //   267: getfield guidePercent : F
      //   270: fstore #6
      //   272: fload #6
      //   274: ldc -1.0
      //   276: fcmpl
      //   277: ifeq -> 301
      //   280: aload_0
      //   281: fconst_1
      //   282: fload #6
      //   284: fsub
      //   285: putfield resolvedGuidePercent : F
      //   288: aload_0
      //   289: iconst_m1
      //   290: putfield resolvedGuideBegin : I
      //   293: aload_0
      //   294: iconst_m1
      //   295: putfield resolvedGuideEnd : I
      //   298: goto -> 449
      //   301: aload_0
      //   302: getfield guideBegin : I
      //   305: istore_1
      //   306: iload_1
      //   307: iconst_m1
      //   308: if_icmpeq -> 330
      //   311: aload_0
      //   312: iload_1
      //   313: putfield resolvedGuideEnd : I
      //   316: aload_0
      //   317: iconst_m1
      //   318: putfield resolvedGuideBegin : I
      //   321: aload_0
      //   322: ldc -1.0
      //   324: putfield resolvedGuidePercent : F
      //   327: goto -> 449
      //   330: aload_0
      //   331: getfield guideEnd : I
      //   334: istore_1
      //   335: iload_1
      //   336: iconst_m1
      //   337: if_icmpeq -> 449
      //   340: aload_0
      //   341: iload_1
      //   342: putfield resolvedGuideBegin : I
      //   345: aload_0
      //   346: iconst_m1
      //   347: putfield resolvedGuideEnd : I
      //   350: aload_0
      //   351: ldc -1.0
      //   353: putfield resolvedGuidePercent : F
      //   356: goto -> 449
      //   359: aload_0
      //   360: getfield startToEnd : I
      //   363: istore_1
      //   364: iload_1
      //   365: iconst_m1
      //   366: if_icmpeq -> 374
      //   369: aload_0
      //   370: iload_1
      //   371: putfield resolvedLeftToRight : I
      //   374: aload_0
      //   375: getfield startToStart : I
      //   378: istore_1
      //   379: iload_1
      //   380: iconst_m1
      //   381: if_icmpeq -> 389
      //   384: aload_0
      //   385: iload_1
      //   386: putfield resolvedLeftToLeft : I
      //   389: aload_0
      //   390: getfield endToStart : I
      //   393: istore_1
      //   394: iload_1
      //   395: iconst_m1
      //   396: if_icmpeq -> 404
      //   399: aload_0
      //   400: iload_1
      //   401: putfield resolvedRightToLeft : I
      //   404: aload_0
      //   405: getfield endToEnd : I
      //   408: istore_1
      //   409: iload_1
      //   410: iconst_m1
      //   411: if_icmpeq -> 419
      //   414: aload_0
      //   415: iload_1
      //   416: putfield resolvedRightToRight : I
      //   419: aload_0
      //   420: getfield goneStartMargin : I
      //   423: istore_1
      //   424: iload_1
      //   425: iconst_m1
      //   426: if_icmpeq -> 434
      //   429: aload_0
      //   430: iload_1
      //   431: putfield resolveGoneLeftMargin : I
      //   434: aload_0
      //   435: getfield goneEndMargin : I
      //   438: istore_1
      //   439: iload_1
      //   440: iconst_m1
      //   441: if_icmpeq -> 449
      //   444: aload_0
      //   445: iload_1
      //   446: putfield resolveGoneRightMargin : I
      //   449: aload_0
      //   450: getfield endToStart : I
      //   453: iconst_m1
      //   454: if_icmpne -> 611
      //   457: aload_0
      //   458: getfield endToEnd : I
      //   461: iconst_m1
      //   462: if_icmpne -> 611
      //   465: aload_0
      //   466: getfield startToStart : I
      //   469: iconst_m1
      //   470: if_icmpne -> 611
      //   473: aload_0
      //   474: getfield startToEnd : I
      //   477: iconst_m1
      //   478: if_icmpne -> 611
      //   481: aload_0
      //   482: getfield rightToLeft : I
      //   485: istore_1
      //   486: iload_1
      //   487: iconst_m1
      //   488: if_icmpeq -> 515
      //   491: aload_0
      //   492: iload_1
      //   493: putfield resolvedRightToLeft : I
      //   496: aload_0
      //   497: getfield rightMargin : I
      //   500: ifgt -> 546
      //   503: iload_3
      //   504: ifle -> 546
      //   507: aload_0
      //   508: iload_3
      //   509: putfield rightMargin : I
      //   512: goto -> 546
      //   515: aload_0
      //   516: getfield rightToRight : I
      //   519: istore_1
      //   520: iload_1
      //   521: iconst_m1
      //   522: if_icmpeq -> 546
      //   525: aload_0
      //   526: iload_1
      //   527: putfield resolvedRightToRight : I
      //   530: aload_0
      //   531: getfield rightMargin : I
      //   534: ifgt -> 546
      //   537: iload_3
      //   538: ifle -> 546
      //   541: aload_0
      //   542: iload_3
      //   543: putfield rightMargin : I
      //   546: aload_0
      //   547: getfield leftToLeft : I
      //   550: istore_1
      //   551: iload_1
      //   552: iconst_m1
      //   553: if_icmpeq -> 580
      //   556: aload_0
      //   557: iload_1
      //   558: putfield resolvedLeftToLeft : I
      //   561: aload_0
      //   562: getfield leftMargin : I
      //   565: ifgt -> 611
      //   568: iload_2
      //   569: ifle -> 611
      //   572: aload_0
      //   573: iload_2
      //   574: putfield leftMargin : I
      //   577: goto -> 611
      //   580: aload_0
      //   581: getfield leftToRight : I
      //   584: istore_1
      //   585: iload_1
      //   586: iconst_m1
      //   587: if_icmpeq -> 611
      //   590: aload_0
      //   591: iload_1
      //   592: putfield resolvedLeftToRight : I
      //   595: aload_0
      //   596: getfield leftMargin : I
      //   599: ifgt -> 611
      //   602: iload_2
      //   603: ifle -> 611
      //   606: aload_0
      //   607: iload_2
      //   608: putfield leftMargin : I
      //   611: return
    }
    
    public void validate() {
      this.isGuideline = false;
      this.horizontalDimensionFixed = true;
      this.verticalDimensionFixed = true;
      if (this.width == -2 && this.constrainedWidth) {
        this.horizontalDimensionFixed = false;
        this.matchConstraintDefaultWidth = 1;
      } 
      if (this.height == -2 && this.constrainedHeight) {
        this.verticalDimensionFixed = false;
        this.matchConstraintDefaultHeight = 1;
      } 
      if (this.width == 0 || this.width == -1) {
        this.horizontalDimensionFixed = false;
        if (this.width == 0 && this.matchConstraintDefaultWidth == 1) {
          this.width = -2;
          this.constrainedWidth = true;
        } 
      } 
      if (this.height == 0 || this.height == -1) {
        this.verticalDimensionFixed = false;
        if (this.height == 0 && this.matchConstraintDefaultHeight == 1) {
          this.height = -2;
          this.constrainedHeight = true;
        } 
      } 
      if (this.guidePercent != -1.0F || this.guideBegin != -1 || this.guideEnd != -1) {
        this.isGuideline = true;
        this.horizontalDimensionFixed = true;
        this.verticalDimensionFixed = true;
        if (!(this.widget instanceof Guideline))
          this.widget = (ConstraintWidget)new Guideline(); 
        ((Guideline)this.widget).setOrientation(this.orientation);
      } 
    }
    
    private static class Table {
      public static final int ANDROID_ORIENTATION = 1;
      
      public static final int LAYOUT_CONSTRAINED_HEIGHT = 28;
      
      public static final int LAYOUT_CONSTRAINED_WIDTH = 27;
      
      public static final int LAYOUT_CONSTRAINT_BASELINE_CREATOR = 43;
      
      public static final int LAYOUT_CONSTRAINT_BASELINE_TO_BASELINE_OF = 16;
      
      public static final int LAYOUT_CONSTRAINT_BOTTOM_CREATOR = 42;
      
      public static final int LAYOUT_CONSTRAINT_BOTTOM_TO_BOTTOM_OF = 15;
      
      public static final int LAYOUT_CONSTRAINT_BOTTOM_TO_TOP_OF = 14;
      
      public static final int LAYOUT_CONSTRAINT_CIRCLE = 2;
      
      public static final int LAYOUT_CONSTRAINT_CIRCLE_ANGLE = 4;
      
      public static final int LAYOUT_CONSTRAINT_CIRCLE_RADIUS = 3;
      
      public static final int LAYOUT_CONSTRAINT_DIMENSION_RATIO = 44;
      
      public static final int LAYOUT_CONSTRAINT_END_TO_END_OF = 20;
      
      public static final int LAYOUT_CONSTRAINT_END_TO_START_OF = 19;
      
      public static final int LAYOUT_CONSTRAINT_GUIDE_BEGIN = 5;
      
      public static final int LAYOUT_CONSTRAINT_GUIDE_END = 6;
      
      public static final int LAYOUT_CONSTRAINT_GUIDE_PERCENT = 7;
      
      public static final int LAYOUT_CONSTRAINT_HEIGHT_DEFAULT = 32;
      
      public static final int LAYOUT_CONSTRAINT_HEIGHT_MAX = 37;
      
      public static final int LAYOUT_CONSTRAINT_HEIGHT_MIN = 36;
      
      public static final int LAYOUT_CONSTRAINT_HEIGHT_PERCENT = 38;
      
      public static final int LAYOUT_CONSTRAINT_HORIZONTAL_BIAS = 29;
      
      public static final int LAYOUT_CONSTRAINT_HORIZONTAL_CHAINSTYLE = 47;
      
      public static final int LAYOUT_CONSTRAINT_HORIZONTAL_WEIGHT = 45;
      
      public static final int LAYOUT_CONSTRAINT_LEFT_CREATOR = 39;
      
      public static final int LAYOUT_CONSTRAINT_LEFT_TO_LEFT_OF = 8;
      
      public static final int LAYOUT_CONSTRAINT_LEFT_TO_RIGHT_OF = 9;
      
      public static final int LAYOUT_CONSTRAINT_RIGHT_CREATOR = 41;
      
      public static final int LAYOUT_CONSTRAINT_RIGHT_TO_LEFT_OF = 10;
      
      public static final int LAYOUT_CONSTRAINT_RIGHT_TO_RIGHT_OF = 11;
      
      public static final int LAYOUT_CONSTRAINT_START_TO_END_OF = 17;
      
      public static final int LAYOUT_CONSTRAINT_START_TO_START_OF = 18;
      
      public static final int LAYOUT_CONSTRAINT_TOP_CREATOR = 40;
      
      public static final int LAYOUT_CONSTRAINT_TOP_TO_BOTTOM_OF = 13;
      
      public static final int LAYOUT_CONSTRAINT_TOP_TO_TOP_OF = 12;
      
      public static final int LAYOUT_CONSTRAINT_VERTICAL_BIAS = 30;
      
      public static final int LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE = 48;
      
      public static final int LAYOUT_CONSTRAINT_VERTICAL_WEIGHT = 46;
      
      public static final int LAYOUT_CONSTRAINT_WIDTH_DEFAULT = 31;
      
      public static final int LAYOUT_CONSTRAINT_WIDTH_MAX = 34;
      
      public static final int LAYOUT_CONSTRAINT_WIDTH_MIN = 33;
      
      public static final int LAYOUT_CONSTRAINT_WIDTH_PERCENT = 35;
      
      public static final int LAYOUT_EDITOR_ABSOLUTEX = 49;
      
      public static final int LAYOUT_EDITOR_ABSOLUTEY = 50;
      
      public static final int LAYOUT_GONE_MARGIN_BOTTOM = 24;
      
      public static final int LAYOUT_GONE_MARGIN_END = 26;
      
      public static final int LAYOUT_GONE_MARGIN_LEFT = 21;
      
      public static final int LAYOUT_GONE_MARGIN_RIGHT = 23;
      
      public static final int LAYOUT_GONE_MARGIN_START = 25;
      
      public static final int LAYOUT_GONE_MARGIN_TOP = 22;
      
      public static final int UNUSED = 0;
      
      public static final SparseIntArray map = new SparseIntArray();
      
      static {
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintLeft_toLeftOf, 8);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintLeft_toRightOf, 9);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintRight_toLeftOf, 10);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintRight_toRightOf, 11);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintTop_toTopOf, 12);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintTop_toBottomOf, 13);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintBottom_toTopOf, 14);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintBottom_toBottomOf, 15);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintBaseline_toBaselineOf, 16);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintCircle, 2);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintCircleRadius, 3);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintCircleAngle, 4);
        map.append(R.styleable.ConstraintLayout_Layout_layout_editor_absoluteX, 49);
        map.append(R.styleable.ConstraintLayout_Layout_layout_editor_absoluteY, 50);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintGuide_begin, 5);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintGuide_end, 6);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintGuide_percent, 7);
        map.append(R.styleable.ConstraintLayout_Layout_android_orientation, 1);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintStart_toEndOf, 17);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintStart_toStartOf, 18);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintEnd_toStartOf, 19);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintEnd_toEndOf, 20);
        map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginLeft, 21);
        map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginTop, 22);
        map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginRight, 23);
        map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginBottom, 24);
        map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginStart, 25);
        map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginEnd, 26);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHorizontal_bias, 29);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintVertical_bias, 30);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintDimensionRatio, 44);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHorizontal_weight, 45);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintVertical_weight, 46);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHorizontal_chainStyle, 47);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintVertical_chainStyle, 48);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constrainedWidth, 27);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constrainedHeight, 28);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintWidth_default, 31);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHeight_default, 32);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintWidth_min, 33);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintWidth_max, 34);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintWidth_percent, 35);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHeight_min, 36);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHeight_max, 37);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHeight_percent, 38);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintLeft_creator, 39);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintTop_creator, 40);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintRight_creator, 41);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintBottom_creator, 42);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintBaseline_creator, 43);
      }
    }
  }
  
  private static class Table {
    public static final int ANDROID_ORIENTATION = 1;
    
    public static final int LAYOUT_CONSTRAINED_HEIGHT = 28;
    
    public static final int LAYOUT_CONSTRAINED_WIDTH = 27;
    
    public static final int LAYOUT_CONSTRAINT_BASELINE_CREATOR = 43;
    
    public static final int LAYOUT_CONSTRAINT_BASELINE_TO_BASELINE_OF = 16;
    
    public static final int LAYOUT_CONSTRAINT_BOTTOM_CREATOR = 42;
    
    public static final int LAYOUT_CONSTRAINT_BOTTOM_TO_BOTTOM_OF = 15;
    
    public static final int LAYOUT_CONSTRAINT_BOTTOM_TO_TOP_OF = 14;
    
    public static final int LAYOUT_CONSTRAINT_CIRCLE = 2;
    
    public static final int LAYOUT_CONSTRAINT_CIRCLE_ANGLE = 4;
    
    public static final int LAYOUT_CONSTRAINT_CIRCLE_RADIUS = 3;
    
    public static final int LAYOUT_CONSTRAINT_DIMENSION_RATIO = 44;
    
    public static final int LAYOUT_CONSTRAINT_END_TO_END_OF = 20;
    
    public static final int LAYOUT_CONSTRAINT_END_TO_START_OF = 19;
    
    public static final int LAYOUT_CONSTRAINT_GUIDE_BEGIN = 5;
    
    public static final int LAYOUT_CONSTRAINT_GUIDE_END = 6;
    
    public static final int LAYOUT_CONSTRAINT_GUIDE_PERCENT = 7;
    
    public static final int LAYOUT_CONSTRAINT_HEIGHT_DEFAULT = 32;
    
    public static final int LAYOUT_CONSTRAINT_HEIGHT_MAX = 37;
    
    public static final int LAYOUT_CONSTRAINT_HEIGHT_MIN = 36;
    
    public static final int LAYOUT_CONSTRAINT_HEIGHT_PERCENT = 38;
    
    public static final int LAYOUT_CONSTRAINT_HORIZONTAL_BIAS = 29;
    
    public static final int LAYOUT_CONSTRAINT_HORIZONTAL_CHAINSTYLE = 47;
    
    public static final int LAYOUT_CONSTRAINT_HORIZONTAL_WEIGHT = 45;
    
    public static final int LAYOUT_CONSTRAINT_LEFT_CREATOR = 39;
    
    public static final int LAYOUT_CONSTRAINT_LEFT_TO_LEFT_OF = 8;
    
    public static final int LAYOUT_CONSTRAINT_LEFT_TO_RIGHT_OF = 9;
    
    public static final int LAYOUT_CONSTRAINT_RIGHT_CREATOR = 41;
    
    public static final int LAYOUT_CONSTRAINT_RIGHT_TO_LEFT_OF = 10;
    
    public static final int LAYOUT_CONSTRAINT_RIGHT_TO_RIGHT_OF = 11;
    
    public static final int LAYOUT_CONSTRAINT_START_TO_END_OF = 17;
    
    public static final int LAYOUT_CONSTRAINT_START_TO_START_OF = 18;
    
    public static final int LAYOUT_CONSTRAINT_TOP_CREATOR = 40;
    
    public static final int LAYOUT_CONSTRAINT_TOP_TO_BOTTOM_OF = 13;
    
    public static final int LAYOUT_CONSTRAINT_TOP_TO_TOP_OF = 12;
    
    public static final int LAYOUT_CONSTRAINT_VERTICAL_BIAS = 30;
    
    public static final int LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE = 48;
    
    public static final int LAYOUT_CONSTRAINT_VERTICAL_WEIGHT = 46;
    
    public static final int LAYOUT_CONSTRAINT_WIDTH_DEFAULT = 31;
    
    public static final int LAYOUT_CONSTRAINT_WIDTH_MAX = 34;
    
    public static final int LAYOUT_CONSTRAINT_WIDTH_MIN = 33;
    
    public static final int LAYOUT_CONSTRAINT_WIDTH_PERCENT = 35;
    
    public static final int LAYOUT_EDITOR_ABSOLUTEX = 49;
    
    public static final int LAYOUT_EDITOR_ABSOLUTEY = 50;
    
    public static final int LAYOUT_GONE_MARGIN_BOTTOM = 24;
    
    public static final int LAYOUT_GONE_MARGIN_END = 26;
    
    public static final int LAYOUT_GONE_MARGIN_LEFT = 21;
    
    public static final int LAYOUT_GONE_MARGIN_RIGHT = 23;
    
    public static final int LAYOUT_GONE_MARGIN_START = 25;
    
    public static final int LAYOUT_GONE_MARGIN_TOP = 22;
    
    public static final int UNUSED = 0;
    
    public static final SparseIntArray map = new SparseIntArray();
    
    static {
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintLeft_toLeftOf, 8);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintLeft_toRightOf, 9);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintRight_toLeftOf, 10);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintRight_toRightOf, 11);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintTop_toTopOf, 12);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintTop_toBottomOf, 13);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintBottom_toTopOf, 14);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintBottom_toBottomOf, 15);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintBaseline_toBaselineOf, 16);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintCircle, 2);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintCircleRadius, 3);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintCircleAngle, 4);
      map.append(R.styleable.ConstraintLayout_Layout_layout_editor_absoluteX, 49);
      map.append(R.styleable.ConstraintLayout_Layout_layout_editor_absoluteY, 50);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintGuide_begin, 5);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintGuide_end, 6);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintGuide_percent, 7);
      map.append(R.styleable.ConstraintLayout_Layout_android_orientation, 1);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintStart_toEndOf, 17);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintStart_toStartOf, 18);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintEnd_toStartOf, 19);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintEnd_toEndOf, 20);
      map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginLeft, 21);
      map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginTop, 22);
      map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginRight, 23);
      map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginBottom, 24);
      map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginStart, 25);
      map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginEnd, 26);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHorizontal_bias, 29);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintVertical_bias, 30);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintDimensionRatio, 44);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHorizontal_weight, 45);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintVertical_weight, 46);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHorizontal_chainStyle, 47);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintVertical_chainStyle, 48);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constrainedWidth, 27);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constrainedHeight, 28);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintWidth_default, 31);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHeight_default, 32);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintWidth_min, 33);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintWidth_max, 34);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintWidth_percent, 35);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHeight_min, 36);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHeight_max, 37);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHeight_percent, 38);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintLeft_creator, 39);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintTop_creator, 40);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintRight_creator, 41);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintBottom_creator, 42);
      map.append(R.styleable.ConstraintLayout_Layout_layout_constraintBaseline_creator, 43);
    }
  }
}


/* Location:              /home/brandon/levelMeter_APK/dex2jar-2.x/dex-tools/build/distributions/dex-tools-2.2-SNAPSHOT/classes-dex2jar.jar!/androidx/constraintlayout/widget/ConstraintLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */